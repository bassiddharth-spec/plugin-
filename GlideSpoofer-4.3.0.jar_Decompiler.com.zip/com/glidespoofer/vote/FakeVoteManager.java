package com.glidespoofer.vote;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.FakePlayer;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.scheduler.BukkitTask;

public class FakeVoteManager {
   private final GlideSpoofer plugin;
   private final RealVoteProvider realVoteProvider;
   private Object autoIncreaseTask;
   private boolean enabled;
   private int votesPerFake;
   private int maxVotesPerFake;
   private boolean randomRangeEnabled;
   private int randomMin;
   private int randomMax;
   private boolean autoIncreaseEnabled;
   private int autoIncreaseInterval;
   private int autoIncreaseAmount;
   private boolean includeRealVotes;

   public FakeVoteManager(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.realVoteProvider = new NoOpRealVoteProvider();
      this.loadConfig();
   }

   public void loadConfig() {
      ConfigurationSection section = this.plugin.getConfigManager().getConfig().getConfigurationSection("fake-votes");
      if (section == null) {
         this.enabled = false;
      } else {
         this.enabled = section.getBoolean("enabled", false);
         this.votesPerFake = section.getInt("votes-per-fake", 10);
         this.maxVotesPerFake = section.getInt("max-votes-per-fake", 300);
         ConfigurationSection random = section.getConfigurationSection("random-range");
         if (random != null) {
            this.randomRangeEnabled = random.getBoolean("enabled", true);
            this.randomMin = random.getInt("min", 5);
            this.randomMax = random.getInt("max", 25);
         }

         ConfigurationSection autoIncrease = section.getConfigurationSection("auto-increase");
         if (autoIncrease != null) {
            this.autoIncreaseEnabled = autoIncrease.getBoolean("enabled", true);
            this.autoIncreaseInterval = autoIncrease.getInt("interval-minutes", 5);
            this.autoIncreaseAmount = autoIncrease.getInt("increase-amount", 1);
         }

         this.includeRealVotes = section.getBoolean("include-real-votes.enabled", false);
      }

   }

   public void start() {
      if (this.enabled) {
         for(FakePlayer fake : this.plugin.getFakePlayerManager().getFakePlayers()) {
            this.initializeFakeVotes(fake);
         }

         if (this.autoIncreaseEnabled && this.autoIncreaseInterval > 0) {
            this.startAutoIncreaseTask();
         }

         this.plugin.getLogger().info("FakeVoteManager started!");
      }

   }

   public void stop() {
      this.cancelTask(this.autoIncreaseTask);
      this.autoIncreaseTask = null;
   }

   private void cancelTask(Object task) {
      if (task != null) {
         try {
            if (task instanceof BukkitTask) {
               ((BukkitTask)task).cancel();
            } else if (task.getClass().getName().contains("ScheduledTask")) {
               task.getClass().getMethod("cancel").invoke(task);
            }
         } catch (Exception var3) {
         }
      }

   }

   public void reload() {
      this.stop();
      this.loadConfig();
      this.start();
   }

   public void initializeFakeVotes(FakePlayer fake) {
      if (this.enabled) {
         int votes;
         if (this.randomRangeEnabled) {
            votes = this.randomMin + (int)(Math.random() * (double)(this.randomMax - this.randomMin + 1));
         } else {
            votes = this.votesPerFake;
         }

         votes = Math.min(votes, this.maxVotesPerFake);
         fake.setFakeVotes(votes);
      }

   }

   private void startAutoIncreaseTask() {
      long interval = (long)this.autoIncreaseInterval * 60L * 20L;
      if (GlideSpoofer.isFolia()) {
         this.autoIncreaseTask = Bukkit.getGlobalRegionScheduler().runAtFixedRate(this.plugin, (task) -> {
            for(FakePlayer fake : this.plugin.getFakePlayerManager().getFakePlayers()) {
               if (fake.getFakeVotes() < this.maxVotesPerFake) {
                  fake.addFakeVotes(this.autoIncreaseAmount);
                  if (fake.getFakeVotes() > this.maxVotesPerFake) {
                     fake.setFakeVotes(this.maxVotesPerFake);
                  }
               }
            }

         }, interval, interval);
      } else {
         this.autoIncreaseTask = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
            for(FakePlayer fake : this.plugin.getFakePlayerManager().getFakePlayers()) {
               if (fake.getFakeVotes() < this.maxVotesPerFake) {
                  fake.addFakeVotes(this.autoIncreaseAmount);
                  if (fake.getFakeVotes() > this.maxVotesPerFake) {
                     fake.setFakeVotes(this.maxVotesPerFake);
                  }
               }
            }

         }, interval, interval);
      }

   }

   public int getFakeVotes(FakePlayer fake) {
      return fake.getFakeVotes();
   }

   public int getTotalFakeVotes() {
      return this.plugin.getFakePlayerManager().getFakePlayers().stream().mapToInt(FakePlayer::getFakeVotes).sum();
   }

   public int getTotalRealVotes() {
      return this.realVoteProvider.getTotalRealVotes();
   }

   public int getTotalVotes() {
      int total = this.getTotalFakeVotes();
      if (this.includeRealVotes) {
         total += this.getTotalRealVotes();
      }

      return total;
   }

   public List<FakePlayer> getTopFakeVoters(int limit) {
      return (List)this.plugin.getFakePlayerManager().getFakePlayers().stream().sorted(Comparator.comparingInt(FakePlayer::getFakeVotes).reversed()).limit((long)limit).collect(Collectors.toList());
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public int getMaxVotesPerFake() {
      return this.maxVotesPerFake;
   }

   public static class NoOpRealVoteProvider implements RealVoteProvider {
      public int getTotalRealVotes() {
         return 0;
      }
   }

   public interface RealVoteProvider {
      int getTotalRealVotes();
   }
}
