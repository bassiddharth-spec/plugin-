package com.glidespoofer.listener;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.FakePlayer;
import com.glidespoofer.fake.FakePlayerInventory;
import com.glidespoofer.fake.FakePlayerManager;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.ItemStack;

public class ItemPickupListener implements Listener {
   private final GlideSpoofer plugin;
   private final FakePlayerManager fakePlayerManager;

   public ItemPickupListener(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.fakePlayerManager = plugin.getFakePlayerManager();
   }

   private boolean isNMSMode() {
      return this.plugin.isUsingNMS();
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerPickupItem(PlayerPickupItemEvent event) {
      if (!this.isNMSMode() && this.fakePlayerManager != null && this.fakePlayerManager.getFakePlayer(event.getPlayer().getName()) != null) {
         event.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onEntityPickupItem(EntityPickupItemEvent event) {
      if (!this.isNMSMode() && this.fakePlayerManager != null) {
         Entity entity = event.getEntity();
         Item item = event.getItem();

         for(FakePlayer fake : this.fakePlayerManager.getFakePlayers()) {
            if (fake.isSpawned() && !fake.isDead()) {
               Location fakeLoc = fake.getLocation();
               if (fakeLoc != null) {
                  double distance = fakeLoc.distance(item.getLocation());
                  if (distance <= (double)1.5F) {
                     ItemStack itemStack = item.getItemStack();
                     FakePlayerInventory inv = fake.getInventory();
                     if (inv.addItem(itemStack)) {
                        event.setCancelled(true);
                        item.remove();
                        inv.syncToEquipment(fake.getEquipment());
                        fakeLoc.getWorld().playSound(fakeLoc, Sound.ENTITY_ITEM_PICKUP, 0.2F, 1.0F);
                        break;
                     }
                  }
               }
            }
         }
      }

   }

   public void checkForNearbyItems() {
      if (!this.isNMSMode() && this.fakePlayerManager != null) {
         for(FakePlayer fake : this.fakePlayerManager.getFakePlayers()) {
            if (fake.isSpawned() && !fake.isDead()) {
               Location fakeLoc = fake.getLocation();
               if (fakeLoc != null && fakeLoc.getWorld() != null) {
                  FakePlayerInventory inv = fake.getInventory();
                  if (!inv.isFull()) {
                     for(Entity entity : fakeLoc.getWorld().getNearbyEntities(fakeLoc, (double)1.5F, (double)1.5F, (double)1.5F)) {
                        if (entity instanceof Item) {
                           Item item = (Item)entity;
                           if (item.getPickupDelay() <= 0) {
                              ItemStack itemStack = item.getItemStack();
                              if (inv.addItem(itemStack)) {
                                 inv.syncToEquipment(fake.getEquipment());
                                 fakeLoc.getWorld().playSound(fakeLoc, Sound.ENTITY_ITEM_PICKUP, 0.2F, 1.0F + (float)(Math.random() * 0.4 - 0.2));
                                 item.remove();
                                 if (inv.isFull()) {
                                    break;
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

   }
}
