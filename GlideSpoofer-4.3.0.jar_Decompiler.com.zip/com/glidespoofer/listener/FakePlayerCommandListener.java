package com.glidespoofer.listener;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.server.TabCompleteEvent;

public class FakePlayerCommandListener implements Listener {
   private final GlideSpoofer plugin;
   private final SimpleFakePlayerManager fakePlayerManager;

   public FakePlayerCommandListener(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.fakePlayerManager = plugin.getSimpleFakePlayerManager();
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
      if (this.fakePlayerManager != null) {
         String message = event.getMessage().toLowerCase();
         String[] parts = message.split(" ");
         if (parts.length >= 2) {
            String command = parts[0].substring(1);
            String targetName = parts[1];
            if (this.fakePlayerManager.hasFakePlayer(targetName)) {
               SimpleFakePlayerManager.FakePlayerData fakeData = this.fakePlayerManager.getFakePlayer(targetName);
               if (fakeData != null) {
                  switch (command) {
                     case "kick":
                        event.setCancelled(true);
                        this.handleKick(event.getPlayer(), fakeData, parts);
                        break;
                     case "ban":
                     case "ban-ip":
                        event.setCancelled(true);
                        this.handleBan(event.getPlayer(), fakeData, parts);
                        break;
                     case "unban":
                     case "unban-ip":
                        event.setCancelled(true);
                        this.handleUnban(event.getPlayer(), fakeData);
                        break;
                     case "mute":
                     case "essentials:mute":
                        event.setCancelled(true);
                        this.handleMute(event.getPlayer(), fakeData, parts);
                        break;
                     case "unmute":
                     case "essentials:unmute":
                        event.setCancelled(true);
                        this.handleUnmute(event.getPlayer(), fakeData);
                        break;
                     case "tp":
                     case "teleport":
                        if (parts.length >= 3) {
                           String destination = parts[2];
                           if (this.fakePlayerManager.hasFakePlayer(destination)) {
                              event.setCancelled(true);
                              this.handleTeleportToFake(event.getPlayer(), destination);
                           }
                        }
                  }
               }
            }
         }
      }

   }

   private void handleKick(Player sender, SimpleFakePlayerManager.FakePlayerData fakeData, String[] parts) {
      String reason = parts.length > 2 ? String.join(" ", (CharSequence[])Arrays.copyOfRange(parts, 2, parts.length)) : "Kicked by " + sender.getName();
      String var10000 = fakeData.getName();
      String kickMessage = "§e" + var10000 + " was kicked by " + sender.getName() + "." + (reason.isEmpty() ? "" : ": " + reason);

      for(Player player : Bukkit.getOnlinePlayers()) {
         player.sendMessage(kickMessage);
      }

      this.fakePlayerManager.despawnFakePlayer(fakeData.getName(), true);
      sender.sendMessage("§aKicked " + fakeData.getName() + " from the server.");
      Logger var8 = this.plugin.getLogger();
      String var10001 = sender.getName();
      var8.info("[FakePlayer] " + var10001 + " kicked fake player: " + fakeData.getName());
   }

   private void handleBan(Player sender, SimpleFakePlayerManager.FakePlayerData fakeData, String[] parts) {
      String reason = parts.length > 2 ? String.join(" ", (CharSequence[])Arrays.copyOfRange(parts, 2, parts.length)) : "Banned by " + sender.getName();
      this.fakePlayerManager.getNMSHandler().setBanned(fakeData.getUuid(), true);
      String var10000 = fakeData.getName();
      String banMessage = "§c" + var10000 + " was banned by " + sender.getName() + "." + (reason.isEmpty() ? "" : ": " + reason);

      for(Player player : Bukkit.getOnlinePlayers()) {
         player.sendMessage(banMessage);
      }

      this.fakePlayerManager.despawnFakePlayer(fakeData.getName(), true);
      sender.sendMessage("§aBanned " + fakeData.getName() + " from the server.");
      Logger var8 = this.plugin.getLogger();
      String var10001 = sender.getName();
      var8.info("[FakePlayer] " + var10001 + " banned fake player: " + fakeData.getName());
   }

   private void handleUnban(Player sender, SimpleFakePlayerManager.FakePlayerData fakeData) {
      this.fakePlayerManager.getNMSHandler().setBanned(fakeData.getUuid(), false);
      sender.sendMessage("§aUnbanned " + fakeData.getName() + ".");
      Logger var10000 = this.plugin.getLogger();
      String var10001 = sender.getName();
      var10000.info("[FakePlayer] " + var10001 + " unbanned fake player: " + fakeData.getName());
   }

   private void handleMute(Player sender, SimpleFakePlayerManager.FakePlayerData fakeData, String[] parts) {
      this.fakePlayerManager.muteFakePlayer(fakeData.getName());
      sender.sendMessage("§aMuted " + fakeData.getName() + ".");
      Logger var10000 = this.plugin.getLogger();
      String var10001 = sender.getName();
      var10000.info("[FakePlayer] " + var10001 + " muted fake player: " + fakeData.getName());
   }

   private void handleUnmute(Player sender, SimpleFakePlayerManager.FakePlayerData fakeData) {
      this.fakePlayerManager.unmuteFakePlayer(fakeData.getName());
      sender.sendMessage("§aUnmuted " + fakeData.getName() + ".");
      Logger var10000 = this.plugin.getLogger();
      String var10001 = sender.getName();
      var10000.info("[FakePlayer] " + var10001 + " unmuted fake player: " + fakeData.getName());
   }

   private void handleTeleportToFake(Player sender, String fakeName) {
      SimpleFakePlayerManager.FakePlayerData fakeData = this.fakePlayerManager.getFakePlayer(fakeName);
      if (fakeData != null && fakeData.getPlayer() != null) {
         sender.teleport(fakeData.getPlayer().getLocation());
         sender.sendMessage("§aTeleported to " + fakeName + ".");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onTabComplete(TabCompleteEvent event) {
      if (this.fakePlayerManager != null) {
         String buffer = event.getBuffer().toLowerCase();
         if (buffer.startsWith("/kick") || buffer.startsWith("/ban") || buffer.startsWith("/unban") || buffer.startsWith("/mute") || buffer.startsWith("/unmute") || buffer.startsWith("/ban-ip") || buffer.startsWith("/unban-ip") || buffer.startsWith("/essentials:kick") || buffer.startsWith("/essentials:ban") || buffer.startsWith("/essentials:mute") || buffer.startsWith("/essentials:unmute") || buffer.startsWith("/lp") || buffer.startsWith("/luckperms") || buffer.startsWith("/tp") || buffer.startsWith("/teleport")) {
            String[] parts = buffer.split(" ");
            if (parts.length >= 2) {
               String lastPart = parts[parts.length - 1];
               List<String> completions = new ArrayList();

               for(SimpleFakePlayerManager.FakePlayerData data : this.fakePlayerManager.getAllFakePlayers()) {
                  if (data.getName().toLowerCase().startsWith(lastPart)) {
                     completions.add(data.getName());
                  }
               }

               for(Player player : Bukkit.getOnlinePlayers()) {
                  if (player.getName().toLowerCase().startsWith(lastPart)) {
                     completions.add(player.getName());
                  }
               }

               event.setCompletions(completions);
            }
         }
      }

   }
}
