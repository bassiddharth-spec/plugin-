package com.glidespoofer.listener;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import java.io.File;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.Plugin;

public class TeleportListener implements Listener {
   private final GlideSpoofer plugin;
   private final ConcurrentHashMap<UUID, Long> fakeTpaCooldowns = new ConcurrentHashMap();
   private static final long TPA_COOLDOWN_MS = 5000L;
   private String tpaSentMessage = "§eRequest sent to {PLAYER}.";

   public TeleportListener(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.initializeEssentials();
   }

   private void initializeEssentials() {
      try {
         Plugin essPlugin = Bukkit.getPluginManager().getPlugin("Essentials");
         if (essPlugin != null && essPlugin.isEnabled()) {
            try {
               File configFolder = essPlugin.getDataFolder();
               File configFile = new File(configFolder, "config.yml");
               if (configFile.exists()) {
                  YamlConfiguration config = YamlConfiguration.loadConfiguration(configFile);
                  this.tpaSentMessage = config.getString("tpaSent", "§eRequest sent to {PLAYER}.");
               }
            } catch (Exception var5) {
            }

            this.plugin.getLogger().fine("Essentials found - TPA to fake players will use Essentials format");
         }
      } catch (Exception var6) {
         this.plugin.getLogger().fine("Could not initialize Essentials for TPA: " + var6.getMessage());
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
      String message = event.getMessage().toLowerCase();
      Player sender = event.getPlayer();
      if (message.startsWith("/tpa") || message.startsWith("/etpa") || message.startsWith("/tpask") || message.startsWith("/call")) {
         String[] args = message.split(" ");
         if (args.length >= 2) {
            String targetName = args[1];
            SimpleFakePlayerManager fakePlayerManager = this.plugin.getSimpleFakePlayerManager();
            if (fakePlayerManager != null) {
               SimpleFakePlayerManager.FakePlayerData fakeData = fakePlayerManager.getFakePlayer(targetName);
               if (fakeData != null) {
                  UUID senderUuid = sender.getUniqueId();
                  Long lastRequest = (Long)this.fakeTpaCooldowns.get(senderUuid);
                  if (lastRequest != null && System.currentTimeMillis() - lastRequest < 5000L) {
                     long remaining = (5000L - (System.currentTimeMillis() - lastRequest)) / 1000L;
                     String var13 = String.valueOf(ChatColor.RED);
                     sender.sendMessage(var13 + "Please wait " + remaining + " seconds before sending another request.");
                     event.setCancelled(true);
                  } else if (!fakeData.isOnline()) {
                     sender.sendMessage(String.valueOf(ChatColor.RED) + "That player is not online.");
                     event.setCancelled(true);
                  } else {
                     event.setCancelled(true);
                     String successMessage = this.tpaSentMessage.replace("{PLAYER}", fakeData.getName()).replace("{player}", fakeData.getName());
                     sender.sendMessage(successMessage);
                     this.fakeTpaCooldowns.put(senderUuid, System.currentTimeMillis());
                     Logger var10000 = this.plugin.getLogger();
                     String var10001 = sender.getName();
                     var10000.fine(var10001 + " sent fake TPA to " + fakeData.getName());
                  }
               }
            }
         }
      }

   }

   public void cleanupCooldowns() {
      long now = System.currentTimeMillis();
      this.fakeTpaCooldowns.entrySet().removeIf((entry) -> {
         if (now - (Long)entry.getValue() > 5000L) {
            return true;
         } else {
            Player player = Bukkit.getPlayer((UUID)entry.getKey());
            return player == null || !player.isOnline();
         }
      });
   }

   public void removeCooldown(UUID uuid) {
      this.fakeTpaCooldowns.remove(uuid);
   }

   public void clearAllCooldowns() {
      this.fakeTpaCooldowns.clear();
   }
}
