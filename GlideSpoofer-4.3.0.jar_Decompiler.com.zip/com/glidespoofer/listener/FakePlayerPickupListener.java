package com.glidespoofer.listener;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import java.util.HashMap;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.scheduler.BukkitTask;

public class FakePlayerPickupListener implements Listener {
   private final GlideSpoofer plugin;
   private BukkitTask pickupScanTask;
   private BukkitTask equipSyncTask;
   private volatile boolean pickupScanningEnabled = false;
   private static final double PICKUP_RANGE = (double)1.5F;
   private static final long SCAN_INTERVAL = 4L;
   private static final long EQUIP_INTERVAL = 10L;

   public FakePlayerPickupListener(GlideSpoofer plugin) {
      this.plugin = plugin;
   }

   public void startPickupScanning() {
      if (!this.pickupScanningEnabled) {
         this.pickupScanningEnabled = true;
         if (GlideSpoofer.isFolia()) {
            this.plugin.getLogger().info("[FakePlayerPickupListener] Pickup scanning disabled on Folia due to region threading constraints");
         } else {
            this.pickupScanTask = Bukkit.getScheduler().runTaskTimer(this.plugin, this::scanForItems, 20L, 4L);
            this.equipSyncTask = Bukkit.getScheduler().runTaskTimer(this.plugin, this::syncAllEquipment, 40L, 10L);
         }
      }

   }

   public void stopPickupScanning() {
      this.pickupScanningEnabled = false;
      if (!GlideSpoofer.isFolia()) {
         if (this.pickupScanTask != null) {
            this.pickupScanTask.cancel();
            this.pickupScanTask = null;
         }

         if (this.equipSyncTask != null) {
            this.equipSyncTask.cancel();
            this.equipSyncTask = null;
         }
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onInventoryClose(InventoryCloseEvent event) {
      if (this.plugin.isUsingNMS()) {
         SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
         if (manager != null && event.getInventory().getHolder() instanceof Player) {
            Player holder = (Player)event.getInventory().getHolder();
            if (manager.isFakePlayer(holder)) {
               Runnable equipTask = () -> {
                  this.autoEquipBestItems(holder);
                  this.broadcastEquipment(holder);
               };
               if (GlideSpoofer.isFolia()) {
                  Bukkit.getGlobalRegionScheduler().execute(this.plugin, equipTask);
               } else {
                  Bukkit.getScheduler().runTaskLater(this.plugin, equipTask, 1L);
               }
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onEntityPickupItem(EntityPickupItemEvent event) {
      if (this.plugin.isUsingNMS()) {
         SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
         if (manager != null && event.getEntity() instanceof Player) {
            Player player = (Player)event.getEntity();
            if (manager.isFakePlayer(player)) {
               Runnable equipTask = () -> {
                  this.autoEquipBestItems(player);
                  this.broadcastEquipment(player);
               };
               if (GlideSpoofer.isFolia()) {
                  Bukkit.getGlobalRegionScheduler().execute(this.plugin, equipTask);
               } else {
                  Bukkit.getScheduler().runTaskLater(this.plugin, equipTask, 1L);
               }
            }
         }
      }

   }

   private void scanForItems() {
      if (this.plugin.isUsingNMS()) {
         SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
         if (manager != null) {
            for(SimpleFakePlayerManager.FakePlayerData data : manager.getAllFakePlayers()) {
               Player fp = data.getPlayer();
               if (fp != null && fp.isOnline()) {
                  Location loc = fp.getLocation();
                  if (loc != null && loc.getWorld() != null) {
                     boolean pickedUp = false;

                     for(Entity entity : loc.getWorld().getNearbyEntities(loc, (double)1.5F, (double)1.5F, (double)1.5F)) {
                        if (entity instanceof Item) {
                           Item item = (Item)entity;
                           if (item.isValid() && !item.isDead() && item.getPickupDelay() <= 0 && !(loc.distanceSquared(item.getLocation()) > (double)2.25F)) {
                              ItemStack stack = item.getItemStack();
                              HashMap<Integer, ItemStack> leftover = fp.getInventory().addItem(new ItemStack[]{stack.clone()});
                              if (leftover.isEmpty()) {
                                 item.remove();
                                 pickedUp = true;
                                 loc.getWorld().playSound(loc, Sound.ENTITY_ITEM_PICKUP, 0.2F, 1.0F + (float)(Math.random() * 0.4 - 0.2));
                              }
                           }
                        }
                     }

                     if (pickedUp) {
                        this.autoEquipBestItems(fp);
                        this.broadcastEquipment(fp);
                     }
                  }
               }
            }
         }
      }

   }

   private void syncAllEquipment() {
      if (this.plugin.isUsingNMS()) {
         SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
         if (manager != null) {
            for(SimpleFakePlayerManager.FakePlayerData data : manager.getAllFakePlayers()) {
               Player fp = data.getPlayer();
               if (fp != null && fp.isOnline()) {
                  this.autoEquipBestItems(fp);
                  this.broadcastEquipment(fp);
               }
            }
         }
      }

   }

   private void autoEquipBestItems(Player player) {
      PlayerInventory inv = player.getInventory();

      for(int i = 0; i < 36; ++i) {
         ItemStack item = inv.getItem(i);
         if (item != null && !item.getType().isAir()) {
            String name = item.getType().name();
            if (this.isHelmet(name) && this.isEmpty(inv.getHelmet())) {
               inv.setHelmet(item.clone());
               inv.setItem(i, (ItemStack)null);
            } else if (this.isChestplate(name) && this.isEmpty(inv.getChestplate())) {
               inv.setChestplate(item.clone());
               inv.setItem(i, (ItemStack)null);
            } else if (this.isLeggings(name) && this.isEmpty(inv.getLeggings())) {
               inv.setLeggings(item.clone());
               inv.setItem(i, (ItemStack)null);
            } else if (this.isBoots(name) && this.isEmpty(inv.getBoots())) {
               inv.setBoots(item.clone());
               inv.setItem(i, (ItemStack)null);
            } else if (this.isOffhandItem(name) && this.isEmpty(inv.getItemInOffHand())) {
               inv.setItemInOffHand(item.clone());
               inv.setItem(i, (ItemStack)null);
            }
         }
      }

      ItemStack currentMainHand = inv.getItemInMainHand();
      if (this.isEmpty(currentMainHand) || !this.isWeapon(currentMainHand.getType().name())) {
         int bestSlot = -1;
         double bestDamage = (double)0.0F;

         for(int ix = 0; ix < 36; ++ix) {
            ItemStack item = inv.getItem(ix);
            if (item != null && !item.getType().isAir() && this.isWeapon(item.getType().name())) {
               double dmg = this.getWeaponDamage(item.getType().name());
               if (dmg > bestDamage) {
                  bestDamage = dmg;
                  bestSlot = ix;
               }
            }
         }

         if (bestSlot >= 0) {
            ItemStack weapon = inv.getItem(bestSlot);
            if (!this.isEmpty(currentMainHand)) {
               inv.setItem(bestSlot, currentMainHand.clone());
            } else {
               inv.setItem(bestSlot, (ItemStack)null);
            }

            inv.setItemInMainHand(weapon.clone());
         }
      }

   }

   private boolean isEmpty(ItemStack item) {
      return item == null || item.getType().isAir();
   }

   private boolean isHelmet(String name) {
      return name.contains("HELMET") || name.contains("_CAP") || name.equals("TURTLE_HELMET") || name.equals("CARVED_PUMPKIN") || name.contains("SKULL") || name.contains("HEAD");
   }

   private boolean isChestplate(String name) {
      return name.contains("CHESTPLATE") || name.contains("_TUNIC") || name.equals("ELYTRA");
   }

   private boolean isLeggings(String name) {
      return name.contains("LEGGINGS") || name.contains("_PANTS");
   }

   private boolean isBoots(String name) {
      return name.contains("BOOTS");
   }

   private boolean isOffhandItem(String name) {
      return name.contains("SHIELD") || name.equals("TOTEM_OF_UNDYING");
   }

   private boolean isWeapon(String name) {
      return name.contains("SWORD") || name.contains("AXE") || name.contains("TRIDENT") || name.contains("MACE");
   }

   private double getWeaponDamage(String name) {
      if (name.contains("NETHERITE_SWORD")) {
         return (double)8.0F;
      } else if (name.contains("DIAMOND_SWORD")) {
         return (double)7.0F;
      } else if (name.contains("IRON_SWORD")) {
         return (double)6.0F;
      } else if (name.contains("STONE_SWORD")) {
         return (double)5.0F;
      } else if (name.contains("GOLDEN_SWORD")) {
         return (double)4.0F;
      } else if (name.contains("WOODEN_SWORD")) {
         return (double)4.0F;
      } else if (name.contains("NETHERITE_AXE")) {
         return (double)10.0F;
      } else if (name.contains("DIAMOND_AXE")) {
         return (double)9.0F;
      } else if (name.contains("IRON_AXE")) {
         return (double)9.0F;
      } else if (name.contains("STONE_AXE")) {
         return (double)9.0F;
      } else if (name.contains("GOLDEN_AXE")) {
         return (double)7.0F;
      } else if (name.contains("WOODEN_AXE")) {
         return (double)7.0F;
      } else if (name.contains("TRIDENT")) {
         return (double)9.0F;
      } else {
         return name.contains("MACE") ? (double)7.0F : (double)1.0F;
      }
   }

   private void broadcastEquipment(Player fakePlayer) {
      try {
         Object serverPlayer = fakePlayer.getClass().getMethod("getHandle").invoke(fakePlayer);
         if (serverPlayer == null) {
            return;
         }

         PlayerInventory inv = fakePlayer.getInventory();
         int entityId = (Integer)serverPlayer.getClass().getMethod("getId").invoke(serverPlayer);
         this.sendEquipmentPackets(entityId, serverPlayer, inv);
      } catch (Exception var5) {
         this.plugin.getLogger().fine("[Pickup] Equipment broadcast error: " + var5.getMessage());
      }

   }

   private void sendEquipmentPackets(int entityId, Object serverPlayer, PlayerInventory inv) {
   }
}
