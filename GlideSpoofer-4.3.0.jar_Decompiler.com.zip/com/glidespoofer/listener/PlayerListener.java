package com.glidespoofer.listener;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.packet.TeamPacketManager;
import com.glidespoofer.takeover.PlayerTakeoverData;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.luckperms.api.model.user.User;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

public class PlayerListener implements Listener {
   private final GlideSpoofer plugin;
   private final PlayerTakeoverData takeoverData;
   private final Map<UUID, String> takeoverFakes;
   private final Map<String, UUID> reverseTakeover;
   private final Map<UUID, BukkitTask> pendingSpawnTasks;
   private final Map<UUID, List<BukkitTask>> pendingRebroadcastTasks;
   private final Map<String, List<BukkitTask>> fakeSpawnRebroadcastTasks;
   private final Map<UUID, Long> recentlyDespawned;
   private static final long DESPAWN_GRACE_PERIOD_MS = 3000L;
   private final Map<UUID, Boolean> diedFakesToClear;
   private final Map<UUID, Location> takeoverLastLocations;

   private void debug(String message) {
      if (this.plugin.getConfigManager() != null && this.plugin.getConfigManager().isDebugEnabled()) {
         this.plugin.getLogger().info(message);
      }

   }

   public PlayerListener(GlideSpoofer plugin) {
      this(plugin, new PlayerTakeoverData(plugin.getDataFolder(), plugin.getLogger()));
   }

   public PlayerListener(GlideSpoofer plugin, PlayerTakeoverData takeoverData) {
      this.plugin = plugin;
      this.takeoverData = takeoverData;
      this.takeoverFakes = new HashMap();
      this.reverseTakeover = new HashMap();
      this.pendingSpawnTasks = new HashMap();
      this.pendingRebroadcastTasks = new HashMap();
      this.fakeSpawnRebroadcastTasks = new HashMap();
      this.recentlyDespawned = new HashMap();
      this.diedFakesToClear = new HashMap();
      this.takeoverLastLocations = new HashMap();
      this.scheduleRestoreTakeovers();
   }

   private void scheduleRestoreTakeovers() {
      long delay = 200L;
      if (GlideSpoofer.isFolia()) {
         Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> this.restoreTakeovers(), delay);
      } else {
         Bukkit.getScheduler().runTaskLater(this.plugin, this::restoreTakeovers, delay);
      }

   }

   private void restoreTakeovers() {
      if (this.plugin.getSimpleFakePlayerManager() == null) {
         this.plugin.getLogger().warning("[PlayerTakeover] Cannot restore takeovers - fake player manager not initialized");
      } else if (this.plugin.getSimpleFakePlayerManager().getNMSHandler() != null && this.plugin.getSimpleFakePlayerManager().isNMSAvailable()) {
         Map<String, PlayerTakeoverData.TakeoverEntry> entries = this.takeoverData.getAllTakeovers();
         if (entries.isEmpty()) {
            this.debug("[PlayerTakeover] No persistent takeovers to restore");
         } else {
            this.debug("[PlayerTakeover] Restoring " + entries.size() + " persistent takeovers...");
            int restored = 0;

            for(PlayerTakeoverData.TakeoverEntry entry : entries.values()) {
               try {
                  UUID realPlayerUuid = UUID.fromString(entry.getRealPlayerUuid());
                  String fakePlayerName = entry.getFakePlayerName();
                  if (fakePlayerName.endsWith("_Fake")) {
                     this.debug("[PlayerTakeover] Skipping old-format entry: " + fakePlayerName + " - removing from data");
                     this.takeoverData.removeTakeover(realPlayerUuid);
                  } else {
                     if (this.plugin.getSimpleFakePlayerManager().hasFakePlayer(fakePlayerName)) {
                        this.debug("[PlayerTakeover] Fake player " + fakePlayerName + " already exists, checking UUID...");
                        Player existingFake = Bukkit.getPlayerExact(fakePlayerName);
                        if (existingFake != null) {
                           UUID existingUuid = existingFake.getUniqueId();
                           if (existingUuid.equals(realPlayerUuid)) {
                              this.debug("[PlayerTakeover] Existing fake has correct takeover UUID, tracking only");
                              this.takeoverFakes.put(realPlayerUuid, fakePlayerName);
                              this.reverseTakeover.put(fakePlayerName, realPlayerUuid);
                              ++restored;
                              continue;
                           }

                           Logger var10000 = this.plugin.getLogger();
                           String var10001 = String.valueOf(existingUuid);
                           var10000.warning("[PlayerTakeover] Existing fake has WRONG UUID " + var10001 + " (expected " + String.valueOf(realPlayerUuid) + "), removing and respawning as takeover fake");
                           this.plugin.getSimpleFakePlayerManager().despawnFakePlayer(fakePlayerName, false);
                        } else {
                           this.plugin.getLogger().warning("[PlayerTakeover] Fake in tracking but not in server, removing from tracking");
                           this.plugin.getSimpleFakePlayerManager().despawnFakePlayer(fakePlayerName, false);
                        }
                     }

                     Location spawnLoc;
                     if (entry.hasLocation()) {
                        World world = Bukkit.getWorld(entry.getWorld());
                        if (world != null) {
                           spawnLoc = new Location(world, entry.getX(), entry.getY(), entry.getZ(), entry.getYaw(), entry.getPitch());
                           this.debug("[PlayerTakeover] Restoring " + fakePlayerName + " at saved location: " + entry.getWorld() + " " + String.format("%.1f, %.1f, %.1f", entry.getX(), entry.getY(), entry.getZ()));
                        } else {
                           spawnLoc = ((World)Bukkit.getWorlds().get(0)).getSpawnLocation();
                           Logger var13 = this.plugin.getLogger();
                           String var14 = entry.getWorld();
                           var13.warning("[PlayerTakeover] World '" + var14 + "' not loaded, using default spawn for " + fakePlayerName);
                        }
                     } else {
                        spawnLoc = ((World)Bukkit.getWorlds().get(0)).getSpawnLocation();
                     }

                     this.plugin.getSimpleFakePlayerManager().spawnFakePlayer(fakePlayerName, spawnLoc, entry.getRealPlayerName(), (String)null, false, true, (Map)null, true, realPlayerUuid);
                     if (this.plugin.getSimpleFakePlayerManager().getNMSHandler() != null) {
                        this.plugin.getSimpleFakePlayerManager().getNMSHandler().setVisibleInWorld(realPlayerUuid, true);
                        this.debug("[PlayerTakeover] Forced takeover fake " + fakePlayerName + " to be visible in world");
                     }

                     if (!entry.hasDied() && entry.getSerializedInventory() != null && !entry.getSerializedInventory().isEmpty()) {
                        this.restoreInventory(fakePlayerName, entry.getSerializedInventory());
                        this.debug("[PlayerTakeover] Restored inventory for " + fakePlayerName);
                     } else if (entry.hasDied()) {
                        this.debug("[PlayerTakeover] Skipping inventory restore for " + fakePlayerName + " - fake died (inventory lost)");
                     }

                     this.takeoverFakes.put(realPlayerUuid, fakePlayerName);
                     this.reverseTakeover.put(fakePlayerName, realPlayerUuid);
                     if (this.plugin.getRustHook() != null && this.plugin.getRustHook().isEnabled()) {
                        this.plugin.getRustHook().onFakePlayerLogin(fakePlayerName, entry.getRealPlayerUuid(), entry.getRealPlayerName());
                     }

                     ++restored;
                  }
               } catch (Exception var9) {
                  this.plugin.getLogger().log(Level.WARNING, "[PlayerTakeover] Failed to restore takeover for " + entry.getFakePlayerName(), var9);
               }
            }

            if (restored > 0) {
               this.plugin.getLogger().info("[PlayerTakeover] Restored " + restored + " fake players from persistent data");
               Runnable rebroadcastTask = () -> {
                  this.debug("[PlayerTakeover] Rebroadcasting " + restored + " restored takeover fakes to online players");

                  for(String fakeName : this.takeoverFakes.values()) {
                     this.rebroadcastFakePlayerToAll(fakeName);
                  }

               };
               if (GlideSpoofer.isFolia()) {
                  Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> rebroadcastTask.run(), 40L);
               } else {
                  Bukkit.getScheduler().runTaskLater(this.plugin, rebroadcastTask, 40L);
               }
            } else {
               this.debug("[PlayerTakeover] No takeover fakes were restored");
            }
         }
      } else {
         this.plugin.getLogger().warning("[PlayerTakeover] NMS not ready yet - retrying takeover restore in 10 seconds");
         if (GlideSpoofer.isFolia()) {
            Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> this.restoreTakeovers(), 200L);
         } else {
            Bukkit.getScheduler().runTaskLater(this.plugin, this::restoreTakeovers, 200L);
         }
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onAsyncPlayerPreLogin(AsyncPlayerPreLoginEvent event) {
      UUID playerUuid = event.getUniqueId();
      String playerName = event.getName();
      this.debug("[PlayerTakeover] PRE-LOGIN: Player " + playerName + " is connecting (UUID: " + String.valueOf(playerUuid) + ")");
      boolean hasFakeWithSameUUID = false;
      String foundInSource = "none";
      if (this.plugin.getSimpleFakePlayerManager() != null && this.plugin.getSimpleFakePlayerManager().getNMSHandler() != null) {
         hasFakeWithSameUUID = this.plugin.getSimpleFakePlayerManager().getNMSHandler().isFakePlayer(playerUuid);
         if (hasFakeWithSameUUID) {
            foundInSource = "NMS.isFakePlayer";
         }
      }

      if (!hasFakeWithSameUUID && this.takeoverData.hasTakeover(playerUuid)) {
         hasFakeWithSameUUID = true;
         foundInSource = "takeoverData";
      }

      if (!hasFakeWithSameUUID && this.takeoverFakes.containsKey(playerUuid)) {
         hasFakeWithSameUUID = true;
         foundInSource = "takeoverFakes";
      }

      if (!hasFakeWithSameUUID && this.reverseTakeover.containsKey(playerName)) {
         UUID mappedUuid = (UUID)this.reverseTakeover.get(playerName);
         if (mappedUuid.equals(playerUuid)) {
            hasFakeWithSameUUID = true;
            foundInSource = "reverseTakeover map";
            this.debug("[PlayerTakeover] Found in reverseTakeover map for " + playerName);
         }
      }

      this.debug("[PlayerTakeover] PRE-LOGIN: hasFakeWithSameUUID = " + hasFakeWithSameUUID + " (source: " + foundInSource + ") for " + playerName);
      if (hasFakeWithSameUUID) {
         this.debug("[PlayerTakeover] PRE-LOGIN: Player " + playerName + " is logging in, despawning fake IMMEDIATELY!");
         Bukkit.getScheduler().runTask(this.plugin, () -> {
            this.debug("[PlayerTakeover] PRE-LOGIN: Executing force remove for " + playerName);
            boolean foundFakeOnline = false;

            for(Player online : Bukkit.getOnlinePlayers()) {
               if (online.getUniqueId().equals(playerUuid)) {
                  foundFakeOnline = true;
                  Logger var10000 = this.plugin.getLogger();
                  String var10001 = online.getName();
                  var10000.warning("[PlayerTakeover] CONFIRMED: Found fake player " + var10001 + " with UUID " + String.valueOf(playerUuid) + " - REMOVING!");
                  break;
               }
            }

            if (!foundFakeOnline && !this.takeoverFakes.containsKey(playerUuid) && !this.reverseTakeover.containsKey(playerName)) {
               this.debug("[PlayerTakeover] PRE-LOGIN: No fake found during main thread check - may have been cleaned up already");
            } else {
               if (this.plugin.getSimpleFakePlayerManager() != null && this.plugin.getSimpleFakePlayerManager().getNMSHandler() != null) {
                  this.plugin.getSimpleFakePlayerManager().getNMSHandler().forceRemoveFakePlayer(playerUuid);
                  this.debug("[PlayerTakeover] PRE-LOGIN: Force removed fake at PRE-LOGIN STAGE: " + playerName);
               }

               String fakePlayerName = (String)this.takeoverFakes.remove(playerUuid);
               if (fakePlayerName != null) {
                  this.reverseTakeover.remove(fakePlayerName);
                  this.debug("[PlayerTakeover] PRE-LOGIN: Removed from takeoverFakes: " + fakePlayerName);
                  if (this.plugin.getSimpleFakePlayerManager() != null) {
                     this.plugin.getSimpleFakePlayerManager().despawnFakePlayer(fakePlayerName, true);
                     this.debug("[PlayerTakeover] PRE-LOGIN: Removed from SimpleFakePlayerManager: " + fakePlayerName);
                  }
               }

               PlayerTakeoverData.TakeoverEntry entry = this.takeoverData.getTakeover(playerUuid);
               this.plugin.getLogger().info("[PlayerTakeover] PRE-LOGIN: Checking takeover data for " + playerName + " (UUID: " + String.valueOf(playerUuid) + ")");
               boolean fakeDied = entry != null && entry.hasDied();
               this.plugin.getLogger().info("[PlayerTakeover] PRE-LOGIN: entry=" + (entry != null ? "EXISTS" : "NULL") + ", fakeDied=" + fakeDied);
               if (fakeDied) {
                  this.diedFakesToClear.put(playerUuid, true);
                  this.plugin.getLogger().warning("[PlayerTakeover] PRE-LOGIN: Fake died - marking for inventory clear on join: " + playerName);
                  this.debug("[PlayerTakeover] PRE-LOGIN: Fake died - marking for inventory clear on join: " + playerName);
               }

               if (entry != null && entry.hasLocation()) {
                  try {
                     World world = Bukkit.getWorld(entry.getWorld());
                     if (world != null) {
                        Location fakeLoc = new Location(world, entry.getX(), entry.getY(), entry.getZ(), entry.getYaw(), entry.getPitch());
                        this.takeoverLastLocations.put(playerUuid, fakeLoc);
                        this.debug("[PlayerTakeover] PRE-LOGIN: Saved fake location for " + playerName + ": " + String.valueOf(fakeLoc));
                     }
                  } catch (Exception var9) {
                     this.plugin.getLogger().warning("[PlayerTakeover] Failed to save location for " + playerName + ": " + var9.getMessage());
                  }
               }

               this.takeoverData.removeTakeover(playerUuid);
               this.plugin.getLogger().info("[PlayerTakeover] PRE-LOGIN: Removed takeover data for " + playerName);
               this.reverseTakeover.remove(playerName);
               this.recentlyDespawned.put(playerUuid, System.currentTimeMillis());
            }

         });
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPlayerLogin(PlayerLoginEvent event) {
      UUID playerUuid = event.getPlayer().getUniqueId();
      String playerName = event.getPlayer().getName();
      this.debug("[PlayerTakeover] LOGIN: Player " + playerName + " is logging in (UUID: " + String.valueOf(playerUuid) + ")");
      boolean hasFakeWithSameUUID = false;
      String foundInSource = "none";
      if (this.plugin.getSimpleFakePlayerManager() != null && this.plugin.getSimpleFakePlayerManager().getNMSHandler() != null) {
         hasFakeWithSameUUID = this.plugin.getSimpleFakePlayerManager().getNMSHandler().isFakePlayer(playerUuid);
         if (hasFakeWithSameUUID) {
            foundInSource = "NMS.isFakePlayer";
         }
      }

      if (!hasFakeWithSameUUID && this.takeoverData.hasTakeover(playerUuid)) {
         hasFakeWithSameUUID = true;
         foundInSource = "takeoverData";
      }

      if (!hasFakeWithSameUUID && this.takeoverFakes.containsKey(playerUuid)) {
         hasFakeWithSameUUID = true;
         foundInSource = "takeoverFakes";
      }

      if (!hasFakeWithSameUUID) {
         try {
            this.debug("[PlayerTakeover] LOGIN: Checking " + Bukkit.getOnlinePlayers().size() + " online players for UUID match...");

            for(Player online : Bukkit.getOnlinePlayers()) {
               String var10001 = online.getName();
               this.debug("[PlayerTakeover] LOGIN: Checking " + var10001 + " with UUID " + String.valueOf(online.getUniqueId()) + " against " + String.valueOf(playerUuid));
               if (online.getUniqueId().equals(playerUuid)) {
                  hasFakeWithSameUUID = true;
                  foundInSource = "Bukkit.getOnlinePlayers() found UUID match (FAKE DETECTED!)";
                  Logger var10000 = this.plugin.getLogger();
                  var10001 = online.getName();
                  var10000.warning("[PlayerTakeover] CRITICAL: Found existing player " + var10001 + " with UUID " + String.valueOf(playerUuid) + " during LOGIN - this is a FAKE!");
                  break;
               }
            }
         } catch (Exception var12) {
            this.plugin.getLogger().warning("[PlayerTakeover] Error checking online players: " + var12.getMessage());
         }
      }

      if (!hasFakeWithSameUUID && this.reverseTakeover.containsKey(playerName)) {
         UUID mappedUuid = (UUID)this.reverseTakeover.get(playerName);
         if (mappedUuid.equals(playerUuid)) {
            hasFakeWithSameUUID = true;
            foundInSource = "reverseTakeover map";
            this.debug("[PlayerTakeover] Found in reverseTakeover map for " + playerName);
         }
      }

      this.debug("[PlayerTakeover] LOGIN: hasFakeWithSameUUID = " + hasFakeWithSameUUID + " (source: " + foundInSource + ") for " + playerName);
      if (hasFakeWithSameUUID) {
         this.debug("[PlayerTakeover] LOGIN: Player " + playerName + " is logging in, despawning fake FIRST!");
         if (this.plugin.getSimpleFakePlayerManager() != null && this.plugin.getSimpleFakePlayerManager().getNMSHandler() != null) {
            this.plugin.getSimpleFakePlayerManager().getNMSHandler().forceRemoveFakePlayer(playerUuid);
            this.debug("[PlayerTakeover] Force removed fake at LOGIN STAGE: " + playerName);
         }

         String fakePlayerName = (String)this.takeoverFakes.remove(playerUuid);
         if (fakePlayerName != null) {
            this.reverseTakeover.remove(fakePlayerName);
            this.debug("[PlayerTakeover] LOGIN: Removed from takeoverFakes: " + fakePlayerName);
            if (this.plugin.getSimpleFakePlayerManager() != null) {
               this.plugin.getSimpleFakePlayerManager().despawnFakePlayer(fakePlayerName, true);
               this.debug("[PlayerTakeover] LOGIN: Removed from SimpleFakePlayerManager: " + fakePlayerName);
            }
         }

         PlayerTakeoverData.TakeoverEntry entry = this.takeoverData.getTakeover(playerUuid);
         this.plugin.getLogger().info("[PlayerTakeover] LOGIN: Checking takeover data for " + playerName + " (UUID: " + String.valueOf(playerUuid) + ")");
         boolean fakeDied = entry != null && entry.hasDied();
         this.plugin.getLogger().info("[PlayerTakeover] LOGIN: entry=" + (entry != null ? "EXISTS" : "NULL") + ", fakeDied=" + fakeDied);
         if (fakeDied) {
            this.diedFakesToClear.put(playerUuid, true);
            this.plugin.getLogger().warning("[PlayerTakeover] LOGIN: Fake died - marking for inventory clear on join: " + playerName);
            this.debug("[PlayerTakeover] LOGIN: Fake died - marking for inventory clear on join: " + playerName);
         }

         if (entry != null && entry.hasLocation()) {
            try {
               World world = Bukkit.getWorld(entry.getWorld());
               if (world != null) {
                  Location fakeLoc = new Location(world, entry.getX(), entry.getY(), entry.getZ(), entry.getYaw(), entry.getPitch());
                  this.takeoverLastLocations.put(playerUuid, fakeLoc);
                  this.debug("[PlayerTakeover] LOGIN: Saved fake location for " + playerName + ": " + String.valueOf(fakeLoc));
               }
            } catch (Exception var11) {
               this.plugin.getLogger().warning("[PlayerTakeover] Failed to save location for " + playerName + ": " + var11.getMessage());
            }
         }

         this.takeoverData.removeTakeover(playerUuid);
         this.plugin.getLogger().info("[PlayerTakeover] LOGIN: Removed takeover data for " + playerName);
         this.recentlyDespawned.put(playerUuid, System.currentTimeMillis());
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      UUID playerUuid = player.getUniqueId();
      BukkitTask pendingTask = (BukkitTask)this.pendingSpawnTasks.remove(playerUuid);
      if (pendingTask != null) {
         pendingTask.cancel();
         this.debug("[PlayerTakeover] Cancelled pending fake spawn for rejoined player: " + player.getName());
      }

      List<BukkitTask> tasks = (List)this.pendingRebroadcastTasks.remove(playerUuid);
      if (tasks != null) {
         for(BukkitTask task : tasks) {
            task.cancel();
         }

         int var10001 = tasks.size();
         this.debug("[PlayerTakeover] Cancelled " + var10001 + " pending rebroadcast tasks for " + player.getName());
      }

      this.recentlyDespawned.put(playerUuid, System.currentTimeMillis());
      boolean hasFakeWithSameUUID = false;
      String foundInSource = "none";
      boolean isCurrentlySpawning = false;
      if (this.plugin.getSimpleFakePlayerManager() != null && this.plugin.getSimpleFakePlayerManager().getNMSHandler() != null) {
         isCurrentlySpawning = this.plugin.getSimpleFakePlayerManager().getNMSHandler().isCurrentlySpawning(playerUuid);
      }

      if (isCurrentlySpawning) {
         this.debug("[PlayerTakeover] Player " + player.getName() + " is currently being spawned - skipping takeover logic");
      } else {
         if (this.plugin.getSimpleFakePlayerManager() != null && this.plugin.getSimpleFakePlayerManager().getNMSHandler() != null) {
            hasFakeWithSameUUID = this.plugin.getSimpleFakePlayerManager().getNMSHandler().isFakePlayer(playerUuid);
            if (hasFakeWithSameUUID) {
               foundInSource = "NMS.isFakePlayer";
            }
         }

         if (!hasFakeWithSameUUID && this.takeoverData.hasTakeover(playerUuid)) {
            hasFakeWithSameUUID = true;
            foundInSource = "takeoverData";
         }

         if (!hasFakeWithSameUUID && this.takeoverFakes.containsKey(playerUuid)) {
            hasFakeWithSameUUID = true;
            foundInSource = "takeoverFakes";
         }

         if (!hasFakeWithSameUUID) {
            try {
               for(Player online : Bukkit.getOnlinePlayers()) {
                  if (!online.equals(player) && online.getUniqueId().equals(playerUuid)) {
                     hasFakeWithSameUUID = true;
                     foundInSource = "Bukkit.getOnlinePlayers() found UUID match (FAKE DETECTED!)";
                     this.plugin.getLogger().warning("[PlayerTakeover] CRITICAL: Found existing player with UUID " + String.valueOf(playerUuid) + " during JOIN - this is a FAKE!");
                     break;
                  }
               }
            } catch (Exception var17) {
               this.plugin.getLogger().warning("[PlayerTakeover] Error checking online players: " + var17.getMessage());
            }
         }

         if (!hasFakeWithSameUUID && this.reverseTakeover.containsKey(player.getName())) {
            UUID mappedUuid = (UUID)this.reverseTakeover.get(player.getName());
            if (mappedUuid.equals(playerUuid)) {
               hasFakeWithSameUUID = true;
               foundInSource = "reverseTakeover map";
               this.debug("[PlayerTakeover] Found in reverseTakeover map for " + player.getName());
            }
         }

         this.debug("[PlayerTakeover] JOIN: hasFakeWithSameUUID = " + hasFakeWithSameUUID + " (source: " + foundInSource + ") for " + player.getName());
         boolean rustHookEnabled = this.plugin.getRustHook() != null && this.plugin.getRustHook().isEnabled();
         if (hasFakeWithSameUUID && rustHookEnabled) {
            String var32 = player.getName();
            this.debug("[PlayerTakeover] Real player " + var32 + " rejoined, despawning fake (source: " + foundInSource + ")");
            boolean wasRustHookEnabled = this.plugin.getRustHook() != null && this.plugin.getRustHook().isEnabled();
            if (wasRustHookEnabled) {
               this.plugin.getRustHook().setEnabled(false);
               this.debug("[PlayerTakeover] Temporarily disabled Rust hook for cleanup: " + player.getName());
            }

            if (wasRustHookEnabled) {
               this.plugin.getRustHook().onPlayerLogout(player.getName(), playerUuid.toString());
               this.debug("[PlayerTakeover] Pre-notified Rust hook of player logout: " + player.getName());
            }

            if (this.plugin.getSimpleFakePlayerManager() != null && this.plugin.getSimpleFakePlayerManager().getNMSHandler() != null) {
               this.plugin.getSimpleFakePlayerManager().getNMSHandler().forceRemoveFakePlayer(playerUuid);
               this.debug("[PlayerTakeover] Force removed fake from NMS handler: " + player.getName());
            }

            String fakePlayerName = (String)this.takeoverFakes.remove(playerUuid);
            if (fakePlayerName != null) {
               this.reverseTakeover.remove(fakePlayerName);
               this.debug("[PlayerTakeover] Removed from takeoverFakes: " + fakePlayerName);
               if (this.plugin.getSimpleFakePlayerManager() != null) {
                  this.plugin.getSimpleFakePlayerManager().despawnFakePlayer(fakePlayerName, true);
                  this.debug("[PlayerTakeover] Removed from SimpleFakePlayerManager: " + fakePlayerName);
               }
            }

            PlayerTakeoverData.TakeoverEntry entry = this.takeoverData.getTakeover(playerUuid);
            boolean diedFlagInMap = this.diedFakesToClear.containsKey(playerUuid);
            boolean entryExistsAndDied = entry != null && entry.hasDied();
            boolean shouldClearInventory = entryExistsAndDied || diedFlagInMap;
            Logger var10000 = this.plugin.getLogger();
            var32 = player.getName();
            var10000.severe("[PlayerTakeover] JOIN INVENTORY CHECK for " + var32 + " (UUID: " + String.valueOf(playerUuid) + ")");
            this.plugin.getLogger().severe("[PlayerTakeover]   - entry exists: " + (entry != null));
            var10000 = this.plugin.getLogger();
            Object var34 = entry != null ? entry.hasDied() : "N/A";
            var10000.severe("[PlayerTakeover]   - entry.hasDied(): " + String.valueOf(var34));
            this.plugin.getLogger().severe("[PlayerTakeover]   - diedFakesToClear contains: " + diedFlagInMap);
            this.plugin.getLogger().severe("[PlayerTakeover]   - shouldClearInventory: " + shouldClearInventory);
            if (shouldClearInventory) {
               this.plugin.getLogger().severe("[PlayerTakeover] CLEARING INVENTORY for " + player.getName() + " - fake died while away!");
               this.debug("[PlayerTakeover] Fake " + player.getName() + " died while real player was away - clearing real player's inventory!");
               player.getInventory().clear();
               player.getInventory().setHelmet((ItemStack)null);
               player.getInventory().setChestplate((ItemStack)null);
               player.getInventory().setLeggings((ItemStack)null);
               player.getInventory().setBoots((ItemStack)null);
               player.getInventory().setItemInOffHand((ItemStack)null);
               player.sendMessage("§c§l(!) §cYour fake player died while you were away! You lost all your items.");
               this.diedFakesToClear.remove(playerUuid);
            } else {
               this.plugin.getLogger().info("[PlayerTakeover] NOT clearing inventory for " + player.getName() + " - fake did not die");
            }

            this.takeoverData.removeTakeover(playerUuid);
            Location joinLoc = player.getLocation();
            Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
               try {
                  player.teleport(joinLoc);
                  this.debug("[PlayerTakeover] First refresh of " + player.getName() + " client state");
               } catch (Exception var4x) {
                  this.plugin.getLogger().warning("[PlayerTakeover] Failed first refresh: " + var4x.getMessage());
               }

            }, 5L);
            Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
               try {
                  player.teleport(joinLoc);
                  this.debug("[PlayerTakeover] Second refresh of " + player.getName() + " client state");
               } catch (Exception var4x) {
                  this.plugin.getLogger().warning("[PlayerTakeover] Failed second refresh: " + var4x.getMessage());
               }

            }, 15L);
            Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
               try {
                  player.teleport(joinLoc);
                  this.debug("[PlayerTakeover] Final refresh of " + player.getName() + " client state");
               } catch (Exception var4x) {
                  this.plugin.getLogger().warning("[PlayerTakeover] Failed final refresh: " + var4x.getMessage());
               }

            }, 30L);
            if (wasRustHookEnabled) {
               Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                  if (this.plugin.getRustHook() != null) {
                     this.plugin.getRustHook().setEnabled(true);
                     this.debug("[PlayerTakeover] Re-enabled Rust hook after player rejoin: " + player.getName());
                  }

               }, 60L);
            }
         }

         if (rustHookEnabled) {
            if (this.diedFakesToClear.containsKey(playerUuid)) {
               this.plugin.getLogger().severe("[PlayerTakeover] JOIN OUTSIDE BLOCK: Clearing inventory for " + player.getName() + " - fake died (from diedFakesToClear map)!");
               Location fakeLoc = (Location)this.takeoverLastLocations.remove(playerUuid);
               if (fakeLoc != null && fakeLoc.getWorld() != null) {
                  Logger var30 = this.plugin.getLogger();
                  String var35 = player.getName();
                  var30.info("[PlayerTakeover] Teleporting " + var35 + " to fake's last location: " + String.valueOf(fakeLoc));
                  player.teleport(fakeLoc);
               }

               player.getInventory().clear();
               player.getInventory().setHelmet((ItemStack)null);
               player.getInventory().setChestplate((ItemStack)null);
               player.getInventory().setLeggings((ItemStack)null);
               player.getInventory().setBoots((ItemStack)null);
               player.getInventory().setItemInOffHand((ItemStack)null);
               player.sendMessage("§c§l(!) §cYour fake player died while you were away! You lost all your items.");
               this.diedFakesToClear.remove(playerUuid);
            } else if (this.takeoverLastLocations.containsKey(playerUuid)) {
               Location fakeLoc = (Location)this.takeoverLastLocations.remove(playerUuid);
               if (fakeLoc != null && fakeLoc.getWorld() != null) {
                  Logger var31 = this.plugin.getLogger();
                  String var36 = player.getName();
                  var31.info("[PlayerTakeover] Teleporting " + var36 + " to fake's last location (fake alive): " + String.valueOf(fakeLoc));
                  player.teleport(fakeLoc);
               }
            }
         }

         if (this.plugin.isUsingNMS() && !this.takeoverFakes.isEmpty() && !hasFakeWithSameUUID) {
            int var37 = this.takeoverFakes.size();
            this.debug("[PlayerTakeover] Re-broadcasting " + var37 + " takeover fakes to " + player.getName());
            List<BukkitTask> newTasks = new ArrayList();
            Map<UUID, String> takeoverSnapshot = new HashMap(this.takeoverFakes);
            BukkitTask task1 = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
               for(Map.Entry<UUID, String> entryx : takeoverSnapshot.entrySet()) {
                  if (this.takeoverFakes.containsKey(entryx.getKey())) {
                     this.rebroadcastFakePlayerToAll((String)entryx.getValue());
                  }
               }

            }, 20L);
            newTasks.add(task1);
            BukkitTask task2 = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
               for(Map.Entry<UUID, String> entryx : takeoverSnapshot.entrySet()) {
                  if (this.takeoverFakes.containsKey(entryx.getKey())) {
                     this.rebroadcastFakePlayerToAll((String)entryx.getValue());
                  }
               }

            }, 40L);
            newTasks.add(task2);
            this.pendingRebroadcastTasks.put(playerUuid, newTasks);
         }

         if (!this.plugin.isUsingNMS() && this.plugin.getFakePlayerManager() != null) {
            this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> this.plugin.getFakePlayerManager().spawnAllFor(event.getPlayer()), 20L);
         }

         Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            TeamPacketManager.sendAllTeamsToPlayer(player);
            this.debug("[PlayerListener] Sent all team data to " + player.getName() + " for tab list prefixes");
         }, 10L);
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onPlayerQuit(PlayerQuitEvent event) {
      Player player = event.getPlayer();
      UUID playerUuid = player.getUniqueId();
      String playerName = player.getName();
      this.debug("[PlayerTakeover] Player quit: " + playerName + " (UUID: " + String.valueOf(playerUuid) + ")");
      if (this.plugin.getRustHook() != null && this.plugin.getRustHook().isEnabled()) {
         boolean hasPermanent = false;
         if (this.plugin.getRustHook() != null) {
            this.debug("[PlayerTakeover] RustHook exists, enabled: " + this.plugin.getRustHook().isEnabled());
            hasPermanent = this.plugin.getRustHook().hasPermanentPermission(playerUuid.toString());
            this.debug("[PlayerTakeover] RustHook permission check result: " + hasPermanent);
         }

         if (!hasPermanent && this.plugin.getLuckPermsHook() != null && this.plugin.getLuckPermsHook().isEnabled()) {
            try {
               User user = this.plugin.getLuckPermsHook().getUserByUuid(playerUuid);
               if (user != null) {
                  String permissionNode = this.plugin.getConfigManager().getConfig().getString("rust-hook.permanent-permission-node", "glidespoofer.permanent");
                  hasPermanent = user.getCachedData().getPermissionData().checkPermission(permissionNode).asBoolean();
                  this.debug("[PlayerTakeover] Direct LuckPerms check result: " + permissionNode + " = " + hasPermanent);
               } else {
                  this.plugin.getLogger().warning("[PlayerTakeover] LuckPerms user not found for: " + String.valueOf(playerUuid));
               }
            } catch (Exception var11) {
               this.plugin.getLogger().log(Level.WARNING, "[PlayerTakeover] Failed to check LuckPerms permission", var11);
            }
         } else if (!hasPermanent) {
            this.plugin.getLogger().warning("[PlayerTakeover] Both RustHook and LuckPermsHook are not available!");
         }

         this.debug("[PlayerTakeover] Has permanent permission: " + hasPermanent);
         if (hasPermanent) {
            String serializedInventory = this.serializeInventory(player);
            Location playerLoc = player.getLocation();
            BukkitTask task = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
               Long despawnTime = (Long)this.recentlyDespawned.get(playerUuid);
               if (despawnTime != null && System.currentTimeMillis() - despawnTime < 3000L) {
                  this.debug("[PlayerTakeover] Skipping fake spawn for " + playerName + " - player recently rejoined");
                  this.recentlyDespawned.remove(playerUuid);
               } else {
                  Player onlineCheck = Bukkit.getPlayerExact(playerName);
                  if (onlineCheck != null && onlineCheck.isOnline()) {
                     this.debug("[PlayerTakeover] Skipping fake spawn for " + playerName + " - player is still online!");
                  } else {
                     this.spawnFakePlayerTakeoverDelayed(playerName, playerUuid, serializedInventory, playerLoc);
                     this.pendingSpawnTasks.remove(playerUuid);
                  }
               }

            }, 40L);
            this.pendingSpawnTasks.put(playerUuid, task);
         } else if (this.plugin.getRustHook() != null && this.plugin.getRustHook().isEnabled()) {
            this.plugin.getRustHook().onPlayerLogout(playerName, playerUuid.toString());
         }

         if (!this.plugin.isUsingNMS() && this.plugin.getFakePlayerManager() != null) {
            this.plugin.getFakePlayerManager().despawnAllFrom(player);
         }
      } else {
         this.debug("[PlayerTakeover] RustHook is not enabled, skipping takeover check");
      }

   }

   private String serializeInventory(Player player) {
      try {
         YamlConfiguration yaml = new YamlConfiguration();
         ItemStack[] inventory = player.getInventory().getContents();
         yaml.set("inventory", inventory);
         ItemStack[] armor = player.getInventory().getArmorContents();
         yaml.set("armor", armor);
         ItemStack[] extraSlots = player.getInventory().getExtraContents();
         yaml.set("extra", extraSlots);
         ItemStack[] enderChest = player.getEnderChest().getContents();
         yaml.set("enderchest", enderChest);
         String yamlString = yaml.saveToString();
         return Base64.getEncoder().encodeToString(yamlString.getBytes(StandardCharsets.UTF_8));
      } catch (Exception var8) {
         this.plugin.getLogger().log(Level.WARNING, "[PlayerTakeover] Failed to serialize inventory for " + player.getName(), var8);
         return null;
      }
   }

   private void restoreInventory(String fakePlayerName, String serializedInventory) {
      if (serializedInventory != null && !serializedInventory.isEmpty()) {
         try {
            Player fakePlayer = Bukkit.getPlayerExact(fakePlayerName);
            if (fakePlayer == null) {
               return;
            }

            byte[] decoded = Base64.getDecoder().decode(serializedInventory);
            String yamlString = new String(decoded, StandardCharsets.UTF_8);
            YamlConfiguration yaml = new YamlConfiguration();
            yaml.loadFromString(yamlString);
            if (yaml.contains("inventory")) {
               ItemStack[] inventory = (ItemStack[])yaml.getList("inventory").toArray(new ItemStack[0]);
               fakePlayer.getInventory().setContents(inventory);
            }

            if (yaml.contains("armor")) {
               ItemStack[] armor = (ItemStack[])yaml.getList("armor").toArray(new ItemStack[0]);
               fakePlayer.getInventory().setArmorContents(armor);
            }

            if (yaml.contains("extra")) {
               ItemStack[] extra = (ItemStack[])yaml.getList("extra").toArray(new ItemStack[0]);
               fakePlayer.getInventory().setExtraContents(extra);
            }

            if (yaml.contains("enderchest")) {
               ItemStack[] enderChest = (ItemStack[])yaml.getList("enderchest").toArray(new ItemStack[0]);

               try {
                  fakePlayer.getEnderChest().setContents(enderChest);
               } catch (Exception var9) {
               }
            }

            this.debug("[PlayerTakeover] Restored inventory for " + fakePlayerName);
         } catch (Exception var10) {
            this.plugin.getLogger().log(Level.WARNING, "[PlayerTakeover] Failed to restore inventory for " + fakePlayerName, var10);
         }
      }

   }

   private void spawnFakePlayerTakeover(Player realPlayer, String realPlayerName, UUID realPlayerUuid, String serializedInventory) {
      if (this.plugin.getSimpleFakePlayerManager() != null) {
         if (this.takeoverFakes.containsKey(realPlayerUuid)) {
            this.debug("[PlayerTakeover] Fake player already exists for " + realPlayerName);
         } else {
            Location spawnLoc = realPlayer.getLocation();
            this.plugin.getSimpleFakePlayerManager().spawnFakePlayer(realPlayerName, spawnLoc, realPlayerName, (String)null, false, true, (Map)null, true, realPlayerUuid);
            this.copyInventory(realPlayer, realPlayerName);
            this.takeoverData.addTakeover(realPlayerUuid, realPlayerName, realPlayerName, serializedInventory, spawnLoc.getWorld().getName(), spawnLoc.getX(), spawnLoc.getY(), spawnLoc.getZ(), spawnLoc.getYaw(), spawnLoc.getPitch());
            this.takeoverFakes.put(realPlayerUuid, realPlayerName);
            this.reverseTakeover.put(realPlayerName, realPlayerUuid);
            if (this.plugin.getRustHook() != null && this.plugin.getRustHook().isEnabled()) {
               this.plugin.getRustHook().onFakePlayerLogin(realPlayerName, realPlayerUuid.toString(), realPlayerName);
            }

            List<BukkitTask> spawnTasks = new ArrayList();
            BukkitTask task1 = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
               this.debug("[PlayerTakeover] First rebroadcast attempt for " + realPlayerName);
               this.rebroadcastFakePlayerToAll(realPlayerName);
            }, 5L);
            spawnTasks.add(task1);
            BukkitTask task2 = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
               this.debug("[PlayerTakeover] Second rebroadcast attempt for " + realPlayerName);
               this.rebroadcastFakePlayerToAll(realPlayerName);
            }, 15L);
            spawnTasks.add(task2);
            BukkitTask task3 = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
               this.debug("[PlayerTakeover] Third rebroadcast attempt for " + realPlayerName);
               this.rebroadcastFakePlayerToAll(realPlayerName);
            }, 30L);
            spawnTasks.add(task3);
            this.fakeSpawnRebroadcastTasks.put(realPlayerName, spawnTasks);
            this.debug("[PlayerTakeover] Fake player " + realPlayerName + " spawned for " + realPlayerName);
         }
      }

   }

   private void spawnFakePlayerTakeoverDelayed(String realPlayerName, UUID realPlayerUuid, String serializedInventory, Location spawnLoc) {
      if (this.plugin.getSimpleFakePlayerManager() != null) {
         if (this.takeoverFakes.containsKey(realPlayerUuid)) {
            this.debug("[PlayerTakeover] Fake player already exists for " + realPlayerName);
         } else {
            Player onlineCheck = Bukkit.getPlayerExact(realPlayerName);
            if (onlineCheck != null && onlineCheck.isOnline()) {
               this.debug("[PlayerTakeover] Aborting fake spawn for " + realPlayerName + " - player is back online!");
            } else {
               this.plugin.getSimpleFakePlayerManager().spawnFakePlayer(realPlayerName, spawnLoc, realPlayerName, (String)null, false, true, (Map)null, true, realPlayerUuid);
               if (this.plugin.getSimpleFakePlayerManager().getNMSHandler() != null) {
                  this.plugin.getSimpleFakePlayerManager().getNMSHandler().setVisibleInWorld(realPlayerUuid, true);
                  this.debug("[PlayerTakeover] Forced takeover fake " + realPlayerName + " to be visible in world");
               }

               this.restoreInventory(realPlayerName, serializedInventory);
               this.takeoverData.addTakeover(realPlayerUuid, realPlayerName, realPlayerName, serializedInventory, spawnLoc.getWorld().getName(), spawnLoc.getX(), spawnLoc.getY(), spawnLoc.getZ(), spawnLoc.getYaw(), spawnLoc.getPitch());
               this.takeoverFakes.put(realPlayerUuid, realPlayerName);
               this.reverseTakeover.put(realPlayerName, realPlayerUuid);
               if (this.plugin.getRustHook() != null && this.plugin.getRustHook().isEnabled()) {
                  this.plugin.getRustHook().onFakePlayerLogin(realPlayerName, realPlayerUuid.toString(), realPlayerName);
               }

               List<BukkitTask> spawnTasks = new ArrayList();
               BukkitTask task1 = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                  if (this.takeoverFakes.containsKey(realPlayerUuid)) {
                     this.debug("[PlayerTakeover] First rebroadcast attempt for " + realPlayerName);
                     this.rebroadcastFakePlayerToAll(realPlayerName);
                  }

               }, 10L);
               spawnTasks.add(task1);
               BukkitTask task2 = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                  if (this.takeoverFakes.containsKey(realPlayerUuid)) {
                     this.debug("[PlayerTakeover] Second rebroadcast attempt for " + realPlayerName);
                     this.rebroadcastFakePlayerToAll(realPlayerName);
                  }

               }, 30L);
               spawnTasks.add(task2);
               BukkitTask task3 = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                  if (this.takeoverFakes.containsKey(realPlayerUuid)) {
                     this.debug("[PlayerTakeover] Third rebroadcast attempt for " + realPlayerName);
                     this.rebroadcastFakePlayerToAll(realPlayerName);
                  }

               }, 60L);
               spawnTasks.add(task3);
               this.fakeSpawnRebroadcastTasks.put(realPlayerName, spawnTasks);
               this.debug("[PlayerTakeover] Fake player " + realPlayerName + " spawned for " + realPlayerName);
            }
         }
      }

   }

   private void rebroadcastFakePlayerToAll(String fakePlayerName) {
      Player fakePlayer = null;

      for(int i = 0; i < 5; ++i) {
         fakePlayer = Bukkit.getPlayerExact(fakePlayerName);
         if (fakePlayer != null) {
            break;
         }

         try {
            Thread.sleep(10L);
         } catch (InterruptedException var161) {
            break;
         }
      }

      if (fakePlayer == null) {
         this.plugin.getLogger().warning("[PlayerTakeover] Could not find fake player: " + fakePlayerName);
      } else {
         this.debug("[PlayerTakeover] Re-broadcasting " + fakePlayerName + " to all players");

         try {
            Object serverPlayer = this.plugin.getSimpleFakePlayerManager().getNMSHandler().getServerPlayer(fakePlayer);
            if (serverPlayer == null) {
               this.plugin.getLogger().warning("[PlayerTakeover] Could not get server player for: " + fakePlayerName);
               return;
            }

            UUID fakeUuid = fakePlayer.getUniqueId();
            boolean isVisible = this.plugin.getSimpleFakePlayerManager().getNMSHandler().isVisibleInWorld(fakeUuid);
            this.debug("[PlayerTakeover] Fake player visible in world: " + isVisible);
            if (!isVisible) {
               this.debug("[PlayerTakeover] Forcing visibility for " + fakePlayerName);
               this.plugin.getSimpleFakePlayerManager().getNMSHandler().setVisibleInWorld(fakeUuid, true);
            }

            int realPlayerCount = 0;

            for(Player online : Bukkit.getOnlinePlayers()) {
               if (!this.plugin.getSimpleFakePlayerManager().isFakePlayer(online)) {
                  if (online.getUniqueId().equals(fakeUuid)) {
                     Logger var10000 = this.plugin.getLogger();
                     String var10001 = online.getName();
                     var10000.warning("[PlayerTakeover] EMERGENCY: Real player " + var10001 + " has same UUID as fake " + fakePlayerName + " - DESPAWNING FAKE NOW!");
                     if (this.plugin.getSimpleFakePlayerManager() != null && this.plugin.getSimpleFakePlayerManager().getNMSHandler() != null) {
                        this.plugin.getSimpleFakePlayerManager().getNMSHandler().forceRemoveFakePlayer(fakeUuid);
                        this.takeoverFakes.remove(fakeUuid);
                        this.reverseTakeover.remove(fakePlayerName);
                        this.takeoverData.removeTakeover(fakeUuid);
                        this.plugin.getLogger().warning("[PlayerTakeover] EMERGENCY: Force removed fake " + fakePlayerName + " with conflicting UUID");
                     }

                     return;
                  }

                  ++realPlayerCount;
                  this.debug("[PlayerTakeover] Would send packets to: " + online.getName());
               }
            }

            this.debug("[PlayerTakeover] Found " + realPlayerCount + " real players to broadcast to");
            Class<?> nmsHandlerClass = this.plugin.getSimpleFakePlayerManager().getNMSHandler().getClass();
            Method broadcastSpawnMethod = null;

            for(Method m : nmsHandlerClass.getDeclaredMethods()) {
               if (m.getName().equals("broadcastSpawnEntity") && m.getParameterCount() == 1) {
                  broadcastSpawnMethod = m;
                  m.setAccessible(true);
                  break;
               }
            }

            if (broadcastSpawnMethod != null) {
               broadcastSpawnMethod.invoke(this.plugin.getSimpleFakePlayerManager().getNMSHandler(), serverPlayer);
               this.debug("[PlayerTakeover] Called broadcastSpawnEntity for " + fakePlayerName);
            } else {
               this.debug("[PlayerTakeover] broadcastSpawnEntity not found, using manual packet send");

               for(Player onlinex : Bukkit.getOnlinePlayers()) {
                  if (!this.plugin.getSimpleFakePlayerManager().isFakePlayer(onlinex)) {
                     if (onlinex.getUniqueId().equals(fakeUuid)) {
                        this.debug("[PlayerTakeover] Skipping manual packet send to " + onlinex.getName() + " - same UUID as fake");
                     } else {
                        try {
                           this.sendPacketsToPlayer(onlinex, serverPlayer);
                           this.debug("[PlayerTakeover] Manually sent spawn packets to " + onlinex.getName());
                        } catch (Exception var14) {
                           Logger var26 = this.plugin.getLogger();
                           String var27 = onlinex.getName();
                           var26.warning("[PlayerTakeover] Failed to send packets to " + var27 + ": " + var14.getMessage());
                        }
                     }
                  }
               }
            }

            Method broadcastPlayerInfoMethod = null;

            for(Method mx : nmsHandlerClass.getDeclaredMethods()) {
               if (mx.getName().equals("broadcastPlayerInfo") && mx.getParameterCount() == 2) {
                  broadcastPlayerInfoMethod = mx;
                  mx.setAccessible(true);
                  break;
               }
            }

            if (broadcastPlayerInfoMethod != null) {
               broadcastPlayerInfoMethod.invoke(this.plugin.getSimpleFakePlayerManager().getNMSHandler(), serverPlayer, true);
               this.debug("[PlayerTakeover] Called broadcastPlayerInfo for " + fakePlayerName);
            }

            this.debug("[PlayerTakeover] Re-broadcast complete to " + realPlayerCount + " real players");
         } catch (Exception var15) {
            this.plugin.getLogger().warning("[PlayerTakeover] Could not re-broadcast " + fakePlayerName + ": " + var15.getMessage());
            var15.printStackTrace();
         }
      }

   }

   private void sendPacketsToPlayer(Player target, Object serverPlayer) throws Exception {
      Class<?> nmsHandlerClass = this.plugin.getSimpleFakePlayerManager().getNMSHandler().getClass();
      UUID fakeUuid = null;

      try {
         Method getUUIDMethod = serverPlayer.getClass().getMethod("getUUID");
         fakeUuid = (UUID)getUUIDMethod.invoke(serverPlayer);
      } catch (Exception var14) {
         this.plugin.getLogger().warning("[PlayerTakeover] Could not get UUID from serverPlayer: " + var14.getMessage());
      }

      if (fakeUuid != null && target.getUniqueId().equals(fakeUuid)) {
         this.debug("[PlayerTakeover] BLOCKED packet send to " + target.getName() + " - same UUID as fake (would cause self-interaction kick)");
      } else {
         this.debug("[PlayerTakeover] Attempting to send packets to " + target.getName() + " for fake player");
         Method broadcastRemoveMethod = null;

         for(Method m : nmsHandlerClass.getDeclaredMethods()) {
            if (m.getName().equals("broadcastRemoveEntity") && m.getParameterCount() == 1) {
               broadcastRemoveMethod = m;
               m.setAccessible(true);
               break;
            }
         }

         if (broadcastRemoveMethod != null) {
            broadcastRemoveMethod.invoke(this.plugin.getSimpleFakePlayerManager().getNMSHandler(), serverPlayer);
            this.debug("[PlayerTakeover] Sent remove packet to clear cache for " + target.getName());
         }

         try {
            Thread.sleep(50L);
         } catch (InterruptedException var13) {
         }

         Method sendPlayerInfoMethod = null;

         for(Method mx : nmsHandlerClass.getDeclaredMethods()) {
            if (mx.getName().equals("sendPlayerInfoToPlayer") && mx.getParameterCount() == 3) {
               sendPlayerInfoMethod = mx;
               mx.setAccessible(true);
               break;
            }
         }

         if (sendPlayerInfoMethod != null) {
            sendPlayerInfoMethod.invoke(this.plugin.getSimpleFakePlayerManager().getNMSHandler(), target, serverPlayer, true);
            this.debug("[PlayerTakeover] Sent PlayerInfo packet to " + target.getName());
         } else {
            this.plugin.getLogger().warning("[PlayerTakeover] Could not find sendPlayerInfoToPlayer method!");
         }

         Method sendSpawnMethod = null;

         for(Method mxx : nmsHandlerClass.getDeclaredMethods()) {
            if (mxx.getName().equals("sendSpawnPacketToPlayer") && mxx.getParameterCount() == 2) {
               sendSpawnMethod = mxx;
               mxx.setAccessible(true);
               break;
            }
         }

         if (sendSpawnMethod != null) {
            sendSpawnMethod.invoke(this.plugin.getSimpleFakePlayerManager().getNMSHandler(), target, serverPlayer);
            this.debug("[PlayerTakeover] Sent spawn packet to " + target.getName());
         } else {
            this.plugin.getLogger().warning("[PlayerTakeover] Could not find sendSpawnPacketToPlayer method!");
         }

         Method sendTeleportMethod = null;

         for(Method mxxx : nmsHandlerClass.getDeclaredMethods()) {
            if (mxxx.getName().equals("sendTeleportPacketToPlayer") && mxxx.getParameterCount() == 2) {
               sendTeleportMethod = mxxx;
               mxxx.setAccessible(true);
               break;
            }
         }

         if (sendTeleportMethod != null) {
            sendTeleportMethod.invoke(this.plugin.getSimpleFakePlayerManager().getNMSHandler(), target, serverPlayer);
            this.debug("[PlayerTakeover] Sent teleport packet to " + target.getName());
         }
      }

   }

   private void copyInventory(Player realPlayer, String fakePlayerName) {
      Player fakePlayer = Bukkit.getPlayerExact(fakePlayerName);
      if (fakePlayer != null) {
         fakePlayer.getInventory().setContents(realPlayer.getInventory().getContents());
         fakePlayer.getInventory().setArmorContents(realPlayer.getInventory().getArmorContents());
         fakePlayer.getInventory().setExtraContents(realPlayer.getInventory().getExtraContents());

         try {
            fakePlayer.getEnderChest().setContents(realPlayer.getEnderChest().getContents());
         } catch (Exception var5) {
         }

         String var10001 = realPlayer.getName();
         this.debug("[PlayerTakeover] Copied inventory from " + var10001 + " to " + fakePlayerName);
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onFakePlayerDeath(PlayerDeathEvent event) {
      Player player = event.getEntity();
      if (this.plugin.getSimpleFakePlayerManager() != null && this.plugin.getSimpleFakePlayerManager().isFakePlayer(player)) {
         String fakePlayerName = player.getName();
         if (this.reverseTakeover.containsKey(fakePlayerName)) {
            UUID realPlayerUuid = (UUID)this.reverseTakeover.get(fakePlayerName);
            if (this.plugin.getRustHook() != null && this.plugin.getRustHook().isEnabled()) {
               this.plugin.getRustHook().onFakePlayerDeath(fakePlayerName);
            }

            this.takeoverFakes.remove(realPlayerUuid);
            this.reverseTakeover.remove(fakePlayerName);
            PlayerTakeoverData.TakeoverEntry entry = this.takeoverData.getTakeover(realPlayerUuid);
            if (entry != null) {
               this.takeoverData.updateTakeover(realPlayerUuid, (String)null, entry.getWorld(), entry.getX(), entry.getY(), entry.getZ(), entry.getYaw(), entry.getPitch());
               this.takeoverData.markAsDied(realPlayerUuid);
               this.debug("[PlayerTakeover] Fake player " + fakePlayerName + " died - marked entry as died, inventory cleared");
            } else {
               this.debug("[PlayerTakeover] Fake player " + fakePlayerName + " died but no takeover entry found - creating died marker");
               this.takeoverData.addTakeover(realPlayerUuid, fakePlayerName, fakePlayerName, (String)null, (String)null, (double)0.0F, (double)0.0F, (double)0.0F, 0.0F, 0.0F);
               this.takeoverData.markAsDied(realPlayerUuid);
            }

            this.plugin.getSimpleFakePlayerManager().despawnFakePlayer(fakePlayerName, true);
            this.debug("[PlayerTakeover] Fake player " + fakePlayerName + " died and was removed (died flag set for inventory clear)");
         } else if (this.plugin.getRustHook() != null && this.plugin.getRustHook().isEnabled()) {
            this.plugin.getRustHook().onFakePlayerDeath(fakePlayerName);
         }
      }

   }

   public void despawnTakeoverFake(UUID realPlayerUuid) {
      String fakePlayerName = (String)this.takeoverFakes.remove(realPlayerUuid);
      if (fakePlayerName != null) {
         this.reverseTakeover.remove(fakePlayerName);
         this.takeoverData.removeTakeover(realPlayerUuid);
         this.recentlyDespawned.put(realPlayerUuid, System.currentTimeMillis());
         List<BukkitTask> tasks = (List)this.pendingRebroadcastTasks.remove(realPlayerUuid);
         if (tasks != null) {
            for(BukkitTask task : tasks) {
               task.cancel();
            }

            int var10001 = tasks.size();
            this.debug("[PlayerTakeover] Cancelled " + var10001 + " pending rebroadcast tasks for " + fakePlayerName);
         }

         List<BukkitTask> spawnTasks = (List)this.fakeSpawnRebroadcastTasks.remove(fakePlayerName);
         if (spawnTasks != null) {
            for(BukkitTask task : spawnTasks) {
               task.cancel();
            }

            int var18 = spawnTasks.size();
            this.debug("[PlayerTakeover] Cancelled " + var18 + " spawn rebroadcast tasks for " + fakePlayerName);
         }

         if (this.plugin.getRustHook() != null) {
            boolean wasEnabled = this.plugin.getRustHook().isEnabled();
            this.plugin.getRustHook().setEnabled(true);
            this.plugin.getRustHook().onFakePlayerDeath(fakePlayerName);
            this.plugin.getRustHook().setEnabled(wasEnabled);
            this.debug("[PlayerTakeover] Notified Rust hook of fake player despawn: " + fakePlayerName);
         }

         try {
            Player fakePlayer = Bukkit.getPlayerExact(fakePlayerName);
            if (fakePlayer != null && this.plugin.getSimpleFakePlayerManager() != null && this.plugin.getSimpleFakePlayerManager().getNMSHandler() != null) {
               Object serverPlayer = this.plugin.getSimpleFakePlayerManager().getNMSHandler().getServerPlayer(fakePlayer);
               if (serverPlayer != null) {
                  Class<?> nmsHandlerClass = this.plugin.getSimpleFakePlayerManager().getNMSHandler().getClass();

                  for(Method m : nmsHandlerClass.getDeclaredMethods()) {
                     if (m.getName().equals("broadcastRemoveEntity") && m.getParameterCount() == 1) {
                        m.setAccessible(true);
                        m.invoke(this.plugin.getSimpleFakePlayerManager().getNMSHandler(), serverPlayer);
                        this.debug("[PlayerTakeover] Broadcasted remove entity for " + fakePlayerName);
                        break;
                     }
                  }
               }
            }
         } catch (Exception var12) {
            this.plugin.getLogger().warning("[PlayerTakeover] Failed to broadcast remove entity: " + var12.getMessage());
         }

         if (this.plugin.getSimpleFakePlayerManager() != null && this.plugin.getSimpleFakePlayerManager().getNMSHandler() != null) {
            this.plugin.getSimpleFakePlayerManager().getNMSHandler().forceRemoveFakePlayer(realPlayerUuid);
            this.debug("[PlayerTakeover] Force removed fake from NMS handler: " + fakePlayerName);
         }

         if (this.plugin.getSimpleFakePlayerManager() != null) {
            this.plugin.getSimpleFakePlayerManager().despawnFakePlayer(fakePlayerName, true);
            this.debug("[PlayerTakeover] Despawned fake player: " + fakePlayerName);
         }

         this.debug("[PlayerTakeover] Complete cleanup for fake player: " + fakePlayerName);
      } else {
         this.debug("[PlayerTakeover] No fake player found to despawn for UUID: " + String.valueOf(realPlayerUuid));
      }

   }

   public boolean isTakeoverFake(String fakePlayerName) {
      return this.reverseTakeover.containsKey(fakePlayerName);
   }

   public UUID getRealPlayerUuid(String fakePlayerName) {
      return (UUID)this.reverseTakeover.get(fakePlayerName);
   }

   public PlayerTakeoverData getTakeoverData() {
      return this.takeoverData;
   }
}
