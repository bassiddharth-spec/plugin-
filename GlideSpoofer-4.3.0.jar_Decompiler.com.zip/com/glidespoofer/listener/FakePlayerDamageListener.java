package com.glidespoofer.listener;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import com.glidespoofer.hooks.WorldGuardHook;
import com.glidespoofer.nms.NMSHandler;
import com.glidespoofer.nms.SimpleNMSHandler;
import com.glidespoofer.physics.AdvancedKnockbackSystem;
import com.glidespoofer.takeover.PlayerTakeoverData;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Logger;
import net.luckperms.api.model.user.User;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.damage.DamageSource;
import org.bukkit.damage.DamageType;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;
import org.bukkit.util.VoxelShape;

public class FakePlayerDamageListener implements Listener {
   private static final Set<String> knockedBackPlayers = ConcurrentHashMap.newKeySet();
   private static final Map<String, Long> nmsKbEndTimeStatic = new ConcurrentHashMap();
   private final GlideSpoofer plugin;
   private final Map<String, Double> health = new ConcurrentHashMap();
   private final Map<String, Boolean> dead = new ConcurrentHashMap();
   private final Map<String, Long> hurtCD = new ConcurrentHashMap();
   private final Map<String, TaskHandle> kbTasks = new ConcurrentHashMap();
   private final Map<String, Long> nmsKbEndTime = new ConcurrentHashMap();
   private final Map<String, Boolean> collisionOn = new ConcurrentHashMap();
   private final Map<String, Double> fallStartY = new ConcurrentHashMap();
   private TaskHandle proximityTask;
   private static final double HW = 0.3;
   private final AdvancedKnockbackSystem advancedKnockback;
   private final boolean isFolia;
   private final Map<String, KnockbackState> knockbackStates = new ConcurrentHashMap();

   public FakePlayerDamageListener(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.isFolia = GlideSpoofer.isFolia();
      this.advancedKnockback = new AdvancedKnockbackSystem(plugin);
      this.advancedKnockback.setPositionUpdateCallback((update) -> {
         SimpleFakePlayerManager.FakePlayerData foundData = null;

         for(SimpleFakePlayerManager.FakePlayerData fd : plugin.getSimpleFakePlayerManager().getAllFakePlayers()) {
            if (fd.getUuid().equals(update.getPlayerUuid())) {
               foundData = fd;
               break;
            }
         }

         if (foundData != null && foundData.getPlayer() != null && foundData.getPlayer().isOnline()) {
            plugin.getSimpleFakePlayerManager().getNMSHandler().updatePosition(foundData.getPlayer(), update.getNewLocation(), true);
            this.updateTakeoverLocation(foundData.getName(), update.getNewLocation());
         }

      });
      this.startProximityPush();
      this.startHealthKeepalive();
   }

   public double getHealth(String n) {
      return (Double)this.health.getOrDefault(n, (double)20.0F);
   }

   public boolean isDead(String n) {
      return (Boolean)this.dead.getOrDefault(n, false);
   }

   public void setCollision(String n, boolean v) {
      this.collisionOn.put(n, v);
   }

   public boolean hasCollision(String n) {
      return (Boolean)this.collisionOn.getOrDefault(n, true);
   }

   public static boolean isKnockedBackStatic(String playerName) {
      long now = System.currentTimeMillis();
      nmsKbEndTimeStatic.entrySet().removeIf((e) -> {
         if ((Long)e.getValue() < now) {
            knockedBackPlayers.remove(e.getKey());
            return true;
         } else {
            return false;
         }
      });
      return knockedBackPlayers.contains(playerName);
   }

   public boolean isKnockedBack(String n) {
      if (knockedBackPlayers.contains(n)) {
         Long end = (Long)this.nmsKbEndTime.get(n);
         if (end != null && System.currentTimeMillis() < end) {
            return true;
         }

         knockedBackPlayers.remove(n);
         this.nmsKbEndTime.remove(n);
      }

      return false;
   }

   public void cleanup(String n) {
      this.health.remove(n);
      this.dead.remove(n);
      this.hurtCD.remove(n);
      this.collisionOn.remove(n);
      this.fallStartY.remove(n);
      this.nmsKbEndTime.remove(n);
      nmsKbEndTimeStatic.remove(n);
      TaskHandle t = (TaskHandle)this.kbTasks.remove(n);
      if (t != null) {
         t.cancel();
      }

      knockedBackPlayers.remove(n);
      SimpleFakePlayerManager.FakePlayerData fd = this.plugin.getSimpleFakePlayerManager().getFakePlayer(n);
      if (fd != null) {
         this.advancedKnockback.cancelKnockback(fd.getUuid());
      }

   }

   public void setFallStart(String name, double y) {
      this.fallStartY.putIfAbsent(name, y);
   }

   public boolean applyFallDamage(String name, Player fake, double landY) {
      Double startY = (Double)this.fallStartY.remove(name);
      if (startY == null) {
         return false;
      } else {
         double fallDist = startY - landY;
         if (fallDist > (double)3.0F) {
            double dmg = fallDist - (double)3.0F;
            fake.getWorld().playSound(fake.getLocation(), Sound.ENTITY_PLAYER_HURT, 1.0F, 1.0F);
            Block below = fake.getWorld().getBlockAt(this.fl(fake.getLocation().getX()), this.fl(landY) - 1, this.fl(fake.getLocation().getZ()));
            if (below.getType().isSolid()) {
               try {
                  fake.getWorld().spawnParticle(Particle.BLOCK, fake.getLocation().getX(), landY + 0.1, fake.getLocation().getZ(), 20, 0.3, 0.05, 0.3, (double)0.0F, below.getBlockData());
               } catch (Exception var13) {
               }
            }

            this.plugin.getSimpleFakePlayerManager().getNMSHandler().performAction(fake, NMSHandler.FakePlayerAction.DAMAGE_ANIMATION);
            double hp = (Double)this.health.getOrDefault(name, (double)20.0F) - dmg;
            this.health.put(name, Math.max((double)0.0F, hp));
            this.syncHealthToClients(fake, Math.max((double)0.0F, hp));
            if (hp <= (double)0.0F) {
               this.handleDeath(fake, name, (Player)null, DamageCause.FALL, (Entity)null);
               return true;
            }
         }

         return false;
      }
   }

   public void resetFall(String name) {
      this.fallStartY.remove(name);
   }

   private int fl(double v) {
      return (int)Math.floor(v);
   }

   private void resetNmsHealth(Player v) {
      try {
         Object sp = v.getClass().getMethod("getHandle").invoke(v);
         double tracked = (Double)this.health.getOrDefault(v.getName(), (double)20.0F);
         float nmsHealth = Math.max(0.5F, (float)tracked);
         sp.getClass().getMethod("setHealth", Float.TYPE).invoke(sp, nmsHealth);

         try {
            for(Class<?> clazz = sp.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
               for(Field f : clazz.getDeclaredFields()) {
                  if (!Modifier.isStatic(f.getModifiers())) {
                     f.setAccessible(true);
                     if ((f.getName().equals("invulnerableTime") || f.getName().equals("noActionTime")) && f.getType() == Integer.TYPE) {
                        f.setInt(sp, 0);
                     }

                     if (f.getName().equals("hurtTime") && f.getType() == Integer.TYPE) {
                        f.setInt(sp, 0);
                     }
                  }
               }
            }
         } catch (Exception var11) {
         }
      } catch (Exception var12) {
      }

   }

   private void syncHealthToClients(Player v, double trackedHealth) {
      try {
         Object sp = v.getClass().getMethod("getHandle").invoke(v);
         boolean inKnockback = this.kbTasks.containsKey(v.getName());
         if (!inKnockback) {
            float nmsHealth = Math.max(0.5F, (float)trackedHealth);
            sp.getClass().getMethod("setHealth", Float.TYPE).invoke(sp, nmsHealth);
         }

         Object ed = this.getEntityData(sp);
         if (ed != null) {
            this.setHealthMeta(ed, (float)trackedHealth);
            int eid = (Integer)sp.getClass().getMethod("getId").invoke(sp);
            this.sendMetaPkt(eid, ed);
         }
      } catch (Exception var8) {
      }

   }

   private void startHealthKeepalive() {
      if (this.isFolia) {
         ScheduledTask var1 = Bukkit.getGlobalRegionScheduler().runAtFixedRate(this.plugin, (task) -> {
            SimpleFakePlayerManager mgr = this.plugin.getSimpleFakePlayerManager();
            if (mgr != null) {
               for(SimpleFakePlayerManager.FakePlayerData fd : mgr.getAllFakePlayers()) {
                  if (!(Boolean)this.dead.getOrDefault(fd.getName(), false)) {
                     Player fp = fd.getPlayer();
                     if (fp != null && fp.isOnline()) {
                        try {
                           double tracked = (Double)this.health.getOrDefault(fd.getName(), (double)20.0F);
                           Object sp = fp.getClass().getMethod("getHandle").invoke(fp);
                           sp.getClass().getMethod("setHealth", Float.TYPE).invoke(sp, Math.max(0.5F, (float)tracked));
                        } catch (Exception var9) {
                        }
                     }
                  }
               }
            }

         }, 20L, 10L);
      } else {
         (new BukkitRunnable() {
            public void run() {
               SimpleFakePlayerManager mgr = FakePlayerDamageListener.this.plugin.getSimpleFakePlayerManager();
               if (mgr != null) {
                  for(SimpleFakePlayerManager.FakePlayerData fd : mgr.getAllFakePlayers()) {
                     if (!(Boolean)FakePlayerDamageListener.this.dead.getOrDefault(fd.getName(), false)) {
                        Player fp = fd.getPlayer();
                        if (fp != null && fp.isOnline()) {
                           try {
                              double tracked = (Double)FakePlayerDamageListener.this.health.getOrDefault(fd.getName(), (double)20.0F);
                              Object sp = fp.getClass().getMethod("getHandle").invoke(fp);
                              sp.getClass().getMethod("setHealth", Float.TYPE).invoke(sp, Math.max(0.5F, (float)tracked));
                           } catch (Exception var8) {
                           }
                        }
                     }
                  }
               }

            }
         }).runTaskTimer(this.plugin, 20L, 10L);
      }

   }

   private void startProximityPush() {
      if (this.isFolia) {
         ScheduledTask foliaTask = Bukkit.getGlobalRegionScheduler().runAtFixedRate(this.plugin, (task) -> this.runProximityPush(), 5L, 2L);
         this.proximityTask = new TaskHandle(foliaTask);
      } else {
         BukkitTask bukkitTask = (new BukkitRunnable() {
            public void run() {
               FakePlayerDamageListener.this.runProximityPush();
            }
         }).runTaskTimer(this.plugin, 5L, 2L);
         this.proximityTask = new TaskHandle(bukkitTask);
      }

   }

   private void runProximityPush() {
      SimpleFakePlayerManager mgr = this.plugin.getSimpleFakePlayerManager();
      if (mgr != null) {
         for(SimpleFakePlayerManager.FakePlayerData fd : mgr.getAllFakePlayers()) {
            String name = fd.getName();
            if ((Boolean)this.collisionOn.getOrDefault(name, true) && !(Boolean)this.dead.getOrDefault(name, false) && !this.kbTasks.containsKey(name)) {
               Player fake = fd.getPlayer();
               if (fake != null && fake.isOnline()) {
                  Location fl = fake.getLocation();
                  World w = fl.getWorld();
                  if (w != null) {
                     for(Player real : Bukkit.getOnlinePlayers()) {
                        if (!mgr.isFakePlayer(real) && w.equals(real.getWorld())) {
                           Location rl = real.getLocation();
                           double dx = fl.getX() - rl.getX();
                           double dz = fl.getZ() - rl.getZ();
                           double dist = Math.sqrt(dx * dx + dz * dz);
                           if (dist < 0.8 && dist > 0.01) {
                              double push = (0.8 - dist) * 0.06;
                              double nx = fl.getX() + dx / dist * push;
                              double nz = fl.getZ() + dz / dist * push;
                              if (!this.isInsideBlock(w, nx, fl.getY(), nz)) {
                                 mgr.getNMSHandler().updatePosition(fake, new Location(w, nx, fl.getY(), nz, fl.getYaw(), fl.getPitch()), false);
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = false
   )
   public void onDamage(EntityDamageEvent ev) {
      if (this.plugin.isUsingNMS()) {
         SimpleFakePlayerManager mgr = this.plugin.getSimpleFakePlayerManager();
         if (mgr != null && ev.getEntity() instanceof Player) {
            Player victim = (Player)ev.getEntity();
            if (mgr.isFakePlayer(victim)) {
               ev.setCancelled(true);
               String name = victim.getName();
               boolean noDamage = false;

               try {
                  if (this.plugin.getGuiListener() != null && this.plugin.getGuiListener().getGUI() != null) {
                     noDamage = this.plugin.getGuiListener().getGUI().isNoDamageEnabled(name);
                  }
               } catch (Exception var17) {
               }

               if (!noDamage && !(Boolean)this.dead.getOrDefault(name, false)) {
                  this.health.putIfAbsent(name, (double)20.0F);
                  if (ev.getCause() == DamageCause.FALL) {
                     this.applyDmg(victim, name, ev.getDamage(), (Player)null, DamageCause.FALL, (Entity)null);
                  } else if (ev instanceof EntityDamageByEntityEvent) {
                     EntityDamageByEntityEvent ede = (EntityDamageByEntityEvent)ev;
                     boolean isPlayerAttacker = ede.getDamager() instanceof Player;
                     if (isPlayerAttacker) {
                        Player atk = (Player)ede.getDamager();
                        WorldGuardHook wg = this.plugin.getWorldGuardHook();
                        if (wg != null && wg.isEnabled() && wg.isPvPDisabled(victim.getLocation())) {
                           atk.sendMessage("§c§l(!) §cPvP is disabled in this area.");
                        } else {
                           long now = System.currentTimeMillis();
                           Long last = (Long)this.hurtCD.get(name);
                           if (last == null || now - last >= 500L) {
                              this.hurtCD.put(name, now);
                              this.applyDmg(victim, name, ev.getFinalDamage(), atk);
                              boolean knockbackEnabled = true;

                              try {
                                 if (this.plugin.getGuiListener() == null) {
                                    this.plugin.getLogger().fine("[Knockback] GUIListener is null!");
                                 } else if (this.plugin.getGuiListener().getGUI() == null) {
                                    this.plugin.getLogger().fine("[Knockback] GUI is null!");
                                 } else {
                                    boolean guiResult = this.plugin.getGuiListener().getGUI().isPhysicsEnabled(name);
                                    if (this.plugin.getConfigManager().isDebugEnabled()) {
                                       this.plugin.getLogger().fine("[Knockback] GUI returned isPhysicsEnabled(" + name + ") = " + guiResult);
                                    }

                                    knockbackEnabled = guiResult;
                                 }
                              } catch (Exception var15) {
                                 this.plugin.getLogger().fine("[Knockback] Exception checking physics: " + var15.getMessage());
                                 var15.printStackTrace();
                              }

                              if (this.plugin.getConfigManager().isDebugEnabled()) {
                                 this.plugin.getLogger().fine("[Knockback] Final knockback enabled for " + name + ": " + knockbackEnabled);
                              }

                              if (knockbackEnabled) {
                                 this.applyKnockback(victim, name, atk);
                              } else if (this.plugin.getConfigManager().isDebugEnabled()) {
                                 this.plugin.getLogger().fine("[Knockback] Knockback is disabled for " + name + " - enable via GUI");
                              }
                           }
                        }
                     } else {
                        long now = System.currentTimeMillis();
                        Long last = (Long)this.hurtCD.get(name);
                        if (last == null || now - last >= 300L) {
                           this.hurtCD.put(name, now);
                           this.applyDmg(victim, name, ev.getFinalDamage(), (Player)null, ev.getCause(), ede.getDamager());
                           boolean knockbackEnabled = true;

                           try {
                              if (this.plugin.getGuiListener() != null && this.plugin.getGuiListener().getGUI() != null) {
                                 knockbackEnabled = this.plugin.getGuiListener().getGUI().isPhysicsEnabled(name);
                              }
                           } catch (Exception var151) {
                           }

                           if (this.plugin.getConfigManager().isDebugEnabled()) {
                              this.plugin.getLogger().fine("[Knockback] Mob knockback enabled for " + name + ": " + knockbackEnabled);
                           }

                           if (knockbackEnabled) {
                              this.applyKnockbackFromEntity(victim, name, ede.getDamager());
                           } else if (this.plugin.getConfigManager().isDebugEnabled()) {
                              this.plugin.getLogger().fine("[Knockback] Mob knockback is disabled for " + name + " - enable via GUI");
                           }
                        }
                     }
                  } else if (ev.getCause() == DamageCause.LAVA || ev.getCause() == DamageCause.FIRE || ev.getCause() == DamageCause.FIRE_TICK || ev.getCause() == DamageCause.VOID) {
                     this.applyDmg(victim, name, ev.getDamage(), (Player)null, ev.getCause(), (Entity)null);
                  }
               }
            }
         }
      }

   }

   private void applyDmg(Player v, String name, double dmg, Player atk) {
      this.applyDmg(v, name, dmg, atk, (EntityDamageEvent.DamageCause)null, (Entity)null);
   }

   private void applyDmg(Player v, String name, double dmg, Player atk, EntityDamageEvent.DamageCause cause, Entity damager) {
      double hp = (Double)this.health.getOrDefault(name, (double)20.0F) - dmg;
      this.health.put(name, Math.max((double)0.0F, hp));
      this.plugin.getSimpleFakePlayerManager().getNMSHandler().performAction(v, NMSHandler.FakePlayerAction.DAMAGE_ANIMATION);
      v.getWorld().playSound(v.getLocation(), Sound.ENTITY_PLAYER_HURT, 1.0F, 1.0F);
      this.syncHealthToClients(v, Math.max((double)0.0F, hp));
      if (hp <= (double)0.0F) {
         this.handleDeath(v, name, atk, cause, damager);
      }

   }

   private void applyKnockback(Player victim, String name, Player attacker) {
      if (this.plugin.getConfigManager().isDebugEnabled()) {
         this.plugin.getLogger().fine("[Knockback] Applying NMS knockback to " + name + " from " + attacker.getName());
      }

      this.syncNMSPosition(victim);
      TaskHandle old = (TaskHandle)this.kbTasks.remove(name);
      if (old != null) {
         old.cancel();
      }

      double dx = victim.getLocation().getX() - attacker.getLocation().getX();
      double dz = victim.getLocation().getZ() - attacker.getLocation().getZ();
      double len = Math.sqrt(dx * dx + dz * dz);
      if (len > 0.001) {
         dx /= len;
         dz /= len;
      } else {
         float yaw = attacker.getLocation().getYaw();
         double rad = Math.toRadians((double)yaw);
         dx = -Math.sin(rad);
         dz = Math.cos(rad);
      }

      boolean victimOnGround = this.onGround(victim.getLocation());
      boolean victimInAir = !victimOnGround;
      double str = 0.7;
      int knockbackLevel = 0;

      try {
         ItemStack wep = attacker.getInventory().getItemInMainHand();
         if (wep != null && !wep.getType().isAir()) {
            for(Map.Entry<Enchantment, Integer> e : wep.getEnchantments().entrySet()) {
               if (((Enchantment)e.getKey()).getKey().getKey().equalsIgnoreCase("knockback")) {
                  knockbackLevel = (Integer)e.getValue();
                  str += (double)knockbackLevel * (double)1.0F;
                  break;
               }
            }
         }
      } catch (Exception var23) {
      }

      if (attacker.isSprinting()) {
         str += (double)0.5F;
      }

      if (victimInAir) {
         str *= (double)0.5F;
      }

      try {
         double knockbackResistance = (double)0.0F;

         for(ItemStack armor : victim.getInventory().getArmorContents()) {
            if (armor != null && !armor.getType().isAir() && armor.getType().name().contains("NETHERITE")) {
               knockbackResistance += 0.1;
            }
         }

         str *= (double)1.0F - Math.min(knockbackResistance, (double)1.0F);
      } catch (Exception var22) {
      }

      if (str > (double)3.0F) {
         str = (double)3.0F;
      }

      if (this.plugin.getConfigManager().isDebugEnabled()) {
         Logger var10000 = this.plugin.getLogger();
         String var10001 = String.format("%.2f", str);
         var10000.info("[Knockback] Calculated strength: " + var10001 + " (KB level: " + knockbackLevel + ", sprinting: " + attacker.isSprinting() + ", victim in air: " + victimInAir + ")");
      }

      this.applyNMSKnockback(victim, dx, dz, str);
      long kbEndTime = System.currentTimeMillis() + 300L;
      this.nmsKbEndTime.put(name, kbEndTime);
      nmsKbEndTimeStatic.put(name, kbEndTime);
   }

   private void applyAdvancedKnockback(Player victim, String name, double dx, double dz, double strength) {
      SimpleFakePlayerManager.FakePlayerData fd = this.plugin.getSimpleFakePlayerManager().getFakePlayer(name);
      if (fd == null) {
         this.plugin.getLogger().fine("[Knockback] Fake player data not found for " + name);
      } else {
         this.advancedKnockback.cancelKnockback(fd.getUuid());
         TaskHandle old = (TaskHandle)this.kbTasks.remove(name);
         if (old != null) {
            old.cancel();
         }

         try {
            Object serverPlayer = victim.getClass().getMethod("getHandle").invoke(victim);
            if (serverPlayer != null) {
               try {
                  Method setDeltaMovement = serverPlayer.getClass().getMethod("setDeltaMovement", Class.forName("org.bukkit.util.Vector"));
                  setDeltaMovement.invoke(serverPlayer, new Vector(0, 0, 0));
               } catch (Exception var22) {
                  try {
                     Class<?> vec3Class = Class.forName("net.minecraft.world.phys.Vec3");
                     Method setDeltaMovementx = serverPlayer.getClass().getMethod("setDeltaMovement", vec3Class);
                     Object zeroVec = null;

                     try {
                        Constructor<?> vec3Constructor = vec3Class.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE);
                        zeroVec = vec3Constructor.newInstance((double)0.0F, (double)0.0F, (double)0.0F);
                     } catch (Exception var20) {
                        try {
                           zeroVec = vec3Class.getField("ZERO").get((Object)null);
                        } catch (Exception var19) {
                        }
                     }

                     if (zeroVec != null) {
                        setDeltaMovementx.invoke(serverPlayer, zeroVec);
                     }
                  } catch (Exception var21) {
                     try {
                        Method setDeltaMovementx = serverPlayer.getClass().getMethod("setDeltaMovement", Double.TYPE, Double.TYPE, Double.TYPE);
                        setDeltaMovementx.invoke(serverPlayer, (double)0.0F, (double)0.0F, (double)0.0F);
                     } catch (Exception var18) {
                     }
                  }
               }
            }
         } catch (Exception var23) {
         }

         knockedBackPlayers.add(name);
         this.advancedKnockback.applyKnockback(victim, dx, dz, strength, () -> {
            knockedBackPlayers.remove(name);
            this.nmsKbEndTime.remove(name);
            nmsKbEndTimeStatic.remove(name);
         });
      }

   }

   private void applyNMSKnockback(Player victim, double dx, double dz, double strength) {
      try {
         Object serverPlayer = victim.getClass().getMethod("getHandle").invoke(victim);
         if (serverPlayer == null) {
            this.plugin.getLogger().fine("[Knockback] ServerPlayer is null, falling back to task-based KB");
            this.applyKnockbackDirect(victim, victim.getName(), dx, dz, strength);
            return;
         }

         Class<?> entityClass = Class.forName("net.minecraft.world.entity.Entity");
         Location loc = victim.getLocation();
         double bx = loc.getX();
         double by = loc.getY();
         double bz = loc.getZ();

         try {
            Method absMoveTo = serverPlayer.getClass().getMethod("absMoveTo", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
            absMoveTo.invoke(serverPlayer, bx, by, bz, loc.getYaw(), loc.getPitch());
         } catch (NoSuchMethodException var33) {
            Method setPos = serverPlayer.getClass().getMethod("setPos", Double.TYPE, Double.TYPE, Double.TYPE);
            setPos.invoke(serverPlayer, bx, by, bz);
         }

         double horizontalMultiplier = 0.45;
         double vx = dx * strength * horizontalMultiplier;
         double vz = dz * strength * horizontalMultiplier;
         boolean victimOnGround = this.onGround(loc);
         double vy = victimOnGround ? 0.3 : 0.1;
         Logger var10000 = this.plugin.getLogger();
         String var10001 = victim.getName();
         var10000.fine("[Knockback] " + var10001 + " vx=" + String.format("%.3f", vx) + " vy=" + String.format("%.3f", vy) + " vz=" + String.format("%.3f", vz) + " str=" + String.format("%.2f", strength) + " ground=" + victimOnGround);

         try {
            Class<?> vec3Class = Class.forName("net.minecraft.world.phys.Vec3");
            Constructor<?> vec3Ctor = vec3Class.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE);
            Object vel = vec3Ctor.newInstance(vx, vy, vz);
            Method setDeltaMovement = entityClass.getDeclaredMethod("setDeltaMovement", vec3Class);
            setDeltaMovement.setAccessible(true);
            setDeltaMovement.invoke(serverPlayer, vel);
         } catch (Exception e) {
            this.plugin.getLogger().fine("[Knockback] setDeltaMovement failed: " + e.getMessage());
         }

         try {
            for(Class<?> c = serverPlayer.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
               try {
                  Field hm = c.getDeclaredField("hurtMarked");
                  hm.setAccessible(true);
                  hm.setBoolean(serverPlayer, true);
                  break;
               }
            }
         } catch (Exception var35) {
         }

         try {
            this.plugin.getSimpleFakePlayerManager().getNMSHandler().sendVelocityPacket(serverPlayer, vx, vy, vz);
         } catch (Exception var311) {
         }

         try {
            this.plugin.getSimpleFakePlayerManager().getNMSHandler().sendHurtAnimationPacket(serverPlayer, loc.getYaw());
         } catch (Exception var30) {
         }

         long kbEndTime = System.currentTimeMillis() + 300L;
         this.nmsKbEndTime.put(victim.getName(), kbEndTime);
         nmsKbEndTimeStatic.put(victim.getName(), kbEndTime);
         knockedBackPlayers.add(victim.getName());
         TaskHandle old = (TaskHandle)this.kbTasks.remove(victim.getName());
         if (old != null) {
            old.cancel();
         }
      } catch (Exception var31) {
         this.plugin.getLogger().fine("[Knockback] Vanilla knockback failed, using fallback: " + var31.getMessage());
         var31.printStackTrace();
         this.applyKnockbackDirect(victim, victim.getName(), dx, dz, strength);
      }

   }

   private void startNMSKnockbackTask(final String name, final Player victim) {
      TaskHandle old = (TaskHandle)this.kbTasks.remove(name);
      if (old != null) {
         old.cancel();
      }

      TaskHandle task;
      if (this.isFolia) {
         ScheduledTask foliaTask = Bukkit.getRegionScheduler().runAtFixedRate(this.plugin, victim.getLocation(), (t) -> this.runNMSKnockbackTick(name, victim), 1L, 1L);
         task = new TaskHandle(foliaTask);
      } else {
         BukkitTask bukkitTask = (new BukkitRunnable() {
            public void run() {
               if (!FakePlayerDamageListener.this.runNMSKnockbackTick(name, victim)) {
                  this.cancel();
                  FakePlayerDamageListener.this.kbTasks.remove(name);
                  FakePlayerDamageListener.knockedBackPlayers.remove(name);
               }

            }
         }).runTaskTimer(this.plugin, 1L, 1L);
         task = new TaskHandle(bukkitTask);
      }

      this.kbTasks.put(name, task);
   }

   private boolean runNMSKnockbackTick(String name, Player victim) {
      SimpleFakePlayerManager.FakePlayerData d = this.plugin.getSimpleFakePlayerManager().getFakePlayer(name);
      if (d != null && d.getPlayer().isOnline() && !(Boolean)this.dead.getOrDefault(name, false)) {
         Player player = d.getPlayer();
         World world = player.getWorld();
         SimpleNMSHandler nmsHandler = this.plugin.getSimpleFakePlayerManager().getNMSHandler();

         try {
            Object serverPlayer = player.getClass().getMethod("getHandle").invoke(player);
            if (serverPlayer == null) {
               return true;
            }

            Class<?> vec3Class = Class.forName("net.minecraft.world.phys.Vec3");
            Method getDeltaMovement = serverPlayer.getClass().getMethod("getDeltaMovement");
            getDeltaMovement.setAccessible(true);
            Object delta = getDeltaMovement.invoke(serverPlayer);
            Method xMethod = vec3Class.getMethod("x");
            Method yMethod = vec3Class.getMethod("y");
            Method zMethod = vec3Class.getMethod("z");
            double vx = (Double)xMethod.invoke(delta);
            double vy = (Double)yMethod.invoke(delta);
            double vz = (Double)zMethod.invoke(delta);
            double oldX = (double)0.0F;
            double oldY = (double)0.0F;
            double oldZ = (double)0.0F;

            try {
               Object pos = this.invokeMethodRecursive(serverPlayer, "getPos");
               oldX = (Double)this.invokeMethod(pos, "x");
               oldY = (Double)this.invokeMethod(pos, "y");
               oldZ = (Double)this.invokeMethod(pos, "z");
            } catch (Exception var46) {
               Location loc = player.getLocation();
               oldX = loc.getX();
               oldY = loc.getY();
               oldZ = loc.getZ();
            }

            boolean onGround = false;

            try {
               onGround = (Boolean)this.invokeMethodRecursive(serverPlayer, "isOnGround");
            } catch (Exception var45) {
               onGround = this.isSolidBlockAt(world, oldX, oldY - 0.1, oldZ);
            }

            if (!onGround) {
               vy -= 0.08;
               if (vy < (double)-3.0F) {
                  vy = (double)-3.0F;
               }
            }

            double friction;
            if (!onGround) {
               friction = 0.91;
            } else {
               friction = 0.6;
            }

            vx *= friction;
            vz *= friction;
            double newX = oldX;
            double newY = oldY;
            double newZ = oldZ;
            if (Math.abs(vx) > 1.0E-4) {
               double tryX = oldX + vx;
               if (!this.wouldCollide(world, tryX, oldY, oldZ) && !this.wouldCollide(world, tryX, oldY + 1.6, oldZ)) {
                  newX = tryX;
               } else {
                  vx = (double)0.0F;
               }
            }

            if (Math.abs(vz) > 1.0E-4) {
               double tryZ = oldZ + vz;
               if (!this.wouldCollide(world, newX, oldY, tryZ) && !this.wouldCollide(world, newX, oldY + 1.6, tryZ)) {
                  newZ = tryZ;
               } else {
                  vz = (double)0.0F;
               }
            }

            if (Math.abs(vy) > 1.0E-4) {
               double tryY = oldY + vy;
               if (vy > (double)0.0F && this.wouldCollide(world, newX, tryY + 1.9, newZ)) {
                  vy = (double)0.0F;
                  tryY = oldY;
               }

               if (vy < (double)0.0F) {
                  if (!this.wouldCollide(world, newX, tryY, newZ) && !this.wouldCollide(world, newX, tryY - 0.05, newZ)) {
                     newY = tryY;
                  } else {
                     vy *= -0.3;
                     tryY = oldY + vy;
                     if (Math.abs(vy) < 0.02) {
                        vy = (double)0.0F;
                        tryY = Math.floor(tryY) + (double)1.0F;
                        onGround = true;
                     }
                  }
               } else {
                  newY = tryY;
               }
            }

            try {
               this.invokeMethodWithArgs(serverPlayer, "setPos", newX, newY, newZ);
               this.invokeMethodWithArgs(serverPlayer, "setOnGround", onGround);
            } catch (Exception var44) {
               this.plugin.getLogger().fine("[Knockback] Could not set position: " + var44.getMessage());
            }

            try {
               Object newDelta = vec3Class.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE).newInstance(vx, vy, vz);
               this.invokeMethodWithArgs(serverPlayer, "setDeltaMovement", newDelta);
            } catch (Exception var43) {
               this.plugin.getLogger().fine("[Knockback] Could not set velocity: " + var43.getMessage());
            }

            Location newLoc = new Location(world, newX, newY, newZ, player.getLocation().getYaw(), player.getLocation().getPitch());
            nmsHandler.updatePosition(d.getPlayer(), newLoc, true);
            this.updateTakeoverLocation(name, newLoc);
            double newSpeed = Math.sqrt(vx * vx + vz * vz);
            boolean shouldEnd = newSpeed < 0.005 && Math.abs(vy) < 0.05 && onGround;
            if (shouldEnd) {
               this.plugin.getLogger().fine("[Knockback] KB ended for " + name);

               try {
                  double groundY = Math.floor(newY) + (double)1.0F;
                  this.invokeMethodWithArgs(serverPlayer, "setPos", newX, groundY, newZ);
                  this.invokeMethodWithArgs(serverPlayer, "setOnGround", true);
                  Object zeroDelta = vec3Class.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE).newInstance(0, 0, 0);
                  this.invokeMethodWithArgs(serverPlayer, "setDeltaMovement", zeroDelta);
                  nmsHandler.updatePosition(d.getPlayer(), new Location(world, newX, groundY, newZ, player.getLocation().getYaw(), player.getLocation().getPitch()), true);
               } catch (Exception var42) {
               }

               return true;
            }
         } catch (Exception var47) {
            this.plugin.getLogger().fine("[Knockback] Error in knockback tick: " + var47.getMessage());
            var47.printStackTrace();
         }

         return false;
      } else {
         return true;
      }
   }

   private void startKnockbackPositionTracking(final String name, Player victim, final double vx, final double vy, final double vz) {
      TaskHandle old = (TaskHandle)this.kbTasks.remove(name);
      if (old != null) {
         old.cancel();
      }

      final Location startLoc = victim.getLocation().clone();
      final World world = startLoc.getWorld();
      this.plugin.getLogger().fine("[Knockback] Starting position tracking: vx=" + vx + ", vy=" + vy + ", vz=" + vz);
      TaskHandle task;
      if (this.isFolia) {
         ScheduledTask foliaTask = Bukkit.getRegionScheduler().runAtFixedRate(this.plugin, victim.getLocation(), (t) -> this.runKnockbackMove(name, startLoc, vx, vy, vz, world), 1L, 1L);
         task = new TaskHandle(foliaTask);
      } else {
         BukkitTask bukkitTask = (new BukkitRunnable() {
            double px = startLoc.getX();
            double py = startLoc.getY();
            double pz = startLoc.getZ();
            double cvx = vx;
            double cvy = vy;
            double cvz = vz;
            int tick = 0;

            public void run() {
               ++this.tick;
               SimpleFakePlayerManager.FakePlayerData d = FakePlayerDamageListener.this.plugin.getSimpleFakePlayerManager().getFakePlayer(name);
               if (d != null && d.getPlayer().isOnline() && !(Boolean)FakePlayerDamageListener.this.dead.getOrDefault(name, false)) {
                  this.cvy -= 0.08;
                  if (this.cvy < (double)-3.0F) {
                     this.cvy = (double)-3.0F;
                  }

                  this.cvx *= 0.92;
                  this.cvz *= 0.92;
                  double nx = this.px;
                  double ny = this.py;
                  double nz = this.pz;
                  double tryX = this.px + this.cvx;
                  if (!FakePlayerDamageListener.this.isSolidBlockAt(world, tryX, this.py, this.pz) && !FakePlayerDamageListener.this.isSolidBlockAt(world, tryX, this.py + (double)1.0F, this.pz)) {
                     nx = tryX;
                  } else {
                     this.cvx = (double)0.0F;
                  }

                  double tryZ = this.pz + this.cvz;
                  if (!FakePlayerDamageListener.this.isSolidBlockAt(world, nx, this.py, tryZ) && !FakePlayerDamageListener.this.isSolidBlockAt(world, nx, this.py + (double)1.0F, tryZ)) {
                     nz = tryZ;
                  } else {
                     this.cvz = (double)0.0F;
                  }

                  double tryY = this.py + this.cvy;
                  if (this.cvy > (double)0.0F && (FakePlayerDamageListener.this.isSolidBlockAt(world, nx, tryY + 1.8, nz) || FakePlayerDamageListener.this.isSolidBlockAt(world, nx, tryY + 1.9, nz))) {
                     this.cvy = (double)0.0F;
                     tryY = this.py;
                  }

                  if (this.cvy < (double)0.0F) {
                     boolean groundBelow = FakePlayerDamageListener.this.isSolidBlockAt(world, nx, tryY - 0.1, nz);
                     if (groundBelow) {
                        double groundY = FakePlayerDamageListener.this.findNearestGround(world, nx, tryY, nz);
                        if (tryY <= groundY + 0.1) {
                           ny = groundY;
                           this.cvy = (double)0.0F;
                           this.cvx *= (double)0.5F;
                           this.cvz *= (double)0.5F;
                        } else {
                           ny = tryY;
                        }
                     } else {
                        ny = tryY;
                     }
                  } else {
                     ny = tryY;
                  }

                  if (FakePlayerDamageListener.this.isSolidBlockAt(world, nx, ny, nz) || FakePlayerDamageListener.this.isSolidBlockAt(world, nx, ny + (double)1.0F, nz)) {
                     nx = this.px;
                     ny = this.py;
                     nz = this.pz;
                     this.cvx = (double)0.0F;
                     this.cvy = (double)0.0F;
                     this.cvz = (double)0.0F;
                  }

                  this.px = nx;
                  this.py = ny;
                  this.pz = nz;
                  Location newLoc = new Location(world, this.px, this.py, this.pz, startLoc.getYaw(), startLoc.getPitch());
                  FakePlayerDamageListener.this.plugin.getSimpleFakePlayerManager().getNMSHandler().updatePosition(d.getPlayer(), newLoc, true);
                  FakePlayerDamageListener.this.updateTakeoverLocation(name, newLoc);
                  double speed = Math.sqrt(this.cvx * this.cvx + this.cvz * this.cvz);
                  boolean onGround = FakePlayerDamageListener.this.isSolidBlockAt(world, this.px, this.py - 0.1, this.pz);
                  if (speed < 0.01 && Math.abs(this.cvy) < 0.1 && onGround && this.tick > 5) {
                     FakePlayerDamageListener.this.plugin.getLogger().fine("[Knockback] KB ended for " + name + " after " + this.tick + " ticks");
                     this.cancel();
                     FakePlayerDamageListener.this.kbTasks.remove(name);
                     FakePlayerDamageListener.knockedBackPlayers.remove(name);
                  } else if (this.tick > 20) {
                     this.cancel();
                     FakePlayerDamageListener.this.kbTasks.remove(name);
                     FakePlayerDamageListener.knockedBackPlayers.remove(name);
                  }
               } else {
                  this.cancel();
                  FakePlayerDamageListener.this.kbTasks.remove(name);
                  FakePlayerDamageListener.knockedBackPlayers.remove(name);
               }

            }
         }).runTaskTimer(this.plugin, 1L, 1L);
         task = new TaskHandle(bukkitTask);
      }

      this.kbTasks.put(name, task);
   }

   private void startKnockbackTracking(final String name, final Player victim, double initialVx, double initialVy, double initialVz) {
      TaskHandle existing = (TaskHandle)this.kbTasks.remove(name);
      if (existing != null) {
         existing.cancel();
      }

      TaskHandle task;
      if (this.isFolia) {
         ScheduledTask foliaTask = Bukkit.getRegionScheduler().runAtFixedRate(this.plugin, victim.getLocation(), (t) -> this.trackKnockbackTick(name, victim), 1L, 1L);
         task = new TaskHandle(foliaTask);
      } else {
         BukkitTask bukkitTask = (new BukkitRunnable() {
            int tick = 0;

            public void run() {
               ++this.tick;
               if (FakePlayerDamageListener.this.trackKnockbackTick(name, victim)) {
                  this.cancel();
                  FakePlayerDamageListener.this.kbTasks.remove(name);
                  FakePlayerDamageListener.knockedBackPlayers.remove(name);
               }

               if (this.tick > 20) {
                  this.cancel();
                  FakePlayerDamageListener.this.kbTasks.remove(name);
                  FakePlayerDamageListener.knockedBackPlayers.remove(name);
               }

            }
         }).runTaskTimer(this.plugin, 0L, 1L);
         task = new TaskHandle(bukkitTask);
      }

      this.kbTasks.put(name, task);
   }

   private boolean trackKnockbackTick(String name, Player victim) {
      try {
         Object serverPlayer = victim.getClass().getMethod("getHandle").invoke(victim);
         if (serverPlayer == null) {
            return true;
         } else {
            Class<?> vec3Class = Class.forName("net.minecraft.world.phys.Vec3");
            Method getDeltaMovement = serverPlayer.getClass().getMethod("getDeltaMovement");
            getDeltaMovement.setAccessible(true);
            Object delta = getDeltaMovement.invoke(serverPlayer);
            Method xMethod = vec3Class.getMethod("x");
            Method yMethod = vec3Class.getMethod("y");
            Method zMethod = vec3Class.getMethod("z");
            double vx = (Double)xMethod.invoke(delta);
            double vy = (Double)yMethod.invoke(delta);
            double vz = (Double)zMethod.invoke(delta);
            double speed = Math.sqrt(vx * vx + vz * vz);

            try {
               Object nmsHandler = this.plugin.getSimpleFakePlayerManager().getNMSHandler();
               if (nmsHandler != null) {
                  Method updatePosMethod = nmsHandler.getClass().getMethod("updatePosition", Player.class, Location.class, Boolean.TYPE);
                  updatePosMethod.setAccessible(true);
                  updatePosMethod.invoke(nmsHandler, victim, victim.getLocation(), true);
               }
            } catch (Exception var20) {
            }

            return speed < 0.02 && Math.abs(vy) < 0.1;
         }
      } catch (Exception var21) {
         return true;
      }
   }

   private void startKnockbackPositionBroadcast(final String name, Player victim, double kbdx, double kbdz, double kbStrength) {
      TaskHandle old = (TaskHandle)this.kbTasks.remove(name);
      if (old != null) {
         old.cancel();
      }

      knockedBackPlayers.add(name);
      final Location startLoc = victim.getLocation().clone();
      final World world = startLoc.getWorld();
      boolean onGround = this.isOnGround(world, startLoc.getX(), startLoc.getY(), startLoc.getZ());
      final double vx = kbdx * kbStrength * (double)1.5F;
      final double vz = kbdz * kbStrength * (double)1.5F;
      final double vy = onGround ? 0.4 : (double)0.25F;
      if (this.plugin.getConfigManager().isDebugEnabled()) {
         this.plugin.getLogger().fine("[Knockback] Starting KB task: X=" + vx + ", Y=" + vy + ", Z=" + vz + ", onGround=" + onGround);
      }

      TaskHandle task;
      if (this.isFolia) {
         ScheduledTask foliaTask = Bukkit.getRegionScheduler().runAtFixedRate(this.plugin, victim.getLocation(), (t) -> this.runKnockbackMove(name, startLoc, vx, vy, vz, world), 1L, 1L);
         task = new TaskHandle(foliaTask);
      } else {
         BukkitTask bukkitTask = (new BukkitRunnable() {
            double px = startLoc.getX();
            double py = startLoc.getY();
            double pz = startLoc.getZ();
            double cvx = vx;
            double cvy = vy;
            double cvz = vz;
            int tick = 0;

            public void run() {
               ++this.tick;
               SimpleFakePlayerManager.FakePlayerData d = FakePlayerDamageListener.this.plugin.getSimpleFakePlayerManager().getFakePlayer(name);
               if (d != null && d.getPlayer().isOnline() && !(Boolean)FakePlayerDamageListener.this.dead.getOrDefault(name, false)) {
                  this.cvy -= 0.08;
                  if (this.cvy < (double)-3.0F) {
                     this.cvy = (double)-3.0F;
                  }

                  boolean wasOnGround = FakePlayerDamageListener.this.isSolidBlockAt(world, this.px, this.py - 0.1, this.pz);
                  if (!wasOnGround) {
                     this.cvx *= 0.91;
                     this.cvz *= 0.91;
                  } else {
                     this.cvx *= 0.6;
                     this.cvz *= 0.6;
                  }

                  double nx = this.px;
                  double ny = this.py;
                  double nz = this.pz;
                  double tryX = this.px + this.cvx;
                  boolean canMoveX = !FakePlayerDamageListener.this.isSolidBlockAt(world, tryX, this.py, this.pz) && !FakePlayerDamageListener.this.isSolidBlockAt(world, tryX, this.py + (double)1.0F, this.pz);
                  if (canMoveX) {
                     nx = tryX;
                  } else {
                     this.cvx = (double)0.0F;
                  }

                  double tryZ = this.pz + this.cvz;
                  boolean canMoveZ = !FakePlayerDamageListener.this.isSolidBlockAt(world, nx, this.py, tryZ) && !FakePlayerDamageListener.this.isSolidBlockAt(world, nx, this.py + (double)1.0F, tryZ);
                  if (canMoveZ) {
                     nz = tryZ;
                  } else {
                     this.cvz = (double)0.0F;
                  }

                  double tryY = this.py + this.cvy;
                  if (this.cvy > (double)0.0F) {
                     boolean hitCeiling = FakePlayerDamageListener.this.isSolidBlockAt(world, nx, tryY + 1.8, nz) || FakePlayerDamageListener.this.isSolidBlockAt(world, nx, tryY + 1.9, nz);
                     if (hitCeiling) {
                        this.cvy = (double)0.0F;
                        tryY = this.py;
                     }
                  }

                  if (this.cvy < (double)0.0F) {
                     boolean groundBelow = FakePlayerDamageListener.this.isSolidBlockAt(world, nx, tryY - 0.1, nz);
                     if (groundBelow) {
                        double groundY = FakePlayerDamageListener.this.findNearestGround(world, nx, tryY, nz);
                        if (tryY <= groundY + 0.1) {
                           ny = groundY;
                           this.cvy = (double)0.0F;
                           this.cvx *= (double)0.5F;
                           this.cvz *= (double)0.5F;
                        } else {
                           ny = tryY;
                        }
                     } else {
                        ny = tryY;
                     }
                  } else {
                     ny = tryY;
                  }

                  if (FakePlayerDamageListener.this.isSolidBlockAt(world, nx, ny, nz) || FakePlayerDamageListener.this.isSolidBlockAt(world, nx, ny + (double)1.0F, nz)) {
                     nx = this.px;
                     ny = this.py;
                     nz = this.pz;
                     this.cvx = (double)0.0F;
                     this.cvy = (double)0.0F;
                     this.cvz = (double)0.0F;
                  }

                  this.px = nx;
                  this.py = ny;
                  this.pz = nz;

                  try {
                     Object nmsHandler = FakePlayerDamageListener.this.plugin.getSimpleFakePlayerManager().getNMSHandler();
                     if (nmsHandler != null) {
                        Method updatePosMethod = nmsHandler.getClass().getMethod("updatePosition", Player.class, Location.class, Boolean.TYPE);
                        updatePosMethod.setAccessible(true);
                        Location currentLoc = d.getPlayer().getLocation();
                        Location newLoc = new Location(world, this.px, this.py, this.pz, currentLoc.getYaw(), currentLoc.getPitch());
                        updatePosMethod.invoke(nmsHandler, d.getPlayer(), newLoc, true);
                     }
                  } catch (Exception var21) {
                     FakePlayerDamageListener.this.plugin.getLogger().fine("[Knockback] Failed to update position: " + var21.getMessage());
                  }

                  double speed = Math.sqrt(this.cvx * this.cvx + this.cvz * this.cvz);
                  boolean isOnGroundNow = FakePlayerDamageListener.this.isSolidBlockAt(world, this.px, this.py - 0.1, this.pz);
                  if (speed < 0.02 && isOnGroundNow && this.tick > 10) {
                     if (FakePlayerDamageListener.this.plugin.getConfigManager().isDebugEnabled()) {
                        FakePlayerDamageListener.this.plugin.getLogger().fine("[Knockback] KB ended for " + name + " after " + this.tick + " ticks");
                     }

                     this.cancel();
                     FakePlayerDamageListener.this.kbTasks.remove(name);
                     FakePlayerDamageListener.knockedBackPlayers.remove(name);
                  } else if (this.tick > 30) {
                     if (FakePlayerDamageListener.this.plugin.getConfigManager().isDebugEnabled()) {
                        FakePlayerDamageListener.this.plugin.getLogger().fine("[Knockback] KB timeout for " + name + " after " + this.tick + " ticks");
                     }

                     this.cancel();
                     FakePlayerDamageListener.this.kbTasks.remove(name);
                     FakePlayerDamageListener.knockedBackPlayers.remove(name);
                  }
               } else {
                  this.cancel();
                  FakePlayerDamageListener.this.kbTasks.remove(name);
                  FakePlayerDamageListener.knockedBackPlayers.remove(name);
               }

            }
         }).runTaskTimer(this.plugin, 1L, 1L);
         task = new TaskHandle(bukkitTask);
      }

      this.kbTasks.put(name, task);
   }

   private boolean wouldCollide(World world, double x, double y, double z) {
      try {
         Material m = world.getBlockAt((int)Math.floor(x), (int)Math.floor(y), (int)Math.floor(z)).getType();
         return m.isSolid() && !this.isPassthrough(m);
      } catch (Exception var9) {
         return false;
      }
   }

   private double findGroundBelow(World world, double x, double y, double z) {
      int startY = (int)Math.floor(y);
      int minY = Math.max(world.getMinHeight(), startY - 10);

      for(int checkY = startY; checkY >= minY; --checkY) {
         Block below = world.getBlockAt((int)Math.floor(x), checkY - 1, (int)Math.floor(z));
         Block at = world.getBlockAt((int)Math.floor(x), checkY, (int)Math.floor(z));
         if (below.getType().isSolid() && !at.getType().isSolid()) {
            return (double)checkY;
         }
      }

      return (double)-1.0F;
   }

   private void applyKnockbackFromEntity(Player victim, String name, Entity damager) {
      if (this.plugin.getConfigManager().isDebugEnabled()) {
         this.plugin.getLogger().fine("[Knockback] Applying NMS knockback to " + name + " from entity " + damager.getName());
      }

      TaskHandle old = (TaskHandle)this.kbTasks.remove(name);
      if (old != null) {
         old.cancel();
      }

      double dx = victim.getLocation().getX() - damager.getLocation().getX();
      double dz = victim.getLocation().getZ() - damager.getLocation().getZ();
      double len = Math.sqrt(dx * dx + dz * dz);
      if (len > 0.001) {
         dx /= len;
         dz /= len;
      } else {
         float yaw = damager.getLocation().getYaw();
         double rad = Math.toRadians((double)yaw);
         dx = -Math.sin(rad);
         dz = Math.cos(rad);
      }

      String damagerType = damager.getType().name();
      double str = (double)2.0F;
      switch (damagerType) {
         case "SNOWBALL":
         case "EGG":
            str = 0.3;
            break;
         case "ARROW":
         case "SPECTRAL_ARROW":
         case "TIPPED_ARROW":
            str = (double)0.5F;
            break;
         case "SHULKER_BULLET":
            str = 0.7;
            break;
         case "IRON_GOLEM":
         case "RAVAGER":
            str = (double)1.5F;
            break;
         case "WITHER_SKULL":
         case "DRAGON_FIREBALL":
            str = 1.2;
      }

      if (!this.onGround(victim.getLocation())) {
         str *= (double)0.5F;
      }

      if (str > (double)2.0F) {
         str = (double)2.0F;
      }

      if (this.plugin.getConfigManager().isDebugEnabled()) {
         this.plugin.getLogger().fine("[Knockback] Entity knockback from " + damagerType + ": strength=" + str);
      }

      this.applyNMSKnockback(victim, dx, dz, str);
      long kbEndTime = System.currentTimeMillis() + 300L;
      this.nmsKbEndTime.put(name, kbEndTime);
      nmsKbEndTimeStatic.put(name, kbEndTime);
   }

   private void applyKnockbackDirect(Player victim, final String name, double dx, double dz, double str) {
      final Location startLoc = victim.getLocation().clone();
      final World world = startLoc.getWorld();
      double horizontalMultiplier = (double)5.0F;
      final double vx = dx * str * horizontalMultiplier;
      final double vz = dz * str * horizontalMultiplier;
      final double vy = this.onGround(startLoc) ? 0.4 : (double)0.25F;
      if (this.plugin.getConfigManager().isDebugEnabled()) {
         Logger var10000 = this.plugin.getLogger();
         String var10001 = String.format("%.4f", vx);
         var10000.info("[Knockback Direct] vx=" + var10001 + ", vy=" + String.format("%.4f", vy) + ", vz=" + String.format("%.4f", vz));
      }

      TaskHandle task;
      if (this.isFolia) {
         ScheduledTask foliaTask = Bukkit.getRegionScheduler().runAtFixedRate(this.plugin, victim.getLocation(), (t) -> this.runKnockbackMove(name, startLoc, vx, vy, vz, world), 1L, 1L);
         task = new TaskHandle(foliaTask);
      } else {
         BukkitTask bukkitTask = (new BukkitRunnable() {
            double px = startLoc.getX();
            double py = startLoc.getY();
            double pz = startLoc.getZ();
            double cvx = vx;
            double cvy = vy;
            double cvz = vz;
            int tick = 0;

            public void run() {
               ++this.tick;
               SimpleFakePlayerManager.FakePlayerData d = FakePlayerDamageListener.this.plugin.getSimpleFakePlayerManager().getFakePlayer(name);
               if (d != null && d.getPlayer().isOnline() && !(Boolean)FakePlayerDamageListener.this.dead.getOrDefault(name, false)) {
                  this.cvy -= 0.08;
                  if (this.cvy < (double)-3.0F) {
                     this.cvy = (double)-3.0F;
                  }

                  boolean onGroundNow = FakePlayerDamageListener.this.isSolidBlockAt(world, this.px, this.py - 0.05, this.pz);
                  double friction = onGroundNow ? 0.6 : 0.91;
                  this.cvx *= friction;
                  this.cvz *= friction;
                  double nx = this.px;
                  double ny = this.py;
                  double nz = this.pz;
                  double tryX = this.px + this.cvx;
                  if (!FakePlayerDamageListener.this.isSolidBlockAt(world, tryX, this.py, this.pz) && !FakePlayerDamageListener.this.isSolidBlockAt(world, tryX, this.py + (double)1.0F, this.pz)) {
                     nx = tryX;
                  } else {
                     this.cvx = (double)0.0F;
                  }

                  double tryZ = this.pz + this.cvz;
                  if (!FakePlayerDamageListener.this.isSolidBlockAt(world, nx, this.py, tryZ) && !FakePlayerDamageListener.this.isSolidBlockAt(world, nx, this.py + (double)1.0F, tryZ)) {
                     nz = tryZ;
                  } else {
                     this.cvz = (double)0.0F;
                  }

                  double tryY = this.py + this.cvy;
                  if (this.cvy > (double)0.0F && (FakePlayerDamageListener.this.isSolidBlockAt(world, nx, tryY + 1.8, nz) || FakePlayerDamageListener.this.isSolidBlockAt(world, nx, tryY + 1.9, nz))) {
                     this.cvy = (double)0.0F;
                     tryY = this.py + this.cvy;
                  }

                  if (this.cvy < (double)0.0F) {
                     boolean groundBelow = FakePlayerDamageListener.this.isSolidBlockAt(world, nx, tryY - 0.1, nz);
                     if (groundBelow) {
                        double groundY = FakePlayerDamageListener.this.findNearestGround(world, nx, tryY, nz);
                        if (tryY <= groundY + 0.1) {
                           ny = groundY;
                           this.cvy = (double)0.0F;
                           this.cvx *= (double)0.5F;
                           this.cvz *= (double)0.5F;
                        } else {
                           ny = tryY;
                        }
                     } else {
                        ny = tryY;
                     }
                  } else {
                     ny = tryY;
                  }

                  if (FakePlayerDamageListener.this.isSolidBlockAt(world, nx, ny, nz) || FakePlayerDamageListener.this.isSolidBlockAt(world, nx, ny + (double)1.0F, nz)) {
                     nx = this.px;
                     ny = this.py;
                     nz = this.pz;
                     this.cvx = (double)0.0F;
                     this.cvy = (double)0.0F;
                     this.cvz = (double)0.0F;
                  }

                  this.px = nx;
                  this.py = ny;
                  this.pz = nz;
                  Location newLoc = new Location(world, this.px, this.py, this.pz, startLoc.getYaw(), startLoc.getPitch());
                  FakePlayerDamageListener.this.plugin.getSimpleFakePlayerManager().getNMSHandler().updatePosition(d.getPlayer(), newLoc, true);
                  FakePlayerDamageListener.this.updateTakeoverLocation(name, newLoc);
                  double speed = Math.sqrt(this.cvx * this.cvx + this.cvz * this.cvz);
                  if (speed < 0.005 && Math.abs(this.cvy) < 0.03) {
                     this.cancel();
                     FakePlayerDamageListener.this.kbTasks.remove(name);
                     FakePlayerDamageListener.knockedBackPlayers.remove(name);
                  }

                  if (this.tick > 15) {
                     this.cancel();
                     FakePlayerDamageListener.this.kbTasks.remove(name);
                     FakePlayerDamageListener.knockedBackPlayers.remove(name);
                  }
               } else {
                  this.cancel();
                  FakePlayerDamageListener.this.kbTasks.remove(name);
                  FakePlayerDamageListener.knockedBackPlayers.remove(name);
               }

            }
         }).runTaskTimer(this.plugin, 0L, 1L);
         task = new TaskHandle(bukkitTask);
      }

      this.kbTasks.put(name, task);
   }

   private boolean onGround(Location loc) {
      World w = loc.getWorld();
      double x = loc.getX();
      double y = loc.getY();
      double z = loc.getZ();
      return this.isSolidBlockAt(w, x, y - 0.1, z) || this.isSolidBlockAt(w, x - 0.3, y - 0.1, z - 0.3) || this.isSolidBlockAt(w, x + 0.3, y - 0.1, z + 0.3);
   }

   private boolean isSolidBlockAt(World w, double x, double y, double z) {
      try {
         Material m = w.getBlockAt((int)Math.floor(x), (int)Math.floor(y), (int)Math.floor(z)).getType();
         return m.isSolid() && !this.isPassthrough(m);
      } catch (Exception var9) {
         return false;
      }
   }

   private double findNearestGround(World w, double x, double y, double z) {
      int startY = (int)Math.floor(y);
      int minX = Math.max(w.getMinHeight(), startY - 5);

      for(int checkY = startY; checkY >= minX; --checkY) {
         Block below = w.getBlockAt((int)Math.floor(x), checkY - 1, (int)Math.floor(z));
         Block at = w.getBlockAt((int)Math.floor(x), checkY, (int)Math.floor(z));
         if (below.getType().isSolid() && !at.getType().isSolid()) {
            return (double)checkY;
         }
      }

      return y;
   }

   private void runKnockbackMove(String name, Location startLoc, double vx, double vy, double vz, World world) {
      KnockbackState state = (KnockbackState)this.knockbackStates.computeIfAbsent(name, (k) -> new KnockbackState(startLoc, vx, vy, vz));
      ++state.t;
      SimpleFakePlayerManager.FakePlayerData d = this.plugin.getSimpleFakePlayerManager().getFakePlayer(name);
      if (d != null && d.getPlayer().isOnline() && !(Boolean)this.dead.getOrDefault(name, false)) {
         state.vy -= 0.08;
         if (state.vy < (double)-3.0F) {
            state.vy = (double)-3.0F;
         }

         state.vx *= 0.91;
         state.vz *= 0.91;
         double nx = state.px;
         double ny = state.py;
         double nz = state.pz;
         double tryX = state.px + state.vx;
         if (!this.isSolidBlockAt(world, tryX, state.py, state.pz) && !this.isSolidBlockAt(world, tryX, state.py + (double)1.0F, state.pz)) {
            nx = tryX;
         } else {
            state.vx = (double)0.0F;
         }

         double tryZ = state.pz + state.vz;
         if (!this.isSolidBlockAt(world, nx, state.py, tryZ) && !this.isSolidBlockAt(world, nx, state.py + (double)1.0F, tryZ)) {
            nz = tryZ;
         } else {
            state.vz = (double)0.0F;
         }

         double tryY = state.py + state.vy;
         if (state.vy > (double)0.0F && (this.isSolidBlockAt(world, nx, tryY + 1.8, nz) || this.isSolidBlockAt(world, nx, tryY + 1.9, nz))) {
            state.vy = (double)0.0F;
            tryY = state.py + state.vy;
         }

         if (state.vy < (double)0.0F) {
            boolean groundBelow = this.isSolidBlockAt(world, nx, tryY - 0.1, nz);
            if (groundBelow) {
               double groundY = this.findNearestGround(world, nx, tryY, nz);
               if (tryY <= groundY + 0.1) {
                  ny = groundY;
                  state.vy = (double)0.0F;
                  state.vx *= (double)0.5F;
                  state.vz *= (double)0.5F;
               } else {
                  ny = tryY;
               }
            } else {
               ny = tryY;
            }
         } else {
            ny = tryY;
         }

         if (this.isSolidBlockAt(world, nx, ny, nz) || this.isSolidBlockAt(world, nx, ny + (double)1.0F, nz)) {
            nx = state.px;
            ny = state.py;
            nz = state.pz;
            state.vx = (double)0.0F;
            state.vy = (double)0.0F;
            state.vz = (double)0.0F;
         }

         state.px = nx;
         state.py = ny;
         state.pz = nz;
         Location newLoc = new Location(world, state.px, state.py, state.pz, startLoc.getYaw(), startLoc.getPitch());
         this.plugin.getSimpleFakePlayerManager().getNMSHandler().updatePosition(d.getPlayer(), newLoc, true);
         this.updateTakeoverLocation(name, newLoc);
         double speed = Math.sqrt(state.vx * state.vx + state.vz * state.vz);
         if (speed < 0.01 && Math.abs(state.vy) < 0.1) {
            this.knockbackStates.remove(name);
            this.kbTasks.remove(name);
            knockedBackPlayers.remove(name);
         }

         if (state.t > 20) {
            this.knockbackStates.remove(name);
            this.kbTasks.remove(name);
            knockedBackPlayers.remove(name);
         }
      } else {
         this.knockbackStates.remove(name);
         this.kbTasks.remove(name);
         knockedBackPlayers.remove(name);
      }

   }

   private boolean bodyOverlapsBlock(World w, double x, double y, double z) {
      int minBX = this.fl(x - 0.3);
      int maxBX = this.fl(x + 0.3);
      int minBZ = this.fl(z - 0.3);
      int maxBZ = this.fl(z + 0.3);
      int minBY = this.fl(y + 0.01);
      int maxBY = this.fl(y + 1.79);

      for(int bx = minBX; bx <= maxBX; ++bx) {
         for(int bz = minBZ; bz <= maxBZ; ++bz) {
            for(int by = minBY; by <= maxBY; ++by) {
               Block b = w.getBlockAt(bx, by, bz);
               Material m = b.getType();
               if (!m.isAir() && m.isSolid() && !this.isPassthrough(m)) {
                  try {
                     VoxelShape shape = b.getCollisionShape();
                     if (shape != null) {
                        Collection<BoundingBox> boxes = shape.getBoundingBoxes();
                        if (boxes != null && !boxes.isEmpty()) {
                           for(BoundingBox box : boxes) {
                              double bMinX = (double)bx + box.getMinX();
                              double bMaxX = (double)bx + box.getMaxX();
                              double bMinY = (double)by + box.getMinY();
                              double bMaxY = (double)by + box.getMaxY();
                              double bMinZ = (double)bz + box.getMinZ();
                              double bMaxZ = (double)bz + box.getMaxZ();
                              double pMinX = x - 0.3;
                              double pMaxX = x + 0.3;
                              double pMaxY = y + 1.8;
                              double pMinZ = z - 0.3;
                              double pMaxZ = z + 0.3;
                              if (pMaxX > bMinX && pMinX < bMaxX && pMaxY > bMinY && y < bMaxY && pMaxZ > bMinZ && pMinZ < bMaxZ) {
                                 return true;
                              }
                           }
                           continue;
                        }
                     }
                  } catch (Exception var45) {
                  }

                  double bMinX = (double)bx;
                  double bMaxX = (double)(bx + 1);
                  double bMinY = (double)by;
                  double bMaxY = (double)(by + 1);
                  double bMinZ = (double)bz;
                  double bMaxZ = (double)(bz + 1);
                  double pMinX = x - 0.3;
                  double pMaxX = x + 0.3;
                  double pMaxY = y + 1.8;
                  double pMinZ = z - 0.3;
                  double pMaxZ = z + 0.3;
                  if (pMaxX > bMinX && pMinX < bMaxX && pMaxY > bMinY && y < bMaxY && pMaxZ > bMinZ && pMinZ < bMaxZ) {
                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   private boolean bodyOverlapsBlockAt(World w, double x, double y, double z) {
      int minBX = this.fl(x - 0.3);
      int maxBX = this.fl(x + 0.3);
      int minBZ = this.fl(z - 0.3);
      int maxBZ = this.fl(z + 0.3);
      int by = this.fl(y);

      for(int bx = minBX; bx <= maxBX; ++bx) {
         for(int bz = minBZ; bz <= maxBZ; ++bz) {
            Material m = w.getBlockAt(bx, by, bz).getType();
            if (m.isSolid() && !m.isAir() && !this.isPassthrough(m)) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean isInsideBlock(World w, double x, double y, double z) {
      return this.bodyOverlapsBlock(w, x, y, z);
   }

   private boolean isPassthrough(Material m) {
      if (!m.isAir() && m != Material.WATER && m != Material.LAVA) {
         if (m != Material.LADDER && m != Material.VINE) {
            String n = m.name();
            return n.contains("TORCH") || n.contains("SIGN") || n.contains("CARPET") || n.contains("BUTTON") || n.contains("PRESSURE_PLATE") || n.contains("RAIL") || n.contains("VINES") || n.contains("BANNER") || n.contains("FLOWER") || n.contains("TALL_GRASS") || n.contains("SHORT_GRASS") || n.contains("FERN") || n.contains("SAPLING") || n.contains("MUSHROOM") || n.contains("DEAD_BUSH") || n.contains("SNOW") || n.contains("LAYER");
         } else {
            return true;
         }
      } else {
         return true;
      }
   }

   private void syncNMSPosition(Player player) {
      try {
         Object serverPlayer = player.getClass().getMethod("getHandle").invoke(player);
         if (serverPlayer == null) {
            return;
         }

         Location loc = player.getLocation();

         try {
            Method setPosMethod = serverPlayer.getClass().getMethod("setPos", Double.TYPE, Double.TYPE, Double.TYPE);
            setPosMethod.invoke(serverPlayer, loc.getX(), loc.getY(), loc.getZ());
         } catch (Exception var10) {
            try {
               Method setPositionMethod = serverPlayer.getClass().getMethod("setPosition", Double.TYPE, Double.TYPE, Double.TYPE);
               setPositionMethod.invoke(serverPlayer, loc.getX(), loc.getY(), loc.getZ());
            } catch (Exception var9) {
            }
         }

         boolean onGround = this.onGround(loc);

         try {
            Method setOnGroundMethod = serverPlayer.getClass().getMethod("setOnGround", Boolean.TYPE);
            setOnGroundMethod.invoke(serverPlayer, onGround);
         } catch (NoSuchMethodException var8) {
            try {
               Method setOnGroundMethodx = serverPlayer.getClass().getDeclaredMethod("b", Boolean.TYPE);
               setOnGroundMethodx.setAccessible(true);
               setOnGroundMethodx.invoke(serverPlayer, onGround);
            } catch (Exception var7) {
            }
         }
      } catch (Exception var11) {
      }

   }

   private String getDeathMessage(String name, Player killer, EntityDamageEvent.DamageCause cause, Entity damager) {
      if (killer != null) {
         return name + " was slain by " + killer.getName();
      } else if (damager != null && !(damager instanceof Player)) {
         String var10000;
         if (damager instanceof LivingEntity) {
            LivingEntity le = (LivingEntity)damager;
            var10000 = le.getCustomName() != null ? le.getCustomName() : damager.getType().translationKey();
         } else {
            var10000 = damager.getType().translationKey();
         }

         String entityName = var10000;
         if (entityName.startsWith("entity.") || entityName.startsWith("block.")) {
            entityName = damager.getType().name();
         }

         return name + " was slain by " + entityName;
      } else if (cause != null) {
         switch (cause) {
            case FALL -> {
               return name + " hit the ground too hard";
            }
            case LAVA -> {
               return name + " tried to swim in lava";
            }
            case FIRE -> {
               return name + " went up in flames";
            }
            case FIRE_TICK -> {
               return name + " burned to death";
            }
            case VOID -> {
               return name + " fell into the void";
            }
            case DROWNING -> {
               return name + " drowned";
            }
            case SUFFOCATION -> {
               return name + " suffocated in a wall";
            }
            case STARVATION -> {
               return name + " starved to death";
            }
            case POISON -> {
               return name + " was poisoned";
            }
            case WITHER -> {
               return name + " withered away";
            }
            case CONTACT -> {
               return name + " was pricked to death";
            }
            case MAGIC -> {
               return name + " was killed by magic";
            }
            case PROJECTILE -> {
               return name + " was shot";
            }
            case ENTITY_EXPLOSION -> {
               return name + " blew up";
            }
            case BLOCK_EXPLOSION -> {
               return name + " was killed by an explosion";
            }
            case HOT_FLOOR -> {
               return name + " discovered the floor was lava";
            }
            case CRAMMING -> {
               return name + " was squished too much";
            }
            case FREEZE -> {
               return name + " froze to death";
            }
            case LIGHTNING -> {
               return name + " was struck by lightning";
            }
            case DRAGON_BREATH -> {
               return name + " was roasted by dragon breath";
            }
            case FLY_INTO_WALL -> {
               return name + " experienced kinetic energy";
            }
            default -> {
               return name + " died";
            }
         }
      } else {
         return name + " died";
      }
   }

   private void handleDeath(Player victim, String name, Player killer, EntityDamageEvent.DamageCause cause, Entity damager) {
      this.dead.put(name, true);
      TaskHandle kb = (TaskHandle)this.kbTasks.remove(name);
      if (kb != null) {
         kb.cancel();
      }

      this.knockbackStates.remove(name);
      Location deathLoc = victim.getLocation();
      victim.getWorld().playSound(deathLoc, Sound.ENTITY_PLAYER_DEATH, 1.0F, 1.0F);

      try {
         Object sp = victim.getClass().getMethod("getHandle").invoke(victim);
         Object ed = this.getEntityData(sp);
         if (ed != null) {
            this.setHealthMeta(ed, 0.0F);
            int eid = (Integer)sp.getClass().getMethod("getId").invoke(sp);
            this.sendMetaPkt(eid, ed);
         }
      } catch (Exception var20) {
      }

      try {
         String msg = this.getDeathMessage(name, killer, cause, damager);
         List<ItemStack> emptyDrops = new ArrayList();
         DamageSource src = DamageSource.builder(DamageType.GENERIC).build();
         PlayerDeathEvent deathEvent = new PlayerDeathEvent(victim, src, emptyDrops, 0, msg);
         Bukkit.getPluginManager().callEvent(deathEvent);
      } catch (Exception var19) {
      }

      try {
         PlayerInventory inv = victim.getInventory();

         for(ItemStack i : inv.getContents()) {
            if (i != null && !i.getType().isAir()) {
               deathLoc.getWorld().dropItemNaturally(deathLoc, i);
            }
         }

         for(ItemStack ix : inv.getArmorContents()) {
            if (ix != null && !ix.getType().isAir()) {
               deathLoc.getWorld().dropItemNaturally(deathLoc, ix);
            }
         }

         ItemStack off = inv.getItemInOffHand();
         if (off != null && !off.getType().isAir()) {
            deathLoc.getWorld().dropItemNaturally(deathLoc, off);
         }

         inv.clear();
         inv.setHelmet((ItemStack)null);
         inv.setChestplate((ItemStack)null);
         inv.setLeggings((ItemStack)null);
         inv.setBoots((ItemStack)null);
         inv.setItemInOffHand(new ItemStack(Material.AIR));
      } catch (Exception var21) {
      }

      UUID fakeUuid = victim.getUniqueId();
      boolean shouldLogout = false;
      boolean isTakeover = false;
      PlayerTakeoverData takeoverData = this.plugin.getTakeoverData();
      if (takeoverData != null && takeoverData.hasTakeover(fakeUuid)) {
         isTakeover = true;
         PlayerTakeoverData.TakeoverEntry entry = takeoverData.getTakeover(fakeUuid);
         if (entry != null) {
            entry.setDied(true);
            takeoverData.save();
         }

         boolean rustHookEnabled = this.plugin.getConfigManager() != null && this.plugin.getConfigManager().getConfig().getBoolean("rust-hook.enabled", false);
         boolean logoutOnDeath = this.plugin.getConfigManager() != null && this.plugin.getConfigManager().getConfig().getBoolean("rust-hook.logout-on-death", false);
         if (rustHookEnabled && logoutOnDeath) {
            boolean isPermanent = false;
            if (this.plugin.getRustHook() != null) {
               isPermanent = this.plugin.getRustHook().hasPermanentPermission(fakeUuid.toString());
            }

            if (!isPermanent && this.plugin.getLuckPermsHook() != null && this.plugin.getLuckPermsHook().isEnabled()) {
               try {
                  User user = this.plugin.getLuckPermsHook().getUserByUuid(fakeUuid);
                  if (user != null) {
                     String permNode = this.plugin.getConfigManager().getConfig().getString("rust-hook.permanent-permission-node", "glidespoofer.permanent");
                     isPermanent = user.getCachedData().getPermissionData().checkPermission(permNode).asBoolean();
                  }
               } catch (Exception var18) {
               }
            }

            shouldLogout = isPermanent;
         }
      }

      Consumer<Object> afterDeathTask = (t) -> {
         if (shouldLogout) {
            if (this.plugin.getConfigManager().isDebugEnabled()) {
               this.plugin.getLogger().info("[FakePlayerDeath] RustHook logout-on-death for " + name);
            }

            this.plugin.getSimpleFakePlayerManager().despawnFakePlayer(name, true);
            this.cleanup(name);
         } else {
            try {
               SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
               SimpleFakePlayerManager.FakePlayerData data = manager.getFakePlayer(name);
               if (data != null) {
                  Player fake = Bukkit.getPlayer(data.getUuid());
                  if (fake != null) {
                     Location respawnLoc = null;
                     if (this.plugin.getGuiListener() != null && this.plugin.getGuiListener().getGUI() != null) {
                        respawnLoc = this.plugin.getGuiListener().getGUI().getRandomFluctuationPoint();
                        if (respawnLoc == null) {
                           respawnLoc = this.plugin.getGuiListener().getGUI().getConfiguredSpawnLocation();
                        }
                     }

                     if (respawnLoc == null || respawnLoc.getWorld() == null) {
                        respawnLoc = deathLoc.getWorld().getSpawnLocation();
                     }

                     fake.teleport(respawnLoc);
                     fake.setHealth((double)20.0F);
                     fake.setFoodLevel(20);
                     fake.setFireTicks(0);
                     this.dead.remove(name);
                     this.health.put(name, (double)20.0F);

                     try {
                        Object sp = fake.getClass().getMethod("getHandle").invoke(fake);
                        int eid = (Integer)sp.getClass().getMethod("getId").invoke(sp);
                        Object destroyPkt = null;

                        try {
                           Class<?> destroyClass = Class.forName("net.minecraft.network.protocol.game.ClientboundRemoveEntitiesPacket");
                           destroyPkt = destroyClass.getConstructor(Integer.TYPE).newInstance(eid);
                        } catch (Exception var16) {
                           try {
                              Class<?> destroyClass = Class.forName("net.minecraft.network.protocol.game.PacketPlayOutEntityDestroy");
                              destroyPkt = destroyClass.getConstructor(int[].class).newInstance(new int[]{eid});
                           } catch (Exception var15) {
                           }
                        }

                        if (destroyPkt != null) {
                           for(Player viewer : Bukkit.getOnlinePlayers()) {
                              if (!this.plugin.getSimpleFakePlayerManager().isFakePlayer(viewer)) {
                                 this.sendPkt(viewer, destroyPkt);
                              }
                           }
                        }

                        Runnable respawnPackets = () -> {
                           try {
                              Object sp2 = fake.getClass().getMethod("getHandle").invoke(fake);
                              Class<?> nmsHandlerClass = this.plugin.getSimpleFakePlayerManager().getNMSHandler().getClass();
                              Method broadcastPlayerInfoMethod = null;

                              for(Method m : nmsHandlerClass.getDeclaredMethods()) {
                                 if (m.getName().equals("broadcastPlayerInfo") && m.getParameterCount() == 2) {
                                    broadcastPlayerInfoMethod = m;
                                    m.setAccessible(true);
                                    break;
                                 }
                              }

                              if (broadcastPlayerInfoMethod != null) {
                                 broadcastPlayerInfoMethod.invoke(this.plugin.getSimpleFakePlayerManager().getNMSHandler(), sp2, true);
                              }

                              try {
                                 Object level = null;

                                 for(String methodName : new String[]{"level", "getLevel", "serverLevel"}) {
                                    try {
                                       level = sp2.getClass().getMethod(methodName).invoke(sp2);
                                       break;
                                    } catch (Exception var22) {
                                    }
                                 }

                                 if (level == null) {
                                    this.plugin.getLogger().warning("[FakePlayerDeath] Could not get level from ServerPlayer");
                                 } else {
                                    Object chunkSource = null;

                                    for(String csMethod : new String[]{"getChunkSource", "chunkSource"}) {
                                       try {
                                          chunkSource = level.getClass().getMethod(csMethod).invoke(level);
                                          break;
                                       } catch (Exception var32) {
                                       }
                                    }

                                    if (chunkSource == null) {
                                       this.plugin.getLogger().warning("[FakePlayerDeath] Could not get chunkSource from level");
                                    } else {
                                       Object chunkMap = null;

                                       for(Field cmf : chunkSource.getClass().getDeclaredFields()) {
                                          cmf.setAccessible(true);

                                          try {
                                             Object v = cmf.get(chunkSource);
                                             if (v != null && v.getClass().getName().equals("net.minecraft.server.level.ChunkMap")) {
                                                chunkMap = v;
                                                break;
                                             }
                                          } catch (Exception var31) {
                                          }
                                       }

                                       if (chunkMap == null) {
                                          for(Field cmf : chunkSource.getClass().getDeclaredFields()) {
                                             cmf.setAccessible(true);
                                             if (cmf.getName().equals("chunkMap") || cmf.getName().equals("a")) {
                                                try {
                                                   chunkMap = cmf.get(chunkSource);
                                                   if (chunkMap != null) {
                                                      break;
                                                   }
                                                } catch (Exception var30) {
                                                }
                                             }
                                          }
                                       }

                                       if (chunkMap == null) {
                                          for(Method cmMethod : chunkSource.getClass().getDeclaredMethods()) {
                                             if (cmMethod.getName().equals("getChunkMap")) {
                                                cmMethod.setAccessible(true);

                                                try {
                                                   chunkMap = cmMethod.invoke(chunkSource);
                                                   break;
                                                } catch (Exception var29) {
                                                }
                                             }
                                          }
                                       }

                                       Object trackerEntry = null;
                                       if (chunkMap != null) {
                                          List<Field> allFields = new ArrayList();

                                          for(Class<?> cmClass = chunkMap.getClass(); cmClass != null && cmClass != Object.class; cmClass = cmClass.getSuperclass()) {
                                             allFields.addAll(Arrays.asList(cmClass.getDeclaredFields()));
                                          }

                                          for(Field f2 : allFields) {
                                             f2.setAccessible(true);

                                             try {
                                                Object val2 = f2.get(chunkMap);
                                                if (val2 instanceof Map) {
                                                   Object entry = ((Map)val2).get(eid);
                                                   if (entry != null) {
                                                      trackerEntry = entry;
                                                      break;
                                                   }
                                                }

                                                try {
                                                   Method getMethod = val2.getClass().getMethod("get", Integer.TYPE);
                                                   Object entry = getMethod.invoke(val2, eid);
                                                   if (entry != null) {
                                                      trackerEntry = entry;
                                                      break;
                                                   }
                                                } catch (Exception var27) {
                                                }

                                                if (!(val2 instanceof Map)) {
                                                   try {
                                                      Method getMethod = val2.getClass().getMethod("get", Object.class);
                                                      Object entry = getMethod.invoke(val2, eid);
                                                      if (entry != null) {
                                                         trackerEntry = entry;
                                                         break;
                                                      }
                                                   } catch (Exception var26) {
                                                   }
                                                }
                                             } catch (Exception var28) {
                                             }
                                          }
                                       }

                                       if (trackerEntry != null) {
                                          Object serverEntity = null;

                                          for(Field f : trackerEntry.getClass().getDeclaredFields()) {
                                             f.setAccessible(true);

                                             try {
                                                Object v = f.get(trackerEntry);
                                                if (v != null && v.getClass().getName().contains("ServerEntity")) {
                                                   serverEntity = v;
                                                   break;
                                                }
                                             } catch (Exception var25) {
                                             }
                                          }

                                          if (serverEntity != null) {
                                             for(Player viewer : Bukkit.getOnlinePlayers()) {
                                                if (!this.plugin.getSimpleFakePlayerManager().isFakePlayer(viewer)) {
                                                   Object viewerHandle = viewer.getClass().getMethod("getHandle").invoke(viewer);
                                                   boolean sent = false;

                                                   for(Method m : serverEntity.getClass().getDeclaredMethods()) {
                                                      String mName = m.getName();
                                                      if (mName.equals("sendCreatePacket") || mName.equals("sendPairingData") || mName.equals("sendSpawnPacket") || mName.equals("addPairing") || mName.equals("broadcastSpawnPacket") || mName.equals("sendChangesTo")) {
                                                         m.setAccessible(true);

                                                         try {
                                                            if (m.getParameterCount() == 1) {
                                                               m.invoke(serverEntity, viewerHandle);
                                                               sent = true;
                                                               break;
                                                            }
                                                         } catch (Exception var23) {
                                                         }
                                                      }
                                                   }

                                                   if (!sent) {
                                                      for(Method m : serverEntity.getClass().getDeclaredMethods()) {
                                                         m.setAccessible(true);
                                                         if (m.getParameterCount() == 1 && m.getParameterTypes()[0].getName().contains("ServerPlayer") && m.getReturnType() == Void.TYPE && !m.getName().equals("sendChangePacket")) {
                                                            try {
                                                               m.invoke(serverEntity, viewerHandle);
                                                               sent = true;
                                                               break;
                                                            } catch (Exception var24) {
                                                            }
                                                         }
                                                      }
                                                   }
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              } catch (Exception trackerEx) {
                                 this.plugin.getLogger().warning("[FakePlayerDeath] Entity tracker respawn failed: " + trackerEx.getMessage());
                              }

                              Object ed2 = this.getEntityData(sp2);
                              if (ed2 != null) {
                                 this.setHealthMeta(ed2, 20.0F);
                                 int eid2 = (Integer)sp2.getClass().getMethod("getId").invoke(sp2);
                                 List<?> allData = (List)ed2.getClass().getMethod("packAll").invoke(ed2);
                                 if (allData != null && !allData.isEmpty()) {
                                    Class<?> pktClass = Class.forName("net.minecraft.network.protocol.game.ClientboundSetEntityDataPacket");
                                    Object metaPkt = null;

                                    for(Constructor<?> c : pktClass.getDeclaredConstructors()) {
                                       c.setAccessible(true);
                                       if (c.getParameterCount() == 2 && c.getParameterTypes()[0] == Integer.TYPE) {
                                          try {
                                             metaPkt = c.newInstance(eid2, allData);
                                             break;
                                          } catch (Exception var21) {
                                          }
                                       }
                                    }

                                    if (metaPkt != null) {
                                       for(Player viewer : Bukkit.getOnlinePlayers()) {
                                          if (!this.plugin.getSimpleFakePlayerManager().isFakePlayer(viewer)) {
                                             this.sendPkt(viewer, metaPkt);
                                          }
                                       }
                                    }
                                 }
                              }
                           } catch (Exception ex) {
                              this.plugin.getLogger().warning("[FakePlayerDeath] Respawn packets failed: " + ex.getMessage());
                           }

                        };
                        if (this.isFolia) {
                           Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> respawnPackets.run(), 2L);
                        } else {
                           Bukkit.getScheduler().runTaskLater(this.plugin, respawnPackets, 2L);
                        }
                     } catch (Exception ex) {
                        this.plugin.getLogger().warning("[FakePlayerDeath] Respawn error: " + ex.getMessage());
                     }
                  } else {
                     this.plugin.getSimpleFakePlayerManager().despawnFakePlayer(name, true);
                     this.cleanup(name);
                  }
               } else {
                  this.plugin.getSimpleFakePlayerManager().despawnFakePlayer(name, true);
                  this.cleanup(name);
               }
            } catch (Exception var10) {
               this.plugin.getLogger().warning("[FakePlayerDeath] Failed to respawn " + name + ": " + var10.getMessage());
            }
         }

      };
      if (this.isFolia) {
         Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (t) -> afterDeathTask.accept(t), 20L);
      } else {
         Bukkit.getScheduler().runTaskLater(this.plugin, () -> afterDeathTask.accept((Object)null), 20L);
      }

   }

   private boolean isOnGround(World w, double x, double y, double z) {
      return this.isSol(w, x, y - 0.1, z) || this.isSol(w, x - 0.3, y - 0.1, z - 0.3) || this.isSol(w, x + 0.3, y - 0.1, z + 0.3);
   }

   private double findGroundAABB(World w, double x, double sy, double z) {
      double best = (double)w.getMinHeight();
      double[][] pts = new double[][]{{x, z}, {x - 0.3, z - 0.3}, {x + 0.3, z - 0.3}, {x - 0.3, z + 0.3}, {x + 0.3, z + 0.3}};

      for(double[] p : pts) {
         double g = this.findGround1(w, p[0], sy, p[1]);
         if (g > best) {
            best = g;
         }
      }

      return best <= (double)w.getMinHeight() ? sy : best;
   }

   private double findGround1(World w, double x, double sy, double z) {
      int sx = this.fl(x);
      int sz = this.fl(z);
      int isy = this.fl(sy);
      int minY = Math.max(w.getMinHeight(), isy - 30);

      for(int y = isy; y >= minY; --y) {
         if (w.getBlockAt(sx, y - 1, sz).getType().isSolid() && !w.getBlockAt(sx, y, sz).getType().isSolid()) {
            return (double)y;
         }
      }

      return (double)w.getMinHeight();
   }

   private Object getEntityData(Object sp) {
      try {
         return sp.getClass().getMethod("getEntityData").invoke(sp);
      } catch (Exception var5) {
         try {
            return sp.getClass().getMethod("getDataWatcher").invoke(sp);
         } catch (Exception var4) {
            return null;
         }
      }
   }

   private void setHealthMeta(Object ed, float val) {
      try {
         Class<?> lc = Class.forName("net.minecraft.world.entity.LivingEntity");
         Class<?> ac = Class.forName("net.minecraft.network.syncher.EntityDataAccessor");
         Method get = ed.getClass().getMethod("get", ac);
         Method set = ed.getClass().getMethod("set", ac, Object.class);

         for(Field f : lc.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers()) && ac.isAssignableFrom(f.getType())) {
               f.setAccessible(true);

               try {
                  Object a = f.get((Object)null);
                  Object v = get.invoke(ed, a);
                  if (v instanceof Float) {
                     set.invoke(ed, a, val);
                     return;
                  }
               } catch (Exception var13) {
               }
            }
         }
      } catch (Exception var14) {
      }

   }

   private void sendMetaPkt(int eid, Object ed) {
      try {
         List<?> data = null;

         try {
            data = (List)ed.getClass().getMethod("packDirty").invoke(ed);
         } catch (Exception var121) {
            try {
               data = (List)ed.getClass().getMethod("packAll").invoke(ed);
            } catch (Exception var11) {
            }
         }

         if (data == null || data.isEmpty()) {
            return;
         }

         Class<?> pc = Class.forName("net.minecraft.network.protocol.game.ClientboundSetEntityDataPacket");
         Object pkt = null;

         for(Constructor<?> c : pc.getDeclaredConstructors()) {
            c.setAccessible(true);
            if (c.getParameterCount() == 2 && c.getParameterTypes()[0] == Integer.TYPE) {
               try {
                  pkt = c.newInstance(eid, data);
                  break;
               } catch (Exception var13) {
               }
            }
         }

         if (pkt != null) {
            this.broadcastPkt(pkt);
         }
      } catch (Exception var14) {
      }

   }

   private void broadcastPkt(Object pkt) {
      for(Player on : Bukkit.getOnlinePlayers()) {
         if (!this.plugin.getSimpleFakePlayerManager().isFakePlayer(on)) {
            this.sendPkt(on, pkt);
         }
      }

   }

   private void sendPkt(Player p, Object pkt) {
      try {
         Object h = p.getClass().getMethod("getHandle").invoke(p);
         Object c = h.getClass().getField("connection").get(h);

         for(Method m : c.getClass().getMethods()) {
            if (m.getName().equals("send") && m.getParameterCount() == 1) {
               m.invoke(c, pkt);
               break;
            }
         }
      } catch (Exception var9) {
      }

   }

   private void sendVelocityPacket(Player victim, double vx, double vy, double vz) {
      try {
         Object serverPlayer = victim.getClass().getMethod("getHandle").invoke(victim);
         int entityId = (Integer)serverPlayer.getClass().getMethod("getId").invoke(serverPlayer);

         Class<?> packetClass;
         try {
            packetClass = Class.forName("net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket");
         } catch (ClassNotFoundException var20) {
            packetClass = Class.forName("net.minecraft.network.protocol.game.PacketPlayOutEntityVelocity");
         }

         Object vec3 = null;

         try {
            Class<?> vec3Class = Class.forName("net.minecraft.world.phys.Vec3");
            Constructor<?> vec3Constructor = vec3Class.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE);
            vec3 = vec3Constructor.newInstance(vx, vy, vz);
         } catch (Exception var19) {
            try {
               Class<?> vec3Classx = Class.forName("net.minecraft.world.phys.Vec3");
               Constructor<?> vec3Constructorx = vec3Classx.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE);
               vec3 = vec3Constructorx.newInstance(vx, vy, vz);
            } catch (Exception var18) {
            }
         }

         if (vec3 != null) {
            Object velocityPacket = null;

            for(Constructor<?> c : packetClass.getDeclaredConstructors()) {
               c.setAccessible(true);

               try {
                  if (c.getParameterCount() == 2) {
                     velocityPacket = c.newInstance(entityId, vec3);
                     break;
                  }
               } catch (Exception var211) {
               }
            }

            if (velocityPacket != null) {
               this.broadcastPkt(velocityPacket);
               this.plugin.getLogger().fine("[Knockback] Sent velocity packet: eid=" + entityId + ", vx=" + vx + ", vy=" + vy + ", vz=" + vz);
            }
         }
      } catch (Exception var23) {
         this.plugin.getLogger().fine("[Knockback] Could not send velocity packet: " + var23.getMessage());
      }

   }

   private boolean isSol(World w, double x, double y, double z) {
      Material m = w.getBlockAt(this.fl(x), this.fl(y), this.fl(z)).getType();
      if (!m.isAir() && m != Material.WATER && m != Material.LAVA && m != Material.LADDER && m != Material.VINE) {
         String n = m.name();
         return !n.contains("TORCH") && !n.contains("SIGN") && !n.contains("CARPET") && !n.contains("BUTTON") && !n.contains("PRESSURE_PLATE") && !n.contains("RAIL") && !n.contains("VINES") && !n.contains("BANNER") ? m.isSolid() : false;
      } else {
         return false;
      }
   }

   private double findActualGround(World w, double x, double startY, double z) {
      int sx = this.fl(x);
      int sz = this.fl(z);
      int isy = this.fl(startY);
      int minY = Math.max(w.getMinHeight(), isy - 60);

      for(int y = isy; y >= minY; --y) {
         if (w.getBlockAt(sx, y, sz).getType().isSolid() && !w.getBlockAt(sx, y + 1, sz).getType().isSolid()) {
            return (double)(y + 1);
         }
      }

      return (double)w.getMinHeight();
   }

   private void updateTakeoverLocation(String fakeName, Location loc) {
      PlayerTakeoverData takeoverData = this.plugin.getTakeoverData();
      if (takeoverData != null) {
         UUID realPlayerUuid = null;

         for(Map.Entry<String, PlayerTakeoverData.TakeoverEntry> entry : takeoverData.getAllTakeovers().entrySet()) {
            if (((PlayerTakeoverData.TakeoverEntry)entry.getValue()).getFakePlayerName().equals(fakeName)) {
               try {
                  realPlayerUuid = UUID.fromString(((PlayerTakeoverData.TakeoverEntry)entry.getValue()).getRealPlayerUuid());
                  break;
               } catch (Exception var8) {
               }
            }
         }

         if (realPlayerUuid != null) {
            takeoverData.updateLocation(realPlayerUuid, loc.getWorld() != null ? loc.getWorld().getName() : "world", loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch());
         }
      }

   }

   private boolean respawnPermanentFake(String fakeName, UUID realPlayerUuid) {
      PlayerTakeoverData takeoverData = this.plugin.getTakeoverData();
      if (takeoverData != null && takeoverData.hasTakeover(realPlayerUuid)) {
         PlayerTakeoverData.TakeoverEntry entry = takeoverData.getTakeover(realPlayerUuid);
         if (entry == null) {
            this.plugin.getLogger().warning("[FakePlayerRespawn] Cannot respawn " + fakeName + " - entry is null");
            return false;
         } else {
            Location spawnLoc;
            if (entry.hasLocation()) {
               World world = Bukkit.getWorld(entry.getWorld());
               if (world != null) {
                  spawnLoc = new Location(world, entry.getX(), entry.getY(), entry.getZ(), entry.getYaw(), entry.getPitch());
               } else {
                  spawnLoc = ((World)Bukkit.getWorlds().get(0)).getSpawnLocation();
               }
            } else {
               spawnLoc = ((World)Bukkit.getWorlds().get(0)).getSpawnLocation();
            }

            this.plugin.getSimpleFakePlayerManager().spawnFakePlayer(fakeName, spawnLoc, entry.getRealPlayerName(), (String)null, false, true, (Map)null, true, realPlayerUuid);
            if (this.plugin.getSimpleFakePlayerManager().getFakePlayer(fakeName) == null) {
               this.plugin.getLogger().warning("[FakePlayerRespawn] Failed to respawn permanent fake " + fakeName);
               return false;
            } else {
               if (this.plugin.getSimpleFakePlayerManager().getNMSHandler() != null) {
                  this.plugin.getSimpleFakePlayerManager().getNMSHandler().setVisibleInWorld(realPlayerUuid, true);
               }

               this.dead.remove(fakeName);
               this.health.put(fakeName, (double)20.0F);
               if (this.plugin.getConfigManager().isDebugEnabled()) {
                  this.plugin.getLogger().info("[FakePlayerRespawn] Respawned permanent fake " + fakeName + " at " + (entry.hasLocation() ? entry.getWorld() : "default spawn"));
               }

               if (this.isFolia) {
                  Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> this.rebroadcastRespawnedFake(fakeName), 10L);
               } else {
                  Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.rebroadcastRespawnedFake(fakeName), 10L);
               }

               return true;
            }
         }
      } else {
         this.plugin.getLogger().warning("[FakePlayerRespawn] Cannot respawn " + fakeName + " - no takeover data found");
         return false;
      }
   }

   private void rebroadcastRespawnedFake(String fakeName) {
      try {
         Player fakePlayer = Bukkit.getPlayerExact(fakeName);
         if (fakePlayer == null || !fakePlayer.isOnline()) {
            this.plugin.getLogger().warning("[FakePlayerRespawn] Cannot rebroadcast " + fakeName + " - not online");
            return;
         }

         Object serverPlayer = this.plugin.getSimpleFakePlayerManager().getNMSHandler().getServerPlayer(fakePlayer);
         if (serverPlayer == null) {
            this.plugin.getLogger().warning("[FakePlayerRespawn] Cannot get server player for " + fakeName);
            return;
         }

         Class<?> nmsHandlerClass = this.plugin.getSimpleFakePlayerManager().getNMSHandler().getClass();
         Method broadcastSpawnMethod = null;

         for(Method m : nmsHandlerClass.getDeclaredMethods()) {
            if (m.getName().equals("broadcastSpawnEntity") && m.getParameterCount() == 1) {
               broadcastSpawnMethod = m;
               m.setAccessible(true);
               break;
            }
         }

         if (broadcastSpawnMethod != null) {
            broadcastSpawnMethod.invoke(this.plugin.getSimpleFakePlayerManager().getNMSHandler(), serverPlayer);
         }

         Method broadcastPlayerInfoMethod = null;

         for(Method mx : nmsHandlerClass.getDeclaredMethods()) {
            if (mx.getName().equals("broadcastPlayerInfo") && mx.getParameterCount() == 2) {
               broadcastPlayerInfoMethod = mx;
               mx.setAccessible(true);
               break;
            }
         }

         if (broadcastPlayerInfoMethod != null) {
            broadcastPlayerInfoMethod.invoke(this.plugin.getSimpleFakePlayerManager().getNMSHandler(), serverPlayer, true);
         }

         if (this.plugin.getConfigManager().isDebugEnabled()) {
            this.plugin.getLogger().info("[FakePlayerRespawn] Re-broadcasted respawned fake " + fakeName);
         }
      } catch (Exception var11) {
         this.plugin.getLogger().warning("[FakePlayerRespawn] Failed to rebroadcast " + fakeName + ": " + var11.getMessage());
      }

   }

   private Object invokeMethodRecursive(Object target, String methodName) throws Exception {
      for(Class<?> clazz = target.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
         try {
            Method method = clazz.getDeclaredMethod(methodName);
            method.setAccessible(true);
            return method.invoke(target);
         }
      }

      throw new NoSuchMethodException(methodName + " not found in " + target.getClass().getName());
   }

   private Object invokeMethodWithArgs(Object target, String methodName, Object... args) throws Exception {
      for(Class<?> clazz = target.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
         for(Method method : clazz.getDeclaredMethods()) {
            if (method.getName().equals(methodName) && method.getParameterCount() == args.length) {
               method.setAccessible(true);

               try {
                  return method.invoke(target, args);
               } catch (IllegalArgumentException var10) {
               }
            }
         }
      }

      throw new NoSuchMethodException(methodName + " with " + args.length + " args not found in " + target.getClass().getName());
   }

   private Object invokeMethod(Object target, String methodName) throws Exception {
      return this.invokeMethodRecursive(target, methodName);
   }

   private static class KnockbackState {
      double px;
      double py;
      double pz;
      double vx;
      double vy;
      double vz;
      int t;
      final World world;
      final Location startLoc;

      KnockbackState(Location startLoc, double vx, double vy, double vz) {
         this.startLoc = startLoc;
         this.px = startLoc.getX();
         this.py = startLoc.getY();
         this.pz = startLoc.getZ();
         this.vx = vx;
         this.vy = vy;
         this.vz = vz;
         this.t = 0;
         this.world = startLoc.getWorld();
      }
   }

   private static class TaskHandle {
      private final ScheduledTask foliaTask;
      private final BukkitTask bukkitTask;

      TaskHandle(ScheduledTask foliaTask) {
         this.foliaTask = foliaTask;
         this.bukkitTask = null;
      }

      TaskHandle(BukkitTask bukkitTask) {
         this.foliaTask = null;
         this.bukkitTask = bukkitTask;
      }

      void cancel() {
         if (this.foliaTask != null) {
            this.foliaTask.cancel();
         }

         if (this.bukkitTask != null) {
            this.bukkitTask.cancel();
         }

      }
   }
}
