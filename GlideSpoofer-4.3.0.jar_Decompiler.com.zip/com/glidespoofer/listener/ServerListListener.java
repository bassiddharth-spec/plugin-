package com.glidespoofer.listener;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.server.ServerListPingEvent;

public class ServerListListener implements Listener {
   private final GlideSpoofer plugin;

   public ServerListListener(GlideSpoofer plugin) {
      this.plugin = plugin;
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onServerListPing(ServerListPingEvent event) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("server-list.enabled", true)) {
         SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
         if (manager != null) {
            int fakeCount = manager.getFakePlayerCount();
            int realPlayerCount = 0;

            for(Player p : Bukkit.getOnlinePlayers()) {
               if (!manager.isFakePlayer(p)) {
                  ++realPlayerCount;
               }
            }

            int totalCount = realPlayerCount + fakeCount;
            if (this.plugin.getConfigManager().getConfig().getBoolean("server-list.add-to-online-count", true)) {
               try {
                  Method setNumPlayers = event.getClass().getMethod("setNumPlayers", Integer.TYPE);
                  setNumPlayers.invoke(event, totalCount);
               } catch (Exception var16) {
                  this.plugin.getLogger().fine("Could not set num players: " + var16.getMessage());
               }
            }

            if (this.plugin.getConfigManager().getConfig().getBoolean("server-list.show-fake-names", true)) {
               try {
                  Set<String> fakeNamesSet = manager.getNMSHandler().getFakePlayerNames();
                  List<String> fakeNames = new ArrayList(fakeNamesSet);

                  try {
                     Method getPlayerSample = event.getClass().getMethod("getPlayerSample");
                     Object sampleObj = getPlayerSample.invoke(event);
                     if (sampleObj instanceof List) {
                        List<Object> sampleList = (List)sampleObj;
                        sampleList.clear();

                        for(Player px : Bukkit.getOnlinePlayers()) {
                           if (!manager.isFakePlayer(px)) {
                              try {
                                 Object profile = Bukkit.createProfile(px.getUniqueId(), px.getName());
                                 sampleList.add(profile);
                              } catch (Exception var161) {
                              }
                           }
                        }

                        for(String fakeName : fakeNames) {
                           try {
                              UUID fakeUUID = UUID.nameUUIDFromBytes(("GlideSpoofer:" + fakeName).getBytes());
                              Object profile = Bukkit.createProfile(fakeUUID, fakeName);
                              sampleList.add(profile);
                           } catch (Exception var15) {
                           }
                        }
                     }
                  } catch (NoSuchMethodException var181) {
                     this.tryIteratorApproach(event, fakeNames, manager);
                  }
               } catch (Exception var18) {
                  this.plugin.getLogger().fine("Could not modify player sample: " + var18.getMessage());
               }
            }
         }
      }

   }

   private void tryIteratorApproach(ServerListPingEvent event, List<String> fakeNames, SimpleFakePlayerManager manager) {
      try {
         Iterator<Player> iterator = event.iterator();

         while(iterator.hasNext()) {
            Player p = (Player)iterator.next();
            if (manager.isFakePlayer(p)) {
               iterator.remove();
            }
         }
      } catch (Exception var6) {
      }

   }
}
