package com.glidespoofer.listener;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.FakePlayer;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.server.TabCompleteEvent;

public class TabCompleteListener implements Listener {
   private final GlideSpoofer plugin;
   private final List<String> excludedCommands;

   public TabCompleteListener(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.excludedCommands = plugin.getConfigManager().getConfig().getStringList("tab-completion.exclude-commands");
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onTabComplete(TabCompleteEvent event) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("tab-completion.inject-fakes", true)) {
         String buffer = event.getBuffer().toLowerCase();

         for(String excluded : this.excludedCommands) {
            if (buffer.startsWith("/" + excluded.toLowerCase())) {
               return;
            }
         }

         if ((!this.plugin.isUsingPacketEvents() || this.plugin.getFakePlayerManager() != null) && (!this.plugin.isUsingNMS() || this.plugin.getSimpleFakePlayerManager() != null)) {
            List<FakePlayer> fakes;
            if (this.plugin.isUsingPacketEvents()) {
               fakes = this.plugin.getFakePlayerManager().getSpawnedFakePlayers();
            } else {
               fakes = new ArrayList();

               for(SimpleFakePlayerManager.FakePlayerData data : this.plugin.getSimpleFakePlayerManager().getAllFakePlayers()) {
                  fakes.add(new FakePlayer(data.getName()));
               }
            }

            if (!fakes.isEmpty()) {
               List<String> completions = new ArrayList(event.getCompletions());
               String[] parts = buffer.split(" ");
               String typing = parts.length > 1 ? parts[parts.length - 1].toLowerCase() : "";

               for(FakePlayer fake : fakes) {
                  String name = fake.getName();
                  if (!completions.stream().anyMatch((c) -> c.equalsIgnoreCase(name)) && (typing.isEmpty() || name.toLowerCase().startsWith(typing))) {
                     completions.add(name);
                  }
               }

               event.setCompletions(completions);
            }
         }
      }

   }
}
