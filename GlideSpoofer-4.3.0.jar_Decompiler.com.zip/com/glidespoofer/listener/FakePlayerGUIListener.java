package com.glidespoofer.listener;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.gui.FakePlayerGUI;
import com.glidespoofer.pathfinding.FakePlayerPathfinding;
import com.glidespoofer.pathfinding.FollowModeManager;
import java.lang.reflect.Method;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class FakePlayerGUIListener implements Listener {
   private final GlideSpoofer plugin;
   private final FakePlayerPathfinding pathfinding;
   private final FollowModeManager followModeManager;
   private FakePlayerGUI gui;
   private Method getTitleMethod;

   public FakePlayerGUIListener(GlideSpoofer plugin, FakePlayerPathfinding pathfinding, FollowModeManager followModeManager) {
      this.plugin = plugin;
      this.pathfinding = pathfinding;
      this.followModeManager = followModeManager;

      try {
         this.getTitleMethod = Class.forName("org.bukkit.inventory.InventoryView").getMethod("getTitle");
      } catch (Exception var5) {
         var5.printStackTrace();
      }

   }

   public FakePlayerGUI getGUI() {
      if (this.gui == null) {
         this.gui = new FakePlayerGUI(this.plugin, this.pathfinding, this.followModeManager);
      }

      return this.gui;
   }

   private String getInventoryTitle(Object inventoryView) {
      if (this.getTitleMethod != null) {
         try {
            return (String)this.getTitleMethod.invoke(inventoryView);
         } catch (Exception var6) {
         }
      }

      try {
         Object topInv = inventoryView.getClass().getMethod("getTopInventory").invoke(inventoryView);
         if (topInv != null) {
            try {
               Method getNameMethod = topInv.getClass().getMethod("getName");
               return (String)getNameMethod.invoke(topInv);
            } catch (NoSuchMethodException var4) {
            }
         }
      } catch (Exception var5) {
      }

      return "";
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onInventoryClick(InventoryClickEvent event) {
      String title = this.getInventoryTitle(event.getView());
      if (title.contains("Fake Players") || title.contains("Settings: ") || title.contains("Global Settings") || title.contains("Select Target for ") || title.contains("Plugin Hooks") || title.contains("SetLocation") || title.contains("Spawn Points") || title.contains("Fluctuation Settings") || title.contains("AI Settings")) {
         event.setCancelled(true);
         if (event.getWhoClicked() instanceof Player) {
            Player player = (Player)event.getWhoClicked();
            int slot = event.getSlot();
            if (!title.contains("Select Target for ") || !this.getGUI().handleFollowTargetClick(player, title, slot, event.getCurrentItem())) {
               boolean isRightClick = event.getClick() != null && event.getClick().isRightClick();
               if (!this.getGUI().handleClick(player, title, slot, event.getCurrentItem(), isRightClick) && slot == 45 && event.getCurrentItem() != null && event.getCurrentItem().getType().name().contains("BARRIER")) {
                  player.closeInventory();
               }
            }
         }
      }

   }
}
