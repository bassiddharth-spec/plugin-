package com.glidespoofer.listener;

import com.glidespoofer.core.GlideSpoofer;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.SimpleCommandMap;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.server.TabCompleteEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginDescriptionFile;

public class PluginDisguiseListener implements Listener {
   private final GlideSpoofer plugin;
   private final List<Plugin> originalPluginList = new ArrayList();

   public PluginDisguiseListener(GlideSpoofer plugin) {
      this.plugin = plugin;
   }

   private String getDisguiseName() {
      return this.plugin.getConfigManager().getConfig().getString("plugin-disguise.name", "PlayerManager");
   }

   private boolean isHideCompletely() {
      return this.plugin.getConfigManager().getConfig().getBoolean("plugin-disguise.hide-from-plugins", false);
   }

   private String getFakeVersion() {
      return this.plugin.getConfigManager().getConfig().getString("plugin-disguise.version", "1.0.0");
   }

   private String getFakeAuthor() {
      return this.plugin.getConfigManager().getConfig().getString("plugin-disguise.author", "SpigotMC");
   }

   public void applyDisguise() {
      try {
         Collection<Plugin> pluginCollection = Arrays.asList(this.plugin.getServer().getPluginManager().getPlugins());
         List<Plugin> plugins = new ArrayList(pluginCollection);
         if (this.originalPluginList.isEmpty()) {
            for(Plugin p : plugins) {
               try {
                  this.originalPluginList.add(p);
               } catch (Exception var6) {
               }
            }
         }

         for(Plugin p : plugins) {
            if (p.getName().equalsIgnoreCase("GlideSpoofer")) {
               this.modifyPluginDescription(p, this.getDisguiseName(), this.getFakeVersion(), this.getFakeAuthor());
               Logger var10000 = this.plugin.getLogger();
               String var10001 = p.getName();
               var10000.info("Plugin disguise applied: " + var10001 + " -> " + this.getDisguiseName());
               break;
            }
         }

         this.replacePluginsCommand();
      } catch (Exception var7) {
         this.plugin.getLogger().warning("Failed to apply plugin disguise: " + var7.getMessage());
         var7.printStackTrace();
      }

   }

   private void modifyPluginDescription(Plugin plugin, String newName, String newVersion, String newAuthor) {
      try {
         PluginDescriptionFile description = plugin.getDescription();
         Field nameField = PluginDescriptionFile.class.getDeclaredField("name");
         nameField.setAccessible(true);
         nameField.set(description, newName);

         try {
            Field versionField = PluginDescriptionFile.class.getDeclaredField("version");
            versionField.setAccessible(true);
            versionField.set(description, newVersion);
         } catch (Exception var13) {
         }

         try {
            String[] authorFields = new String[]{"authors", "author"};

            for(String fieldName : authorFields) {
               try {
                  Field authorField = PluginDescriptionFile.class.getDeclaredField(fieldName);
                  authorField.setAccessible(true);
                  if (fieldName.equals("authors")) {
                     authorField.set(description, Arrays.asList(newAuthor));
                  } else {
                     authorField.set(description, newAuthor);
                  }
                  break;
               } catch (NoSuchFieldException var14) {
               }
            }
         } catch (Exception var15) {
         }
      } catch (Exception var16) {
         this.plugin.getLogger().warning("Failed to modify plugin description: " + var16.getMessage());
      }

   }

   private void replacePluginsCommand() {
      try {
         SimpleCommandMap commandMap = this.getCommandMap();
         if (commandMap == null) {
            return;
         }

         Map<String, Command> knownCommands = this.getKnownCommands(commandMap);
         if (knownCommands == null) {
            return;
         }

         DisguisedPluginsCommand disguisedCommand = new DisguisedPluginsCommand();
         String[] commandKeys = new String[]{"plugins", "pl", "bukkit:plugins", "bukkit:pl"};
         int replacedCount = 0;

         for(String key : commandKeys) {
            if (knownCommands.containsKey(key)) {
               knownCommands.put(key, disguisedCommand);
               ++replacedCount;
            }
         }

         this.plugin.getLogger().info("Plugin commands replaced (" + replacedCount + " commands)");
      } catch (Exception var10) {
         this.plugin.getLogger().warning("Failed to replace plugins command: " + var10.getMessage());
      }

   }

   public void removeDisguise() {
      try {
         for(Plugin p : this.originalPluginList) {
            if (p.getName().equalsIgnoreCase(this.getDisguiseName()) || p.getDescription().getName().equalsIgnoreCase(this.getDisguiseName())) {
               this.modifyPluginDescription(p, "GlideSpoofer", this.plugin.getDescription().getVersion(), "GlideSpoofer");
               this.plugin.getLogger().info("Plugin disguise removed");
               break;
            }
         }

         this.originalPluginList.clear();
      } catch (Exception var3) {
         this.plugin.getLogger().warning("Failed to remove plugin disguise: " + var3.getMessage());
      }

   }

   private SimpleCommandMap getCommandMap() {
      try {
         Field commandMapField = this.plugin.getServer().getClass().getDeclaredField("commandMap");
         commandMapField.setAccessible(true);
         return (SimpleCommandMap)commandMapField.get(this.plugin.getServer());
      } catch (Exception var2) {
         return null;
      }
   }

   private Map<String, Command> getKnownCommands(SimpleCommandMap commandMap) {
      try {
         Field knownCommandsField = SimpleCommandMap.class.getDeclaredField("knownCommands");
         knownCommandsField.setAccessible(true);
         return (Map)knownCommandsField.get(commandMap);
      } catch (Exception var3) {
         return null;
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onCommand(PlayerCommandPreprocessEvent event) {
      if (!event.isCancelled()) {
         String message = event.getMessage().toLowerCase();
         if ((message.startsWith("/ver glidespoofer") || message.startsWith("/version glidespoofer") || message.startsWith("/bukkit:ver glidespoofer") || message.startsWith("/bukkit:version glidespoofer")) && !event.getPlayer().hasPermission("glidespoofer.bypass.disguise")) {
            event.setCancelled(true);
            Player var10000 = event.getPlayer();
            String var10001 = this.getDisguiseName();
            var10000.sendMessage("§f" + var10001 + " §7version §f" + this.getFakeVersion());
            event.getPlayer().sendMessage("§7Author: §f" + this.getFakeAuthor());
         }
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onTabComplete(TabCompleteEvent event) {
      String buffer = event.getBuffer().toLowerCase();
      if (buffer.startsWith("/ver ") || buffer.startsWith("/version ") || buffer.startsWith("/bukkit:ver ") || buffer.startsWith("/bukkit:version ") || buffer.startsWith("/help ")) {
         List<String> completions = new ArrayList(event.getCompletions());
         completions.removeIf((s) -> s.equalsIgnoreCase("GlideSpoofer") || s.equalsIgnoreCase("glidespoofer"));
         if (!this.isHideCompletely() && !completions.contains(this.getDisguiseName())) {
            completions.add(this.getDisguiseName());
         }

         event.setCompletions(completions);
      }

   }

   private class DisguisedPluginsCommand extends Command {
      public DisguisedPluginsCommand() {
         super("plugins");
         this.setAliases(List.of("pl"));
         this.setDescription("Shows a list of plugins");
         this.setUsage("/plugins");
      }

      public boolean execute(CommandSender sender, String commandLabel, String[] args) {
         if (sender.hasPermission("glidespoofer.bypass.disguise")) {
            this.sendRealPluginList(sender);
            return true;
         } else {
            this.sendDisguisedPluginList(sender);
            return true;
         }
      }

      public List<String> tabComplete(CommandSender sender, String alias, String[] args) throws IllegalArgumentException {
         return new ArrayList();
      }

      private void sendDisguisedPluginList(CommandSender sender) {
         StringBuilder plugins = new StringBuilder();
         int count = 0;

         for(Plugin p : PluginDisguiseListener.this.plugin.getServer().getPluginManager().getPlugins()) {
            String name = p.getName();
            boolean isEnabled = p.isEnabled();
            if (name.equalsIgnoreCase("GlideSpoofer")) {
               if (PluginDisguiseListener.this.isHideCompletely()) {
                  continue;
               }

               name = PluginDisguiseListener.this.getDisguiseName();
            }

            if (count > 0) {
               plugins.append("§7, ");
            }

            plugins.append(isEnabled ? "§a" : "§c").append(name);
            ++count;
         }

         sender.sendMessage("§fPlugins (" + count + "): " + String.valueOf(plugins));
      }

      private void sendRealPluginList(CommandSender sender) {
         StringBuilder plugins = new StringBuilder();
         int count = 0;

         for(Plugin p : PluginDisguiseListener.this.plugin.getServer().getPluginManager().getPlugins()) {
            if (count > 0) {
               plugins.append("§7, ");
            }

            plugins.append(p.isEnabled() ? "§a" : "§c").append(p.getName());
            ++count;
         }

         sender.sendMessage("§fPlugins (" + count + "): " + String.valueOf(plugins));
      }
   }
}
