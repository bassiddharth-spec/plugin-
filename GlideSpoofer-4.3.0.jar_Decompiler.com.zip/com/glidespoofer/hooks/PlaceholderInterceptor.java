package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import java.lang.reflect.Method;
import java.util.Set;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class PlaceholderInterceptor {
   private final GlideSpoofer plugin;
   private boolean enabled;
   private static final Set<String> ONLINE_PLACEHOLDERS = Set.of("server_online", "server_online_players", "player_online", "players_online", "online", "online_players", "bungee_total", "bungee_online", "velocity_total", "velocity_online", "network_total", "network_online");

   public PlaceholderInterceptor(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.enabled = false;
   }

   public void register() {
      if (!this.plugin.getConfigManager().getConfig().getBoolean("hooks.placeholderapi.intercept-online", true)) {
         this.plugin.getLogger().info("PlaceholderAPI interception disabled in config");
      } else {
         Plugin papiPlugin = Bukkit.getPluginManager().getPlugin("PlaceholderAPI");
         if (papiPlugin != null) {
            try {
               this.enabled = true;
               this.plugin.getLogger().info("PlaceholderAPI interceptor enabled - use %glidespoofer_online% for spoofed count");
               if (GlideSpoofer.isFolia()) {
                  Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> this.tryHookServerPlaceholder(), 100L);
               } else {
                  Bukkit.getScheduler().runTaskLater(this.plugin, this::tryHookServerPlaceholder, 100L);
               }
            } catch (Exception var3) {
               this.plugin.getLogger().warning("Failed to register placeholder interceptor: " + var3.getMessage());
            }
         }
      }

   }

   private void tryHookServerPlaceholder() {
      try {
         Class<?> papiClass = Class.forName("me.clip.placeholderapi.PlaceholderAPIPlugin");
         Method getInstance = papiClass.getMethod("getInstance");
         Object papiInstance = getInstance.invoke((Object)null);
         this.plugin.getLogger().info("PlaceholderAPI integration active:");
         this.plugin.getLogger().info("  %glidespoofer_online% - Total players (real + fake)");
         this.plugin.getLogger().info("  %glidespoofer_fake% - Fake player count");
         this.plugin.getLogger().info("  %glidespoofer_real% - Real player count");
      } catch (Exception var4) {
      }

   }

   public int getSpoofedOnlineCount() {
      int real = Bukkit.getOnlinePlayers().size();
      int fake = this.plugin.getFakePlayerManager().getSpawnedCount();
      return real + fake;
   }

   public String processString(String text, Player player) {
      if (text != null && !text.isEmpty()) {
         int spoofedCount = this.getSpoofedOnlineCount();
         int realCount = Bukkit.getOnlinePlayers().size();
         text = text.replace("%server_online%", String.valueOf(spoofedCount));
         text = text.replace("%server_online_players%", String.valueOf(spoofedCount));
         text = text.replace("%online%", String.valueOf(spoofedCount));
         text = text.replace("%players_online%", String.valueOf(spoofedCount));
         text = text.replace("%player_online%", String.valueOf(spoofedCount));
         if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            text = PlaceholderAPI.setPlaceholders(player, text);
            text = text.replace(String.valueOf(realCount), String.valueOf(spoofedCount));
         }

         return text;
      } else {
         return text;
      }
   }

   public boolean isEnabled() {
      return this.enabled;
   }
}
