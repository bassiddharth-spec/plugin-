package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import me.neznamy.tab.api.TabAPI;
import me.neznamy.tab.api.TabPlayer;
import me.neznamy.tab.api.placeholder.PlaceholderManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class TABHook {
   private final GlideSpoofer plugin;
   private boolean enabled;
   private Plugin tabPlugin;
   private TabAPI tabAPI;
   private PlaceholderManager placeholderManager;
   private final Map<UUID, Player> fakePlayers = new ConcurrentHashMap();
   private static final String GLIDE_HEARTS_PLACEHOLDER = "%glidespoofer_hearts%";
   private static final String GLIDE_HEARTS_COLORED_PLACEHOLDER = "%glidespoofer_hearts_colored%";
   private static final String GLIDE_HEARTS_BAR_PLACEHOLDER = "%glidespoofer_hearts_bar%";
   private static Class<?> tabPlayerClass;
   private static Class<?> tabClass;
   private static Method addPlayerMethod;

   public TABHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.enabled = false;
      if (!plugin.getConfigManager().getConfig().getBoolean("hooks.tab.enabled", true)) {
         plugin.getLogger().info("TAB hook disabled in config");
      } else {
         this.tabPlugin = Bukkit.getPluginManager().getPlugin("TAB");
         if (this.tabPlugin != null && this.tabPlugin.isEnabled()) {
            try {
               this.tabAPI = TabAPI.getInstance();
               if (this.tabAPI != null) {
                  this.enabled = true;
                  String version = "unknown";

                  try {
                     version = this.tabPlugin.getPluginMeta().getVersion();
                  } catch (Throwable var4) {
                  }

                  plugin.getLogger().info("TAB hook enabled! Using TAB v" + version);
                  this.initializeTABReflection();
                  this.registerPlaceholders();
               } else {
                  plugin.getLogger().warning("TAB plugin found but API instance is null.");
               }
            } catch (NoClassDefFoundError var5) {
               plugin.getLogger().warning("TAB plugin found but API classes not available.");
            } catch (Exception var6) {
               plugin.getLogger().log(Level.WARNING, "Failed to initialize TAB API hook", var6);
            }
         }
      }

   }

   private void initializeTABReflection() {
      try {
         tabClass = Class.forName("me.neznamy.tab.Tab");
         tabPlayerClass = Class.forName("me.neznamy.tab.shared.TabPlayer");

         try {
            addPlayerMethod = tabClass.getMethod("addPlayer", Player.class);
         } catch (NoSuchMethodException var21) {
         }

         this.plugin.getLogger().fine("TAB reflection initialized successfully");
      } catch (Exception var2) {
         this.plugin.getLogger().fine("TAB reflection initialization failed: " + var2.getMessage());
      }

   }

   private void registerPlaceholders() {
      if (this.isEnabled()) {
         try {
            this.placeholderManager = this.tabAPI.getPlaceholderManager();
            this.placeholderManager.registerPlayerPlaceholder("%glidespoofer_hearts%", 1000, (tabPlayer) -> {
               UUID uuid = this.getTabPlayerUUID(tabPlayer);
               return uuid != null ? String.valueOf(this.getPlayerHearts(uuid)) : "10";
            });
            this.placeholderManager.registerPlayerPlaceholder("%glidespoofer_hearts_colored%", 1000, (tabPlayer) -> {
               UUID uuid = this.getTabPlayerUUID(tabPlayer);
               if (uuid != null) {
                  int hearts = this.getPlayerHearts(uuid);
                  return this.formatHeartsColored(hearts);
               } else {
                  return "§c❤❤❤❤❤❤❤❤❤❤";
               }
            });
            this.placeholderManager.registerPlayerPlaceholder("%glidespoofer_hearts_bar%", 1000, (tabPlayer) -> {
               UUID uuid = this.getTabPlayerUUID(tabPlayer);
               if (uuid != null) {
                  int hearts = this.getPlayerHearts(uuid);
                  return this.formatHeartsBar(hearts);
               } else {
                  return "§c▓▓▓▓▓▓▓▓▓▓§7░░░░░░░░░ §f10";
               }
            });
            this.plugin.getLogger().info("Registered TAB placeholders: glidespoofer_hearts, glidespoofer_hearts_colored, glidespoofer_hearts_bar");
         } catch (Exception var2) {
            this.plugin.getLogger().log(Level.WARNING, "Failed to register TAB placeholders", var2);
         }
      }

   }

   private int getPlayerHearts(UUID uuid) {
      LifeStealZHook lszHook = this.plugin.getLifeStealZHook();
      if (lszHook != null && lszHook.isEnabled()) {
         return lszHook.getHearts(uuid);
      } else {
         LifestealCoreHook lsHook = this.plugin.getLifestealCoreHook();
         return lsHook != null && lsHook.isEnabled() ? lsHook.getHearts(uuid) : 10;
      }
   }

   private UUID getTabPlayerUUID(TabPlayer tabPlayer) {
      if (tabPlayer == null) {
         return null;
      } else {
         try {
            Object uniqueId = tabPlayer.getUniqueId();
            if (uniqueId instanceof UUID) {
               return (UUID)uniqueId;
            }

            if (uniqueId instanceof String) {
               return UUID.fromString((String)uniqueId);
            }
         } catch (Exception var3) {
            this.plugin.getLogger().fine("Failed to get UUID from TabPlayer: " + var3.getMessage());
         }

         return null;
      }
   }

   private String formatHeartsColored(int hearts) {
      if (hearts <= 0) {
         return "§4✖";
      } else {
         StringBuilder sb = new StringBuilder();
         String color;
         if (hearts >= 15) {
            color = "§c";
         } else if (hearts >= 10) {
            color = "§6";
         } else if (hearts >= 6) {
            color = "§e";
         } else if (hearts >= 3) {
            color = "§7";
         } else {
            color = "§4";
         }

         int displayHearts = Math.min(hearts, 20);

         for(int i = 0; i < displayHearts; ++i) {
            sb.append(color).append("❤");
         }

         if (hearts > 20) {
            sb.append("§7+").append(hearts - 20);
         }

         return sb.toString();
      }
   }

   private String formatHeartsBar(int hearts) {
      int maxDisplay = 20;
      int filled = Math.min(hearts, maxDisplay);
      int empty = maxDisplay - filled;
      StringBuilder sb = new StringBuilder();
      String color;
      if (hearts >= 15) {
         color = "§c";
      } else if (hearts >= 10) {
         color = "§6";
      } else if (hearts >= 6) {
         color = "§e";
      } else if (hearts >= 3) {
         color = "§7";
      } else {
         color = "§4";
      }

      sb.append(color);

      for(int i = 0; i < filled; ++i) {
         sb.append("▓");
      }

      sb.append("§7");

      for(int i = 0; i < empty; ++i) {
         sb.append("░");
      }

      sb.append(" §f").append(hearts);
      return sb.toString();
   }

   public boolean isEnabled() {
      return this.enabled && this.tabPlugin != null && this.tabAPI != null;
   }

   public TabAPI getTabAPI() {
      return this.tabAPI;
   }

   public TabPlayer getTabPlayer(UUID uuid) {
      if (!this.isEnabled()) {
         return null;
      } else {
         try {
            return this.tabAPI.getPlayer(uuid);
         } catch (Exception var3) {
            return null;
         }
      }
   }

   public TabPlayer getTabPlayer(String name) {
      if (!this.isEnabled()) {
         return null;
      } else {
         try {
            return this.tabAPI.getPlayer(name);
         } catch (Exception var3) {
            return null;
         }
      }
   }

   public String getTabVersion() {
      if (this.tabPlugin != null) {
         try {
            return this.tabPlugin.getPluginMeta().getVersion();
         } catch (Throwable var2) {
         }
      }

      return "unknown";
   }

   public void registerFakePlayer(UUID uuid, String name, String world) {
      if (this.isEnabled()) {
         this.plugin.getLogger().fine("Registered fake player with TAB: " + name);
      }

   }

   public void unregisterFakePlayer(UUID uuid) {
      if (this.isEnabled()) {
         this.fakePlayers.remove(uuid);
      }

   }

   public void forceReload() {
      if (this.isEnabled()) {
         try {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "tab reload");
         } catch (Exception var2) {
            this.plugin.getLogger().warning("Failed to execute /tab reload: " + var2.getMessage());
         }
      }

   }

   public void scheduleReload() {
      this.forceReload();
   }

   public void reapplyAllFormatting() {
      if (this.isEnabled()) {
         this.forceReload();
      }

   }

   public int getTrackedCount() {
      return this.fakePlayers.size();
   }

   public boolean isFakePlayerTracked(UUID uuid) {
      return this.fakePlayers.containsKey(uuid);
   }

   public void shutdown() {
      this.fakePlayers.clear();
   }

   public boolean injectFakePlayerTAB(Player player, UUID uuid, String name) {
      if (!this.isEnabled()) {
         this.fakePlayers.put(uuid, player);
         return false;
      } else {
         try {
            this.fakePlayers.put(uuid, player);
            if (this.plugin.getLuckPermsHook() != null && this.plugin.getLuckPermsHook().isEnabled()) {
               try {
                  String prefix = this.plugin.getLuckPermsHook().setupFakePlayerWithDefaultGroup(uuid, name);
                  this.plugin.getLogger().info("[TABHook] Pre-cached LuckPerms data for " + name + " with prefix: " + prefix);
               } catch (Exception e) {
                  this.plugin.getLogger().warning("[TABHook] Could not pre-cache LuckPerms data: " + e.getMessage());
               }
            }

            try {
               TabPlayer tabPlayer = this.tabAPI.getPlayer(player.getUniqueId());
               if (tabPlayer == null && addPlayerMethod != null) {
                  addPlayerMethod.invoke((Object)null, player);
                  this.plugin.getLogger().info("[TABHook] Added " + name + " to TAB using direct API");
               }

               return true;
            } catch (Exception var8) {
               this.plugin.getLogger().warning("[TABHook] TAB registration check failed: " + var8.getMessage());
               return true;
            }
         } catch (Exception var9) {
            this.plugin.getLogger().warning("Failed to inject fake player into TAB: " + var9.getMessage());
            return false;
         }
      }
   }

   public void refreshPlayerInTAB(UUID uuid, String name) {
      if (this.isEnabled()) {
         try {
            TabPlayer tabPlayer = this.tabAPI.getPlayer(uuid);
            if (tabPlayer != null) {
               try {
                  Method forceRefresh = tabPlayer.getClass().getMethod("forceRefresh");
                  forceRefresh.invoke(tabPlayer);
                  this.plugin.getLogger().fine("[TABHook] Force refreshed TAB data for " + name);
               } catch (NoSuchMethodException var7) {
                  try {
                     Method markRefresh = tabPlayer.getClass().getMethod("markRefresh");
                     markRefresh.invoke(tabPlayer);
                  } catch (NoSuchMethodException var6) {
                     this.plugin.getLogger().fine("[TABHook] No refresh method available for " + name);
                  }
               }
            } else {
               this.plugin.getLogger().fine("[TABHook] TabPlayer not found for " + name);
            }
         } catch (Exception e) {
            this.plugin.getLogger().fine("[TABHook] Error refreshing player in TAB: " + e.getMessage());
         }

      }
   }

   public void updatePlayerPrefix(UUID uuid, String name, String prefix) {
      if (this.isEnabled()) {
         try {
            this.refreshPlayerInTAB(uuid, name);
            TabPlayer tabPlayer = this.tabAPI.getPlayer(uuid);
            if (tabPlayer != null) {
               try {
                  this.plugin.getLogger().info("[TABHook] Refreshing TAB prefix for " + name);
               } catch (Exception var6) {
                  this.refreshPlayerInTAB(uuid, name);
               }
            }
         } catch (Exception e) {
            this.plugin.getLogger().fine("[TABHook] Error updating player prefix: " + e.getMessage());
         }

      }
   }

   private Object getTABInstance() {
      try {
         return tabClass.getMethod("getInstance").invoke((Object)null);
      } catch (Exception var2) {
         return null;
      }
   }

   private Object createFakeTabPlayer(Player player, UUID uuid, String name) {
      try {
         return Proxy.newProxyInstance(tabPlayerClass.getClassLoader(), new Class[]{tabPlayerClass}, (proxy, method, args) -> {
            switch (method.getName()) {
               case "getUniqueId":
                  return uuid;
               case "getName":
                  return name;
               case "getWorld":
                  return player.getWorld() != null ? player.getWorld().getName() : "world";
               case "getServer":
                  return player.getServer() != null ? player.getServer().getName() : "main";
               case "isBedrockPlayer":
                  return false;
               case "getPlayer":
                  return player;
               case "isLoaded":
                  return true;
               case "hasPermission":
                  return true;
               case "getGroup":
                  return "default";
               case "toString":
                  return "FakeTabPlayer{" + name + "}";
               default:
                  Class<?> returnType = method.getReturnType();
                  if (returnType == Boolean.TYPE) {
                     return false;
                  } else if (returnType == Integer.TYPE) {
                     return 0;
                  } else if (returnType == Long.TYPE) {
                     return 0L;
                  } else if (returnType == Double.TYPE) {
                     return (double)0.0F;
                  } else {
                     return returnType == String.class ? "" : null;
                  }
            }
         });
      } catch (Exception var5) {
         this.plugin.getLogger().fine("Failed to create fake TabPlayer: " + var5.getMessage());
         return null;
      }
   }

   public boolean removeFakePlayerTAB(UUID uuid, String name) {
      this.fakePlayers.remove(uuid);

      try {
         Object tabInstance = this.getTABInstance();
         if (tabInstance != null) {
            for(Field field : tabInstance.getClass().getDeclaredFields()) {
               field.setAccessible(true);
               Object var9 = field.get(tabInstance);
               if (var9 instanceof Map) {
                  Map map = (Map)var9;
                  map.remove(uuid);
                  map.remove(name);
               }
            }
         }

         this.plugin.getLogger().fine("Removed " + name + " from TAB internal tracking");
         return true;
      } catch (Exception var10) {
         this.plugin.getLogger().warning("Failed to remove fake player from TAB: " + var10.getMessage());
         return false;
      }
   }

   public boolean isFakePlayer(Player player) {
      return player == null ? false : this.fakePlayers.containsKey(player.getUniqueId());
   }

   public boolean isFakePlayer(UUID uuid) {
      return this.fakePlayers.containsKey(uuid);
   }
}
