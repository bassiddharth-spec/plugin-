package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;

public class ZelChatHook {
   private final GlideSpoofer plugin;
   private boolean enabled;
   private Plugin zelChatPlugin;
   private Object chatModule;
   private Object moduleManager;
   private Class<?> zelChatApiClass;
   private Class<?> chatModuleClass;
   private Class<?> chatMessageClass;
   private Class<?> chatPlayerManagerClass;
   private Method getModuleManagerMethod;
   private Method registerModuleMethod;
   private Method unregisterModuleMethod;
   private Method getBukkitPlayerMethod;
   private Method getRawMessageMethod;
   private Method getPlayerServiceMethod;
   private Method makePlayerChatMethod;
   private Object chatPlayerManager;

   public ZelChatHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.enabled = false;
      if (!plugin.getConfigManager().getConfig().getBoolean("chat-hooks.zelchat.enabled", true)) {
         plugin.getLogger().info("ZelChat hook disabled in config");
      } else {
         this.zelChatPlugin = Bukkit.getPluginManager().getPlugin("ZelChat");
         if (this.zelChatPlugin != null && this.zelChatPlugin.isEnabled()) {
            try {
               this.initReflection();
               this.registerModule();
               this.enabled = true;
               plugin.getLogger().info("ZelChat hook enabled! Fake players will use ZelChat for chat processing.");
            } catch (Exception var3) {
               plugin.getLogger().log(Level.WARNING, "Failed to initialize ZelChat hook: " + var3.getMessage(), var3);
            }
         } else {
            plugin.getLogger().info("ZelChat not found - hook disabled");
         }
      }

   }

   private void initReflection() throws Exception {
      this.zelChatApiClass = Class.forName("it.pino.zelchat.api.ZelChatAPI");
      this.chatModuleClass = Class.forName("it.pino.zelchat.api.module.ChatModule");
      this.chatMessageClass = Class.forName("it.pino.zelchat.api.message.ChatMessage");
      this.getModuleManagerMethod = this.zelChatApiClass.getMethod("getModuleManager");
      Class<?> moduleManagerClass = Class.forName("it.pino.zelchat.api.module.ModuleManager");
      this.registerModuleMethod = moduleManagerClass.getMethod("register", Plugin.class, this.chatModuleClass);
      this.unregisterModuleMethod = moduleManagerClass.getMethod("unregister", Plugin.class, this.chatModuleClass);
      this.getBukkitPlayerMethod = this.chatMessageClass.getMethod("getBukkitPlayer");
      this.getRawMessageMethod = this.chatMessageClass.getMethod("getRawMessage");
      this.chatPlayerManagerClass = Class.forName("it.pino.zelchat.api.player.ChatPlayerManager");
      this.getPlayerServiceMethod = this.zelChatApiClass.getMethod("getPlayerService");
      this.makePlayerChatMethod = this.chatPlayerManagerClass.getMethod("makePlayerChat", Player.class, String.class);
      Object api = this.zelChatApiClass.getMethod("get").invoke((Object)null);
      this.moduleManager = this.getModuleManagerMethod.invoke(api);
      this.chatPlayerManager = this.getPlayerServiceMethod.invoke(api);
   }

   private void registerModule() {
      if (this.moduleManager != null) {
         try {
            this.chatModule = Proxy.newProxyInstance(this.chatModuleClass.getClassLoader(), new Class[]{this.chatModuleClass}, (proxy, method, args) -> {
               if (method.getName().equals("handleChatMessage")) {
                  this.handleChatMessage(args[0]);
                  return null;
               } else {
                  return !method.getName().equals("load") && !method.getName().equals("unload") && !method.getName().equals("reload") ? null : null;
               }
            });
            this.registerModuleMethod.invoke(this.moduleManager, this.plugin, this.chatModule);
            this.plugin.getLogger().info("Registered GlideSpoofer module with ZelChat");
         } catch (Exception var2) {
            this.plugin.getLogger().log(Level.WARNING, "Failed to register ZelChat module: " + var2.getMessage(), var2);
         }
      }

   }

   private void handleChatMessage(Object chatMessage) {
      try {
         Player player = (Player)this.getBukkitPlayerMethod.invoke(chatMessage);
         if (this.plugin.getSimpleFakePlayerManager() != null && this.plugin.getSimpleFakePlayerManager().isFakePlayer(player)) {
            String rawMessage = (String)this.getRawMessageMethod.invoke(chatMessage);
            if (this.plugin.getConfigManager().getConfig().getBoolean("debug.enabled", false)) {
               Logger var10000 = this.plugin.getLogger();
               String var10001 = player.getName();
               var10000.info("[ZelChat] Processing fake player message from " + var10001 + ": " + rawMessage);
            }
         }
      } catch (Exception var4) {
         this.plugin.getLogger().fine("Error handling ZelChat message: " + var4.getMessage());
      }

   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void shutdown() {
      if (this.enabled && this.moduleManager != null && this.chatModule != null) {
         try {
            this.unregisterModuleMethod.invoke(this.moduleManager, this.plugin, this.chatModule);
            this.plugin.getLogger().info("Unregistered GlideSpoofer module from ZelChat");
         } catch (Exception var2) {
            this.plugin.getLogger().warning("Failed to unregister ZelChat module: " + var2.getMessage());
         }
      }

   }

   public boolean sendFakePlayerMessage(Player fakePlayer, String message) {
      if (this.enabled && this.chatPlayerManager != null && this.makePlayerChatMethod != null) {
         try {
            this.makePlayerChatMethod.invoke(this.chatPlayerManager, fakePlayer, message);
            if (this.plugin.getConfigManager().getConfig().getBoolean("debug.enabled", false)) {
               Logger var10000 = this.plugin.getLogger();
               String var10001 = fakePlayer.getName();
               var10000.info("[ZelChat] Sent message via makePlayerChat: " + var10001 + ": " + message);
            }

            return true;
         } catch (Exception var4) {
            this.plugin.getLogger().log(Level.FINE, "Failed to send message through ZelChat makePlayerChat: " + var4.getMessage(), var4);
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean isChatMuted() {
      if (!this.enabled) {
         return false;
      } else {
         try {
            Method isChatMutedMethod = this.zelChatApiClass.getMethod("isChatMuted");
            Object api = this.zelChatApiClass.getMethod("get").invoke((Object)null);
            return (Boolean)isChatMutedMethod.invoke(api);
         } catch (Exception var3) {
            return false;
         }
      }
   }

   public void registerFakePlayer(Player fakePlayer) {
      if (this.enabled && fakePlayer != null) {
         try {
            PlayerJoinEvent joinEvent = new PlayerJoinEvent(fakePlayer, "");
            Bukkit.getPluginManager().callEvent(joinEvent);
            if (this.plugin.getConfigManager().getConfig().getBoolean("debug.enabled", false)) {
               this.plugin.getLogger().info("[ZelChat] Fired PlayerJoinEvent for fake player: " + fakePlayer.getName());
            }
         } catch (Exception var3) {
            this.plugin.getLogger().log(Level.FINE, "Failed to register fake player with ZelChat: " + var3.getMessage(), var3);
         }
      }

   }

   public void unregisterFakePlayer(Player fakePlayer) {
      if (this.enabled && fakePlayer != null) {
         try {
            PlayerQuitEvent quitEvent = new PlayerQuitEvent(fakePlayer, "");
            Bukkit.getPluginManager().callEvent(quitEvent);
            if (this.plugin.getConfigManager().getConfig().getBoolean("debug.enabled", false)) {
               this.plugin.getLogger().info("[ZelChat] Fired PlayerQuitEvent for fake player: " + fakePlayer.getName());
            }
         } catch (Exception var3) {
            this.plugin.getLogger().log(Level.FINE, "Failed to unregister fake player from ZelChat: " + var3.getMessage(), var3);
         }
      }

   }
}
