package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import java.lang.reflect.Constructor;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent.Result;

public class LoginEventManager {
   private final GlideSpoofer plugin;
   private static Constructor<?> asyncPreLoginConstructor;
   private static Constructor<?> playerLoginConstructor;
   private static Constructor<?> playerJoinConstructor;
   private static Constructor<?> playerQuitConstructor;
   private static boolean initialized = false;

   public LoginEventManager(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.initializeReflection();
   }

   private synchronized void initializeReflection() {
      if (!initialized) {
         try {
            Class<?> asyncPreLoginClass = AsyncPlayerPreLoginEvent.class;

            try {
               asyncPreLoginConstructor = asyncPreLoginClass.getConstructor(String.class, InetAddress.class, UUID.class, String.class);
               this.plugin.getLogger().fine("[LoginEventManager] Using AsyncPlayerPreLoginEvent(String, InetAddress, UUID, String)");
            } catch (NoSuchMethodException var15) {
               try {
                  asyncPreLoginConstructor = asyncPreLoginClass.getConstructor(String.class, InetAddress.class, UUID.class);
                  this.plugin.getLogger().fine("[LoginEventManager] Using AsyncPlayerPreLoginEvent(String, InetAddress, UUID)");
               } catch (NoSuchMethodException var14) {
                  this.plugin.getLogger().warning("[LoginEventManager] Could not find AsyncPlayerPreLoginEvent constructor");
               }
            }

            Class<?> playerLoginClass = PlayerLoginEvent.class;

            try {
               playerLoginConstructor = playerLoginClass.getConstructor(Player.class, String.class, InetSocketAddress.class);
               this.plugin.getLogger().fine("[LoginEventManager] Using PlayerLoginEvent(Player, String, InetSocketAddress)");
            } catch (NoSuchMethodException var13) {
               try {
                  playerLoginConstructor = playerLoginClass.getConstructor(Player.class, String.class, InetAddress.class);
                  this.plugin.getLogger().fine("[LoginEventManager] Using PlayerLoginEvent(Player, String, InetAddress)");
               } catch (NoSuchMethodException var12) {
                  try {
                     playerLoginConstructor = playerLoginClass.getConstructor(Player.class, String.class);
                     this.plugin.getLogger().fine("[LoginEventManager] Using PlayerLoginEvent(Player, String)");
                  } catch (NoSuchMethodException var11) {
                     this.plugin.getLogger().warning("[LoginEventManager] Could not find PlayerLoginEvent constructor");
                  }
               }
            }

            Class<?> playerJoinClass = PlayerJoinEvent.class;

            try {
               playerJoinConstructor = playerJoinClass.getConstructor(Player.class, Component.class);
               this.plugin.getLogger().fine("[LoginEventManager] Using PlayerJoinEvent(Player, Component)");
            } catch (NoSuchMethodException var10) {
               try {
                  playerJoinConstructor = playerJoinClass.getConstructor(Player.class, String.class);
                  this.plugin.getLogger().fine("[LoginEventManager] Using PlayerJoinEvent(Player, String)");
               } catch (NoSuchMethodException var9) {
                  this.plugin.getLogger().warning("[LoginEventManager] Could not find PlayerJoinEvent constructor");
               }
            }

            Class<?> playerQuitClass = PlayerQuitEvent.class;

            try {
               playerQuitConstructor = playerQuitClass.getConstructor(Player.class, Component.class);
               this.plugin.getLogger().fine("[LoginEventManager] Using PlayerQuitEvent(Player, Component)");
            } catch (NoSuchMethodException var8) {
               try {
                  playerQuitConstructor = playerQuitClass.getConstructor(Player.class, String.class);
                  this.plugin.getLogger().fine("[LoginEventManager] Using PlayerQuitEvent(Player, String)");
               } catch (NoSuchMethodException var7) {
                  this.plugin.getLogger().warning("[LoginEventManager] Could not find PlayerQuitEvent constructor");
               }
            }

            initialized = true;
            this.plugin.getLogger().info("[LoginEventManager] Reflection initialized successfully");
         } catch (Exception e) {
            this.plugin.getLogger().log(Level.WARNING, "[LoginEventManager] Failed to initialize reflection", e);
         }

      }
   }

   public boolean fireLoginEventChain(Player player, UUID uuid, String name, InetAddress address) {
      try {
         AsyncPlayerPreLoginEvent.Result preLoginResult = this.fireAsyncPreLoginEvent(name, address, uuid);
         if (preLoginResult != Result.ALLOWED) {
            this.plugin.getLogger().warning("[LoginEventManager] Pre-login denied for " + name + ": " + String.valueOf(preLoginResult));
            return false;
         } else {
            PlayerLoginEvent.Result loginResult = this.firePlayerLoginEvent(player, address);
            if (loginResult != org.bukkit.event.player.PlayerLoginEvent.Result.ALLOWED) {
               this.plugin.getLogger().warning("[LoginEventManager] Login denied for " + name + ": " + String.valueOf(loginResult));
               return false;
            } else {
               this.firePlayerJoinEvent(player, name);
               this.plugin.getLogger().info("[LoginEventManager] Complete login chain fired successfully for " + name);
               return true;
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.WARNING, "[LoginEventManager] Error firing login chain for " + name, e);
         return false;
      }
   }

   public CompletableFuture<Boolean> fireLoginEventChainAsync(Player player, UUID uuid, String name, InetAddress address) {
      return CompletableFuture.supplyAsync(() -> {
         AsyncPlayerPreLoginEvent.Result preLoginResult = this.fireAsyncPreLoginEvent(name, address, uuid);
         if (preLoginResult != Result.ALLOWED) {
            return false;
         } else {
            CompletableFuture<Boolean> future = new CompletableFuture();
            Bukkit.getScheduler().runTask(this.plugin, () -> {
               try {
                  PlayerLoginEvent.Result loginResult = this.firePlayerLoginEvent(player, address);
                  if (loginResult != org.bukkit.event.player.PlayerLoginEvent.Result.ALLOWED) {
                     future.complete(false);
                     return;
                  }

                  this.firePlayerJoinEvent(player, name);
                  future.complete(true);
               } catch (Exception e) {
                  this.plugin.getLogger().log(Level.WARNING, "[LoginEventManager] Error in sync login events", e);
                  future.complete(false);
               }

            });
            return (Boolean)future.join();
         }
      });
   }

   public AsyncPlayerPreLoginEvent.Result fireAsyncPreLoginEvent(String name, InetAddress address, UUID uuid) {
      try {
         AsyncPlayerPreLoginEvent event;
         if (asyncPreLoginConstructor != null) {
            if (asyncPreLoginConstructor.getParameterCount() == 4) {
               String hostname = address != null ? address.getHostAddress() : "127.0.0.1";
               event = (AsyncPlayerPreLoginEvent)asyncPreLoginConstructor.newInstance(name, address, uuid, hostname);
            } else {
               event = (AsyncPlayerPreLoginEvent)asyncPreLoginConstructor.newInstance(name, address, uuid);
            }
         } else {
            try {
               event = new AsyncPlayerPreLoginEvent(name, address, uuid);
            } catch (Exception var6) {
               this.plugin.getLogger().fine("[LoginEventManager] Using fallback AsyncPlayerPreLoginEvent creation");
               return Result.ALLOWED;
            }
         }

         Bukkit.getPluginManager().callEvent(event);
         this.plugin.getLogger().fine("[LoginEventManager] AsyncPlayerPreLoginEvent fired for " + name + " result=" + String.valueOf(event.getLoginResult()));
         return event.getLoginResult();
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.FINE, "[LoginEventManager] Error firing AsyncPlayerPreLoginEvent for " + name, e);
         return Result.ALLOWED;
      }
   }

   public PlayerLoginEvent.Result firePlayerLoginEvent(Player player, InetAddress address) {
      try {
         if (playerLoginConstructor != null) {
            PlayerLoginEvent event;
            if (playerLoginConstructor.getParameterCount() == 3) {
               Class<?> thirdParam = playerLoginConstructor.getParameterTypes()[2];
               if (thirdParam == InetSocketAddress.class) {
                  InetSocketAddress socketAddress = new InetSocketAddress(address, 25565);
                  String hostname = address != null ? address.getHostAddress() : "127.0.0.1";
                  event = (PlayerLoginEvent)playerLoginConstructor.newInstance(player, hostname, socketAddress);
               } else {
                  String hostname = address != null ? address.getHostAddress() : "127.0.0.1";
                  event = (PlayerLoginEvent)playerLoginConstructor.newInstance(player, hostname, address);
               }
            } else {
               if (playerLoginConstructor.getParameterCount() != 2) {
                  return org.bukkit.event.player.PlayerLoginEvent.Result.ALLOWED;
               }

               String hostname = address != null ? address.getHostAddress() : "127.0.0.1";
               event = (PlayerLoginEvent)playerLoginConstructor.newInstance(player, hostname);
            }

            Bukkit.getPluginManager().callEvent(event);
            Logger var10000 = this.plugin.getLogger();
            String var10001 = player.getName();
            var10000.fine("[LoginEventManager] PlayerLoginEvent fired for " + var10001 + " result=" + String.valueOf(event.getResult()));
            return event.getResult();
         } else {
            return org.bukkit.event.player.PlayerLoginEvent.Result.ALLOWED;
         }
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.FINE, "[LoginEventManager] Error firing PlayerLoginEvent for " + player.getName(), e);
         return org.bukkit.event.player.PlayerLoginEvent.Result.ALLOWED;
      }
   }

   public void firePlayerJoinEvent(Player player, String name) {
      try {
         if (playerJoinConstructor == null) {
            return;
         }

         Class<?> secondParam = playerJoinConstructor.getParameterTypes()[1];
         PlayerJoinEvent event;
         if (secondParam == Component.class) {
            Component joinMessage = Component.text(name + " joined the game").color(NamedTextColor.YELLOW);
            event = (PlayerJoinEvent)playerJoinConstructor.newInstance(player, joinMessage);
         } else {
            String var10000 = String.valueOf(ChatColor.YELLOW);
            String joinMessage = var10000 + name + " joined the game";
            event = (PlayerJoinEvent)playerJoinConstructor.newInstance(player, joinMessage);
         }

         Bukkit.getPluginManager().callEvent(event);

         try {
            Component joinMessage = event.joinMessage();
            if (joinMessage != null) {
               Bukkit.broadcast(joinMessage);
            }
         } catch (NoSuchMethodError var6) {
         }

         this.plugin.getLogger().fine("[LoginEventManager] PlayerJoinEvent fired for " + name);
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.FINE, "[LoginEventManager] Error firing PlayerJoinEvent for " + name, e);
      }

   }

   public void firePlayerQuitEvent(Player player, String name) {
      try {
         if (playerQuitConstructor == null) {
            return;
         }

         Class<?> secondParam = playerQuitConstructor.getParameterTypes()[1];
         PlayerQuitEvent event;
         if (secondParam == Component.class) {
            Component quitMessage = Component.text(name + " left the game").color(NamedTextColor.YELLOW);
            event = (PlayerQuitEvent)playerQuitConstructor.newInstance(player, quitMessage);
         } else {
            String var10000 = String.valueOf(ChatColor.YELLOW);
            String quitMessage = var10000 + name + " left the game";
            event = (PlayerQuitEvent)playerQuitConstructor.newInstance(player, quitMessage);
         }

         Bukkit.getPluginManager().callEvent(event);

         try {
            Component quitMessage = event.quitMessage();
            if (quitMessage != null) {
               Bukkit.broadcast(quitMessage);
            }
         } catch (NoSuchMethodError var6) {
         }

         this.plugin.getLogger().fine("[LoginEventManager] PlayerQuitEvent fired for " + name);
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.FINE, "[LoginEventManager] Error firing PlayerQuitEvent for " + name, e);
      }

   }

   public boolean isPreLoginAllowed(String name, InetAddress address, UUID uuid) {
      return this.fireAsyncPreLoginEvent(name, address, uuid) == Result.ALLOWED;
   }
}
