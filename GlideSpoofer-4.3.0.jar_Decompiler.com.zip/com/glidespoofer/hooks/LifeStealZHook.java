package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import com.zetaplugins.lifestealz.LifeStealZ;
import com.zetaplugins.lifestealz.api.LifeStealZAPI;
import com.zetaplugins.lifestealz.storage.PlayerData;
import java.lang.reflect.Method;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class LifeStealZHook {
   private final GlideSpoofer plugin;
   private boolean enabled;
   private Plugin lifestealZPlugin;
   private LifeStealZAPI lifestealZAPI;
   private final ConcurrentHashMap<UUID, Integer> heartsCache = new ConcurrentHashMap();
   private final ConcurrentHashMap<UUID, Long> cacheTime = new ConcurrentHashMap();
   private static final long CACHE_DURATION_MS = 3000L;
   private final Random random = new Random();
   private static final int MIN_FAKE_HEARTS = 3;
   private static final int MAX_FAKE_HEARTS = 25;

   public LifeStealZHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.enabled = false;
      if (!plugin.getConfigManager().getConfig().getBoolean("hooks.lifestealz.enabled", true)) {
         plugin.getLogger().info("LifeStealZ hook disabled in config");
      } else {
         String[] possibleNames = new String[]{"LifeStealZ", "LifestealZ", "lifestealz"};

         for(String name : possibleNames) {
            this.lifestealZPlugin = Bukkit.getPluginManager().getPlugin(name);
            if (this.lifestealZPlugin != null) {
               plugin.getLogger().info("Found LifeStealZ plugin with name: " + name);
               break;
            }
         }

         if (this.lifestealZPlugin == null) {
            plugin.getLogger().info("LifeStealZ plugin not found - hook disabled");
         } else if (this.lifestealZPlugin.isEnabled()) {
            plugin.getLogger().info("LifeStealZ is enabled - initializing hook...");
            this.initializeHook();
         } else {
            plugin.getLogger().info("LifeStealZ found but not enabled yet");
         }
      }

   }

   private void initializeHook() {
      try {
         this.plugin.getLogger().info("Attempting to initialize LifeStealZ hook for version " + this.getPluginVersion() + "...");
         Plugin var2 = this.lifestealZPlugin;
         if (var2 instanceof LifeStealZ lifestealZ) {
            this.lifestealZAPI = lifestealZ.getAPI();
            if (this.lifestealZAPI != null) {
               this.enabled = true;
               this.plugin.getLogger().info("LifeStealZ hook enabled via official API!");
               return;
            }
         }

         try {
            Method getApiMethod = this.lifestealZPlugin.getClass().getMethod("getAPI");
            this.lifestealZAPI = (LifeStealZAPI)getApiMethod.invoke(this.lifestealZPlugin);
            if (this.lifestealZAPI != null) {
               this.enabled = true;
               this.plugin.getLogger().info("LifeStealZ hook enabled via reflection API!");
               return;
            }
         } catch (NoSuchMethodException var31) {
            this.plugin.getLogger().warning("LifeStealZ getAPI() method not found");
         }

         this.enabled = true;
         this.plugin.getLogger().info("LifeStealZ hook enabled (fake players only, using random hearts)");
      } catch (Exception var3) {
         this.plugin.getLogger().log(Level.WARNING, "Failed to initialize LifeStealZ hook", var3);
         this.enabled = true;
         this.plugin.getLogger().info("LifeStealZ hook enabled (fake players only, after error)");
      }

   }

   public boolean isEnabled() {
      return this.enabled && this.lifestealZPlugin != null;
   }

   public int getHearts(UUID uuid) {
      if (!this.isEnabled()) {
         return this.getDefaultHearts();
      } else {
         Long cachedTime = (Long)this.cacheTime.get(uuid);
         if (cachedTime != null && System.currentTimeMillis() - cachedTime < 3000L) {
            Integer cached = (Integer)this.heartsCache.get(uuid);
            if (cached != null) {
               return cached;
            }
         }

         int hearts = this.getDefaultHearts();
         boolean isFake = this.plugin.getSimpleFakePlayerManager() != null && this.plugin.getSimpleFakePlayerManager().isFakePlayer(uuid);
         if (isFake) {
            hearts = this.generateRandomHearts();
         } else {
            hearts = this.getRealPlayerHearts(uuid);
         }

         this.heartsCache.put(uuid, hearts);
         this.cacheTime.put(uuid, System.currentTimeMillis());
         return hearts;
      }
   }

   private int getRealPlayerHearts(UUID uuid) {
      if (this.lifestealZAPI == null) {
         return this.getDefaultHearts();
      } else {
         try {
            PlayerData playerData = this.lifestealZAPI.getPlayerData(uuid);
            if (playerData != null) {
               double maxHealth = playerData.getMaxHealth();
               return (int)(maxHealth / (double)2.0F);
            }
         } catch (Exception var5) {
            this.plugin.getLogger().fine("Failed to get hearts from LifeStealZ API: " + var5.getMessage());
         }

         Player player = Bukkit.getPlayer(uuid);
         if (player != null && player.isOnline()) {
            try {
               double maxHealth = player.getMaxHealth();
               return (int)(maxHealth / (double)2.0F);
            } catch (Exception var6) {
            }
         }

         return this.getDefaultHearts();
      }
   }

   private int generateRandomHearts() {
      int rand = this.random.nextInt(100);
      if (rand < 30) {
         return 3 + this.random.nextInt(3);
      } else if (rand < 60) {
         return 6 + this.random.nextInt(5);
      } else {
         return rand < 85 ? 11 + this.random.nextInt(5) : 16 + this.random.nextInt(10);
      }
   }

   public int getHearts(String name) {
      if (!this.isEnabled()) {
         return this.getDefaultHearts();
      } else {
         try {
            Player player = Bukkit.getPlayer(name);
            if (player != null && player.isOnline()) {
               return this.getHearts(player.getUniqueId());
            }

            OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(name);
            if (offlinePlayer != null && offlinePlayer.getUniqueId() != null) {
               return this.getHearts(offlinePlayer.getUniqueId());
            }
         } catch (Exception var4) {
            this.plugin.getLogger().fine("Failed to get hearts for name: " + name);
         }

         return this.getDefaultHearts();
      }
   }

   public int getDefaultHearts() {
      return 10;
   }

   public String getPluginVersion() {
      if (this.lifestealZPlugin != null) {
         try {
            return this.lifestealZPlugin.getPluginMeta().getVersion();
         } catch (Throwable var2) {
         }
      }

      return "unknown";
   }

   public void clearCache(UUID uuid) {
      this.heartsCache.remove(uuid);
      this.cacheTime.remove(uuid);
   }

   public void clearAllCache() {
      this.heartsCache.clear();
      this.cacheTime.clear();
   }

   public void shutdown() {
      this.clearAllCache();
      this.plugin.getLogger().fine("LifeStealZ hook shutdown complete");
   }
}
