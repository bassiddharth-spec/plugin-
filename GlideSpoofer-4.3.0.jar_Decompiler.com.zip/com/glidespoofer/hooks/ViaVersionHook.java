package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.nms.FakeChannelV2;
import com.glidespoofer.serverside.FakeChannel;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import sun.misc.Unsafe;

public class ViaVersionHook {
   private final GlideSpoofer plugin;
   private boolean enabled;
   private Plugin viaVersionPlugin;
   private Class<?> viaAPIClass;
   private Class<?> userConnectionClass;
   private Class<?> userConnectionImplClass;
   private Class<?> protocolInfoClass;
   private Class<?> protocolPipelineClass;
   private Class<?> connectionManagerClass;
   private Class<?> bukkitEncodeHandlerClass;
   private Object viaAPI;
   private Object connectionManager;
   private Method onLoginSuccessMethod;
   private Method onDisconnectMethod;
   private Method isConnectedMethod;
   private Field channelField;
   private Field protocolInfoField;
   private Method setUuidMethod;
   private Method setUsernameMethod;
   private Method setProtocolVersionMethod;
   private final Map<UUID, Object> fakeUserConnections = new HashMap();

   public ViaVersionHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.enabled = false;
      if (!plugin.getConfigManager().getConfig().getBoolean("hooks.viaversion.enabled", true)) {
         plugin.getLogger().info("[ViaVersionHook] Disabled in config");
      } else {
         this.initialize();
      }
   }

   private void initialize() {
      this.viaVersionPlugin = Bukkit.getPluginManager().getPlugin("ViaVersion");
      if (this.viaVersionPlugin != null && this.viaVersionPlugin.isEnabled()) {
         this.initializeReflection();
         if (this.enabled) {
            this.plugin.getLogger().info("[ViaVersionHook] Enabled! Fake players will be registered with ViaVersion.");
         }
      } else {
         this.plugin.getLogger().fine("[ViaVersionHook] ViaVersion not found or disabled");
      }

   }

   private void initializeReflection() {
      try {
         String[] apiClassNames = new String[]{"com.viaversion.viaversion.api.Via", "us.myles.ViaVersion.api.Via"};

         for(String className : apiClassNames) {
            try {
               this.viaAPIClass = Class.forName(className);
               break;
            } catch (ClassNotFoundException var21) {
            }
         }

         if (this.viaAPIClass == null) {
            this.plugin.getLogger().warning("[ViaVersionHook] Could not find Via API class");
            return;
         }

         Method getApi = this.viaAPIClass.getMethod("getAPI");
         this.viaAPI = getApi.invoke((Object)null);
         if (!this.initializeConnectionManager()) {
            this.plugin.getLogger().warning("[ViaVersionHook] Could not get ConnectionManager");
            return;
         }

         String[] userConnImplClassNames = new String[]{"com.viaversion.viaversion.connection.UserConnectionImpl", "us.myles.ViaVersion.classgenerator.GeneratedConnection"};

         for(String className : userConnImplClassNames) {
            try {
               this.userConnectionImplClass = Class.forName(className);
               this.plugin.getLogger().fine("[ViaVersionHook] Found UserConnectionImpl class: " + className);
               break;
            } catch (ClassNotFoundException var20) {
            }
         }

         String[] userConnClassNames = new String[]{"com.viaversion.viaversion.api.connection.UserConnection", "us.myles.ViaVersion.api.data.UserConnection"};

         for(String className : userConnClassNames) {
            try {
               this.userConnectionClass = Class.forName(className);
               break;
            } catch (ClassNotFoundException var19) {
            }
         }

         String[] protocolInfoClassNames = new String[]{"com.viaversion.viaversion.api.connection.ProtocolInfo", "com.viaversion.viaversion.protocol.ProtocolInfo", "com.viaversion.viaversion.data.ProtocolInfo"};

         for(String className : protocolInfoClassNames) {
            try {
               this.protocolInfoClass = Class.forName(className);
               this.plugin.getLogger().fine("[ViaVersionHook] Found ProtocolInfo class: " + className);
               break;
            } catch (ClassNotFoundException var18) {
            }
         }

         String[] pipelineClassNames = new String[]{"com.viaversion.viaversion.protocol.ProtocolPipelineImpl", "com.viaversion.viaversion.protocol.packet.ProtocolPipelineImpl"};

         for(String className : pipelineClassNames) {
            try {
               this.protocolPipelineClass = Class.forName(className);
               this.plugin.getLogger().fine("[ViaVersionHook] Found ProtocolPipeline class: " + className);
               break;
            } catch (ClassNotFoundException var17) {
            }
         }

         String[] encodeHandlerClassNames = new String[]{"com.viaversion.viaversion.bukkit.handlers.BukkitEncodeHandler", "us.myles.ViaVersion.bukkit.handlers.BukkitEncodeHandler"};

         for(String className : encodeHandlerClassNames) {
            try {
               this.bukkitEncodeHandlerClass = Class.forName(className);
               this.plugin.getLogger().fine("[ViaVersionHook] Found BukkitEncodeHandler class: " + className);
               break;
            } catch (ClassNotFoundException var16) {
            }
         }

         this.findConnectionMethods();
         if (this.userConnectionImplClass != null) {
            this.channelField = this.findField(this.userConnectionImplClass, Channel.class);
            if (this.channelField != null) {
               this.channelField.setAccessible(true);
            }
         }

         if (this.protocolInfoClass != null) {
            try {
               this.setUuidMethod = this.protocolInfoClass.getMethod("setUuid", UUID.class);
               this.plugin.getLogger().fine("[ViaVersionHook] Found setUuid method");
            } catch (NoSuchMethodException var15) {
               this.plugin.getLogger().warning("[ViaVersionHook] Could not find setUuid method");
            }

            try {
               this.setUsernameMethod = this.protocolInfoClass.getMethod("setUsername", String.class);
               this.plugin.getLogger().fine("[ViaVersionHook] Found setUsername method");
            } catch (NoSuchMethodException var14) {
               this.plugin.getLogger().warning("[ViaVersionHook] Could not find setUsername method");
            }

            try {
               Class<?> protocolVersionClass = Class.forName("com.viaversion.viaversion.api.protocol.version.ProtocolVersion");
               this.setProtocolVersionMethod = this.protocolInfoClass.getMethod("setProtocolVersion", protocolVersionClass);
               this.plugin.getLogger().fine("[ViaVersionHook] Found setProtocolVersion method");
            } catch (Exception e) {
               this.plugin.getLogger().fine("[ViaVersionHook] Could not find setProtocolVersion method: " + e.getMessage());
            }
         }

         if (this.userConnectionImplClass != null && this.protocolInfoClass != null) {
            this.protocolInfoField = this.findField(this.userConnectionImplClass, this.protocolInfoClass);
            if (this.protocolInfoField != null) {
               this.protocolInfoField.setAccessible(true);
            }
         }

         this.enabled = true;
         this.plugin.getLogger().info("[ViaVersionHook] Reflection initialized successfully");
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.WARNING, "[ViaVersionHook] API initialization failed: " + e.getMessage());
         e.printStackTrace();
      }

   }

   private boolean initializeConnectionManager() {
      try {
         Method getConnectionManager = this.viaAPIClass.getMethod("getConnectionManager");
         this.connectionManager = getConnectionManager.invoke(this.viaAPI);
         if (this.connectionManager != null) {
            this.connectionManagerClass = this.connectionManager.getClass();
            this.plugin.getLogger().fine("[ViaVersionHook] Got ConnectionManager via getAPI().getConnectionManager()");
            return true;
         }
      } catch (Exception e) {
         this.plugin.getLogger().fine("[ViaVersionHook] Method 1 failed: " + e.getMessage());
      }

      try {
         Method getManager = this.viaAPIClass.getMethod("getManager");
         Object manager = getManager.invoke((Object)null);
         if (manager != null) {
            Method getConnectionManager = manager.getClass().getMethod("getConnectionManager");
            this.connectionManager = getConnectionManager.invoke(manager);
            if (this.connectionManager != null) {
               this.connectionManagerClass = this.connectionManager.getClass();
               this.plugin.getLogger().fine("[ViaVersionHook] Got ConnectionManager via getManager().getConnectionManager()");
               return true;
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().fine("[ViaVersionHook] Method 2 failed: " + e.getMessage());
      }

      try {
         Class<?> viaManagerClass = Class.forName("com.viaversion.viaversion.ViaManagerImpl");
         Method getManager = this.viaAPIClass.getMethod("getManager");
         Object manager = getManager.invoke((Object)null);
         if (viaManagerClass.isInstance(manager)) {
            Method getConnectionManager = viaManagerClass.getMethod("getConnectionManager");
            this.connectionManager = getConnectionManager.invoke(manager);
            if (this.connectionManager != null) {
               this.connectionManagerClass = this.connectionManager.getClass();
               this.plugin.getLogger().fine("[ViaVersionHook] Got ConnectionManager via ViaManagerImpl");
               return true;
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().fine("[ViaVersionHook] Method 3 failed: " + e.getMessage());
      }

      return false;
   }

   private void findConnectionMethods() {
      if (this.connectionManagerClass != null) {
         for(Method m : this.connectionManagerClass.getMethods()) {
            String name = m.getName();
            if (name.equals("onLoginSuccess") && m.getParameterCount() == 1) {
               Class<?> paramType = m.getParameterTypes()[0];
               if (this.userConnectionClass != null && this.userConnectionClass.isAssignableFrom(paramType)) {
                  this.onLoginSuccessMethod = m;
                  this.plugin.getLogger().info("[ViaVersionHook] Found onLoginSuccess method: " + m.getName());
               }
            }

            if (name.equals("onDisconnect") && m.getParameterCount() == 1) {
               Class<?> paramType = m.getParameterTypes()[0];
               if (this.userConnectionClass != null && this.userConnectionClass.isAssignableFrom(paramType)) {
                  this.onDisconnectMethod = m;
                  this.plugin.getLogger().fine("[ViaVersionHook] Found onDisconnect method: " + m.getName());
               }
            }

            if (name.equals("hasServerConnection") && m.getParameterCount() == 1 && m.getParameterTypes()[0] == UUID.class) {
               this.isConnectedMethod = m;
               this.plugin.getLogger().fine("[ViaVersionHook] Found hasServerConnection method");
            }
         }

         if (this.onLoginSuccessMethod == null) {
            this.plugin.getLogger().warning("[ViaVersionHook] Could not find onLoginSuccess method - registration will fail!");
         }

      }
   }

   public void registerFakePlayer(UUID uuid, String name, Player player) {
      if (this.isEnabled() && uuid != null) {
         try {
            if (this.fakeUserConnections.containsKey(uuid)) {
               return;
            }

            if (this.isConnectedMethod != null && this.connectionManager != null) {
               Boolean connected = (Boolean)this.isConnectedMethod.invoke(this.connectionManager, uuid);
               if (connected != null && connected) {
                  this.plugin.getLogger().fine("[ViaVersionHook] Player " + name + " already registered with ViaVersion");
                  return;
               }
            }

            Channel playerChannel = this.getPlayerChannel(player);
            if (playerChannel == null) {
               this.plugin.getLogger().warning("[ViaVersionHook] Could not get channel from player " + name + ", using fallback");
               playerChannel = this.createRobustFakeChannel();
            }

            Object userConnection = this.createUserConnectionForChannel(playerChannel, uuid, name);
            if (userConnection != null && this.onLoginSuccessMethod != null && this.connectionManager != null) {
               this.onLoginSuccessMethod.invoke(this.connectionManager, userConnection);
               this.fakeUserConnections.put(uuid, userConnection);
               this.plugin.getLogger().info("[ViaVersionHook] Registered fake player " + name + " via onLoginSuccess");
            } else {
               this.plugin.getLogger().warning("[ViaVersionHook] Failed to create/register UserConnection for " + name);
            }
         } catch (Exception e) {
            this.plugin.getLogger().log(Level.WARNING, "[ViaVersionHook] Registration failed for " + name + ": " + e.getMessage());
            e.printStackTrace();
         }

      }
   }

   private Channel getPlayerChannel(Player player) {
      if (player == null) {
         return null;
      } else {
         try {
            Method getHandle = player.getClass().getMethod("getHandle");
            Object entityPlayer = getHandle.invoke(player);
            Field packetListenerField = this.findFieldByTypeName(entityPlayer.getClass(), false, "PlayerConnection", "ServerGamePacketListenerImpl");
            if (packetListenerField == null) {
               this.plugin.getLogger().fine("[ViaVersionHook] Could not find packet listener field");
               return null;
            } else {
               packetListenerField.setAccessible(true);
               Object packetListener = packetListenerField.get(entityPlayer);
               Field connectionField = this.findFieldByTypeName(packetListener.getClass(), true, "NetworkManager", "Connection");
               if (connectionField == null) {
                  this.plugin.getLogger().fine("[ViaVersionHook] Could not find connection field");
                  return null;
               } else {
                  connectionField.setAccessible(true);
                  Object connection = connectionField.get(packetListener);
                  Field channelField = this.findField(connection.getClass(), Channel.class);
                  if (channelField == null) {
                     this.plugin.getLogger().fine("[ViaVersionHook] Could not find channel field");
                     return null;
                  } else {
                     channelField.setAccessible(true);
                     return (Channel)channelField.get(connection);
                  }
               }
            }
         } catch (Exception e) {
            this.plugin.getLogger().warning("[ViaVersionHook] Could not get player channel: " + e.getMessage());
            return null;
         }
      }
   }

   private Field findFieldByTypeName(Class<?> clazz, boolean checkSuperClass, String... typeNames) {
      for(Field field : clazz.getDeclaredFields()) {
         String fieldTypeName = field.getType().getSimpleName();

         for(String typeName : typeNames) {
            if (fieldTypeName.equals(typeName)) {
               return field;
            }
         }
      }

      if (checkSuperClass && clazz != Object.class && clazz.getSuperclass() != null) {
         return this.findFieldByTypeName(clazz.getSuperclass(), true, typeNames);
      } else {
         return null;
      }
   }

   private Field findFieldByNames(Class<?> clazz, String... names) {
      for(String name : names) {
         try {
            Field field = clazz.getDeclaredField(name);
            return field;
         } catch (NoSuchFieldException var8) {
         }
      }

      Class<?> superClass = clazz.getSuperclass();
      if (superClass != null) {
         return this.findFieldByNames(superClass, names);
      } else {
         return null;
      }
   }

   private Object createUserConnectionForChannel(Channel channel, UUID uuid, String name) {
      try {
         if (this.userConnectionImplClass == null) {
            this.plugin.getLogger().warning("[ViaVersionHook] UserConnectionImpl class not found");
            return null;
         } else {
            Object userConnection = null;

            try {
               Constructor<?> constructor = this.userConnectionImplClass.getConstructor(Channel.class, Boolean.TYPE);
               userConnection = constructor.newInstance(channel, false);
               this.plugin.getLogger().fine("[ViaVersionHook] Created UserConnection via (Channel, boolean) constructor");
            } catch (NoSuchMethodException var8) {
               try {
                  Constructor<?> constructor = this.userConnectionImplClass.getConstructor(Channel.class);
                  userConnection = constructor.newInstance(channel);
                  this.plugin.getLogger().fine("[ViaVersionHook] Created UserConnection via (Channel) constructor");
               } catch (NoSuchMethodException var7) {
                  userConnection = this.tryCreateWithUnsafe();
                  if (userConnection != null) {
                     if (this.channelField != null) {
                        this.channelField.set(userConnection, channel);
                     }

                     this.plugin.getLogger().fine("[ViaVersionHook] Created UserConnection via Unsafe");
                  }
               }
            }

            if (userConnection == null) {
               this.plugin.getLogger().warning("[ViaVersionHook] Failed to create UserConnection instance");
               return null;
            } else {
               this.initializeProtocolPipeline(userConnection);
               this.initializeProtocolInfo(userConnection, uuid, name);
               this.injectEncodeHandlerIntoChannel(channel, userConnection);
               return userConnection;
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.WARNING, "[ViaVersionHook] Failed to create UserConnection: " + e.getMessage());
         e.printStackTrace();
         return null;
      }
   }

   public void registerFakePlayer(UUID uuid, Object connection) {
      this.registerFakePlayer(uuid, "unknown", (Player)null);
   }

   private Object createProperUserConnection(UUID uuid, String name) {
      try {
         if (this.userConnectionImplClass == null) {
            this.plugin.getLogger().warning("[ViaVersionHook] UserConnectionImpl class not found");
            return null;
         } else {
            Channel fakeChannel = this.createRobustFakeChannel();
            Object userConnection = null;

            try {
               Constructor<?> constructor = this.userConnectionImplClass.getConstructor(Channel.class, Boolean.TYPE);
               userConnection = constructor.newInstance(fakeChannel, false);
               this.plugin.getLogger().fine("[ViaVersionHook] Created UserConnection via (Channel, boolean) constructor");
            } catch (NoSuchMethodException var8) {
               try {
                  Constructor<?> constructor = this.userConnectionImplClass.getConstructor(Channel.class);
                  userConnection = constructor.newInstance(fakeChannel);
                  this.plugin.getLogger().fine("[ViaVersionHook] Created UserConnection via (Channel) constructor");
               } catch (NoSuchMethodException var7) {
                  userConnection = this.tryCreateWithUnsafe();
                  if (userConnection != null) {
                     if (this.channelField != null) {
                        this.channelField.set(userConnection, fakeChannel);
                     }

                     this.plugin.getLogger().fine("[ViaVersionHook] Created UserConnection via Unsafe");
                  }
               }
            }

            if (userConnection == null) {
               this.plugin.getLogger().warning("[ViaVersionHook] Failed to create UserConnection instance");
               return null;
            } else {
               this.initializeProtocolPipeline(userConnection);
               this.initializeProtocolInfo(userConnection, uuid, name);
               this.injectEncodeHandlerIntoChannel(fakeChannel, userConnection);
               return userConnection;
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.WARNING, "[ViaVersionHook] Failed to create UserConnection: " + e.getMessage());
         e.printStackTrace();
         return null;
      }
   }

   private void injectEncodeHandlerIntoChannel(Channel channel, Object userConnection) {
      if (this.bukkitEncodeHandlerClass == null) {
         this.plugin.getLogger().fine("[ViaVersionHook] BukkitEncodeHandler class not found, skipping pipeline injection");
      } else {
         try {
            Constructor<?> handlerConstructor = this.bukkitEncodeHandlerClass.getConstructor(this.userConnectionClass);
            Object handler = handlerConstructor.newInstance(userConnection);
            String encoderName = this.getViaEncoderName();
            channel.pipeline().addLast(encoderName, (ChannelHandler)handler);
            this.plugin.getLogger().fine("[ViaVersionHook] Injected BukkitEncodeHandler into channel pipeline as: " + encoderName);
         } catch (Exception e) {
            this.plugin.getLogger().warning("[ViaVersionHook] Failed to inject BukkitEncodeHandler: " + e.getMessage());
         }

      }
   }

   private String getViaEncoderName() {
      try {
         if (this.viaAPI != null) {
            Method getManager = this.viaAPIClass.getMethod("getManager");
            Object manager = getManager.invoke((Object)null);
            if (manager != null) {
               Method getInjector = manager.getClass().getMethod("getInjector");
               Object injector = getInjector.invoke(manager);
               if (injector != null) {
                  Method getEncoderName = injector.getClass().getMethod("getEncoderName");
                  return (String)getEncoderName.invoke(injector);
               }
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().fine("[ViaVersionHook] Could not get encoder name: " + e.getMessage());
      }

      return "via-encoder";
   }

   private void initializeProtocolPipeline(Object userConnection) {
      if (this.protocolPipelineClass == null) {
         this.plugin.getLogger().fine("[ViaVersionHook] ProtocolPipeline class not found, skipping pipeline init");
      } else {
         try {
            Constructor<?> pipelineConstructor = this.protocolPipelineClass.getConstructor(this.userConnectionClass != null ? this.userConnectionClass : this.userConnectionImplClass);
            pipelineConstructor.newInstance(userConnection);
            this.plugin.getLogger().fine("[ViaVersionHook] Initialized ProtocolPipeline");
         } catch (Exception e) {
            this.plugin.getLogger().fine("[ViaVersionHook] Failed to initialize ProtocolPipeline: " + e.getMessage());
         }

      }
   }

   private void initializeProtocolInfo(Object userConnection, UUID uuid, String name) {
      Object protocolInfo = null;
      if (this.protocolInfoField != null) {
         try {
            protocolInfo = this.protocolInfoField.get(userConnection);
         } catch (Exception e) {
            this.plugin.getLogger().fine("[ViaVersionHook] Could not get ProtocolInfo from UserConnection: " + e.getMessage());
         }
      }

      if (protocolInfo == null) {
         this.plugin.getLogger().warning("[ViaVersionHook] ProtocolInfo is null - this should not happen!");
      } else {
         if (this.setUuidMethod != null) {
            try {
               this.setUuidMethod.invoke(protocolInfo, uuid);
               Logger var10000 = this.plugin.getLogger();
               String var10001 = String.valueOf(uuid);
               var10000.fine("[ViaVersionHook] Set UUID " + var10001 + " for " + name);
            } catch (Exception e) {
               this.plugin.getLogger().warning("[ViaVersionHook] Could not set UUID on ProtocolInfo: " + e.getMessage());
            }
         } else {
            this.plugin.getLogger().warning("[ViaVersionHook] setUuidMethod is null - cannot set UUID!");
         }

         if (this.setUsernameMethod != null) {
            try {
               this.setUsernameMethod.invoke(protocolInfo, name);
               this.plugin.getLogger().fine("[ViaVersionHook] Set username " + name);
            } catch (Exception e) {
               this.plugin.getLogger().fine("[ViaVersionHook] Could not set username on ProtocolInfo: " + e.getMessage());
            }
         }

         if (this.setProtocolVersionMethod != null) {
            try {
               Object protocolVersion = this.getServerProtocolVersionObject();
               if (protocolVersion != null) {
                  this.setProtocolVersionMethod.invoke(protocolInfo, protocolVersion);
                  this.plugin.getLogger().fine("[ViaVersionHook] Set protocol version");
               }
            } catch (Exception e) {
               this.plugin.getLogger().fine("[ViaVersionHook] Could not set protocol version: " + e.getMessage());
            }
         }

         this.plugin.getLogger().info("[ViaVersionHook] ProtocolInfo initialized for " + name + " with UUID " + String.valueOf(uuid));
      }
   }

   private Object getServerProtocolVersionObject() {
      try {
         Class<?> protocolVersionClass = Class.forName("com.viaversion.viaversion.api.protocol.version.ProtocolVersion");
         Method getProtocol = protocolVersionClass.getMethod("getProtocol", Integer.TYPE);
         int serverVersion = this.getServerProtocolVersion();
         return getProtocol.invoke((Object)null, serverVersion);
      } catch (Exception e) {
         this.plugin.getLogger().fine("[ViaVersionHook] Could not get ProtocolVersion object: " + e.getMessage());
         return null;
      }
   }

   private Object tryCreateWithUnsafe() {
      try {
         Unsafe unsafe = this.getUnsafe();
         if (unsafe != null && this.userConnectionImplClass != null) {
            return unsafe.allocateInstance(this.userConnectionImplClass);
         }
      } catch (Exception e) {
         this.plugin.getLogger().fine("[ViaVersionHook] Unsafe allocation failed: " + e.getMessage());
      }

      return null;
   }

   private Channel createRobustFakeChannel() {
      try {
         return new FakeChannelV2((Channel)null, InetAddress.getLoopbackAddress());
      } catch (Exception var2) {
         return new FakeChannel();
      }
   }

   private int getServerProtocolVersion() {
      try {
         if (this.viaAPI != null) {
            Method getServerVersion = this.viaAPI.getClass().getMethod("getServerVersion");
            Object version = getServerVersion.invoke(this.viaAPI);
            if (version instanceof Integer) {
               return (Integer)version;
            }
         }
      } catch (Exception var3) {
      }

      return 767;
   }

   public void unregisterFakePlayer(UUID uuid) {
      if (this.isEnabled() && uuid != null) {
         try {
            Object userConnection = this.fakeUserConnections.remove(uuid);
            if (userConnection != null && this.onDisconnectMethod != null && this.connectionManager != null) {
               this.onDisconnectMethod.invoke(this.connectionManager, userConnection);
               this.plugin.getLogger().fine("[ViaVersionHook] Unregistered fake player " + String.valueOf(uuid) + " via onDisconnect");
            } else if (userConnection == null) {
               this.plugin.getLogger().fine("[ViaVersionHook] Connection not tracked, may have already been removed");
            }
         } catch (Exception e) {
            this.plugin.getLogger().log(Level.FINE, "[ViaVersionHook] Unregistration failed: " + e.getMessage());
         }

      }
   }

   public int getPlayerProtocolVersion(UUID uuid) {
      if (this.isEnabled() && uuid != null) {
         try {
            if (this.viaAPI != null) {
               Method getProtocolVersion = this.viaAPI.getClass().getMethod("getProtocolVersion", UUID.class);
               Object version = getProtocolVersion.invoke(this.viaAPI, uuid);
               if (version instanceof Integer) {
                  return (Integer)version;
               }
            }
         } catch (Exception var4) {
         }

         return -1;
      } else {
         return -1;
      }
   }

   public boolean isEnabled() {
      return this.enabled && this.viaVersionPlugin != null && this.viaVersionPlugin.isEnabled();
   }

   public static boolean isViaVersionActive() {
      Plugin viaVersion = Bukkit.getPluginManager().getPlugin("ViaVersion");
      return viaVersion != null && viaVersion.isEnabled();
   }

   private Unsafe getUnsafe() {
      try {
         Field unsafeField = Unsafe.class.getDeclaredField("theUnsafe");
         unsafeField.setAccessible(true);
         return (Unsafe)unsafeField.get((Object)null);
      } catch (Exception var2) {
         return null;
      }
   }

   private Field findField(Class<?> clazz, Class<?> type) {
      for(Field f : clazz.getDeclaredFields()) {
         if (type.isAssignableFrom(f.getType())) {
            return f;
         }
      }

      Class<?> superClass = clazz.getSuperclass();
      if (superClass != null) {
         return this.findField(superClass, type);
      } else {
         return null;
      }
   }
}
