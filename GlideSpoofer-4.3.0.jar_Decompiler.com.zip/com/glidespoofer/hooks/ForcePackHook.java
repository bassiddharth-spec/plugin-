package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class ForcePackHook {
   private final GlideSpoofer plugin;
   private boolean enabled;
   private Plugin forcePackPlugin;
   private Class<?> forcePackClass;
   private Class<?> packManagerClass;
   private Class<?> statusManagerClass;
   private Object forcePackInstance;
   private final Map<UUID, Boolean> fakePlayerStatus = new ConcurrentHashMap();

   public ForcePackHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.enabled = false;
      if (!plugin.getConfigManager().getConfig().getBoolean("hooks.forcepack.enabled", true)) {
         plugin.getLogger().info("[ForcePackHook] Disabled in config");
      } else {
         this.initialize();
      }
   }

   private void initialize() {
      try {
         this.forcePackPlugin = Bukkit.getPluginManager().getPlugin("ForcePack");
         if (this.forcePackPlugin == null) {
            this.forcePackPlugin = Bukkit.getPluginManager().getPlugin("forcepack");
            if (this.forcePackPlugin == null) {
               this.forcePackPlugin = Bukkit.getPluginManager().getPlugin("Force-Pack");
            }
         }

         if (this.forcePackPlugin == null || !this.forcePackPlugin.isEnabled()) {
            this.plugin.getLogger().fine("[ForcePackHook] ForcePack not found or disabled");
            return;
         }

         this.plugin.getLogger().info("[ForcePackHook] Found ForcePack: " + this.forcePackPlugin.getDescription().getVersion());
         this.initializeReflection();
         this.enabled = true;
         this.plugin.getLogger().info("[ForcePackHook] Hook enabled successfully!");
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.WARNING, "[ForcePackHook] Failed to initialize hook: " + e.getMessage());
      }

   }

   private void initializeReflection() {
      try {
         String[] classNames = new String[]{"com.github.imifou.client.Main", "me.ianguerin.forcepack.ForcePack", "com.ianguerin.forcepack.ForcePack", "forcepack.ForcePack", "io.github.imifou.client.Main"};

         for(String className : classNames) {
            try {
               this.forcePackClass = Class.forName(className);
               this.plugin.getLogger().fine("[ForcePackHook] Found main class: " + className);
               break;
            } catch (ClassNotFoundException var12) {
            }
         }

         if (this.forcePackClass != null) {
            try {
               Field instanceField = this.forcePackClass.getDeclaredField("instance");
               instanceField.setAccessible(true);
               this.forcePackInstance = instanceField.get((Object)null);
               this.plugin.getLogger().fine("[ForcePackHook] Got ForcePack instance");
            } catch (Exception var9) {
               this.forcePackInstance = this.forcePackPlugin;
            }
         }

         String[] managerClassNames = new String[]{"com.github.imifou.client.manager.PackManager", "me.ianguerin.forcepack.manager.PackManager", "com.ianguerin.forcepack.manager.PackManager", "forcepack.manager.PackManager"};

         for(String className : managerClassNames) {
            try {
               this.packManagerClass = Class.forName(className);
               this.plugin.getLogger().fine("[ForcePackHook] Found pack manager class: " + className);
               break;
            } catch (ClassNotFoundException var11) {
            }
         }

         String[] statusClassNames = new String[]{"com.github.imifou.client.manager.StatusManager", "me.ianguerin.forcepack.manager.StatusManager", "com.ianguerin.forcepack.manager.StatusManager", "forcepack.manager.StatusManager"};

         for(String className : statusClassNames) {
            try {
               this.statusManagerClass = Class.forName(className);
               this.plugin.getLogger().fine("[ForcePackHook] Found status manager class: " + className);
               break;
            } catch (ClassNotFoundException var10) {
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.FINE, "[ForcePackHook] Reflection initialization failed", e);
      }

   }

   public void registerFakePlayer(Player player, UUID uuid, String name) {
      if (this.isEnabled()) {
         try {
            if (this.forcePackInstance != null && this.statusManagerClass != null) {
               Field statusField = this.findField(this.forcePackInstance.getClass(), this.statusManagerClass);
               if (statusField != null) {
                  statusField.setAccessible(true);
                  Object statusManager = statusField.get(this.forcePackInstance);
                  if (statusManager != null) {
                     Method addMethod = this.findMethod(statusManager.getClass(), "add", "register", "put");
                     if (addMethod != null) {
                        addMethod.setAccessible(true);
                        Class<?>[] params = addMethod.getParameterTypes();
                        if (params.length == 2 && params[0] == UUID.class) {
                           addMethod.invoke(statusManager, uuid, this.getAcceptedStatus());
                        } else if (params.length == 1 && params[0] == Player.class) {
                           addMethod.invoke(statusManager, player);
                        }

                        this.plugin.getLogger().fine("[ForcePackHook] Registered " + name + " via " + addMethod.getName());
                     }
                  }
               }
            }

            this.fakePlayerStatus.put(uuid, true);
            this.plugin.getLogger().fine("[ForcePackHook] Registered fake player: " + name);
         } catch (Exception e) {
            this.plugin.getLogger().log(Level.FINE, "[ForcePackHook] Could not register fake player " + name + ": " + e.getMessage());
         }

      }
   }

   public void unregisterFakePlayer(UUID uuid, String name) {
      if (this.isEnabled()) {
         try {
            if (this.forcePackInstance != null && this.statusManagerClass != null) {
               Field statusField = this.findField(this.forcePackInstance.getClass(), this.statusManagerClass);
               if (statusField != null) {
                  statusField.setAccessible(true);
                  Object statusManager = statusField.get(this.forcePackInstance);
                  if (statusManager != null) {
                     Method removeMethod = this.findMethod(statusManager.getClass(), "remove", "unregister");
                     if (removeMethod != null) {
                        removeMethod.setAccessible(true);
                        Class<?>[] params = removeMethod.getParameterTypes();
                        if (params.length == 1 && params[0] == UUID.class) {
                           removeMethod.invoke(statusManager, uuid);
                           this.plugin.getLogger().fine("[ForcePackHook] Unregistered " + name + " via " + removeMethod.getName());
                        }
                     }
                  }
               }
            }

            this.fakePlayerStatus.remove(uuid);
            this.plugin.getLogger().fine("[ForcePackHook] Unregistered fake player: " + name);
         } catch (Exception e) {
            this.plugin.getLogger().log(Level.FINE, "[ForcePackHook] Could not unregister fake player " + name + ": " + e.getMessage());
         }

      }
   }

   private Object getAcceptedStatus() {
      try {
         Class<?> statusClass = null;
         String[] statusClassNames = new String[]{"com.github.imifou.client.data.PackStatus", "me.ianguerin.forcepack.data.PackStatus", "com.ianguerin.forcepack.data.PackStatus", "forcepack.data.PackStatus"};

         for(String className : statusClassNames) {
            try {
               statusClass = Class.forName(className);
               break;
            } catch (ClassNotFoundException var8) {
            }
         }

         if (statusClass != null && statusClass.isEnum()) {
            for(Object constant : statusClass.getEnumConstants()) {
               String name = constant.toString().toUpperCase();
               if (name.contains("ACCEPTED") || name.contains("SUCCESS") || name.contains("LOADED")) {
                  return constant;
               }
            }

            Object[] constants = statusClass.getEnumConstants();
            if (constants.length > 0) {
               return constants[0];
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().fine("[ForcePackHook] Could not get accepted status: " + e.getMessage());
      }

      return null;
   }

   public boolean isEnabled() {
      return this.enabled && this.forcePackPlugin != null && this.forcePackPlugin.isEnabled();
   }

   public boolean isFakePlayer(UUID uuid) {
      return this.fakePlayerStatus.containsKey(uuid);
   }

   public boolean hasAcceptedPack(UUID uuid) {
      return (Boolean)this.fakePlayerStatus.getOrDefault(uuid, true);
   }

   private Field findField(Class<?> clazz, Class<?> type) {
      for(Field f : clazz.getDeclaredFields()) {
         if (type.isAssignableFrom(f.getType())) {
            return f;
         }
      }

      if (clazz.getSuperclass() != null) {
         return this.findField(clazz.getSuperclass(), type);
      } else {
         return null;
      }
   }

   private Method findMethod(Class<?> clazz, String... names) {
      for(Method m : clazz.getDeclaredMethods()) {
         for(String name : names) {
            if (m.getName().toLowerCase().contains(name.toLowerCase())) {
               return m;
            }
         }
      }

      if (clazz.getSuperclass() != null) {
         return this.findMethod(clazz.getSuperclass(), names);
      } else {
         return null;
      }
   }

   public Plugin getForcePackPlugin() {
      return this.forcePackPlugin;
   }
}
