package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import java.lang.reflect.Method;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class WorldGuardHook {
   private final GlideSpoofer plugin;
   private boolean enabled;
   private Object worldGuardPlugin;

   public WorldGuardHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.enabled = false;
      if (!plugin.getConfigManager().getConfig().getBoolean("hooks.worldguard.enabled", true)) {
         plugin.getLogger().info("WorldGuard hook disabled in config");
      } else {
         Plugin wgPlugin = plugin.getServer().getPluginManager().getPlugin("WorldGuard");
         if (wgPlugin != null && wgPlugin.isEnabled()) {
            this.worldGuardPlugin = wgPlugin;
            this.enabled = true;
            plugin.getLogger().info("WorldGuard hook enabled!");
         }
      }

   }

   public boolean isEnabled() {
      return this.enabled && this.worldGuardPlugin != null;
   }

   public boolean isPvPDisabled(Location location) {
      if (!this.isEnabled()) {
         return false;
      } else {
         try {
            return this.checkPvPModern(location);
         } catch (Exception var5) {
            try {
               return this.checkPvPLegacy(location);
            } catch (Exception var4) {
               this.plugin.getLogger().fine("[WorldGuard] Error checking PvP: " + var4.getMessage());
               return false;
            }
         }
      }
   }

   private boolean checkPvPModern(Location location) throws Exception {
      Class<?> wgClass = Class.forName("com.sk89mc.worldguard.WorldGuard");
      Class<?> adapterClass = Class.forName("com.sk89mc.worldguard.bukkit.BukkitAdapter");
      Class<?> flagsClass = Class.forName("com.sk89mc.worldguard.protection.flags.Flags");
      Class<?> stateFlagClass = Class.forName("com.sk89mc.worldguard.protection.flags.StateFlag");
      Object wgInstance = wgClass.getMethod("getInstance").invoke((Object)null);
      Object platform = wgClass.getMethod("getPlatform").invoke(wgInstance);
      Object regionContainer = platform.getClass().getMethod("getRegionContainer").invoke(platform);
      Object world = adapterClass.getMethod("adapt", World.class).invoke((Object)null, location.getWorld());
      Object blockVector = adapterClass.getMethod("asBlockVector", Location.class).invoke((Object)null, location);
      Object regionManager = regionContainer.getClass().getMethod("get", Class.forName("com.sk89mc.worldguard.world.World")).invoke(regionContainer, world);
      if (regionManager == null) {
         return false;
      } else {
         Object regions = regionManager.getClass().getMethod("getApplicableRegions", Class.forName("com.sk89mc.worldguard.util.BlockVector3")).invoke(regionManager, blockVector);
         if (regions == null) {
            return false;
         } else {
            Object pvpFlag = flagsClass.getField("PVP").get((Object)null);
            Object result = regions.getClass().getMethod("queryState", Object.class, stateFlagClass).invoke(regions, null, pvpFlag);
            return result instanceof Enum ? result.toString().equals("DENY") : false;
         }
      }
   }

   private boolean checkPvPLegacy(Location location) throws Exception {
      Class<?> wgClass = Class.forName("com.sk89mq.worldguard.bukkit.WorldGuardPlugin");
      Class<?> regionManagerClass = Class.forName("com.sk89mq.worldguard.protection.managers.RegionManager");
      Class<?> stateFlagClass = Class.forName("com.sk89mq.worldguard.protection.flags.StateFlag");
      Object wg = this.worldGuardPlugin;
      Object regionManager = wgClass.getMethod("getRegionManager", World.class).invoke(wg, location.getWorld());
      if (regionManager == null) {
         return false;
      } else {
         Object regions = regionManagerClass.getMethod("getApplicableRegions", Location.class).invoke(regionManager, location);
         if (regions == null) {
            return false;
         } else {
            try {
               Class<?> defaultFlagClass = Class.forName("com.sk89mq.worldguard.protection.flags.DefaultFlag");
               Object pvpFlag = defaultFlagClass.getField("PVP").get((Object)null);
               Method allowsMethod = regions.getClass().getMethod("allows", stateFlagClass);
               Object result = allowsMethod.invoke(regions, pvpFlag);
               if (result instanceof Boolean) {
                  return !(Boolean)result;
               }
            } catch (Exception var12) {
            }

            return false;
         }
      }
   }

   public boolean isPvPDisabled(Player player) {
      return player == null ? false : this.isPvPDisabled(player.getLocation());
   }

   public boolean shouldCancelAttack(Player attacker, Player defender) {
      return !this.isEnabled() ? false : this.isPvPDisabled(defender.getLocation());
   }

   public Object getWorldGuard() {
      return this.worldGuardPlugin;
   }
}
