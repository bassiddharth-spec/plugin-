package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.LinkedHashSet;
import java.util.UUID;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.plugin.Plugin;

public class InteractiveChatHook {
   private final GlideSpoofer plugin;
   private boolean enabled;
   private Plugin interactiveChatPlugin;
   private Method markSenderMethod;
   private Method createOrUpdateRemoteICPlayerMethod;
   private Method removeRemoteICPlayerMethod;
   private Method getICPlayerMethod;
   private Method resetCacheMethod;
   private Field resetNamesField;

   public InteractiveChatHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.enabled = false;
      if (!plugin.getConfigManager().getConfig().getBoolean("chat-hooks.interactive-chat.enabled", true)) {
         plugin.getLogger().info("InteractiveChat hook disabled in config");
      } else {
         this.interactiveChatPlugin = Bukkit.getPluginManager().getPlugin("InteractiveChat");
         if (this.interactiveChatPlugin != null && this.interactiveChatPlugin.isEnabled()) {
            try {
               this.initReflection();
               this.enabled = true;
               plugin.getLogger().info("InteractiveChat hook enabled! Fake players will use IC for chat with hover events.");
            } catch (Exception var3) {
               plugin.getLogger().log(Level.WARNING, "Failed to initialize InteractiveChat hook: " + var3.getMessage(), var3);
            }
         } else {
            plugin.getLogger().info("InteractiveChat not found - hook disabled");
         }
      }

   }

   private void initReflection() throws Exception {
      Class<?> icApiClass = Class.forName("com.loohp.interactivechat.api.InteractiveChatAPI");
      this.markSenderMethod = icApiClass.getMethod("markSender", String.class, UUID.class);
      Class<?> icPlayerFactoryClass = Class.forName("com.loohp.interactivechat.objectholders.ICPlayerFactory");

      try {
         this.createOrUpdateRemoteICPlayerMethod = icPlayerFactoryClass.getMethod("createOrUpdateRemoteICPlayer", String.class, String.class, UUID.class, Boolean.TYPE, Integer.TYPE, Integer.TYPE, Inventory.class, Inventory.class, Boolean.TYPE);
      } catch (NoSuchMethodException var91) {
         this.plugin.getLogger().info("createOrUpdateRemoteICPlayer method not found - using alternative registration");
      }

      try {
         this.removeRemoteICPlayerMethod = icPlayerFactoryClass.getMethod("removeRemoteICPlayer", UUID.class);
      } catch (NoSuchMethodException var8) {
      }

      try {
         this.resetCacheMethod = icPlayerFactoryClass.getMethod("getOnlineICPlayers");
      } catch (NoSuchMethodException var7) {
      }

      try {
         Class<?> playerNameDisplayClass = Class.forName("com.loohp.interactivechat.modules.PlayernameDisplay");
         this.resetCacheMethod = playerNameDisplayClass.getMethod("resetCache");

         try {
            Field namesField = playerNameDisplayClass.getDeclaredField("names");
            namesField.setAccessible(true);
            this.resetNamesField = namesField;
         } catch (Exception var5) {
            this.plugin.getLogger().fine("Cannot access PlayernameDisplay.names field: " + var5.getMessage());
         }
      } catch (Exception var6) {
         this.plugin.getLogger().fine("PlayernameDisplay.resetCache() not found: " + var6.getMessage());
      }

      this.getICPlayerMethod = icPlayerFactoryClass.getMethod("getICPlayer", UUID.class);
   }

   public boolean isEnabled() {
      return this.enabled && this.interactiveChatPlugin != null && this.interactiveChatPlugin.isEnabled();
   }

   public String markSender(String message, UUID senderUuid) {
      if (this.isEnabled() && this.markSenderMethod != null) {
         try {
            return (String)this.markSenderMethod.invoke((Object)null, message, senderUuid);
         } catch (Exception var4) {
            this.plugin.getLogger().log(Level.WARNING, "Error marking sender: " + var4.getMessage(), var4);
            return message;
         }
      } else {
         return message;
      }
   }

   public boolean registerFakePlayer(String name, UUID uuid) {
      if (!this.isEnabled()) {
         return false;
      } else {
         if (this.createOrUpdateRemoteICPlayerMethod != null) {
            try {
               Inventory emptyInv = Bukkit.createInventory((InventoryHolder)null, 45);
               Inventory emptyEnder = Bukkit.createInventory((InventoryHolder)null, 9);
               this.createOrUpdateRemoteICPlayerMethod.invoke((Object)null, "GlideSpoofer", name, uuid, true, 0, 0, emptyInv, emptyEnder, false);
               if (this.resetCacheMethod != null) {
                  try {
                     if (this.resetNamesField != null) {
                        this.resetNamesField.set((Object)null, new LinkedHashSet());
                     }

                     this.resetCacheMethod.invoke((Object)null);
                     this.plugin.getLogger().fine("Reset IC PlayernameDisplay cache for " + name);
                  } catch (Exception var8) {
                     this.plugin.getLogger().log(Level.FINE, "Error resetting IC cache: " + var8.getMessage());
                  }
               }

               this.plugin.getLogger().fine("Registered fake player " + name + " with InteractiveChat");
               return true;
            } catch (Exception var9) {
               this.plugin.getLogger().log(Level.WARNING, "Error registering fake player with IC (remote method): " + var9.getMessage(), var9);
            }
         }

         try {
            Class<?> icPlayerFactoryClass = Class.forName("com.loohp.interactivechat.objectholders.ICPlayerFactory");
            Object unsafe = icPlayerFactoryClass.getDeclaredMethod("getUnsafe").invoke((Object)null);
            Method triggerJoinMethod = unsafe.getClass().getMethod("triggerPlayerJoinEarly", Player.class);
            Player fakePlayer = Bukkit.getPlayer(uuid);
            if (fakePlayer != null) {
               triggerJoinMethod.invoke(unsafe, fakePlayer);
               this.plugin.getLogger().fine("Registered fake player " + name + " with InteractiveChat (Unsafe API)");
               return true;
            }
         } catch (Exception var7) {
            this.plugin.getLogger().log(Level.FINE, "Unsafe registration not available: " + var7.getMessage());
         }

         return false;
      }
   }

   public void unregisterFakePlayer(UUID uuid) {
      if (this.isEnabled() && this.removeRemoteICPlayerMethod != null) {
         try {
            this.removeRemoteICPlayerMethod.invoke((Object)null, uuid);
            this.plugin.getLogger().fine("Unregistered fake player from InteractiveChat");
         } catch (Exception var3) {
            this.plugin.getLogger().log(Level.FINE, "Error unregistering fake player: " + var3.getMessage());
         }
      }

   }

   public boolean isPlayerRegistered(UUID uuid) {
      if (this.isEnabled() && this.getICPlayerMethod != null) {
         try {
            return this.getICPlayerMethod.invoke((Object)null, uuid) != null;
         } catch (Exception var3) {
            return false;
         }
      } else {
         return false;
      }
   }

   public Plugin getPlugin() {
      return this.interactiveChatPlugin;
   }
}
