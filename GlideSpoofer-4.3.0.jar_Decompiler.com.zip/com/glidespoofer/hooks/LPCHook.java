package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class LPCHook {
   private final GlideSpoofer plugin;
   private boolean enabled;
   private Plugin lpcPlugin;

   public LPCHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.enabled = false;
      if (!plugin.getConfigManager().getConfig().getBoolean("chat-hooks.lpc.enabled", true)) {
         plugin.getLogger().info("LPC hook disabled in config");
      } else {
         this.lpcPlugin = Bukkit.getPluginManager().getPlugin("LPC");
         if (this.lpcPlugin != null && this.lpcPlugin.isEnabled()) {
            this.enabled = true;
            plugin.getLogger().info("LPC hook enabled! Fake players will use LPC for chat formatting.");
         } else {
            plugin.getLogger().info("LPC not found - hook disabled");
         }
      }

   }

   public boolean isEnabled() {
      return this.enabled && this.lpcPlugin != null && this.lpcPlugin.isEnabled();
   }

   public boolean shouldFormatWithLPC() {
      return this.isEnabled();
   }

   public Plugin getPlugin() {
      return this.lpcPlugin;
   }

   public boolean isFakePlayer(Player player) {
      if (this.isEnabled() && player != null) {
         return this.plugin.getSimpleFakePlayerManager() != null ? this.plugin.getSimpleFakePlayerManager().isFakePlayer(player) : false;
      } else {
         return false;
      }
   }
}
