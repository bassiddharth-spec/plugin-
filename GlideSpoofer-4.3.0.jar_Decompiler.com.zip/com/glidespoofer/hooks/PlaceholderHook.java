package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.FakePlayer;
import com.glidespoofer.messaging.ProxyMessenger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PlaceholderHook extends PlaceholderExpansion {
   private final GlideSpoofer plugin;
   private Connection dbConnection;
   private boolean dbEnabled = false;
   private final Map<String, Integer> serverFakeCountsCache = new HashMap();
   private int totalFakeCountCache = 0;

   public PlaceholderHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.initializeDatabaseSync();
   }

   private void initializeDatabaseSync() {
      ConfigurationSection dbConfig = this.plugin.getConfigManager().getConfig().getConfigurationSection("velocity-sync.database");
      if (dbConfig != null && dbConfig.getBoolean("enabled", false)) {
         try {
            String host = dbConfig.getString("host", "localhost");
            int port = dbConfig.getInt("port", 3306);
            String database = dbConfig.getString("database", "glidespoofer");
            String username = dbConfig.getString("username", "root");
            String password = dbConfig.getString("password", "");
            this.dbConnection = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + database + "?useSSL=false&autoReconnect=true&useUnicode=true&characterEncoding=UTF-8", username, password);
            this.dbEnabled = true;
            if (GlideSpoofer.isFolia()) {
               Bukkit.getGlobalRegionScheduler().runAtFixedRate(this.plugin, (task) -> this.syncFromDatabase(), 100L, 100L);
            } else {
               Bukkit.getScheduler().runTaskTimer(this.plugin, this::syncFromDatabase, 100L, 100L);
            }
         } catch (SQLException var7) {
            this.plugin.getLogger().warning("Failed to connect to placeholder database: " + var7.getMessage());
         }
      }

   }

   private void syncFromDatabase() {
      if (this.dbEnabled && this.dbConnection != null) {
         try {
            if (this.dbConnection.isClosed()) {
               this.initializeDatabaseSync();
               return;
            }

            long twoMinAgo = System.currentTimeMillis() - 120000L;
            String query = "SELECT server_name, fake_players FROM server_data WHERE last_updated > ?";
            PreparedStatement pstmt = this.dbConnection.prepareStatement(query);

            try {
               pstmt.setLong(1, twoMinAgo);
               ResultSet rs = pstmt.executeQuery();

               try {
                  this.serverFakeCountsCache.clear();

                  int fakeCount;
                  for(this.totalFakeCountCache = 0; rs.next(); this.totalFakeCountCache += fakeCount) {
                     String serverName = rs.getString("server_name");
                     fakeCount = rs.getInt("fake_players");
                     this.serverFakeCountsCache.put(serverName, fakeCount);
                  }

                  if (this.plugin.getConfigManager().isDebugEnabled()) {
                     Logger var10000 = this.plugin.getLogger();
                     int var10001 = this.serverFakeCountsCache.size();
                     var10000.info("[PlaceholderDB] Synced " + var10001 + " servers, total fakes: " + this.totalFakeCountCache);
                  }
               } catch (Throwable var10) {
                  if (rs != null) {
                     try {
                        rs.close();
                     } catch (Throwable var9) {
                        var10.addSuppressed(var9);
                     }
                  }

                  throw var10;
               }

               if (rs != null) {
                  rs.close();
               }
            } catch (Throwable var11) {
               if (pstmt != null) {
                  try {
                     pstmt.close();
                  } catch (Throwable var8) {
                     var11.addSuppressed(var8);
                  }
               }

               throw var11;
            }

            if (pstmt != null) {
               pstmt.close();
            }
         } catch (SQLException var12) {
            this.plugin.getLogger().warning("Failed to sync placeholder database: " + var12.getMessage());
         }
      }

   }

   private int getTotalFakePlayersFromDatabase() {
      return this.totalFakeCountCache;
   }

   private int getServerFakePlayersFromDatabase(String serverName) {
      return (Integer)this.serverFakeCountsCache.getOrDefault(serverName, 0);
   }

   private int getServerRealPlayersFromDatabase(String serverName) {
      if (this.dbEnabled && this.dbConnection != null) {
         try {
            long twoMinAgo = System.currentTimeMillis() - 120000L;
            String query = "SELECT real_players FROM server_data WHERE server_name = ? AND last_updated > ?";
            PreparedStatement pstmt = this.dbConnection.prepareStatement(query);

            byte var8;
            label83: {
               int var7;
               try {
                  pstmt.setString(1, serverName);
                  pstmt.setLong(2, twoMinAgo);
                  ResultSet rs = pstmt.executeQuery();

                  label85: {
                     try {
                        if (rs.next()) {
                           var7 = rs.getInt("real_players");
                           break label85;
                        }

                        var8 = 0;
                     } catch (Throwable var12) {
                        if (rs != null) {
                           try {
                              rs.close();
                           } catch (Throwable var11) {
                              var12.addSuppressed(var11);
                           }
                        }

                        throw var12;
                     }

                     if (rs != null) {
                        rs.close();
                     }
                     break label83;
                  }

                  if (rs != null) {
                     rs.close();
                  }
               } catch (Throwable var131) {
                  if (pstmt != null) {
                     try {
                        pstmt.close();
                     } catch (Throwable var10) {
                        var131.addSuppressed(var10);
                     }
                  }

                  throw var131;
               }

               if (pstmt != null) {
                  pstmt.close();
               }

               return var7;
            }

            if (pstmt != null) {
               pstmt.close();
            }

            return var8;
         } catch (SQLException var13) {
            this.plugin.getLogger().fine("Failed to get real players from database: " + var13.getMessage());
            return 0;
         }
      } else {
         return 0;
      }
   }

   public @NotNull String getIdentifier() {
      return "glidespoofer";
   }

   public @NotNull String getAuthor() {
      return "GlideSpoofer";
   }

   public @NotNull String getVersion() {
      return this.plugin.getDescription().getVersion();
   }

   public boolean persist() {
      return true;
   }

   public boolean canRegister() {
      return true;
   }

   public @Nullable String onRequest(OfflinePlayer player, @NotNull String params) {
      int proxyTotalFakeCount = 0;
      ProxyMessenger proxyMessenger = this.plugin.getProxyMessenger();
      int fakeCount;
      if (proxyMessenger != null) {
         fakeCount = proxyMessenger.getTotalFakeCount();
         proxyTotalFakeCount = fakeCount;
      } else {
         fakeCount = this.plugin.getFakePlayerManager().getSpawnedCount();
      }

      int realCount = Bukkit.getOnlinePlayers().size();
      int totalCount = realCount + fakeCount;
      if (!params.toLowerCase().startsWith("bungee_") && !params.toLowerCase().startsWith("velocity_")) {
         switch (params.toLowerCase()) {
            case "online":
            case "total":
            case "players":
               return String.valueOf(totalCount);
            case "fake":
            case "fakes":
            case "fake_count":
               return String.valueOf(fakeCount);
            case "real":
            case "real_count":
               return String.valueOf(realCount);
            case "max":
               return String.valueOf(Bukkit.getMaxPlayers());
            case "fake_list":
               StringBuilder list = new StringBuilder();

               for(FakePlayer fake : this.plugin.getFakePlayerManager().getSpawnedFakePlayers()) {
                  if (list.length() > 0) {
                     list.append(", ");
                  }

                  list.append(fake.getName());
               }

               return list.toString();
            case "random_fake":
               List<FakePlayer> fakes = this.plugin.getFakePlayerManager().getSpawnedFakePlayers();
               if (fakes.isEmpty()) {
                  return "";
               }

               return ((FakePlayer)fakes.get((int)(Math.random() * (double)fakes.size()))).getName();
            case "lifesteal_hearts":
            case "hearts":
               if (player != null && player.getUniqueId() != null) {
                  LifestealCoreHook lsHook = this.plugin.getLifestealCoreHook();
                  if (lsHook != null && lsHook.isEnabled()) {
                     return String.valueOf(lsHook.getHearts(player.getUniqueId()));
                  }

                  LifeStealZHook lszHook = this.plugin.getLifeStealZHook();
                  if (lszHook != null && lszHook.isEnabled()) {
                     return String.valueOf(lszHook.getHearts(player.getUniqueId()));
                  }
               }

               return "0";
            case "lifestealz_hearts":
               if (player != null && player.getUniqueId() != null) {
                  LifeStealZHook lszHook = this.plugin.getLifeStealZHook();
                  if (lszHook != null && lszHook.isEnabled()) {
                     return String.valueOf(lszHook.getHearts(player.getUniqueId()));
                  }
               }

               return "0";
            default:
               if (params.startsWith("fake_")) {
                  String[] parts = params.split("_", 3);
                  if (parts.length >= 3) {
                     String fakeName = parts[1];
                     String property = parts[2];
                     FakePlayer fake = this.plugin.getFakePlayerManager().getFakePlayer(fakeName);
                     if (fake != null) {
                        switch (property.toLowerCase()) {
                           case "rank" -> {
                              return fake.getRank();
                           }
                           case "ping" -> {
                              return String.valueOf(fake.getPing());
                           }
                           case "votes" -> {
                              return String.valueOf(fake.getFakeVotes());
                           }
                           case "prefix" -> {
                              return fake.getPrefix() != null ? fake.getPrefix() : "";
                           }
                           case "suffix" -> {
                              return fake.getSuffix() != null ? fake.getSuffix() : "";
                           }
                        }
                     }
                  }
               }

               return null;
         }
      } else {
         String subParam = params.substring(params.startsWith("bungee_") ? 7 : 8);
         switch (subParam.toLowerCase()) {
            case "total":
            case "all":
               int dbFakesx = this.dbEnabled ? this.getTotalFakePlayersFromDatabase() : 0;
               if (dbFakesx > 0) {
                  return String.valueOf(realCount + dbFakesx);
               } else {
                  if (proxyMessenger != null) {
                     return String.valueOf(realCount + proxyTotalFakeCount);
                  }

                  return String.valueOf(realCount + fakeCount);
               }
            case "fake":
            case "fakes":
               int dbFakes = this.dbEnabled ? this.getTotalFakePlayersFromDatabase() : 0;
               if (dbFakes > 0) {
                  return String.valueOf(dbFakes);
               } else {
                  if (proxyMessenger != null) {
                     return String.valueOf(proxyTotalFakeCount);
                  }

                  return String.valueOf(fakeCount);
               }
            case "real":
               return String.valueOf(realCount);
            default:
               return this.handleBungeeServerPlaceholder(subParam, proxyMessenger);
         }
      }
   }

   private String handleBungeeServerPlaceholder(String serverName, ProxyMessenger proxyMessenger) {
      int serverFakeCount = 0;
      int serverRealCount = 0;
      if (this.dbEnabled) {
         serverFakeCount = this.getServerFakePlayersFromDatabase(serverName);
         serverRealCount = this.getServerRealPlayersFromDatabase(serverName);
      }

      if (serverFakeCount == 0 && proxyMessenger != null) {
         serverFakeCount = proxyMessenger.getServerFakeCount(serverName);
      }

      if (serverFakeCount == 0) {
         String localServerName = this.plugin.getConfigManager().getConfig().getString("proxy-sync.server-name", "server");
         if (serverName.equalsIgnoreCase(localServerName)) {
            return String.valueOf(Bukkit.getOnlinePlayers().size() + this.plugin.getFakePlayerManager().getSpawnedCount());
         }
      }

      return String.valueOf(serverRealCount + serverFakeCount);
   }

   public @Nullable String onPlaceholderRequest(Player player, @NotNull String params) {
      if (player != null) {
         switch (params.toLowerCase()) {
            case "isreal":
            case "is_real":
               return String.valueOf(!this.plugin.getFakePlayerManager().isFakePlayer(player.getUniqueId()));
            case "isfake":
            case "is_fake":
               return String.valueOf(this.plugin.getFakePlayerManager().isFakePlayer(player.getUniqueId()));
         }
      }

      return this.onRequest(player, params);
   }
}
