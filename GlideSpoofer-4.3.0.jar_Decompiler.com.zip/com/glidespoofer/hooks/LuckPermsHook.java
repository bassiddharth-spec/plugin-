package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.FakePlayer;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.Node;
import net.luckperms.api.node.types.InheritanceNode;
import net.luckperms.api.query.QueryOptions;
import net.luckperms.api.track.Track;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

public class LuckPermsHook {
   private final GlideSpoofer plugin;
   private boolean enabled;
   private LuckPerms luckPermsApi;

   public LuckPermsHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.enabled = false;
      if (!plugin.getConfigManager().getConfig().getBoolean("hooks.luckperms.enabled", true)) {
         plugin.getLogger().info("LuckPerms hook disabled in config");
      } else {
         Plugin luckPermsPlugin = Bukkit.getPluginManager().getPlugin("LuckPerms");
         if (luckPermsPlugin != null && luckPermsPlugin.isEnabled()) {
            try {
               this.luckPermsApi = LuckPermsProvider.get();
               this.enabled = true;
               plugin.getLogger().info("LuckPerms hook enabled (API-based)!");
            } catch (Exception var4) {
               plugin.getLogger().log(Level.WARNING, "Failed to get LuckPerms API", var4);
            }
         }
      }

   }

   public boolean isEnabled() {
      return this.enabled && this.luckPermsApi != null;
   }

   public LuckPerms getLuckPermsApi() {
      return this.luckPermsApi;
   }

   public CompletableFuture<User> loadUser(UUID uuid, String name) {
      return !this.isEnabled() ? CompletableFuture.completedFuture((Object)null) : this.luckPermsApi.getUserManager().loadUser(uuid, name).thenCompose((user) -> {
         if (user == null) {
            this.plugin.getLogger().warning("[LuckPerms] Failed to load user: " + name + " (UUID: " + String.valueOf(uuid) + ")");
            return CompletableFuture.completedFuture((Object)null);
         } else {
            return this.luckPermsApi.getUserManager().saveUser(user).thenCompose((v) -> this.luckPermsApi.getUserManager().savePlayerData(uuid, name).thenApply((result) -> {
                  this.plugin.getLogger().info("[LuckPerms] Registered user: " + name + " (UUID: " + String.valueOf(uuid) + ")");
                  return user;
               }).exceptionally((e) -> {
                  this.plugin.getLogger().warning("[LuckPerms] Failed to save player data for " + name + ": " + e.getMessage());
                  return user;
               }));
         }
      });
   }

   public void ensureUserCachedForVault(UUID uuid, String name) {
      if (this.isEnabled()) {
         try {
            User user = (User)this.luckPermsApi.getUserManager().loadUser(uuid, name).join();
            if (user != null) {
               this.luckPermsApi.getUserManager().saveUser(user).join();

               try {
                  Thread.sleep(50L);
               } catch (InterruptedException var5) {
               }

               this.plugin.getLogger().info("[LuckPerms] Sync cached user for Vault: " + name);
            }
         } catch (Exception e) {
            this.plugin.getLogger().warning("[LuckPerms] Failed to sync cache user: " + e.getMessage());
         }

      }
   }

   public User lookupUser(String name) {
      if (!this.isEnabled()) {
         return null;
      } else {
         try {
            UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
            return (User)this.luckPermsApi.getUserManager().loadUser(uuid).join();
         } catch (Exception var3) {
            this.plugin.getLogger().fine("[LuckPerms] Could not lookup user by name: " + name);
            return null;
         }
      }
   }

   public User getUserByUuid(UUID uuid) {
      if (!this.isEnabled()) {
         return null;
      } else {
         try {
            return (User)this.luckPermsApi.getUserManager().loadUser(uuid).join();
         } catch (Exception var3) {
            this.plugin.getLogger().warning("[LuckPerms] Failed to load user by UUID: " + String.valueOf(uuid));
            return null;
         }
      }
   }

   public void setupFakePlayer(FakePlayer fake) {
      this.setupFakePlayer(fake.getUuid(), fake.getName(), fake.getRank()).thenAccept((prefix) -> {
         if (prefix != null && !prefix.isEmpty()) {
            fake.setPrefix(prefix);
            Logger var10000 = this.plugin.getLogger();
            String var10001 = fake.getName();
            var10000.info("[LuckPerms] Applied prefix to " + var10001 + ": " + prefix);
         }

      });
   }

   public CompletableFuture<String> setupFakePlayer(UUID uuid, String name, String group) {
      return !this.isEnabled() ? CompletableFuture.completedFuture("") : this.loadUser(uuid, name).thenApplyAsync((user) -> {
         if (user == null) {
            this.plugin.getLogger().warning("[LuckPerms] Failed to load user: " + name);
            return "";
         } else {
            String prefix = "";
            if (group != null && !group.isEmpty()) {
               this.setGroup(user, uuid, name, group);
               Group lpGroup = this.luckPermsApi.getGroupManager().getGroup(group);
               if (lpGroup != null) {
                  QueryOptions queryOptions = this.luckPermsApi.getContextManager().getStaticQueryOptions();
                  prefix = lpGroup.getCachedData().getMetaData(queryOptions).getPrefix();
                  if (prefix != null && !prefix.isEmpty()) {
                     this.plugin.getLogger().info("[LuckPerms] Fetched prefix for " + name + " from group " + group + ": " + prefix);
                  }
               }
            }

            this.luckPermsApi.getUserManager().saveUser(user);
            this.luckPermsApi.getUserManager().savePlayerData(uuid, name);
            return prefix != null ? prefix : "";
         }
      }, Bukkit.getScheduler().getMainThreadExecutor(this.plugin));
   }

   private void setGroup(User user, UUID uuid, String name, String group) {
      try {
         user.data().clear((nodex) -> nodex instanceof InheritanceNode);
         InheritanceNode node = (InheritanceNode)InheritanceNode.builder(group).build();
         user.data().add(node);
         this.luckPermsApi.getUserManager().saveUser(user);
         this.luckPermsApi.getUserManager().savePlayerData(uuid, name);
         this.plugin.getLogger().info("[LuckPerms] Set group for " + name + " to " + group);
      } catch (Exception var6) {
         this.plugin.getLogger().log(Level.WARNING, "[LuckPerms] Failed to set group for " + name, var6);
      }

   }

   public void setGroup(FakePlayer fake, String group) {
      if (this.isEnabled()) {
         this.luckPermsApi.getUserManager().loadUser(fake.getUuid()).thenAcceptAsync((user) -> {
            if (user != null) {
               this.setGroup(user, fake.getUuid(), fake.getName(), group);
               fake.setRank(group);
            }

         }, Bukkit.getScheduler().getMainThreadExecutor(this.plugin));
      }

   }

   public void addGroup(FakePlayer fake, String group) {
      if (this.isEnabled()) {
         this.luckPermsApi.getUserManager().loadUser(fake.getUuid()).thenAcceptAsync((user) -> {
            if (user != null) {
               InheritanceNode node = (InheritanceNode)InheritanceNode.builder(group).build();
               user.data().add(node);
               this.luckPermsApi.getUserManager().saveUser(user);
               this.plugin.getLogger().info("[LuckPerms] Added group " + group + " to " + fake.getName());
            }

         }, Bukkit.getScheduler().getMainThreadExecutor(this.plugin));
      }

   }

   public void removeGroup(FakePlayer fake, String group) {
      if (this.isEnabled()) {
         this.luckPermsApi.getUserManager().loadUser(fake.getUuid()).thenAcceptAsync((user) -> {
            if (user != null) {
               InheritanceNode node = (InheritanceNode)InheritanceNode.builder(group).build();
               user.data().remove(node);
               this.luckPermsApi.getUserManager().saveUser(user);
               this.plugin.getLogger().info("[LuckPerms] Removed group " + group + " from " + fake.getName());
            }

         }, Bukkit.getScheduler().getMainThreadExecutor(this.plugin));
      }

   }

   public void setTrack(FakePlayer fake, String track, String group) {
      if (this.isEnabled()) {
         this.luckPermsApi.getUserManager().loadUser(fake.getUuid()).thenAcceptAsync((user) -> {
            if (user != null) {
               try {
                  Track lpTrack = this.luckPermsApi.getTrackManager().getTrack(track);
                  if (lpTrack == null) {
                     this.plugin.getLogger().warning("[LuckPerms] Track '" + track + "' not found");
                     return;
                  }

                  for(String trackGroup : lpTrack.getGroups()) {
                     InheritanceNode removeNode = (InheritanceNode)InheritanceNode.builder(trackGroup).build();
                     user.data().remove(removeNode);
                  }

                  InheritanceNode node = (InheritanceNode)InheritanceNode.builder(group).build();
                  user.data().add(node);
                  this.luckPermsApi.getUserManager().saveUser(user);
                  this.plugin.getLogger().info("[LuckPerms] Set track " + track + " to " + group + " for " + fake.getName());
               } catch (Exception var9) {
                  this.plugin.getLogger().log(Level.WARNING, "[LuckPerms] Failed to set track for " + fake.getName(), var9);
               }
            }

         }, Bukkit.getScheduler().getMainThreadExecutor(this.plugin));
      }

   }

   public void setMultipleTracks(FakePlayer fake, Map<String, String> tracks) {
      if (this.isEnabled() && tracks != null && !tracks.isEmpty()) {
         this.luckPermsApi.getUserManager().loadUser(fake.getUuid()).thenAcceptAsync((user) -> {
            if (user != null) {
               try {
                  for(Map.Entry<String, String> entry : tracks.entrySet()) {
                     String track = (String)entry.getKey();
                     String group = (String)entry.getValue();
                     Track lpTrack = this.luckPermsApi.getTrackManager().getTrack(track);
                     if (lpTrack == null) {
                        this.plugin.getLogger().warning("[LuckPerms] Track '" + track + "' not found");
                     } else {
                        for(String trackGroup : lpTrack.getGroups()) {
                           InheritanceNode removeNode = (InheritanceNode)InheritanceNode.builder(trackGroup).build();
                           user.data().remove(removeNode);
                        }

                        InheritanceNode node = (InheritanceNode)InheritanceNode.builder(group).build();
                        user.data().add(node);
                     }
                  }

                  this.luckPermsApi.getUserManager().saveUser(user);
                  Logger var10000 = this.plugin.getLogger();
                  String var10001 = fake.getName();
                  var10000.info("[LuckPerms] Set multiple tracks for " + var10001 + ": " + String.valueOf(tracks));
               } catch (Exception var12) {
                  this.plugin.getLogger().log(Level.WARNING, "[LuckPerms] Failed to set tracks for " + fake.getName(), var12);
               }
            }

         }, Bukkit.getScheduler().getMainThreadExecutor(this.plugin));
      }

   }

   public List<String> getGroups(FakePlayer fake) {
      if (!this.isEnabled()) {
         return Collections.emptyList();
      } else {
         try {
            User user = (User)this.luckPermsApi.getUserManager().loadUser(fake.getUuid()).join();
            if (user == null) {
               return Collections.emptyList();
            } else {
               List<String> groups = new ArrayList();

               for(Node node : user.getNodes()) {
                  if (node instanceof InheritanceNode) {
                     groups.add(((InheritanceNode)node).getGroupName());
                  }
               }

               return groups;
            }
         } catch (Exception var6) {
            return Collections.emptyList();
         }
      }
   }

   public void setPermission(FakePlayer fake, String permission, boolean value) {
      if (this.isEnabled()) {
         this.luckPermsApi.getUserManager().loadUser(fake.getUuid()).thenAcceptAsync((user) -> {
            if (user != null) {
               Node node = Node.builder(permission).value(value).build();
               user.data().add(node);
               this.luckPermsApi.getUserManager().saveUser(user);
            }

         }, Bukkit.getScheduler().getMainThreadExecutor(this.plugin));
      }

   }

   public String getPrefix(FakePlayer fake) {
      if (fake.getPrefix() != null && !fake.getPrefix().isEmpty()) {
         return fake.getPrefix();
      } else if (!this.isEnabled()) {
         return "";
      } else {
         try {
            User user = (User)this.luckPermsApi.getUserManager().loadUser(fake.getUuid()).join();
            if (user == null) {
               return "";
            }

            String primaryGroup = user.getPrimaryGroup();
            if (primaryGroup == null || primaryGroup.isEmpty()) {
               primaryGroup = "default";
            }

            Group group = this.luckPermsApi.getGroupManager().getGroup(primaryGroup);
            if (group != null) {
               QueryOptions queryOptions = this.luckPermsApi.getContextManager().getStaticQueryOptions();
               String prefix = group.getCachedData().getMetaData(queryOptions).getPrefix();
               if (prefix != null && !prefix.isEmpty()) {
                  fake.setPrefix(prefix);
                  return prefix;
               }
            }

            QueryOptions queryOptions = this.luckPermsApi.getContextManager().getStaticQueryOptions();
            String userPrefix = user.getCachedData().getMetaData(queryOptions).getPrefix();
            if (userPrefix != null && !userPrefix.isEmpty()) {
               fake.setPrefix(userPrefix);
               return userPrefix;
            }
         } catch (Exception e) {
            Logger var10000 = this.plugin.getLogger();
            String var10001 = fake.getName();
            var10000.fine("[LuckPerms] Failed to get prefix for " + var10001 + ": " + e.getMessage());
         }

         return "";
      }
   }

   public String getSuffix(FakePlayer fake) {
      if (fake.getSuffix() != null && !fake.getSuffix().isEmpty()) {
         return fake.getSuffix();
      } else if (!this.isEnabled()) {
         return "";
      } else {
         try {
            User user = (User)this.luckPermsApi.getUserManager().loadUser(fake.getUuid()).join();
            if (user == null) {
               return "";
            }

            String primaryGroup = user.getPrimaryGroup();
            if (primaryGroup == null || primaryGroup.isEmpty()) {
               primaryGroup = "default";
            }

            Group group = this.luckPermsApi.getGroupManager().getGroup(primaryGroup);
            if (group != null) {
               QueryOptions queryOptions = this.luckPermsApi.getContextManager().getStaticQueryOptions();
               String suffix = group.getCachedData().getMetaData(queryOptions).getSuffix();
               if (suffix != null && !suffix.isEmpty()) {
                  fake.setSuffix(suffix);
                  return suffix;
               }
            }

            QueryOptions queryOptions = this.luckPermsApi.getContextManager().getStaticQueryOptions();
            String userSuffix = user.getCachedData().getMetaData(queryOptions).getSuffix();
            if (userSuffix != null && !userSuffix.isEmpty()) {
               fake.setSuffix(userSuffix);
               return userSuffix;
            }
         } catch (Exception e) {
            Logger var10000 = this.plugin.getLogger();
            String var10001 = fake.getName();
            var10000.fine("[LuckPerms] Failed to get suffix for " + var10001 + ": " + e.getMessage());
         }

         return "";
      }
   }

   public CompletableFuture<String> fetchAndUpdatePrefix(FakePlayer fake) {
      return !this.isEnabled() ? CompletableFuture.completedFuture("") : this.luckPermsApi.getUserManager().loadUser(fake.getUuid(), fake.getName()).thenApplyAsync((user) -> {
         if (user == null) {
            return "";
         } else {
            String primaryGroup = user.getPrimaryGroup();
            if (primaryGroup == null || primaryGroup.isEmpty()) {
               primaryGroup = "default";
            }

            String prefix = "";
            Group group = this.luckPermsApi.getGroupManager().getGroup(primaryGroup);
            if (group != null) {
               QueryOptions queryOptions = this.luckPermsApi.getContextManager().getStaticQueryOptions();
               prefix = group.getCachedData().getMetaData(queryOptions).getPrefix();
            }

            if (prefix == null || prefix.isEmpty()) {
               QueryOptions queryOptions = this.luckPermsApi.getContextManager().getStaticQueryOptions();
               prefix = user.getCachedData().getMetaData(queryOptions).getPrefix();
            }

            if (prefix != null && !prefix.isEmpty()) {
               fake.setPrefix(prefix);
               this.plugin.getLogger().info("[LuckPerms] Fetched prefix for " + fake.getName() + " (group: " + primaryGroup + "): " + prefix);
               return prefix;
            } else {
               return "";
            }
         }
      }, Bukkit.getScheduler().getMainThreadExecutor(this.plugin));
   }

   public CompletableFuture<String> fetchAndUpdateSuffix(FakePlayer fake) {
      return !this.isEnabled() ? CompletableFuture.completedFuture("") : this.luckPermsApi.getUserManager().loadUser(fake.getUuid(), fake.getName()).thenApplyAsync((user) -> {
         if (user == null) {
            return "";
         } else {
            String primaryGroup = user.getPrimaryGroup();
            if (primaryGroup == null || primaryGroup.isEmpty()) {
               primaryGroup = "default";
            }

            String suffix = "";
            Group group = this.luckPermsApi.getGroupManager().getGroup(primaryGroup);
            if (group != null) {
               QueryOptions queryOptions = this.luckPermsApi.getContextManager().getStaticQueryOptions();
               suffix = group.getCachedData().getMetaData(queryOptions).getSuffix();
            }

            if (suffix == null || suffix.isEmpty()) {
               QueryOptions queryOptions = this.luckPermsApi.getContextManager().getStaticQueryOptions();
               suffix = user.getCachedData().getMetaData(queryOptions).getSuffix();
            }

            if (suffix != null && !suffix.isEmpty()) {
               fake.setSuffix(suffix);
               return suffix;
            } else {
               return "";
            }
         }
      }, Bukkit.getScheduler().getMainThreadExecutor(this.plugin));
   }

   public void warmUpUserStorage() {
      if (this.isEnabled()) {
         Runnable warmUpTask = () -> {
            SimpleFakePlayerManager fakeManager = this.plugin.getSimpleFakePlayerManager();
            if (fakeManager != null) {
               int count = 0;

               for(SimpleFakePlayerManager.FakePlayerData fakeData : fakeManager.getAllFakePlayers()) {
                  try {
                     User user = (User)this.luckPermsApi.getUserManager().loadUser(fakeData.getUuid(), fakeData.getName()).join();
                     if (user != null) {
                        this.luckPermsApi.getUserManager().saveUser(user).join();
                        this.luckPermsApi.getUserManager().savePlayerData(fakeData.getUuid(), fakeData.getName()).join();
                        ++count;
                     }
                  } catch (Exception var6) {
                     this.plugin.getLogger().fine("[LuckPerms] Could not warm up user: " + fakeData.getName());
                  }
               }

               this.plugin.getLogger().info("[LuckPerms] Warmed up " + count + " users in storage");
            }

         };
         if (GlideSpoofer.isFolia()) {
            warmUpTask.run();
         } else {
            Bukkit.getScheduler().runTaskAsynchronously(this.plugin, warmUpTask);
         }
      }

   }

   public CompletableFuture<Boolean> ensureUserStored(UUID uuid, String name) {
      return !this.isEnabled() ? CompletableFuture.completedFuture(false) : this.luckPermsApi.getUserManager().loadUser(uuid, name).thenCompose((user) -> user != null ? this.luckPermsApi.getUserManager().savePlayerData(uuid, name).thenApply((result) -> {
            this.plugin.getLogger().fine("[LuckPerms] Ensured user stored: " + name);
            return true;
         }) : CompletableFuture.completedFuture(false));
   }

   public String setupFakePlayerSync(UUID uuid, String name, Map<String, String> tracks) {
      if (!this.isEnabled()) {
         return "";
      } else {
         try {
            User user = (User)this.luckPermsApi.getUserManager().loadUser(uuid, name).join();
            if (user == null) {
               this.plugin.getLogger().warning("[LuckPerms] Failed to load user for sync setup: " + name);
               return "";
            } else {
               if (tracks != null && !tracks.isEmpty()) {
                  for(Map.Entry<String, String> entry : tracks.entrySet()) {
                     String trackName = (String)entry.getKey();
                     String groupName = (String)entry.getValue();
                     Track track = this.luckPermsApi.getTrackManager().getTrack(trackName);
                     if (track == null) {
                        this.plugin.getLogger().warning("[LuckPerms] Track '" + trackName + "' not found");
                     } else {
                        for(String trackGroup : track.getGroups()) {
                           InheritanceNode removeNode = (InheritanceNode)InheritanceNode.builder(trackGroup).build();
                           user.data().remove(removeNode);
                        }

                        InheritanceNode node = (InheritanceNode)InheritanceNode.builder(groupName).build();
                        user.data().add(node);
                     }
                  }
               }

               this.luckPermsApi.getUserManager().saveUser(user).join();
               this.luckPermsApi.getUserManager().savePlayerData(uuid, name).join();
               String primaryGroup = user.getPrimaryGroup();
               if (primaryGroup == null || primaryGroup.isEmpty()) {
                  primaryGroup = "default";
               }

               Group group = this.luckPermsApi.getGroupManager().getGroup(primaryGroup);
               if (group != null) {
                  QueryOptions queryOptions = this.luckPermsApi.getContextManager().getStaticQueryOptions();
                  String prefix = group.getCachedData().getMetaData(queryOptions).getPrefix();
                  if (prefix != null && !prefix.isEmpty()) {
                     this.plugin.getLogger().info("[LuckPerms] Sync setup complete for " + name + " with prefix: " + prefix);
                     return prefix;
                  }
               }

               QueryOptions queryOptions = this.luckPermsApi.getContextManager().getStaticQueryOptions();
               String userPrefix = user.getCachedData().getMetaData(queryOptions).getPrefix();
               return userPrefix != null && !userPrefix.isEmpty() ? userPrefix : "";
            }
         } catch (Exception e) {
            this.plugin.getLogger().warning("[LuckPerms] Sync setup failed for " + name + ": " + e.getMessage());
            return "";
         }
      }
   }

   public String setupFakePlayerWithDefaultGroup(UUID uuid, String name) {
      if (!this.isEnabled()) {
         return "";
      } else {
         try {
            User user = (User)this.luckPermsApi.getUserManager().loadUser(uuid, name).join();
            if (user == null) {
               this.plugin.getLogger().warning("[LuckPerms] Failed to load user for default group setup: " + name);
               return "";
            } else {
               this.luckPermsApi.getUserManager().saveUser(user).join();
               this.luckPermsApi.getUserManager().savePlayerData(uuid, name).join();
               String primaryGroup = user.getPrimaryGroup();
               if (primaryGroup == null || primaryGroup.isEmpty()) {
                  primaryGroup = "default";
               }

               this.plugin.getLogger().info("[LuckPerms] Fake player " + name + " using primary group: " + primaryGroup);
               Group group = this.luckPermsApi.getGroupManager().getGroup(primaryGroup);
               if (group != null) {
                  QueryOptions queryOptions = this.luckPermsApi.getContextManager().getStaticQueryOptions();
                  String prefix = group.getCachedData().getMetaData(queryOptions).getPrefix();
                  if (prefix != null && !prefix.isEmpty()) {
                     this.plugin.getLogger().info("[LuckPerms] Got prefix for " + name + " from group " + primaryGroup + ": " + prefix);
                     return prefix;
                  }

                  this.plugin.getLogger().info("[LuckPerms] Group " + primaryGroup + " has no prefix set for " + name);
               } else {
                  this.plugin.getLogger().warning("[LuckPerms] Primary group '" + primaryGroup + "' not found for " + name);
               }

               QueryOptions queryOptions = this.luckPermsApi.getContextManager().getStaticQueryOptions();
               String userPrefix = user.getCachedData().getMetaData(queryOptions).getPrefix();
               if (userPrefix != null && !userPrefix.isEmpty()) {
                  this.plugin.getLogger().info("[LuckPerms] Using user's own prefix for " + name + ": " + userPrefix);
                  return userPrefix;
               } else {
                  if (!primaryGroup.equals("default")) {
                     Group defaultGroup = this.luckPermsApi.getGroupManager().getGroup("default");
                     if (defaultGroup != null) {
                        QueryOptions options = this.luckPermsApi.getContextManager().getStaticQueryOptions();
                        String defaultPrefix = defaultGroup.getCachedData().getMetaData(options).getPrefix();
                        if (defaultPrefix != null && !defaultPrefix.isEmpty()) {
                           this.plugin.getLogger().info("[LuckPerms] Using default group prefix for " + name + ": " + defaultPrefix);
                           return defaultPrefix;
                        }
                     }
                  }

                  this.plugin.getLogger().info("[LuckPerms] No prefix found for " + name + ", using empty string");
                  return "";
               }
            }
         } catch (Exception e) {
            this.plugin.getLogger().warning("[LuckPerms] Default group setup failed for " + name + ": " + e.getMessage());
            return "";
         }
      }
   }
}
