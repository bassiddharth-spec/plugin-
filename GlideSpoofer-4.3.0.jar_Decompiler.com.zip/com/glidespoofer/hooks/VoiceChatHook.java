package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class VoiceChatHook {
   private final GlideSpoofer plugin;
   private boolean enabled;
   private Plugin voiceChatPlugin;
   private Class<?> voiceChatApiClass;
   private Class<?> voiceServerClass;
   private Class<?> voiceConnectionClass;
   private Class<?> playerStateManagerClass;
   private Class<?> authenticatedPlayerClass;
   private Object voiceServer;
   private final Map<UUID, Object> fakeVoiceConnections = new ConcurrentHashMap();

   public VoiceChatHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.enabled = false;
      if (!plugin.getConfigManager().getConfig().getBoolean("hooks.voicechat.enabled", true)) {
         plugin.getLogger().info("[VoiceChatHook] Disabled in config");
      } else {
         this.initialize();
      }
   }

   private void initialize() {
      try {
         this.voiceChatPlugin = Bukkit.getPluginManager().getPlugin("voicechat");
         if (this.voiceChatPlugin == null) {
            this.voiceChatPlugin = Bukkit.getPluginManager().getPlugin("SimpleVoiceChat");
            if (this.voiceChatPlugin == null) {
               this.voiceChatPlugin = Bukkit.getPluginManager().getPlugin("simple-voice-chat");
            }
         }

         if (this.voiceChatPlugin == null || !this.voiceChatPlugin.isEnabled()) {
            this.plugin.getLogger().fine("[VoiceChatHook] VoiceChat not found or disabled");
            return;
         }

         this.plugin.getLogger().info("[VoiceChatHook] Found VoiceChat: " + this.voiceChatPlugin.getDescription().getVersion());
         this.initializeReflection();
         this.enabled = true;
         this.plugin.getLogger().info("[VoiceChatHook] Hook enabled successfully!");
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.WARNING, "[VoiceChatHook] Failed to initialize hook: " + e.getMessage());
      }

   }

   private void initializeReflection() {
      try {
         String[] apiClassNames = new String[]{"de.maxhenkel.voicechat.Voicechat", "de.maxhenkel.voicechat.api.VoicechatApi", "de.maxhenkel.voicechat.VoicechatClient"};

         for(String className : apiClassNames) {
            try {
               this.voiceChatApiClass = Class.forName(className);
               this.plugin.getLogger().fine("[VoiceChatHook] Found API class: " + className);
               break;
            } catch (ClassNotFoundException var14) {
            }
         }

         String[] serverClassNames = new String[]{"de.maxhenkel.voicechat.voice.server.Server", "de.maxhenkel.voicechat.voice.server.VoiceServer", "de.maxhenkel.voicechat.server.VoiceServer"};

         for(String className : serverClassNames) {
            try {
               this.voiceServerClass = Class.forName(className);
               this.plugin.getLogger().fine("[VoiceChatHook] Found server class: " + className);
               break;
            } catch (ClassNotFoundException var13) {
            }
         }

         String[] connectionClassNames = new String[]{"de.maxhenkel.voicechat.voice.server.ClientConnection", "de.maxhenkel.voicechat.voice.server.VoiceConnection", "de.maxhenkel.voicechat.voice.common.PlayerState"};

         for(String className : connectionClassNames) {
            try {
               this.voiceConnectionClass = Class.forName(className);
               this.plugin.getLogger().fine("[VoiceChatHook] Found connection class: " + className);
               break;
            } catch (ClassNotFoundException var12) {
            }
         }

         String[] stateManagerNames = new String[]{"de.maxhenkel.voicechat.voice.server.PlayerStateManager", "de.maxhenkel.voicechat.server.PlayerStateManager"};

         for(String className : stateManagerNames) {
            try {
               this.playerStateManagerClass = Class.forName(className);
               this.plugin.getLogger().fine("[VoiceChatHook] Found state manager class: " + className);
               break;
            } catch (ClassNotFoundException var11) {
            }
         }

         if (this.voiceChatApiClass != null) {
            try {
               Field serverField = this.findField(this.voiceChatApiClass, this.voiceServerClass != null ? this.voiceServerClass : Object.class);
               if (serverField != null) {
                  serverField.setAccessible(true);
                  this.voiceServer = serverField.get((Object)null);
                  this.plugin.getLogger().info("[VoiceChatHook] Got VoiceServer instance");
               }
            } catch (Exception e) {
               this.plugin.getLogger().fine("[VoiceChatHook] Could not get server instance: " + e.getMessage());
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.FINE, "[VoiceChatHook] Reflection initialization failed", e);
      }

   }

   public void registerFakePlayer(Player player, UUID uuid, String name) {
      if (this.isEnabled()) {
         try {
            if (this.voiceServer != null && this.playerStateManagerClass != null) {
               Field stateManagerField = this.findField(this.voiceServer.getClass(), this.playerStateManagerClass);
               if (stateManagerField != null) {
                  stateManagerField.setAccessible(true);
                  Object stateManager = stateManagerField.get(this.voiceServer);
                  if (stateManager != null) {
                     Method[] methods = stateManager.getClass().getDeclaredMethods();

                     for(Method m : methods) {
                        if (m.getName().contains("join") || m.getName().contains("add") || m.getName().contains("register")) {
                           Class<?>[] params = m.getParameterTypes();
                           if (params.length == 1 && (params[0] == Player.class || params[0] == UUID.class)) {
                              m.setAccessible(true);
                              if (params[0] == Player.class) {
                                 m.invoke(stateManager, player);
                              } else {
                                 m.invoke(stateManager, uuid);
                              }

                              this.plugin.getLogger().fine("[VoiceChatHook] Registered " + name + " via " + m.getName());
                              break;
                           }
                        }
                     }
                  }
               }
            }

            this.fakeVoiceConnections.put(uuid, player);
            this.plugin.getLogger().fine("[VoiceChatHook] Registered fake player: " + name);
         } catch (Exception e) {
            this.plugin.getLogger().log(Level.FINE, "[VoiceChatHook] Could not register fake player " + name + ": " + e.getMessage());
         }

      }
   }

   public void unregisterFakePlayer(UUID uuid, String name) {
      if (this.isEnabled()) {
         try {
            if (this.voiceServer != null && this.playerStateManagerClass != null) {
               Field stateManagerField = this.findField(this.voiceServer.getClass(), this.playerStateManagerClass);
               if (stateManagerField != null) {
                  stateManagerField.setAccessible(true);
                  Object stateManager = stateManagerField.get(this.voiceServer);
                  if (stateManager != null) {
                     Method[] methods = stateManager.getClass().getDeclaredMethods();

                     for(Method m : methods) {
                        if (m.getName().contains("leave") || m.getName().contains("remove") || m.getName().contains("unregister")) {
                           Class<?>[] params = m.getParameterTypes();
                           if (params.length == 1 && params[0] == UUID.class) {
                              m.setAccessible(true);
                              m.invoke(stateManager, uuid);
                              this.plugin.getLogger().fine("[VoiceChatHook] Unregistered " + name + " via " + m.getName());
                              break;
                           }
                        }
                     }
                  }
               }
            }

            this.fakeVoiceConnections.remove(uuid);
            this.plugin.getLogger().fine("[VoiceChatHook] Unregistered fake player: " + name);
         } catch (Exception e) {
            this.plugin.getLogger().log(Level.FINE, "[VoiceChatHook] Could not unregister fake player " + name + ": " + e.getMessage());
         }

      }
   }

   public boolean isEnabled() {
      return this.enabled && this.voiceChatPlugin != null && this.voiceChatPlugin.isEnabled();
   }

   public boolean isFakePlayer(UUID uuid) {
      return this.fakeVoiceConnections.containsKey(uuid);
   }

   private Field findField(Class<?> clazz, Class<?> type) {
      for(Field f : clazz.getDeclaredFields()) {
         if (type.isAssignableFrom(f.getType())) {
            return f;
         }
      }

      if (clazz.getSuperclass() != null) {
         return this.findField(clazz.getSuperclass(), type);
      } else {
         return null;
      }
   }

   public Plugin getVoiceChatPlugin() {
      return this.voiceChatPlugin;
   }
}
