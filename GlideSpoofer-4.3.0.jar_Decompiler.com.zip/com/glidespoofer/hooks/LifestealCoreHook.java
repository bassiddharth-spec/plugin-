package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class LifestealCoreHook {
   private final GlideSpoofer plugin;
   private boolean enabled;
   private Plugin lifestealPlugin;
   private Method heartsFromYamlMethod;
   private final Map<UUID, Integer> heartsCache = new ConcurrentHashMap();
   private final Map<UUID, Long> cacheTime = new ConcurrentHashMap();
   private static final long CACHE_DURATION_MS = 5000L;
   private final Random random = new Random();
   private static final int MIN_FAKE_HEARTS = 3;
   private static final int MAX_FAKE_HEARTS = 25;

   public LifestealCoreHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.enabled = false;
      if (plugin.getConfigManager().getConfig().getBoolean("hooks.lifestealcore.enabled", true)) {
         String[] possibleNames = new String[]{"LifeStealCore", "LifestealCore", "lifestealcore", "LifeSteal", "Lifesteal"};

         for(String name : possibleNames) {
            this.lifestealPlugin = Bukkit.getPluginManager().getPlugin(name);
            if (this.lifestealPlugin != null) {
               break;
            }
         }

         if (this.lifestealPlugin != null && this.lifestealPlugin.isEnabled()) {
            this.initializeHook();
         }
      }

   }

   private void initializeHook() {
      try {
         Class<?> pluginMainClass = this.lifestealPlugin.getClass();
         String[] methodNames = new String[]{"getHearts", "getPlayerHearts", "getUserHearts", "getHealth", "getLives"};

         for(String methodName : methodNames) {
            try {
               Method m = pluginMainClass.getDeclaredMethod(methodName, UUID.class);
               m.setAccessible(true);
               this.heartsFromYamlMethod = m;
               break;
            } catch (NoSuchMethodException var15) {
               try {
                  Method mx = pluginMainClass.getDeclaredMethod(methodName, Player.class);
                  mx.setAccessible(true);
                  this.heartsFromYamlMethod = mx;
                  break;
               } catch (NoSuchMethodException var14) {
                  try {
                     Method mxx = pluginMainClass.getDeclaredMethod(methodName);
                     mxx.setAccessible(true);
                     Object result = mxx.invoke(this.lifestealPlugin);
                     if (result != null) {
                        Method getHeartsOnManager = result.getClass().getMethod("getHearts", UUID.class);
                        this.heartsFromYamlMethod = getHeartsOnManager;
                        break;
                     }
                  } catch (Exception var13) {
                  }
               }
            }
         }

         try {
            Class<?> heartsManagerClass = Class.forName("dev.norska.lsc.managers.HeartsManager");
            Method getInstanceMethod = heartsManagerClass.getMethod("getInstance");
            Object heartsManager = getInstanceMethod.invoke((Object)null);
            if (heartsManager != null) {
               this.heartsFromYamlMethod = heartsManager.getClass().getMethod("getHearts", UUID.class);
            }
         } catch (ClassNotFoundException | NoSuchMethodException var12) {
         }

         this.enabled = true;
      } catch (Exception var16) {
         this.plugin.getLogger().log(Level.WARNING, "Failed to initialize LifeStealCore hook", var16);
      }

   }

   public boolean isEnabled() {
      return this.enabled && this.lifestealPlugin != null;
   }

   public int getHearts(UUID uuid) {
      if (!this.isEnabled()) {
         return this.getDefaultHearts();
      } else {
         Long cachedTime = (Long)this.cacheTime.get(uuid);
         if (cachedTime != null && System.currentTimeMillis() - cachedTime < 5000L) {
            Integer cached = (Integer)this.heartsCache.get(uuid);
            if (cached != null) {
               return cached;
            }
         }

         int hearts = this.getDefaultHearts();
         boolean isFake = false;
         if (this.plugin.getSimpleFakePlayerManager() != null) {
            for(Object fakeData : this.plugin.getSimpleFakePlayerManager().getAllFakePlayers()) {
               try {
                  Method getUuidMethod = fakeData.getClass().getMethod("getUuid");
                  Object fakeUuid = getUuidMethod.invoke(fakeData);
                  if (fakeUuid != null && fakeUuid.equals(uuid)) {
                     isFake = true;
                     break;
                  }
               } catch (Exception var10) {
               }
            }
         }

         if (isFake) {
            int rand = this.random.nextInt(100);
            if (rand < 30) {
               hearts = 3 + this.random.nextInt(3);
            } else if (rand < 60) {
               hearts = 6 + this.random.nextInt(5);
            } else if (rand < 85) {
               hearts = 11 + this.random.nextInt(5);
            } else {
               hearts = 16 + this.random.nextInt(10);
            }
         } else if (this.heartsFromYamlMethod != null) {
            try {
               Class<?>[] paramTypes = this.heartsFromYamlMethod.getParameterTypes();
               Object result;
               if (paramTypes.length == 1 && paramTypes[0] == UUID.class) {
                  if (Modifier.isStatic(this.heartsFromYamlMethod.getModifiers())) {
                     result = this.heartsFromYamlMethod.invoke((Object)null, uuid);
                  } else {
                     result = this.heartsFromYamlMethod.invoke(this.lifestealPlugin, uuid);
                  }
               } else if (paramTypes.length == 1 && paramTypes[0] == Player.class) {
                  Player player = Bukkit.getPlayer(uuid);
                  if (player != null && player.isOnline()) {
                     if (Modifier.isStatic(this.heartsFromYamlMethod.getModifiers())) {
                        result = this.heartsFromYamlMethod.invoke((Object)null, player);
                     } else {
                        result = this.heartsFromYamlMethod.invoke(this.lifestealPlugin, player);
                     }
                  } else {
                     result = null;
                  }
               } else {
                  result = null;
               }

               if (result instanceof Integer) {
                  hearts = (Integer)result;
               } else if (result instanceof Double) {
                  hearts = ((Double)result).intValue();
               }
            } catch (Exception var9) {
               this.plugin.getLogger().fine("Failed to get hearts via reflection: " + var9.getMessage());
            }
         }

         this.heartsCache.put(uuid, hearts);
         this.cacheTime.put(uuid, System.currentTimeMillis());
         return hearts;
      }
   }

   public int getHearts(String name) {
      if (!this.isEnabled()) {
         return this.getDefaultHearts();
      } else {
         try {
            OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(name);
            if (offlinePlayer != null && offlinePlayer.getUniqueId() != null) {
               return this.getHearts(offlinePlayer.getUniqueId());
            }
         } catch (Exception var3) {
            this.plugin.getLogger().fine("Failed to get hearts for name: " + name);
         }

         return this.getDefaultHearts();
      }
   }

   public int getDefaultHearts() {
      return 10;
   }

   public String getPluginVersion() {
      if (this.lifestealPlugin != null) {
         try {
            return this.lifestealPlugin.getPluginMeta().getVersion();
         } catch (Throwable var2) {
         }
      }

      return "unknown";
   }

   public void shutdown() {
      this.heartsCache.clear();
      this.cacheTime.clear();
      this.plugin.getLogger().fine("LifeStealCore hook shutdown complete");
   }
}
