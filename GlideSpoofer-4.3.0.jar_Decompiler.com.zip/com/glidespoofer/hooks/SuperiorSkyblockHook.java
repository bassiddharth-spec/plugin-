package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import java.lang.reflect.Method;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.block.Biome;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class SuperiorSkyblockHook {
   private final GlideSpoofer plugin;
   private boolean enabled;
   private Plugin superiorSkyblock;
   private Class<?> islandClass;
   private Method gridManagerCreateIslandMethod;
   private Method islandNewBuilderMethod;
   private Method builderSetOwnerMethod;
   private Method builderSetSchematicNameMethod;
   private Method builderSetNameMethod;

   public SuperiorSkyblockHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.enabled = false;
      if (plugin.getConfigManager().getConfig().getBoolean("hooks.superiorskyblock.enabled", false)) {
         this.superiorSkyblock = Bukkit.getPluginManager().getPlugin("SuperiorSkyblock2");
         if (this.superiorSkyblock != null && this.superiorSkyblock.isEnabled()) {
            this.enabled = true;
            this.cacheReflectionObjects();
            plugin.getLogger().info("SuperiorSkyblock2 hook enabled!");
         }
      }

   }

   public boolean isEnabled() {
      return this.enabled && this.superiorSkyblock != null;
   }

   private void cacheReflectionObjects() {
      try {
         this.islandClass = Class.forName("com.bgsoftware.superiorskyblock.api.island.Island");
         this.plugin.getLogger().info("[SuperiorSkyblock] Found Island class");
         this.islandNewBuilderMethod = this.islandClass.getMethod("newBuilder");
         this.plugin.getLogger().info("[SuperiorSkyblock] Found Island.newBuilder() method");
         Object testBuilder = this.islandNewBuilderMethod.invoke((Object)null);
         Class<?> builderClass = testBuilder.getClass();
         this.builderSetOwnerMethod = builderClass.getMethod("setOwner", Class.forName("com.bgsoftware.superiorskyblock.api.wrappers.SuperiorPlayer"));
         this.plugin.getLogger().info("[SuperiorSkyblock] Found Builder.setOwner() method");
         this.builderSetSchematicNameMethod = builderClass.getMethod("setSchematicName", String.class);
         this.plugin.getLogger().info("[SuperiorSkyblock] Found Builder.setSchematicName() method");
         this.builderSetNameMethod = builderClass.getMethod("setName", String.class);
         this.plugin.getLogger().info("[SuperiorSkyblock] Found Builder.setName() method");
      } catch (Exception var3) {
         this.plugin.getLogger().log(Level.WARNING, "[SuperiorSkyblock] Failed to cache reflection objects", var3);
      }

   }

   public void onFakePlayerJoin(String playerName, UUID playerUuid) {
      this.plugin.getLogger().info("[SuperiorSkyblock] Hook triggered for player: " + playerName);
      if (!this.isEnabled()) {
         this.plugin.getLogger().warning("[SuperiorSkyblock] Hook is not enabled!");
      } else if (GlideSpoofer.isFolia()) {
         Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> {
            Player player = Bukkit.getPlayer(playerUuid);
            if (player == null) {
               this.plugin.getLogger().warning("[SuperiorSkyblock] Player " + playerName + " is not online");
            } else {
               boolean success = this.createIsland(playerName, playerUuid);
               if (success) {
                  this.plugin.getLogger().info("[SuperiorSkyblock] Island creation initiated for " + playerName);
               } else {
                  this.plugin.getLogger().warning("[SuperiorSkyblock] Falling back to commands for " + playerName);
                  this.fallbackToCommands(player, playerName);
               }

               Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (t) -> this.teleportToIsland(playerName, playerUuid), 100L);
            }

         }, 20L);
      } else {
         Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            Player player = Bukkit.getPlayer(playerUuid);
            if (player == null) {
               this.plugin.getLogger().warning("[SuperiorSkyblock] Player " + playerName + " is not online");
            } else {
               boolean success = this.createIsland(playerName, playerUuid);
               if (success) {
                  this.plugin.getLogger().info("[SuperiorSkyblock] Island creation initiated for " + playerName);
               } else {
                  this.plugin.getLogger().warning("[SuperiorSkyblock] Falling back to commands for " + playerName);
                  this.fallbackToCommands(player, playerName);
               }

               Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.teleportToIsland(playerName, playerUuid), 100L);
            }

         }, 20L);
      }

   }

   private boolean createIsland(String playerName, UUID playerUuid) {
      try {
         Object gridManager = this.superiorSkyblock.getClass().getMethod("getGrid").invoke(this.superiorSkyblock);
         Object playersManager = this.superiorSkyblock.getClass().getMethod("getPlayers").invoke(this.superiorSkyblock);
         Object superiorPlayer = playersManager.getClass().getMethod("getSuperiorPlayer", UUID.class).invoke(playersManager, playerUuid);
         if (superiorPlayer == null) {
            this.plugin.getLogger().warning("[SuperiorSkyblock] Cannot get SuperiorPlayer");
            return false;
         } else {
            this.plugin.getLogger().info("[SuperiorSkyblock] Creating island using Island.Builder...");
            Object builder = this.islandNewBuilderMethod.invoke((Object)null);
            this.plugin.getLogger().info("[SuperiorSkyblock] Created builder: " + builder.getClass().getName());
            this.builderSetOwnerMethod.invoke(builder, superiorPlayer);
            this.plugin.getLogger().info("[SuperiorSkyblock] Set owner: " + playerName);
            this.builderSetSchematicNameMethod.invoke(builder, "normal");
            this.plugin.getLogger().info("[SuperiorSkyblock] Set schematic: normal");
            this.builderSetNameMethod.invoke(builder, playerName);
            this.plugin.getLogger().info("[SuperiorSkyblock] Set name: " + playerName);
            Class<?> biomeClass = Biome.class;
            this.gridManagerCreateIslandMethod = gridManager.getClass().getMethod("createIsland", Class.forName("com.bgsoftware.superiorskyblock.api.island.Island$Builder"), biomeClass, Boolean.TYPE);
            this.gridManagerCreateIslandMethod.invoke(gridManager, builder, Biome.PLAINS, false);
            this.plugin.getLogger().info("[SuperiorSkyblock] createIsland() called successfully!");
            if (GlideSpoofer.isFolia()) {
               Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> {
                  if (this.verifyIslandCreated(superiorPlayer)) {
                     this.plugin.getLogger().info("[SuperiorSkyblock] Island VERIFIED!");
                  } else {
                     this.plugin.getLogger().warning("[SuperiorSkyblock] Island not found after creation");
                  }

               }, 40L);
            } else {
               Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                  if (this.verifyIslandCreated(superiorPlayer)) {
                     this.plugin.getLogger().info("[SuperiorSkyblock] Island VERIFIED!");
                  } else {
                     this.plugin.getLogger().warning("[SuperiorSkyblock] Island not found after creation");
                  }

               }, 40L);
            }

            return true;
         }
      } catch (Exception var8) {
         this.plugin.getLogger().log(Level.WARNING, "[SuperiorSkyblock] API island creation failed", var8);
         return false;
      }
   }

   private boolean verifyIslandCreated(Object superiorPlayer) {
      try {
         Method getIslandMethod = superiorPlayer.getClass().getMethod("getIsland");
         Object island = getIslandMethod.invoke(superiorPlayer);
         return island != null;
      } catch (Exception var4) {
         return false;
      }
   }

   private void fallbackToCommands(Player player, String playerName) {
      List<String> commands = this.plugin.getConfigManager().getConfig().getStringList("hooks.superiorskyblock.create-commands");
      if (commands == null || commands.isEmpty()) {
         commands = List.of("is create normal", "is create");
      }

      for(String cmdTemplate : commands) {
         String cmd = cmdTemplate.replace("{player}", playerName).replace("{name}", playerName);
         this.plugin.getLogger().info("[SuperiorSkyblock] Executing: /" + cmd);
         Bukkit.dispatchCommand(player, cmd);
      }

   }

   private void teleportToIsland(String playerName, UUID playerUuid) {
      try {
         Player player = Bukkit.getPlayer(playerUuid);
         if (player == null) {
            return;
         }

         String teleportCmd = this.plugin.getConfigManager().getConfig().getString("hooks.superiorskyblock.teleport-command", "is go");
         teleportCmd = teleportCmd.replace("{player}", playerName).replace("{name}", playerName);
         this.plugin.getLogger().info("[SuperiorSkyblock] Teleporting: /" + teleportCmd);
         Bukkit.dispatchCommand(player, teleportCmd);
      } catch (Exception var5) {
         this.plugin.getLogger().log(Level.WARNING, "[SuperiorSkyblock] Teleport failed", var5);
      }

   }
}
