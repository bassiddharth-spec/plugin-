package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.FakePlayer;
import java.io.File;
import java.lang.reflect.Method;
import java.util.List;
import java.util.UUID;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventPriority;
import org.bukkit.plugin.Plugin;

public class EssentialsHook {
   private final GlideSpoofer plugin;
   private boolean enabled;
   private Object essentials;
   private Object essentialsChat;
   private boolean useEssentialsX;
   private Method broadcastMessageV2Method;
   private Method broadcastMessageV1Method;
   private Method getUserMethod;
   private Method getOfflineUserMethod;
   private Method getSettingsMethod;
   private Method getLoginMethod;
   private Method getLogoutMethod;
   private Method getJoinMessageMethod;
   private Method getQuitMessageMethod;
   private Method isVanishedMethod;
   private Method isHiddenMethod;
   private Method reloadMethod;
   private Method getChatMethod;
   private Method getFormatMethod;
   private Method setFormatMethod;
   private Method getGroupFormatMethod;
   private Method setGroupFormatMethod;
   private Method getRadiusMethod;
   private String customJoinMessage;
   private String customLeaveMessage;

   public EssentialsHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.enabled = false;
      this.essentials = null;
      this.useEssentialsX = false;
      if (!plugin.getConfigManager().getConfig().getBoolean("hooks.essentials.enabled", true)) {
         plugin.getLogger().info("Essentials hook disabled in config");
      } else {
         this.initializeEssentials();
         this.loadCustomMessages();
      }

   }

   private void initializeEssentials() {
      Plugin essPlugin = Bukkit.getPluginManager().getPlugin("Essentials");
      if (essPlugin != null && essPlugin.isEnabled()) {
         try {
            try {
               Class.forName("net.essentialsx.api.v2.ChatType");
               this.useEssentialsX = true;
               this.plugin.getLogger().info("Detected EssentialsX");
            } catch (ClassNotFoundException var31) {
               this.useEssentialsX = false;
               this.plugin.getLogger().info("Detected original Essentials");
            }

            this.essentials = essPlugin;
            Plugin essChatPlugin = Bukkit.getPluginManager().getPlugin("EssentialsChat");
            if (essChatPlugin != null && essChatPlugin.isEnabled()) {
               this.essentialsChat = essChatPlugin;
               this.plugin.getLogger().info("EssentialsX Chat detected - chat formatting enabled");
            }

            this.initializeReflection();
            this.enabled = true;
            this.plugin.getLogger().info("Essentials hook enabled!");
         } catch (Exception var4) {
            this.plugin.getLogger().warning("Could not initialize Essentials hook: " + var4.getMessage());
         }
      } else {
         this.plugin.getLogger().info("Essentials not found - Essentials hook disabled");
      }

   }

   private void initializeReflection() {
      try {
         Class<?> essentialsClass = this.essentials.getClass();

         try {
            Class<?> chatTypeClass = Class.forName("net.essentialsx.api.v2.ChatType");
            this.broadcastMessageV2Method = essentialsClass.getMethod("broadcastMessage", chatTypeClass, String.class);
         } catch (Exception var15) {
         }

         try {
            this.broadcastMessageV1Method = essentialsClass.getMethod("broadcastMessage", EventPriority.class, String.class);
         } catch (Exception var14) {
         }

         this.getUserMethod = essentialsClass.getMethod("getUser", UUID.class);
         this.getOfflineUserMethod = essentialsClass.getMethod("getOfflineUser", String.class);

         try {
            this.getSettingsMethod = essentialsClass.getMethod("getSettings");
         } catch (Exception var13) {
         }

         try {
            this.reloadMethod = essentialsClass.getMethod("reload");
         } catch (Exception var12) {
         }

         if (this.getSettingsMethod != null) {
            try {
               Object settings = this.getSettingsMethod.invoke(this.essentials);
               Class<?> settingsClass = settings.getClass();

               try {
                  this.getLoginMethod = settingsClass.getMethod("getLogin");
               } catch (Exception var10) {
               }

               try {
                  this.getLogoutMethod = settingsClass.getMethod("getLogout");
               } catch (Exception var9) {
               }
            } catch (Exception var11) {
            }
         }

         try {
            Class<?> userClass = Class.forName("com.earth2me.essentials.User");
            this.getJoinMessageMethod = userClass.getMethod("getJoinMessage");
            this.getQuitMessageMethod = userClass.getMethod("getQuitMessage");
            this.isVanishedMethod = userClass.getMethod("isVanished");
            this.isHiddenMethod = userClass.getMethod("isHidden");
         } catch (ClassNotFoundException var8) {
         }

         if (this.essentialsChat != null) {
            try {
               Class<?> essentialsChatClass = this.essentialsChat.getClass();

               try {
                  this.getChatMethod = essentialsChatClass.getMethod("getChat");
               } catch (Exception var6) {
               }

               try {
                  Class<?> chatClass = Class.forName("net.essentialsx.chat.EssentialsChat");
                  this.getFormatMethod = chatClass.getMethod("getFormat", Class.forName("org.bukkit.command.CommandSender"));
                  this.setFormatMethod = chatClass.getMethod("setFormat", Class.forName("org.bukkit.command.CommandSender"), String.class);
                  this.getGroupFormatMethod = chatClass.getMethod("getGroupFormat", Class.forName("org.bukkit.command.CommandSender"), String.class);
                  this.setGroupFormatMethod = chatClass.getMethod("setGroupFormat", Class.forName("org.bukkit.command.CommandSender"), String.class, String.class);
                  this.getRadiusMethod = chatClass.getMethod("getRadius");
               } catch (ClassNotFoundException var5) {
               }

               this.plugin.getLogger().fine("EssentialsX Chat reflection initialized");
            } catch (Exception var7) {
               this.plugin.getLogger().fine("Could not initialize EssentialsX Chat reflection: " + var7.getMessage());
            }
         }
      } catch (Exception var16) {
         this.plugin.getLogger().warning("Could not initialize Essentials reflection: " + var16.getMessage());
      }

   }

   private void loadCustomMessages() {
      this.customJoinMessage = this.plugin.getConfigManager().getConfig().getString("hooks.essentials.custom-join", (String)null);
      this.customLeaveMessage = this.plugin.getConfigManager().getConfig().getString("hooks.essentials.custom-leave", (String)null);
   }

   public boolean isEnabled() {
      return this.enabled && this.essentials != null;
   }

   public boolean isEssentialsX() {
      return this.useEssentialsX;
   }

   public void broadcastFakePlayerJoin(String fakePlayerName, UUID fakeUuid) {
      if (this.isEnabled()) {
         String message;
         if (this.customJoinMessage != null && !this.customJoinMessage.isEmpty()) {
            message = ChatColor.translateAlternateColorCodes('&', this.customJoinMessage.replace("{player}", fakePlayerName));
            this.plugin.getLogger().info("[EssentialsHook] Using custom join message for " + fakePlayerName);
         } else {
            message = this.getEssentialsJoinFormat(fakePlayerName, fakeUuid);
            if (message == null) {
               this.plugin.getLogger().info("[EssentialsHook] Join message suppressed for " + fakePlayerName + " (Essentials: none)");
               return;
            }

            this.plugin.getLogger().info("[EssentialsHook] Using Essentials join format for " + fakePlayerName + ": " + message);
         }

         try {
            for(Player player : Bukkit.getOnlinePlayers()) {
               if (this.plugin.getSimpleFakePlayerManager() == null || !this.plugin.getSimpleFakePlayerManager().isFakePlayer(player)) {
                  player.sendMessage(message);
               }
            }
         } catch (Exception var6) {
            this.plugin.getLogger().fine("Could not broadcast join message: " + var6.getMessage());
         }
      }

   }

   public void broadcastFakePlayerLeave(String fakePlayerName, UUID fakeUuid) {
      if (this.isEnabled()) {
         String message;
         if (this.customLeaveMessage != null && !this.customLeaveMessage.isEmpty()) {
            message = ChatColor.translateAlternateColorCodes('&', this.customLeaveMessage.replace("{player}", fakePlayerName));
         } else {
            message = this.getEssentialsLeaveFormat(fakePlayerName, fakeUuid);
            if (message == null) {
               this.plugin.getLogger().info("[EssentialsHook] Leave message suppressed for " + fakePlayerName + " (Essentials: none)");
               return;
            }
         }

         try {
            for(Player player : Bukkit.getOnlinePlayers()) {
               if (this.plugin.getSimpleFakePlayerManager() == null || !this.plugin.getSimpleFakePlayerManager().isFakePlayer(player)) {
                  player.sendMessage(message);
               }
            }
         } catch (Exception var6) {
            this.plugin.getLogger().fine("Could not broadcast leave message: " + var6.getMessage());
         }
      }

   }

   private String getEssentialsJoinFormat(String playerName, UUID uuid) {
      try {
         Object user = this.getUser(uuid);
         if (user == null) {
            user = this.getOfflineUser(playerName);
         }

         if (user != null && this.getJoinMessageMethod != null) {
            String format = (String)this.getJoinMessageMethod.invoke(user);
            if (format != null && !format.isEmpty()) {
               this.plugin.getLogger().fine("[EssentialsHook] Got join message from User: " + format);
               return format.replace("{PLAYER}", playerName).replace("{DISPLAYNAME}", playerName).replace("{nick}", playerName);
            }
         }

         if (this.getLoginMethod != null && this.getSettingsMethod != null) {
            Object settings = this.getSettingsMethod.invoke(this.essentials);
            String configFormat = (String)this.getLoginMethod.invoke(settings);
            if (configFormat != null && !configFormat.isEmpty() && !configFormat.equalsIgnoreCase("none")) {
               this.plugin.getLogger().fine("[EssentialsHook] Got join format from config: " + configFormat);
               return ChatColor.translateAlternateColorCodes('&', configFormat.replace("{PLAYER}", playerName).replace("{DISPLAYNAME}", playerName).replace("{nick}", playerName).replace("{USERNAME}", playerName));
            }
         }

         String directFormat = this.readEssentialsConfig("login");
         if (directFormat != null) {
            this.plugin.getLogger().fine("[EssentialsHook] Got join format from direct config read: " + directFormat);
            return ChatColor.translateAlternateColorCodes('&', directFormat.replace("{PLAYER}", playerName).replace("{DISPLAYNAME}", playerName).replace("{nick}", playerName).replace("{USERNAME}", playerName).replace("{player}", playerName).replace("{DISPLAYNAME}", playerName));
         }
      } catch (Exception var6) {
         this.plugin.getLogger().warning("[EssentialsHook] Could not get Essentials join format: " + var6.getMessage());
         var6.printStackTrace();
      }

      return null;
   }

   private String getEssentialsLeaveFormat(String playerName, UUID uuid) {
      try {
         Object user = this.getUser(uuid);
         if (user == null) {
            user = this.getOfflineUser(playerName);
         }

         if (user != null && this.getQuitMessageMethod != null) {
            String format = (String)this.getQuitMessageMethod.invoke(user);
            if (format != null && !format.isEmpty()) {
               this.plugin.getLogger().fine("[EssentialsHook] Got quit message from User: " + format);
               return format.replace("{PLAYER}", playerName).replace("{DISPLAYNAME}", playerName).replace("{nick}", playerName);
            }
         }

         if (this.getLogoutMethod != null && this.getSettingsMethod != null) {
            Object settings = this.getSettingsMethod.invoke(this.essentials);
            String configFormat = (String)this.getLogoutMethod.invoke(settings);
            if (configFormat != null && !configFormat.isEmpty() && !configFormat.equalsIgnoreCase("none")) {
               this.plugin.getLogger().fine("[EssentialsHook] Got quit format from config: " + configFormat);
               return ChatColor.translateAlternateColorCodes('&', configFormat.replace("{PLAYER}", playerName).replace("{DISPLAYNAME}", playerName).replace("{nick}", playerName).replace("{USERNAME}", playerName));
            }
         }

         String directFormat = this.readEssentialsConfig("logout");
         if (directFormat != null) {
            this.plugin.getLogger().fine("[EssentialsHook] Got quit format from direct config read: " + directFormat);
            return ChatColor.translateAlternateColorCodes('&', directFormat.replace("{PLAYER}", playerName).replace("{DISPLAYNAME}", playerName).replace("{nick}", playerName).replace("{USERNAME}", playerName).replace("{player}", playerName).replace("{DISPLAYNAME}", playerName));
         }
      } catch (Exception var6) {
         this.plugin.getLogger().warning("[EssentialsHook] Could not get Essentials leave format: " + var6.getMessage());
         var6.printStackTrace();
      }

      return null;
   }

   private String readEssentialsConfig(String key) {
      try {
         File configFolder = ((Plugin)this.essentials).getDataFolder();
         File configFile = new File(configFolder, "config.yml");
         if (!configFile.exists()) {
            this.plugin.getLogger().warning("[EssentialsHook] Essentials config.yml not found at: " + configFile.getPath());
            return null;
         } else {
            YamlConfiguration config = YamlConfiguration.loadConfiguration(configFile);
            String format = null;
            if ("login".equals(key) && config.contains("custom-join-message")) {
               format = config.getString("custom-join-message");
               this.plugin.getLogger().info("[EssentialsHook] Found format at 'custom-join-message': " + format);
            } else if ("logout".equals(key) && config.contains("custom-quit-message")) {
               format = config.getString("custom-quit-message");
               this.plugin.getLogger().info("[EssentialsHook] Found format at 'custom-quit-message': " + format);
            } else if (config.contains("chat." + key)) {
               format = config.getString("chat." + key);
               this.plugin.getLogger().info("[EssentialsHook] Found format at 'chat." + key + "': " + format);
            } else if (config.contains(key)) {
               format = config.getString(key);
               this.plugin.getLogger().info("[EssentialsHook] Found format at '" + key + "': " + format);
            } else if (config.contains("essentials.chat." + key)) {
               format = config.getString("essentials.chat." + key);
               this.plugin.getLogger().info("[EssentialsHook] Found format at 'essentials.chat." + key + "': " + format);
            } else if (config.contains("essentials." + key)) {
               format = config.getString("essentials." + key);
               this.plugin.getLogger().info("[EssentialsHook] Found format at 'essentials." + key + "': " + format);
            } else if (config.contains("messages." + key)) {
               format = config.getString("messages." + key);
               this.plugin.getLogger().info("[EssentialsHook] Found format at 'messages." + key + "': " + format);
            } else {
               this.plugin.getLogger().warning("[EssentialsHook] Could not find '" + key + "' format in Essentials config.yml");
            }

            return format != null && format.equalsIgnoreCase("none") ? null : format;
         }
      } catch (Exception var6) {
         this.plugin.getLogger().warning("[EssentialsHook] Could not read Essentials config directly: " + var6.getMessage());
         var6.printStackTrace();
         return null;
      }
   }

   private void broadcastMessage(String message) {
      if (message != null && !message.isEmpty()) {
         try {
            if (this.broadcastMessageV2Method != null) {
               try {
                  Class<?> chatTypeClass = Class.forName("net.essentialsx.api.v2.ChatType");
                  Object chatType = chatTypeClass.getField("ESSENTIALS").get((Object)null);
                  this.broadcastMessageV2Method.invoke(this.essentials, chatType, message);
                  return;
               } catch (Exception var9) {
                  this.plugin.getLogger().fine("Could not use EssentialsX v2 broadcast: " + var9.getMessage());
               }
            }

            if (this.broadcastMessageV1Method != null) {
               try {
                  this.broadcastMessageV1Method.invoke(this.essentials, EventPriority.NORMAL, message);
                  return;
               } catch (Exception var8) {
                  this.plugin.getLogger().fine("Could not use EssentialsX v1 broadcast: " + var8.getMessage());
               }
            }
         } catch (Exception var10) {
            this.plugin.getLogger().fine("Could not use Essentials broadcast method: " + var10.getMessage());
         }

         try {
            Method broadcastMethod = Bukkit.class.getMethod("broadcast", BaseComponent[].class);
            TextComponent component = new TextComponent(message);
            broadcastMethod.invoke((Object)null, component);
         } catch (Exception var7) {
            try {
               Method broadcastMessageMethod = Bukkit.class.getMethod("broadcastMessage", String.class);
               broadcastMessageMethod.invoke((Object)null, message);
            } catch (Exception var6) {
               for(Player player : Bukkit.getOnlinePlayers()) {
                  player.sendMessage(message);
               }
            }
         }
      }

   }

   public Object getFakePlayerUser(String playerName, UUID uuid) {
      if (!this.isEnabled()) {
         return null;
      } else {
         try {
            Object user = this.getUser(uuid);
            if (user == null) {
               user = this.getOfflineUser(playerName);
            }

            return user;
         } catch (Exception var4) {
            this.plugin.getLogger().fine("Could not get Essentials user for " + playerName + ": " + var4.getMessage());
            return null;
         }
      }
   }

   private Object getUser(UUID uuid) {
      if (this.getUserMethod == null) {
         return null;
      } else {
         try {
            return this.getUserMethod.invoke(this.essentials, uuid);
         } catch (Exception var3) {
            return null;
         }
      }
   }

   private Object getOfflineUser(String name) {
      if (this.getOfflineUserMethod == null) {
         return null;
      } else {
         try {
            return this.getOfflineUserMethod.invoke(this.essentials, name);
         } catch (Exception var3) {
            return null;
         }
      }
   }

   public boolean isVanished(String playerName) {
      if (!this.isEnabled()) {
         return false;
      } else {
         try {
            Object user = this.getOfflineUser(playerName);
            if (user != null && this.isVanishedMethod != null) {
               return (Boolean)this.isVanishedMethod.invoke(user);
            }
         } catch (Exception var3) {
         }

         return false;
      }
   }

   public boolean isJoinQuitEnabled(String playerName) {
      if (!this.isEnabled()) {
         return true;
      } else {
         try {
            Object user = this.getOfflineUser(playerName);
            if (user != null && this.isHiddenMethod != null) {
               return !(Boolean)this.isHiddenMethod.invoke(user);
            }
         } catch (Exception var3) {
         }

         return true;
      }
   }

   public void createFakePlayerUserData(String playerName, UUID uuid, String joinMessage, String quitMessage) {
      if (this.isEnabled()) {
         try {
            Object user = this.getUser(uuid);
            if (user == null) {
               File var10002 = ((Plugin)this.essentials).getDataFolder();
               String var10003 = File.separator;
               File userFile = new File(var10002, "userdata" + var10003 + uuid.toString() + ".yml");
               if (!userFile.exists()) {
                  YamlConfiguration config = YamlConfiguration.loadConfiguration(userFile);
                  if (joinMessage != null && !joinMessage.isEmpty()) {
                     config.set("customjoin", joinMessage);
                  }

                  if (quitMessage != null && !quitMessage.isEmpty()) {
                     config.set("customquit", quitMessage);
                  }

                  config.save(userFile);
                  this.plugin.getLogger().fine("Created Essentials user data for fake player: " + playerName);
               }
            }
         } catch (Exception var8) {
            this.plugin.getLogger().fine("Could not create Essentials user data: " + var8.getMessage());
         }
      }

   }

   public void removeFakePlayerUserData(UUID uuid) {
      if (this.isEnabled()) {
         try {
            File var10002 = ((Plugin)this.essentials).getDataFolder();
            String var10003 = File.separator;
            File userFile = new File(var10002, "userdata" + var10003 + uuid.toString() + ".yml");
            if (userFile.exists()) {
               userFile.delete();
               this.plugin.getLogger().fine("Removed Essentials user data for fake player: " + String.valueOf(uuid));
            }
         } catch (Exception var3) {
            this.plugin.getLogger().fine("Could not remove Essentials user data: " + var3.getMessage());
         }
      }

   }

   public void reloadEssentials() {
      if (this.isEnabled()) {
         try {
            if (this.reloadMethod != null) {
               this.reloadMethod.invoke(this.essentials);
            }

            this.loadCustomMessages();
            this.plugin.getLogger().info("Essentials configuration reloaded");
         } catch (Exception var2) {
            this.plugin.getLogger().warning("Could not reload Essentials: " + var2.getMessage());
         }
      }

   }

   public boolean isEssentialsXChatEnabled() {
      return this.enabled && this.essentialsChat != null;
   }

   public String formatChatMessage(Player player, String message) {
      if (!this.isEssentialsXChatEnabled()) {
         return null;
      } else {
         try {
            return null;
         } catch (Exception var4) {
            this.plugin.getLogger().fine("Could not format chat with EssentialsX: " + var4.getMessage());
            return null;
         }
      }
   }

   public String getChatFormat(Player player) {
      if (this.isEssentialsXChatEnabled() && this.getFormatMethod != null) {
         try {
            Object chat = this.getChatMethod != null ? this.getChatMethod.invoke(this.essentialsChat) : this.essentialsChat;
            return (String)this.getFormatMethod.invoke(chat, player);
         } catch (Exception var3) {
            this.plugin.getLogger().fine("Could not get chat format: " + var3.getMessage());
            return null;
         }
      } else {
         return null;
      }
   }

   public String getGroupChatFormat(Player player, String group) {
      if (this.isEssentialsXChatEnabled() && this.getGroupFormatMethod != null) {
         try {
            Object chat = this.getChatMethod != null ? this.getChatMethod.invoke(this.essentialsChat) : this.essentialsChat;
            return (String)this.getGroupFormatMethod.invoke(chat, player, group);
         } catch (Exception var4) {
            this.plugin.getLogger().fine("Could not get group chat format: " + var4.getMessage());
            return null;
         }
      } else {
         return null;
      }
   }

   public int getChatRadius() {
      if (this.isEssentialsXChatEnabled() && this.getRadiusMethod != null) {
         try {
            Object chat = this.getChatMethod != null ? this.getChatMethod.invoke(this.essentialsChat) : this.essentialsChat;
            Object radius = this.getRadiusMethod.invoke(chat);
            if (radius instanceof Number) {
               return ((Number)radius).intValue();
            }
         } catch (Exception var3) {
            this.plugin.getLogger().fine("Could not get chat radius: " + var3.getMessage());
         }

         return 0;
      } else {
         return 0;
      }
   }

   public String applyEssentialsChatFormat(String format, Player player, String message) {
      if (format == null) {
         return null;
      } else {
         try {
            String displayName;
            try {
               displayName = player.displayName() != null ? player.displayName().toString() : player.getName();
            } catch (NoSuchMethodError var111) {
               displayName = player.getName();
            }

            String formatted = format.replace("{DISPLAYNAME}", displayName).replace("{USERNAME}", player.getName()).replace("{MESSAGE}", message).replace("{NICKNAME}", player.getName());
            if (this.plugin.getLuckPermsHook() != null && this.plugin.getLuckPermsHook().isEnabled()) {
               FakePlayer fake = new FakePlayer(player.getUniqueId(), player.getName());
               String prefix = this.plugin.getLuckPermsHook().getPrefix(fake);
               String suffix = this.plugin.getLuckPermsHook().getSuffix(fake);
               formatted = formatted.replace("{PREFIX}", prefix != null ? prefix : "").replace("{SUFFIX}", suffix != null ? suffix : "");
               List<String> groups = this.plugin.getLuckPermsHook().getGroups(fake);
               if (groups != null && !groups.isEmpty()) {
                  formatted = formatted.replace("{GROUP}", (CharSequence)groups.get(0));
               }
            }

            try {
               formatted = net.md_5.bungee.api.ChatColor.translateAlternateColorCodes('&', formatted);
            } catch (Exception var10) {
               formatted = formatted.replace("&", "§");
            }

            return formatted;
         } catch (Exception var12) {
            this.plugin.getLogger().fine("Could not apply EssentialsX chat format: " + var12.getMessage());
            return null;
         }
      }
   }
}
