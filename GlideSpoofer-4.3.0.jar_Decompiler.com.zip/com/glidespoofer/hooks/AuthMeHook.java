package com.glidespoofer.hooks;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import java.io.File;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class AuthMeHook {
   private final GlideSpoofer plugin;
   private boolean enabled;
   private Object authMeApi;
   private Method isAuthenticatedMethod;
   private Method forceLoginMethod;
   private Method forceRegisterMethod;
   private Method forceRegisterMethodWithPassword;
   private Method isRegisteredMethod;
   private Method registerPlayerMethod;
   private Method dataManagerMethod;
   private Method saveAuthMethod;
   private Method setAuthenticatedMethod;

   public AuthMeHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.enabled = false;
      if (!plugin.getConfigManager().getConfig().getBoolean("hooks.authme.enabled", true)) {
         plugin.getLogger().info("AuthMe hook disabled in config");
      } else {
         this.initializeAuthMe();
      }

   }

   private void initializeAuthMe() {
      Plugin authMePlugin = Bukkit.getPluginManager().getPlugin("AuthMe");
      if (authMePlugin != null && authMePlugin.isEnabled()) {
         try {
            Class<?> authMeApiClass = Class.forName("fr.xephi.authme.api.v3.AuthMeApi");
            Method getInstanceMethod = authMeApiClass.getMethod("getInstance");
            this.authMeApi = getInstanceMethod.invoke((Object)null);
            this.initializeReflection();
            this.enabled = true;
            this.plugin.getLogger().info("AuthMe hook enabled! Fake players will bypass login/register.");
         } catch (ClassNotFoundException var6) {
            this.plugin.getLogger().info("AuthMe API v3 not found, trying v5...");

            try {
               Class<?> authMeApiClassx = Class.forName("fr.xephi.authme.api.v5.AuthMeApi");
               Method getInstanceMethodx = authMeApiClassx.getMethod("getInstance");
               this.authMeApi = getInstanceMethodx.invoke((Object)null);
               this.initializeReflection();
               this.enabled = true;
               this.plugin.getLogger().info("AuthMe v5 hook enabled! Fake players will bypass login/register.");
            } catch (Exception var5) {
               this.plugin.getLogger().warning("Could not initialize AuthMe hook: " + var5.getMessage());
            }
         } catch (Exception var7) {
            this.plugin.getLogger().log(Level.WARNING, "Could not initialize AuthMe hook: " + var7.getMessage(), var7);
         }
      } else {
         this.plugin.getLogger().info("AuthMe not found - AuthMe hook disabled");
      }

   }

   private void initializeReflection() {
      try {
         this.isAuthenticatedMethod = this.authMeApi.getClass().getMethod("isAuthenticated", Player.class);
         this.plugin.getLogger().info("[AuthMeHook] Found isAuthenticated method");
         this.forceLoginMethod = this.authMeApi.getClass().getMethod("forceLogin", Player.class);
         this.plugin.getLogger().info("[AuthMeHook] Found forceLogin method");
         this.forceRegisterMethod = this.authMeApi.getClass().getMethod("forceRegister", Player.class);
         this.plugin.getLogger().info("[AuthMeHook] Found forceRegister(Player) method");
         this.isRegisteredMethod = this.authMeApi.getClass().getMethod("isRegistered", String.class);
         this.plugin.getLogger().info("[AuthMeHook] Found isRegistered method");

         try {
            this.forceRegisterMethodWithPassword = this.authMeApi.getClass().getMethod("forceRegister", Player.class, String.class);
            this.plugin.getLogger().info("[AuthMeHook] Found forceRegister(Player, String) method");
         } catch (Exception var3) {
            this.plugin.getLogger().info("[AuthMeHook] forceRegister(Player, String) not available: " + var3.getMessage());
         }

         try {
            this.registerPlayerMethod = this.authMeApi.getClass().getMethod("registerPlayer", Player.class, String.class, String.class);
            this.plugin.getLogger().info("[AuthMeHook] Found registerPlayer method");
         } catch (Exception var2) {
            this.plugin.getLogger().info("[AuthMeHook] registerPlayer not available: " + var2.getMessage());
         }

         this.plugin.getLogger().info("AuthMe reflection methods initialized successfully");
      } catch (Exception var4) {
         this.plugin.getLogger().log(Level.WARNING, "Could not initialize AuthMe reflection: " + var4.getMessage(), var4);
      }

   }

   public boolean isEnabled() {
      return this.enabled && this.authMeApi != null;
   }

   public boolean isAuthenticated(Player player) {
      if (this.isEnabled() && this.isAuthenticatedMethod != null) {
         try {
            return (Boolean)this.isAuthenticatedMethod.invoke(this.authMeApi, player);
         } catch (Exception var3) {
            Logger var10000 = this.plugin.getLogger();
            String var10001 = player.getName();
            var10000.fine("Could not check auth status for " + var10001 + ": " + var3.getMessage());
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean forceLogin(Player player) {
      if (this.isEnabled() && this.forceLoginMethod != null) {
         try {
            this.forceLoginMethod.invoke(this.authMeApi, player);
            this.plugin.getLogger().fine("[AuthMeHook] Force logged in: " + player.getName());
            return true;
         } catch (Exception var3) {
            this.plugin.getLogger().log(Level.WARNING, "Could not force login for " + player.getName(), var3);
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean forceRegister(Player player) {
      if (this.isEnabled() && this.forceRegisterMethod != null) {
         try {
            this.forceRegisterMethod.invoke(this.authMeApi, player);
            this.plugin.getLogger().fine("[AuthMeHook] Force registered: " + player.getName());
            return true;
         } catch (Exception var3) {
            this.plugin.getLogger().log(Level.WARNING, "Could not force register for " + player.getName(), var3);
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean isRegistered(String playerName) {
      if (this.isEnabled() && this.isRegisteredMethod != null) {
         try {
            return (Boolean)this.isRegisteredMethod.invoke(this.authMeApi, playerName);
         } catch (Exception var3) {
            return false;
         }
      } else {
         return false;
      }
   }

   public void setupFakePlayer(Player player) {
      if (this.isEnabled()) {
         try {
            if (this.isAuthenticated(player)) {
               this.plugin.getLogger().fine("[AuthMeHook] Player " + player.getName() + " already authenticated");
               return;
            }

            this.plugin.getLogger().info("[AuthMeHook] Setting up fake player: " + player.getName());
            String var10000 = player.getUniqueId().toString();
            String password = "GlideSpoofer" + var10000.substring(0, 8);
            boolean registered = false;
            if (this.registerPlayerMethod != null && !registered) {
               try {
                  this.registerPlayerMethod.invoke(this.authMeApi, player, password, password);
                  registered = true;
                  this.plugin.getLogger().info("[AuthMeHook] Registered using registerPlayer: " + player.getName());
               } catch (Exception var7) {
                  this.plugin.getLogger().fine("[AuthMeHook] registerPlayer failed: " + var7.getMessage());
               }
            }

            if (this.forceRegisterMethodWithPassword != null && !registered) {
               try {
                  this.forceRegisterMethodWithPassword.invoke(this.authMeApi, player, password);
                  registered = true;
                  this.plugin.getLogger().info("[AuthMeHook] Registered using forceRegister with password: " + player.getName());
               } catch (Exception var6) {
                  this.plugin.getLogger().fine("[AuthMeHook] forceRegister with password failed: " + var6.getMessage());
               }
            }

            if (this.forceRegisterMethod != null && !registered) {
               try {
                  this.forceRegisterMethod.invoke(this.authMeApi, player);
                  registered = true;
                  this.plugin.getLogger().info("[AuthMeHook] Registered using forceRegister: " + player.getName());
               } catch (Exception var5) {
                  this.plugin.getLogger().fine("[AuthMeHook] forceRegister failed: " + var5.getMessage());
               }
            }

            if (!registered) {
               registered = this.createAuthMePlayerData(player.getName(), player.getUniqueId().toString(), password);
            }

            if (registered) {
               this.forceLogin(player);
               this.plugin.getLogger().info("[AuthMeHook] Force logged in: " + player.getName());
               Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                  if (!this.isAuthenticated(player)) {
                     this.plugin.getLogger().fine("[AuthMeHook] Re-authenticating: " + player.getName());
                     this.forceLogin(player);
                  }

               }, 2L);
            } else {
               this.plugin.getLogger().fine("[AuthMeHook] Registration skipped, trying direct login");
               this.forceLogin(player);
            }
         } catch (Exception var8) {
            this.plugin.getLogger().log(Level.WARNING, "Could not setup AuthMe for " + player.getName(), var8);
         }
      }

   }

   private boolean createAuthMePlayerData(String playerName, String uuid, String password) {
      try {
         Plugin authMePlugin = Bukkit.getPluginManager().getPlugin("AuthMe");
         if (authMePlugin == null) {
            return false;
         } else {
            File dataFolder = authMePlugin.getDataFolder();
            File playerDataFolder = new File(dataFolder, "playerdata");
            if (!playerDataFolder.exists()) {
               playerDataFolder.mkdirs();
            }

            File playerFile = new File(playerDataFolder, uuid.toLowerCase() + ".yml");
            YamlConfiguration config = new YamlConfiguration();
            config.set("password", this.hashPassword(password));
            config.set("ip", "127.0.0.1");
            config.set("lastlogin", System.currentTimeMillis() / 1000L);
            config.save(playerFile);
            this.plugin.getLogger().info("[AuthMeHook] Created AuthMe player data file: " + playerName);
            return true;
         }
      } catch (Exception var9) {
         this.plugin.getLogger().warning("[AuthMeHook] Could not create player data file: " + var9.getMessage());
         return false;
      }
   }

   private String hashPassword(String password) {
      try {
         MessageDigest md = MessageDigest.getInstance("SHA-256");
         byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
         StringBuilder hexString = new StringBuilder();

         for(byte b : hash) {
            String hex = Integer.toHexString(255 & b);
            if (hex.length() == 1) {
               hexString.append('0');
            }

            hexString.append(hex);
         }

         return "$SHA$" + hexString.toString();
      } catch (Exception var10) {
         return password;
      }
   }

   public void setupFakePlayer(UUID uuid, String name) {
      if (this.isEnabled() && this.plugin.getSimpleFakePlayerManager() != null) {
         SimpleFakePlayerManager.FakePlayerData data = this.plugin.getSimpleFakePlayerManager().getFakePlayer(name);
         if (data != null && data.getPlayer() != null) {
            this.setupFakePlayer(data.getPlayer());
         }
      }

   }

   public void markAsAuthenticated(Player player) {
      if (this.isEnabled()) {
         Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.forceLogin(player), 1L);
      }

   }

   public boolean needsAuthentication(Player player) {
      return !this.isEnabled() ? false : !this.isAuthenticated(player);
   }

   public void ensureAuthenticated(Player player) {
      if (this.isEnabled() && !this.isAuthenticated(player)) {
         if (!this.isRegistered(player.getName())) {
            String var10000 = player.getUniqueId().toString();
            String password = "GlideSpoofer" + var10000.substring(0, 8);
            if (this.forceRegisterMethodWithPassword != null) {
               try {
                  this.forceRegisterMethodWithPassword.invoke(this.authMeApi, player, password);
               } catch (Exception var5) {
               }
            } else if (this.registerPlayerMethod != null) {
               try {
                  this.registerPlayerMethod.invoke(this.authMeApi, player, password, password);
               } catch (Exception var4) {
               }
            }
         }

         this.forceLogin(player);
         if (!this.isAuthenticated(player)) {
            Bukkit.getScheduler().runTask(this.plugin, () -> {
               this.forceLogin(player);
               this.plugin.getLogger().fine("[AuthMeHook] Retried force login for: " + player.getName());
            });
         }
      }

   }
}
