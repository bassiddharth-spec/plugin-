package com.glidespoofer.hooks;

import com.glidespoofer.config.ConfigManager;
import com.glidespoofer.core.GlideSpoofer;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.nio.file.Paths;
import java.util.UUID;
import java.util.logging.Level;
import net.luckperms.api.model.user.User;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;

public class RustHook {
   private final GlideSpoofer plugin;
   private final ConfigManager configManager;
   private boolean enabled;
   private Object rustLibraryInstance;
   private boolean useJNI;
   private Method onPlayerLogoutMethod;
   private Method onFakePlayerLoginMethod;
   private Method onFakePlayerDeathMethod;

   public RustHook(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.configManager = plugin.getConfigManager();
      this.enabled = false;
      this.useJNI = false;
      this.loadRustHook();
   }

   private void loadRustHook() {
      FileConfiguration config = this.configManager.getConfig();
      if (!config.getBoolean("rust-hook.enabled", false)) {
         this.plugin.getLogger().info("Rust hook disabled in config");
      } else {
         switch (config.getString("rust-hook.type", "command").toLowerCase()) {
            case "jni":
               this.loadJNILibrary();
               break;
            case "command":
               this.loadCommandHook();
               break;
            default:
               this.plugin.getLogger().warning("Unknown rust-hook type: " + hookType + ". Using 'command' mode.");
               this.loadCommandHook();
         }
      }

   }

   private void loadJNILibrary() {
      FileConfiguration config = this.configManager.getConfig();
      String libraryPath = config.getString("rust-hook.jni.library-path", "");
      String libraryName = config.getString("rust-hook.jni.library-name", "glidespoofer_hook");
      if (libraryPath != null && !libraryPath.isEmpty()) {
         try {
            System.load(Paths.get(libraryPath).toAbsolutePath().toString());
            this.enabled = true;
            this.useJNI = true;
            this.plugin.getLogger().info("§a[RustHook] Loaded Rust library from: " + libraryPath);
            this.initializeJNIMethods();
         } catch (Exception var6) {
            this.plugin.getLogger().log(Level.WARNING, "[RustHook] Failed to load library from path: " + libraryPath, var6);
         }
      } else {
         try {
            System.loadLibrary(libraryName);
            this.enabled = true;
            this.useJNI = true;
            this.plugin.getLogger().info("§a[RustHook] Loaded Rust library: " + libraryName);
            this.initializeJNIMethods();
         } catch (UnsatisfiedLinkError var5) {
            this.plugin.getLogger().log(Level.WARNING, "[RustHook] Failed to load library: " + libraryName, var5);
         }
      }

   }

   private void initializeJNIMethods() {
      try {
         String className = this.plugin.getConfigManager().getConfig().getString("rust-hook.jni.class-name", "com.glidespoofer.hooks.RustNative");
         Class<?> nativeClass = Class.forName(className);
         this.rustLibraryInstance = nativeClass.getDeclaredConstructor().newInstance();
         this.onPlayerLogoutMethod = nativeClass.getMethod("onPlayerLogout", String.class, String.class);
         this.onFakePlayerLoginMethod = nativeClass.getMethod("onFakePlayerLogin", String.class, String.class, String.class);
         this.onFakePlayerDeathMethod = nativeClass.getMethod("onFakePlayerDeath", String.class);
         this.plugin.getLogger().info("§a[RustHook] JNI methods initialized successfully");
      } catch (Exception var3) {
         this.plugin.getLogger().log(Level.WARNING, "[RustHook] Failed to initialize JNI methods", var3);
         this.enabled = false;
      }

   }

   private void loadCommandHook() {
      String executablePath = this.configManager.getConfig().getString("rust-hook.command.executable", "");
      if (executablePath != null && !executablePath.isEmpty()) {
         File exeFile = new File(executablePath);
         if (!exeFile.exists()) {
            this.plugin.getLogger().warning("[RustHook] Executable not found: " + executablePath + " - enabling permission mode only");
            this.enabled = true;
            this.useJNI = false;
         } else {
            this.enabled = true;
            this.useJNI = false;
            this.plugin.getLogger().info("§a[RustHook] Command hook enabled with executable: " + executablePath);
         }
      } else {
         this.plugin.getLogger().info("[RustHook] Command hook enabled (no executable - permission mode only)");
         this.enabled = true;
         this.useJNI = false;
      }

   }

   public void onPlayerLogout(String playerName, String playerUuid) {
      if (this.enabled) {
         if (this.useJNI && this.onPlayerLogoutMethod != null) {
            try {
               this.onPlayerLogoutMethod.invoke(this.rustLibraryInstance, playerName, playerUuid);
               if (this.configManager.getConfig().getBoolean("rust-hook.debug", false)) {
                  this.plugin.getLogger().info("[RustHook] JNI: onPlayerLogout called for " + playerName);
               }
            } catch (Exception var4) {
               this.plugin.getLogger().log(Level.WARNING, "[RustHook] JNI call failed for onPlayerLogout", var4);
            }
         } else {
            this.executeRustCommand("player_logout", playerName, playerUuid, (String)null);
         }
      }

   }

   public void onFakePlayerLogin(String fakePlayerName, String realPlayerUuid, String realPlayerName) {
      if (this.enabled) {
         if (this.useJNI && this.onFakePlayerLoginMethod != null) {
            try {
               this.onFakePlayerLoginMethod.invoke(this.rustLibraryInstance, fakePlayerName, realPlayerUuid, realPlayerName);
               if (this.configManager.getConfig().getBoolean("rust-hook.debug", false)) {
                  this.plugin.getLogger().info("[RustHook] JNI: onFakePlayerLogin called - Fake: " + fakePlayerName + "接管 Real: " + realPlayerName);
               }
            } catch (Exception var5) {
               this.plugin.getLogger().log(Level.WARNING, "[RustHook] JNI call failed for onFakePlayerLogin", var5);
            }
         } else {
            this.executeRustCommand("fake_login", fakePlayerName, realPlayerUuid, realPlayerName);
         }
      }

   }

   public void onFakePlayerDeath(String fakePlayerName) {
      if (this.enabled) {
         if (this.useJNI && this.onFakePlayerDeathMethod != null) {
            try {
               this.onFakePlayerDeathMethod.invoke(this.rustLibraryInstance, fakePlayerName);
               if (this.configManager.getConfig().getBoolean("rust-hook.debug", false)) {
                  this.plugin.getLogger().info("[RustHook] JNI: onFakePlayerDeath called for " + fakePlayerName);
               }
            } catch (Exception var3) {
               this.plugin.getLogger().log(Level.WARNING, "[RustHook] JNI call failed for onFakePlayerDeath", var3);
            }
         } else {
            this.executeRustCommand("fake_death", fakePlayerName, (String)null, (String)null);
         }
      }

   }

   private void executeRustCommand(String action, String targetName, String uuid, String extra) {
      String executablePath = this.configManager.getConfig().getString("rust-hook.command.executable", "");
      if (executablePath != null && !executablePath.isEmpty()) {
         File exeFile = new File(executablePath);
         if (!exeFile.exists()) {
            this.plugin.getLogger().fine("[RustHook] Executable not found, skipping command execution");
         } else {
            try {
               ProcessBuilder pb = new ProcessBuilder(new String[]{executablePath, action, targetName, uuid != null ? uuid : "", extra != null ? extra : ""});
               pb.redirectErrorStream(true);
               Process process = pb.start();
               Bukkit.getScheduler().runTaskAsynchronously(this.plugin, () -> {
                  try {
                     BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                     StringBuilder output = new StringBuilder();

                     String line;
                     while((line = reader.readLine()) != null) {
                        output.append(line).append("\n");
                     }

                     process.waitFor();
                     if (this.configManager.getConfig().getBoolean("rust-hook.debug", false)) {
                        this.plugin.getLogger().info("[RustHook] Command output: " + String.valueOf(output));
                     }
                  } catch (Exception var5x) {
                     this.plugin.getLogger().log(Level.WARNING, "[RustHook] Error reading command output", var5x);
                  }

               });
            } catch (Exception var9) {
               this.plugin.getLogger().log(Level.WARNING, "[RustHook] Failed to execute command", var9);
            }
         }
      } else {
         this.plugin.getLogger().fine("[RustHook] No executable configured, skipping command execution");
      }

   }

   public boolean hasPermanentPermission(String playerUuid) {
      if (this.plugin.getLuckPermsHook() != null && this.plugin.getLuckPermsHook().isEnabled()) {
         try {
            UUID uuid = UUID.fromString(playerUuid);
            User user = this.plugin.getLuckPermsHook().getUserByUuid(uuid);
            if (user != null) {
               String permissionNode = this.configManager.getConfig().getString("rust-hook.permanent-permission-node", "glidespoofer.permanent");
               boolean hasPermission = user.getCachedData().getPermissionData().checkPermission(permissionNode).asBoolean();
               this.plugin.getLogger().info("[RustHook] Permission check for UUID " + playerUuid + ": " + permissionNode + " = " + hasPermission + " (RustHook enabled: " + this.enabled + ")");
               return hasPermission;
            }

            this.plugin.getLogger().warning("[RustHook] User not found in LuckPerms for UUID: " + playerUuid);
         } catch (Exception var6) {
            this.plugin.getLogger().log(Level.WARNING, "[RustHook] Could not check LuckPerms permission for " + playerUuid, var6);
         }
      } else {
         this.plugin.getLogger().warning("[RustHook] LuckPerms hook not available - cannot check permissions");
      }

      return false;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public boolean isUseJNI() {
      return this.useJNI;
   }

   public void setEnabled(boolean enabled) {
      this.enabled = enabled;
   }

   public void shutdown() {
      if (this.enabled && !this.useJNI) {
      }

      this.enabled = false;
   }
}
