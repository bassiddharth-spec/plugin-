package com.glidespoofer.movement;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.FakePlayer;
import com.glidespoofer.fake.FakePlayerAI;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import com.glidespoofer.hooks.LuckPermsHook;
import com.glidespoofer.hooks.TABHook;
import com.glidespoofer.listener.FakePlayerDamageListener;
import com.glidespoofer.nms.NMSHandler;
import com.glidespoofer.pathfinding.FollowModeManager;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class RealisticFakePlayerMovement {
   private final GlideSpoofer plugin;
   private final Map<UUID, FakePlayerMovementData> movementDataMap;
   private Object movementTask;
   private boolean enabled = false;
   private int movementInterval = 1;
   private static final double WALK_SPEED = 0.1;
   private static final double SPRINT_SPEED = 0.13;
   private static final double JUMP_VELOCITY = 0.42;
   private static final double GRAVITY = 0.08;
   private static final double GROUND_FRICTION = 0.6;

   public RealisticFakePlayerMovement(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.movementDataMap = new ConcurrentHashMap();
   }

   public void start() {
      if (this.movementTask != null) {
         this.plugin.getLogger().warning("[Movement] Movement task already running!");
      } else {
         this.plugin.getLogger().info("[Movement] Starting realistic fake player movement system...");
         if (GlideSpoofer.isFolia()) {
            this.startFoliaTask();
         } else {
            this.startBukkitTask();
         }
      }

   }

   private void startBukkitTask() {
      this.movementTask = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
         if (this.enabled) {
            this.tickAll();
         }

      }, 5L, (long)this.movementInterval);
      this.plugin.getLogger().info("[Movement] Started Bukkit task with interval: " + this.movementInterval);
   }

   private void startFoliaTask() {
      try {
         Object regionScheduler = Bukkit.class.getMethod("getRegionScheduler").invoke((Object)null);
         this.movementTask = regionScheduler.getClass().getMethod("runAtFixedRate", Plugin.class, Consumer.class, Long.TYPE, Long.TYPE).invoke(regionScheduler, this.plugin, (Consumer)(task) -> {
            if (this.enabled) {
               this.tickAll();
            }

         }, 5L, (long)this.movementInterval);
         this.plugin.getLogger().info("[Movement] Started Folia task with interval: " + this.movementInterval);
      } catch (Exception var2) {
         this.plugin.getLogger().log(Level.SEVERE, "[Movement] Failed to start Folia task", var2);
      }

   }

   public void stop() {
      if (this.movementTask != null) {
         if (this.movementTask instanceof BukkitTask) {
            ((BukkitTask)this.movementTask).cancel();
         } else if (this.movementTask.getClass().getName().contains("ScheduledTask")) {
            try {
               this.movementTask.getClass().getMethod("cancel").invoke(this.movementTask);
            } catch (Exception var2) {
               this.plugin.getLogger().log(Level.WARNING, "[Movement] Failed to cancel Folia task", var2);
            }
         }

         this.movementTask = null;
      }

      this.movementDataMap.clear();
   }

   private void tickAll() {
      SimpleFakePlayerManager fakeManager = this.plugin.getSimpleFakePlayerManager();
      if (fakeManager != null) {
         for(SimpleFakePlayerManager.FakePlayerData fakeData : fakeManager.getAllFakePlayers()) {
            Player fakePlayer = fakeData.getPlayer();
            if (fakePlayer != null && fakePlayer.isOnline()) {
               UUID uuid = fakeData.getUuid();
               FakePlayerMovementData data = (FakePlayerMovementData)this.movementDataMap.computeIfAbsent(uuid, (u) -> new FakePlayerMovementData());
               this.updateMovement(fakePlayer, data, fakeData);
               if (!FakePlayerDamageListener.isKnockedBackStatic(fakePlayer.getName())) {
                  this.syncPosition(fakePlayer, data);
               }

               if (fakeManager.getNMSHandler() != null && fakeManager.getNMSHandler().isLookingAtPlayers(uuid)) {
                  this.updateHeadRotation(fakePlayer, data);
               }

               this.handleIdleAnimations(fakePlayer, data);
               this.syncPosition(fakePlayer, data);
            }
         }
      }

   }

   private void updateMovement(Player fakePlayer, FakePlayerMovementData data, SimpleFakePlayerManager.FakePlayerData fakeData) {
      if (!FakePlayerDamageListener.isKnockedBackStatic(fakePlayer.getName())) {
         if (data.ticksSinceSpawn < 20) {
            ++data.ticksSinceSpawn;
         } else {
            Location currentLoc = fakePlayer.getLocation();
            if (currentLoc != null) {
               if (data.knockbackTicks > 0) {
                  this.handleKnockback(fakePlayer, data);
                  --data.knockbackTicks;
               } else {
                  FollowModeManager fmm = this.plugin.getFollowModeManager();
                  if (fmm != null && fmm.isFollowing(fakeData.getUuid())) {
                     return;
                  }

                  FakePlayer fake = this.plugin.getFakePlayerManager() != null ? this.plugin.getFakePlayerManager().getFakePlayer(fakeData.getUuid()) : null;
                  if (fake != null && fake.hasAI()) {
                     FakePlayerAI ai = fake.getAI();
                     if (ai != null && ai.isEnabled()) {
                        ai.update();
                        Location aiLoc = fake.getLocation();
                        if (aiLoc != null) {
                           fakePlayer.teleport(aiLoc);
                           data.lastX = aiLoc.getX();
                           data.lastY = aiLoc.getY();
                           data.lastZ = aiLoc.getZ();
                           data.lastYaw = aiLoc.getYaw();
                           data.lastPitch = aiLoc.getPitch();
                           return;
                        }
                     }
                  }

                  this.handleIdleMovement(fakePlayer, data, currentLoc);
               }
            }
         }

      }
   }

   private void handleIdleMovement(Player fakePlayer, FakePlayerMovementData data, Location currentLoc) {
      if (data.ticksUntilLook <= 0) {
         data.targetYaw = (double)(currentLoc.getYaw() + (float)((Math.random() - (double)0.5F) * (double)60.0F));
         data.targetPitch = (double)((float)((Math.random() - (double)0.5F) * (double)30.0F));
         data.ticksUntilLook = 40 + (int)(Math.random() * (double)60.0F);
      }

      --data.ticksUntilLook;
      if (data.ticksUntilMove <= 0) {
         data.isMoving = Math.random() < 0.4;
         data.ticksUntilMove = 60 + (int)(Math.random() * (double)120.0F);
         if (data.isMoving) {
            data.moveYaw = (double)(currentLoc.getYaw() + (float)((Math.random() - (double)0.5F) * (double)180.0F));
         }
      }

      --data.ticksUntilMove;
      if (data.isMoving && data.onGround) {
         double speed = data.isSprinting ? 0.13 : 0.1;
         double yawRad = Math.toRadians(-data.moveYaw);
         double dx = -Math.sin(yawRad) * speed;
         double dz = Math.cos(yawRad) * speed;
         Location newLoc = currentLoc.clone().add(dx, (double)0.0F, dz);
         if (!this.checkCollision(newLoc)) {
            fakePlayer.teleport(newLoc);
            data.lastX = newLoc.getX();
            data.lastY = newLoc.getY();
            data.lastZ = newLoc.getZ();
         } else {
            data.isMoving = false;
            data.ticksUntilMove = 20;
         }
      }

      float yawDiff = this.normalizeAngle((float)(data.targetYaw - (double)currentLoc.getYaw()));
      float pitchDiff = (float)data.targetPitch - currentLoc.getPitch();
      fakePlayer.getLocation().setYaw(currentLoc.getYaw() + yawDiff * 0.1F);
      fakePlayer.getLocation().setPitch(currentLoc.getPitch() + pitchDiff * 0.1F);
   }

   private void handleKnockback(Player fakePlayer, FakePlayerMovementData data) {
      Location loc = fakePlayer.getLocation();
      double newX = loc.getX() + data.velocityX;
      double newY = loc.getY() + data.velocityY;
      double newZ = loc.getZ() + data.velocityZ;
      data.velocityX *= 0.6;
      data.velocityZ *= 0.6;
      data.velocityY -= 0.08;
      if (data.velocityY < (double)-0.5F) {
         data.velocityY = (double)-0.5F;
      }

      Location checkLoc = new Location(loc.getWorld(), newX, newY - 0.1, newZ);
      if (checkLoc.getBlock().getType().isSolid()) {
         newY = Math.floor(newY) + (double)1.0F;
         data.velocityY = (double)0.0F;
         data.onGround = true;
      } else {
         data.onGround = false;
      }

      Location newLoc = new Location(loc.getWorld(), newX, newY, newZ, loc.getYaw(), loc.getPitch());
      if (this.checkCollision(newLoc)) {
         data.velocityX = (double)0.0F;
         data.velocityZ = (double)0.0F;
         newX = loc.getX();
         newZ = loc.getZ();
         newLoc.setX(newX);
         newLoc.setZ(newZ);
      }

      fakePlayer.teleport(newLoc);
      data.lastX = newX;
      data.lastY = newY;
      data.lastZ = newZ;
   }

   private void updateHeadRotation(Player fakePlayer, FakePlayerMovementData data) {
      if (data.ticksUntilLook <= 0) {
         Location fakeLoc = fakePlayer.getLocation();
         Player nearest = null;
         double nearestDist = (double)8.0F;

         for(Player real : Bukkit.getOnlinePlayers()) {
            SimpleFakePlayerManager fakeManager = this.plugin.getSimpleFakePlayerManager();
            if ((fakeManager == null || !fakeManager.isFakePlayer(real)) && real.getWorld().equals(fakeLoc.getWorld())) {
               double dist = fakeLoc.distance(real.getLocation());
               if (dist < nearestDist) {
                  nearest = real;
                  nearestDist = dist;
               }
            }
         }

         if (nearest != null) {
            Location targetLoc = nearest.getLocation().add((double)0.0F, 1.62, (double)0.0F);
            this.lookAt(fakePlayer, targetLoc);
         }
      }

   }

   private void lookAt(Player player, Location target) {
      Location loc = player.getLocation();
      double dx = target.getX() - loc.getX();
      double dy = target.getY() - loc.getY();
      double dz = target.getZ() - loc.getZ();
      double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horizontalDistance)));
      loc.setYaw(yaw);
      loc.setPitch(pitch);
      player.teleport(loc);
   }

   private void handleIdleAnimations(Player fakePlayer, FakePlayerMovementData data) {
      if (data.isMoving && Math.random() < 0.05) {
         NMSHandler nms = this.plugin.getSimpleFakePlayerManager().getNMSHandler();
         if (nms != null) {
            nms.performAction(fakePlayer, NMSHandler.FakePlayerAction.SWING_MAIN_ARM);
         }
      }

      if (data.isMoving && data.onGround && Math.random() < 0.01) {
         data.velocityY = 0.42;
         data.onGround = false;
      }

   }

   private void syncPosition(Player fakePlayer, FakePlayerMovementData data) {
   }

   public void applyKnockback(Player fakePlayer, Player attacker, double strength) {
      UUID uuid = fakePlayer.getUniqueId();
      FakePlayerMovementData data = (FakePlayerMovementData)this.movementDataMap.get(uuid);
      if (data != null) {
         Vector direction = fakePlayer.getLocation().toVector().subtract(attacker.getLocation().toVector()).setY(0).normalize();
         data.velocityX = direction.getX() * strength;
         data.velocityY = (double)0.5F;
         data.velocityZ = direction.getZ() * strength;
         data.knockbackTicks = 15;
         NMSHandler nms = this.plugin.getSimpleFakePlayerManager().getNMSHandler();
         if (nms != null) {
            nms.performAction(fakePlayer, NMSHandler.FakePlayerAction.DAMAGE_ANIMATION);
         }

         fakePlayer.getWorld().playSound(fakePlayer.getLocation(), Sound.ENTITY_PLAYER_HURT, 1.0F, 1.0F);

         for(Player viewer : Bukkit.getOnlinePlayers()) {
            if (!viewer.equals(fakePlayer)) {
               nms.sendEntityVelocity(viewer, fakePlayer, data.velocityX, data.velocityY, data.velocityZ);
            }
         }
      }

   }

   private boolean check(Location loc, double offsetX, double offsetY, double offsetZ) {
      if (loc.getWorld() == null) {
         return true;
      } else {
         int x = (int)Math.floor(loc.getX() + offsetX);
         int y = (int)Math.floor(loc.getY() + offsetY);
         int z = (int)Math.floor(loc.getZ() + offsetZ);
         return loc.getWorld().getBlockAt(x, y, z).getType().isSolid();
      }
   }

   private boolean checkCollision(Location loc) {
      return this.check(loc, (double)0.0F, (double)0.0F, (double)0.0F) || this.check(loc, (double)0.0F, (double)1.0F, (double)0.0F) || this.check(loc, (double)0.0F, 1.8, (double)0.0F) || this.check(loc, 0.3, (double)0.0F, (double)0.0F) || this.check(loc, -0.3, (double)0.0F, (double)0.0F) || this.check(loc, 0.3, (double)1.0F, (double)0.0F) || this.check(loc, -0.3, (double)1.0F, (double)0.0F) || this.check(loc, (double)0.0F, (double)0.0F, 0.3) || this.check(loc, (double)0.0F, (double)0.0F, -0.3) || this.check(loc, (double)0.0F, (double)1.0F, 0.3) || this.check(loc, (double)0.0F, (double)1.0F, -0.3) || this.check(loc, 0.3, (double)0.0F, 0.3) || this.check(loc, -0.3, (double)0.0F, -0.3) || this.check(loc, 0.3, (double)0.0F, -0.3) || this.check(loc, -0.3, (double)0.0F, 0.3);
   }

   private float normalizeAngle(float angle) {
      while(angle <= -180.0F) {
         angle += 360.0F;
      }

      while(angle > 180.0F) {
         angle -= 360.0F;
      }

      return angle;
   }

   public void setupTABIntegration(Player fakePlayer, FakePlayer fakePlayerData) {
      TABHook tabHook = this.plugin.getTabHook();
      LuckPermsHook lpHook = this.plugin.getLuckPermsHook();
      if (tabHook != null && tabHook.isEnabled()) {
         tabHook.injectFakePlayerTAB(fakePlayer, fakePlayerData.getUuid(), fakePlayerData.getName());
         if (lpHook != null && lpHook.isEnabled()) {
            String prefix = lpHook.getPrefix(fakePlayerData);
            String suffix = lpHook.getSuffix(fakePlayerData);
            if (prefix != null && !prefix.isEmpty()) {
               fakePlayerData.setPrefix(prefix);
            }

            if (suffix != null && !suffix.isEmpty()) {
               fakePlayerData.setSuffix(suffix);
            }

            List<String> groups = lpHook.getGroups(fakePlayerData);
            if (!groups.isEmpty()) {
               fakePlayerData.setRank((String)groups.get(0));
            }
         }
      }

   }

   public void removeFakePlayer(UUID uuid) {
      this.movementDataMap.remove(uuid);
   }

   public FakePlayerMovementData getMovementData(UUID uuid) {
      return (FakePlayerMovementData)this.movementDataMap.get(uuid);
   }

   public boolean isKnockedBack(UUID uuid) {
      FakePlayerMovementData data = (FakePlayerMovementData)this.movementDataMap.get(uuid);
      return data != null && data.knockbackTicks > 0;
   }

   public static class FakePlayerMovementData {
      public double lastX;
      public double lastY;
      public double lastZ;
      public float lastYaw;
      public float lastPitch;
      public boolean isMoving;
      public boolean isSprinting;
      public boolean onGround = true;
      public double moveYaw;
      public double targetYaw;
      public double targetPitch;
      public double velocityX;
      public double velocityY;
      public double velocityZ;
      public int knockbackTicks;
      public int ticksSinceSpawn = 0;
      public int ticksUntilLook = 20;
      public int ticksUntilMove = 40;
   }
}
