package com.glidespoofer.core;

import com.glidespoofer.ai.AIConfigProvider;
import com.glidespoofer.ai.AILicenseVerify;
import com.glidespoofer.ai.AIManager;
import com.glidespoofer.ai.MovementAIService;
import com.glidespoofer.commands.FakeVotesCommand;
import com.glidespoofer.commands.GlideCommand;
import com.glidespoofer.config.ConfigManager;
import com.glidespoofer.database.DatabaseManager;
import com.glidespoofer.fake.FakeChatManager;
import com.glidespoofer.fake.FakePlayerFluctuationManager;
import com.glidespoofer.fake.FakePlayerManager;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import com.glidespoofer.hooks.AuthMeHook;
import com.glidespoofer.hooks.EssentialsHook;
import com.glidespoofer.hooks.InteractiveChatHook;
import com.glidespoofer.hooks.LPCHook;
import com.glidespoofer.hooks.LifeStealZHook;
import com.glidespoofer.hooks.LifestealCoreHook;
import com.glidespoofer.hooks.LuckPermsHook;
import com.glidespoofer.hooks.PlaceholderHook;
import com.glidespoofer.hooks.PlaceholderInterceptor;
import com.glidespoofer.hooks.RustHook;
import com.glidespoofer.hooks.SuperiorSkyblockHook;
import com.glidespoofer.hooks.TABHook;
import com.glidespoofer.hooks.ViaVersionHook;
import com.glidespoofer.hooks.WorldGuardHook;
import com.glidespoofer.hooks.ZelChatHook;
import com.glidespoofer.licence.LicenceCommand;
import com.glidespoofer.licence.UltimateLicenseVerify;
import com.glidespoofer.listener.FakePlayerCommandListener;
import com.glidespoofer.listener.FakePlayerDamageListener;
import com.glidespoofer.listener.FakePlayerGUIListener;
import com.glidespoofer.listener.FakePlayerPickupListener;
import com.glidespoofer.listener.PlayerListener;
import com.glidespoofer.listener.PluginDisguiseListener;
import com.glidespoofer.listener.ServerListListener;
import com.glidespoofer.listener.TabCompleteListener;
import com.glidespoofer.listener.TeleportListener;
import com.glidespoofer.messaging.ProxyMessenger;
import com.glidespoofer.metrics.Metrics;
import com.glidespoofer.nms.UltraSpoofStyleSpawner;
import com.glidespoofer.pathfinding.FakePlayerPathfinding;
import com.glidespoofer.pathfinding.FollowModeManager;
import com.glidespoofer.serverside.ServerSideFakePlayer;
import com.glidespoofer.serverside.ServerSideFakePlayerListener;
import com.glidespoofer.serverside.ServerSideFakePlayerManager;
import com.glidespoofer.serverside.UltraSpoofIntegration;
import com.glidespoofer.takeover.PlayerTakeoverData;
import com.glidespoofer.tasks.FakePlayerCommandExecutor;
import com.glidespoofer.tasks.RealPlayerProximityChecker;
import com.glidespoofer.vote.FakeVoteManager;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitScheduler;

public class GlideSpoofer extends JavaPlugin {
   private static GlideSpoofer instance;
   private static boolean isFolia = false;
   private ConfigManager configManager;
   private SimpleFakePlayerManager simpleFakePlayerManager;
   private FakePlayerDamageListener damageListener;
   private FakeVoteManager fakeVoteManager;
   private FakeChatManager fakeChatManager;
   private LuckPermsHook luckPermsHook;
   private WorldGuardHook worldGuardHook;
   private TABHook tabHook;
   private LifestealCoreHook lifestealCoreHook;
   private LifeStealZHook lifeStealZHook;
   private SuperiorSkyblockHook superiorSkyblockHook;
   private InteractiveChatHook interactiveChatHook;
   private LPCHook lpcHook;
   private ViaVersionHook viaVersionHook;
   private RustHook rustHook;
   private EssentialsHook essentialsHook;
   private AuthMeHook authMeHook;
   private ZelChatHook zelChatHook;
   private ProxyMessenger proxyMessenger;
   private FakePlayerPathfinding pathfinding;
   private FollowModeManager followModeManager;
   private FakePlayerGUIListener guiListener;
   private String minecraftVersion;
   private FakePlayerFluctuationManager fluctuationManager;
   private FakePlayerCommandExecutor commandExecutor;
   private RealPlayerProximityChecker proximityChecker;
   private DatabaseManager databaseManager;
   private PlayerTakeoverData takeoverData;
   private AIManager aiManager;
   private MovementAIService movementAI;
   private PluginDisguiseListener pluginDisguiseListener;
   private Metrics metrics;
   private int heartbeatTaskId = -1;
   private boolean spawnInternalCalled = false;
   private ServerSideFakePlayerManager serverSideFakePlayerManager;
   private UltraSpoofStyleSpawner ultraSpoofStyleSpawner;

   private static boolean detectFolia() {
      try {
         Class.forName("io.papermc.paper.threadedregions.RegionizedServer");
         return true;
      } catch (ClassNotFoundException var7) {
         try {
            Class.forName("io.papermc.paper.threadedregions.scheduler.GlobalRegionScheduler");
            String serverName = Bukkit.getServer().getName().toLowerCase();
            String serverVersion = Bukkit.getServer().getVersion().toLowerCase();
            if (!serverName.contains("folia") && !serverVersion.contains("folia")) {
               if (!serverName.contains("leaves") && !serverName.contains("paper")) {
                  try {
                     Class.forName("io.papermc.paper.threadedregions.RegionizedTask");
                     return true;
                  } catch (ClassNotFoundException var4) {
                     return false;
                  }
               } else {
                  return false;
               }
            } else {
               return true;
            }
         } catch (ClassNotFoundException var6) {
            try {
               Bukkit.class.getMethod("getGlobalRegionScheduler");
               String serverNamex = Bukkit.getServer().getName().toLowerCase();
               if (serverNamex.contains("folia")) {
                  return true;
               }

               if (serverNamex.contains("leaves") || serverNamex.contains("paper")) {
                  return false;
               }
            } catch (NoSuchMethodException var5) {
            }

            return false;
         }
      }
   }

   public void onEnable() {
      instance = this;
      this.printBanner();

      try {
         Method method = Bukkit.class.getMethod("getMinecraftVersion");
         this.minecraftVersion = (String)method.invoke((Object)null);
      } catch (Exception var11) {
         String serverVersion = Bukkit.getServer().getVersion();
         if (serverVersion.contains("(MC: ")) {
            int start = serverVersion.indexOf("(MC: ") + 5;
            int end = serverVersion.indexOf(")", start);
            this.minecraftVersion = serverVersion.substring(start, end);
         } else {
            this.minecraftVersion = "1.8.8";
         }
      }

      this.getLogger().info("Detected: " + this.minecraftVersion);
      this.saveDefaultConfig();
      String licenseKey = this.getConfig().getString("licence.license-key", "");
      UltimateLicenseVerify.init(this);
      if (!licenseKey.isEmpty() && !licenseKey.equals("YOUR_LICENSE_KEY_HERE")) {
         this.getLogger().info("Verifying GlideSpoofer license...");
         if (!UltimateLicenseVerify.verifyKey(licenseKey)) {
            Bukkit.getPluginManager().disablePlugin(this);
         } else {
            this.startHeartbeatScheduler(licenseKey);
            int pluginId = 29167;
            this.metrics = new Metrics(this, pluginId);
            this.metrics.addCustomChart(new Metrics.SimplePie("minecraft_version", () -> this.minecraftVersion));
            this.metrics.addCustomChart(new Metrics.SimplePie("licence_status", () -> UltimateLicenseVerify.isValid() ? "valid" : "unknown"));
            this.metrics.addCustomChart(new Metrics.SingleLineChart("fake_players_count", () -> this.simpleFakePlayerManager != null ? this.simpleFakePlayerManager.getAllFakePlayers().size() : 0));
            this.metrics.addCustomChart(new Metrics.SimplePie("database_type", () -> this.configManager != null && this.configManager.isDatabaseEnabled() ? this.getConfig().getString("database.type", "SQLITE") : "none"));
            this.configManager = new ConfigManager(this);
            this.configManager.loadAll();
            if (this.configManager.getConfig().getBoolean("hooks.luckperms.enabled", true)) {
               try {
                  this.luckPermsHook = new LuckPermsHook(this);
               } catch (NoClassDefFoundError | Exception var10) {
                  this.getLogger().info("LuckPerms not available - LuckPerms hook disabled");
                  this.luckPermsHook = null;
               }
            }

            if (this.configManager.getConfig().getBoolean("hooks.worldguard.enabled", true)) {
               this.worldGuardHook = new WorldGuardHook(this);
            }

            if (this.configManager.getConfig().getBoolean("hooks.tab.enabled", true)) {
               this.tabHook = new TABHook(this);
            }

            this.interactiveChatHook = new InteractiveChatHook(this);
            this.lpcHook = new LPCHook(this);
            this.viaVersionHook = new ViaVersionHook(this);
            this.rustHook = new RustHook(this);
            if (this.rustHook.isEnabled()) {
               this.getLogger().info("Rust hook enabled!");
            }

            this.superiorSkyblockHook = new SuperiorSkyblockHook(this);
            this.essentialsHook = new EssentialsHook(this);
            this.authMeHook = new AuthMeHook(this);
            this.zelChatHook = new ZelChatHook(this);
            this.lifestealCoreHook = new LifestealCoreHook(this);
            this.lifeStealZHook = new LifeStealZHook(this);
            if (this.configManager.getConfig().getBoolean("fake-players.enabled", true)) {
               this.simpleFakePlayerManager = new SimpleFakePlayerManager(this);
               this.pathfinding = new FakePlayerPathfinding(this);
               this.followModeManager = new FollowModeManager(this);
               boolean fluctuationEnabled = this.configManager.getFakesConfig().getBoolean("fluctuation.enabled", true);
               if (fluctuationEnabled) {
                  this.fluctuationManager = new FakePlayerFluctuationManager(this, this.simpleFakePlayerManager);
               }

               try {
                  this.getLogger().info("Checking UltraSpoofStyleSpawner availability...");
                  if (UltraSpoofStyleSpawner.isAvailable()) {
                     this.ultraSpoofStyleSpawner = new UltraSpoofStyleSpawner(this, Collections.emptyList());
                     this.getLogger().info("UltraSpoof-style spawner initialized - fake players will appear in TAB!");
                  } else {
                     this.getLogger().warning("UltraSpoofStyleSpawner not available - NMS classes not loaded");
                  }
               } catch (Exception e) {
                  this.getLogger().warning("Could not initialize UltraSpoof-style spawner: " + e.getMessage());
                  e.printStackTrace();
               }
            }

            if (this.configManager.getConfig().getBoolean("fake-players.server-side.enabled", false)) {
               try {
                  this.serverSideFakePlayerManager = new ServerSideFakePlayerManager(this);
                  ServerSideFakePlayerListener listener = new ServerSideFakePlayerListener(this, this.serverSideFakePlayerManager);
                  this.getServer().getPluginManager().registerEvents(listener, this);
                  this.getLogger().info("Server-Side Fake Players enabled - fakes will appear as REAL players!");
               } catch (Exception e) {
                  this.getLogger().warning("Failed to initialize Server-Side Fake Players: " + e.getMessage());
               }
            }

            if (this.configManager.getConfig().getBoolean("fake-votes.enabled", false)) {
               this.fakeVoteManager = new FakeVoteManager(this);
            }

            if (this.configManager.getConfig().getBoolean("chat.enabled", true)) {
               this.fakeChatManager = new FakeChatManager(this);
               this.fakeChatManager.setInteractiveChatHook(this.interactiveChatHook);
               this.fakeChatManager.setLPCHook(this.lpcHook);
               this.fakeChatManager.setZelChatHook(this.zelChatHook);
            }

            if (this.configManager.isRandomCommandsEnabled()) {
               this.commandExecutor = new FakePlayerCommandExecutor(this);
            }

            if (this.configManager.isProximityCheckEnabled()) {
               this.proximityChecker = new RealPlayerProximityChecker(this);
            }

            if (this.configManager.isDatabaseEnabled()) {
               this.databaseManager = new DatabaseManager(this);
               boolean connected = this.databaseManager.initialize();
               if (connected) {
                  this.getLogger().info(this.configManager.getMessage("database-connected"));
               } else {
                  this.getLogger().warning(this.configManager.getMessage("database-error").replace("%error%", "Connection failed"));
               }
            }

            if (this.configManager.isAIEnabled()) {
               AILicenseVerify.init(this);
               String mainLicenseKey = this.getConfig().getString("licence.license-key", "");
               boolean unlockedViaLicense = false;
               if (mainLicenseKey != null && !mainLicenseKey.isEmpty()) {
                  unlockedViaLicense = AILicenseVerify.verifyAILicense(mainLicenseKey);
               }

               AIConfigProvider aiConfigProvider = this.createAIConfigProvider();
               if (!unlockedViaLicense) {
                  String glideApiKey = aiConfigProvider.getGlideAIKey();
                  if (glideApiKey != null && !glideApiKey.isEmpty() && !glideApiKey.equals("your-glideai-api-key-here") && !glideApiKey.equals("YOUR_GLIDEAI_API_KEY_HERE")) {
                     AILicenseVerify.unlockWithApiKey(glideApiKey);
                  }
               }

               this.aiManager = new AIManager(this, new AIManager.FakePlayerAccessor() {
                  public List<String> getAllFakePlayerNames() {
                     if (GlideSpoofer.this.simpleFakePlayerManager == null) {
                        return Collections.emptyList();
                     } else {
                        List<String> names = new ArrayList();

                        for(SimpleFakePlayerManager.FakePlayerData data : GlideSpoofer.this.simpleFakePlayerManager.getAllFakePlayers()) {
                           names.add(data.getName());
                        }

                        return names;
                     }
                  }

                  public boolean hasFakePlayer(String name) {
                     return GlideSpoofer.this.simpleFakePlayerManager != null && GlideSpoofer.this.simpleFakePlayerManager.hasFakePlayer(name);
                  }

                  public boolean isFakePlayer(Object player) {
                     if (GlideSpoofer.this.simpleFakePlayerManager != null && player != null) {
                        return player instanceof Player ? GlideSpoofer.this.simpleFakePlayerManager.isFakePlayer((Player)player) : false;
                     } else {
                        return false;
                     }
                  }
               }, aiConfigProvider, this.fakeChatManager);
               if (this.aiManager.isEnabled()) {
                  this.getLogger().info("AI Chat enabled!");
               }

               this.movementAI = new MovementAIService(this.getLogger(), "glm-4-flash", 150, 0.7, 2, 2000L);
               this.getLogger().info("[MovementAI] Enabled with 16 rotating API keys");
            }

            this.takeoverData = new PlayerTakeoverData(this.getDataFolder(), this.getLogger());
            this.getServer().getPluginManager().registerEvents(new PlayerListener(this, this.takeoverData), this);
            this.getServer().getPluginManager().registerEvents(new FakePlayerCommandListener(this), this);
            if (this.configManager.getConfig().getBoolean("server-list.enabled", true)) {
               this.getServer().getPluginManager().registerEvents(new ServerListListener(this), this);
            }

            if (this.configManager.getConfig().getBoolean("plugin-disguise.enabled", true)) {
               this.pluginDisguiseListener = new PluginDisguiseListener(this);
               this.getServer().getPluginManager().registerEvents(this.pluginDisguiseListener, this);
               if (isFolia()) {
                  Bukkit.getGlobalRegionScheduler().runDelayed(this, (task) -> this.pluginDisguiseListener.applyDisguise(), 1L);
                  Bukkit.getGlobalRegionScheduler().runDelayed(this, (task) -> this.pluginDisguiseListener.applyDisguise(), 20L);
                  Bukkit.getGlobalRegionScheduler().runDelayed(this, (task) -> this.pluginDisguiseListener.applyDisguise(), 100L);
               } else {
                  BukkitScheduler var10000 = this.getServer().getScheduler();
                  PluginDisguiseListener var10002 = this.pluginDisguiseListener;
                  Objects.requireNonNull(var10002);
                  var10000.runTaskLater(this, var10002::applyDisguise, 1L);
                  var10000 = this.getServer().getScheduler();
                  var10002 = this.pluginDisguiseListener;
                  Objects.requireNonNull(var10002);
                  var10000.runTaskLater(this, var10002::applyDisguise, 20L);
                  var10000 = this.getServer().getScheduler();
                  var10002 = this.pluginDisguiseListener;
                  Objects.requireNonNull(var10002);
                  var10000.runTaskLater(this, var10002::applyDisguise, 100L);
               }
            }

            if (this.configManager.getConfig().getBoolean("tab-completion.inject-fakes", true)) {
               this.getServer().getPluginManager().registerEvents(new TabCompleteListener(this), this);
            }

            if (this.configManager.getConfig().getBoolean("gui.enabled", true)) {
               this.guiListener = new FakePlayerGUIListener(this, this.pathfinding, this.followModeManager);
               this.getServer().getPluginManager().registerEvents(this.guiListener, this);
               this.getServer().getPluginManager().registerEvents(this.guiListener.getGUI(), this);
            }

            FakePlayerPickupListener pickupListener = new FakePlayerPickupListener(this);
            this.getServer().getPluginManager().registerEvents(pickupListener, this);
            pickupListener.startPickupScanning();
            this.damageListener = new FakePlayerDamageListener(this);
            this.getServer().getPluginManager().registerEvents(this.damageListener, this);
            this.getServer().getPluginManager().registerEvents(new TeleportListener(this), this);
            if (this.configManager.getConfig().getBoolean("commands.enabled", true)) {
               this.registerCommands();
            }

            if (this.configManager.getConfig().getBoolean("hooks.placeholderapi.enabled", true) && Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
               (new PlaceholderHook(this)).register();
               if (this.configManager.getConfig().getBoolean("hooks.placeholderapi.intercept-online", true)) {
                  (new PlaceholderInterceptor(this)).register();
               }

               this.getLogger().info("PlaceholderAPI hook enabled!");
            }

            this.spawnFakePlayersInternal();
            int spawnDelay = this.configManager.getConfig().getInt("fake-players.spawn-delay", 60);
            boolean fakePlayersEnabled = this.configManager.getConfig().getBoolean("fake-players.enabled", true);

            try {
               if (isFolia()) {
                  Bukkit.getGlobalRegionScheduler().runDelayed(this, (task) -> this.spawnFakePlayersInternal(), (long)spawnDelay);
               } else {
                  Bukkit.getScheduler().runTaskLater(this, () -> this.spawnFakePlayersInternal(), (long)spawnDelay);
               }
            } catch (Exception var7) {
               this.getLogger().warning("Failed to schedule delayed spawn task: " + var7.getMessage());
               this.spawnFakePlayersInternal();
            }

            Runnable backupTask = () -> {
               if (this.simpleFakePlayerManager != null && this.simpleFakePlayerManager.getAllFakePlayers().isEmpty()) {
                  this.getLogger().warning("No fake players spawned after delay, attempting immediate spawn");
                  this.spawnFakePlayersInternal();
               }

            };
            if (isFolia()) {
               Bukkit.getGlobalRegionScheduler().runDelayed(this, (task) -> backupTask.run(), 100L);
            } else {
               Bukkit.getScheduler().runTaskLater(this, backupTask, 100L);
            }
         }
      } else {
         this.getLogger().severe("═══════════════════════════════════════════════════════");
         this.getLogger().severe("                 LICENCE CONFIGURATION MISSING");
         this.getLogger().severe("═══════════════════════════════════════════════════════");
         this.getLogger().severe("  Please configure your GlideSpoofer license in config.yml:");
         this.getLogger().severe("");
         this.getLogger().severe("  licence:");
         this.getLogger().severe("    license-key: \"YOUR_LICENSE_KEY_HERE\"");
         this.getLogger().severe("");
         this.getLogger().severe("  Get your license from the GlideSpoofer dashboard");
         this.getLogger().severe("═══════════════════════════════════════════════════════");
         Bukkit.getPluginManager().disablePlugin(this);
      }

   }

   private void spawnFakePlayersInternal() {
      if (!this.spawnInternalCalled) {
         this.spawnInternalCalled = true;
         if (this.configManager.getConfig().getBoolean("fake-players.enabled", true)) {
            if (this.fluctuationManager != null && this.fluctuationManager.isEnabled()) {
               this.getLogger().info("Fluctuation enabled - using gradual spawn from fakes.yml");
               this.fluctuationManager.startGradualSpawning();
               this.fluctuationManager.start();
            } else {
               this.getLogger().info("Fluctuation disabled or null - using loadFakePlayers");
               this.loadFakePlayers();
            }
         }

         if (this.fakeVoteManager != null) {
            this.fakeVoteManager.start();
         }

         if (this.fakeChatManager != null) {
            this.fakeChatManager.start();
         }

         if (this.commandExecutor != null) {
            this.commandExecutor.start();
         }

         if (this.proximityChecker != null) {
            this.proximityChecker.start();
         }

         if (this.configManager.getConfig().getBoolean("proxy.enabled", false) || this.configManager.getConfig().getBoolean("proxy-sync.enabled", true)) {
            this.proxyMessenger = new ProxyMessenger(this);
            this.proxyMessenger.register();
            this.getLogger().info("Proxy sync messaging enabled - fake players will be synced to Velocity/BungeeCord");
         }

         this.getLogger().info("GlideSpoofer v" + this.getDescription().getVersion() + " enabled!");
         this.getLogger().info("Mode: Pure NMS (Real Fake Players)");
      }

   }

   public void onDisable() {
      UltimateLicenseVerify.shutdown();
      if (this.heartbeatTaskId != -1) {
         Bukkit.getScheduler().cancelTask(this.heartbeatTaskId);
      }

      if (this.pathfinding != null) {
         this.pathfinding.stopAll();
      }

      if (this.simpleFakePlayerManager != null) {
         this.simpleFakePlayerManager.shutdown();
      }

      if (this.serverSideFakePlayerManager != null) {
         this.serverSideFakePlayerManager.removeAll();
      }

      if (this.fluctuationManager != null) {
         this.fluctuationManager.stop();
      }

      if (this.fakeVoteManager != null) {
         this.fakeVoteManager.stop();
      }

      if (this.fakeChatManager != null) {
         this.fakeChatManager.stop();
      }

      if (this.commandExecutor != null) {
         this.commandExecutor.stop();
      }

      if (this.proximityChecker != null) {
         this.proximityChecker.stop();
      }

      if (this.databaseManager != null) {
         this.databaseManager.shutdown();
      }

      if (this.aiManager != null) {
         this.aiManager.shutdown();
      }

      if (this.pluginDisguiseListener != null) {
         this.pluginDisguiseListener.removeDisguise();
      }

      if (this.rustHook != null) {
         this.rustHook.shutdown();
      }

      if (this.tabHook != null) {
         this.tabHook.shutdown();
      }

      if (this.proxyMessenger != null) {
         this.proxyMessenger.unregister();
      }

      this.getLogger().info("GlideSpoofer disabled!");
   }

   private AIConfigProvider createAIConfigProvider() {
      return new AIConfigProvider() {
         private ConfigManager.AIConfig cfg() {
            return GlideSpoofer.this.configManager.getAIConfig();
         }

         public boolean isEnabled() {
            return this.cfg().getBoolean("enabled", false);
         }

         public Logger getLogger() {
            return this.getLogger();
         }

         public String getOpenAIKey() {
            return this.cfg().getString("openai.api-key", "");
         }

         public String getOpenAIModel() {
            return this.cfg().getString("openai.model", "gpt-3.5-turbo");
         }

         public String getGeminiKey() {
            return this.cfg().getString("gemini.api-key", "");
         }

         public String getGeminiModel() {
            return this.cfg().getString("gemini.model", "gemini-pro");
         }

         public String getGlideAIKey() {
            return this.cfg().getString("glideai.api-key", "");
         }

         public String getGlideAIModel() {
            return this.cfg().getString("glideai.model", "GLM-4-Flash");
         }

         public int getGlideAIMaxTokens() {
            return this.cfg().getInt("glideai.max-tokens", 100);
         }

         public double getGlideAITemperature() {
            return this.cfg().getDouble("glideai.temperature", 0.85);
         }

         public int getGlideAIConnectTimeout() {
            return this.cfg().getInt("glideai.connect-timeout", 5);
         }

         public int getGlideAIWriteTimeout() {
            return this.cfg().getInt("glideai.write-timeout", 10);
         }

         public int getGlideAIReadTimeout() {
            return this.cfg().getInt("glideai.read-timeout", 15);
         }

         public int getGlideAIMaxConcurrentRequests() {
            return this.cfg().getInt("glideai.max-concurrent-requests", 3);
         }

         public int getGlideAIMinRequestInterval() {
            return this.cfg().getInt("glideai.min-request-interval", 2000);
         }

         public String getSystemPrompt() {
            return this.cfg().getString("system-prompt", "You are {player}, a casual Minecraft player.");
         }

         public String getSystemPrompt(String playerName) {
            return this.getSystemPrompt().replace("{player}", playerName != null ? playerName : "Player");
         }

         public String getContextBoost() {
            boolean enabled = this.cfg().getBoolean("deep-thinking.enabled", true);
            return !enabled ? "" : this.cfg().getString("deep-thinking.context-boost", "");
         }

         public String getLanguage() {
            return this.cfg().getString("language", "en");
         }

         public int getMaxTokens() {
            return this.cfg().getInt("openai.max-tokens", 30);
         }

         public double getTemperature() {
            return this.cfg().getDouble("openai.temperature", 0.8);
         }

         public int getMemorySize() {
            return this.cfg().getInt("conversation-memory", 10);
         }

         public String getTriggerMode() {
            return this.cfg().getString("trigger-mode", "mention");
         }

         public List<String> getTriggerKeywords() {
            return this.cfg().getStringList("trigger-keywords");
         }

         public double getResponseChance() {
            return this.cfg().getDouble("response-chance", (double)0.5F);
         }

         public int getMinResponseDelay() {
            return this.cfg().getInt("min-response-delay", 20);
         }

         public int getMaxResponseDelay() {
            return this.cfg().getInt("max-response-delay", 60);
         }

         public long getChatCooldown() {
            return (long)this.cfg().getInt("chat-cooldown", 3000);
         }

         public boolean isAutoChatEnabled() {
            return this.cfg().getBoolean("auto-chat.enabled", false);
         }

         public int getAutoChatInterval() {
            return this.cfg().getInt("auto-chat.interval", 600);
         }

         public double getAutoChatChance() {
            return this.cfg().getDouble("auto-chat.chance", 0.1);
         }

         public List<String> getAutoChatTopics() {
            String lang = this.cfg().getString("language", "en");
            List<String> languageTopics = this.cfg().getStringList("auto-chat.languages." + lang);
            return languageTopics != null && !languageTopics.isEmpty() ? languageTopics : this.cfg().getStringList("auto-chat.topics");
         }

         public boolean isAiToAiChatEnabled() {
            return this.cfg().getBoolean("ai-to-ai-chat.enabled", false);
         }

         public int getAiToAiChatInterval() {
            return this.cfg().getInt("ai-to-ai-chat.interval", 900);
         }

         public List<String> getAiToAiTopics() {
            return this.cfg().getStringList("ai-to-ai-chat.topics");
         }

         public String getChatFormat() {
            return this.cfg().getString("chat-format", "&7{player}: &f{message}");
         }

         public List<String> getFakePlayerNames() {
            List<String> names = new ArrayList();
            if (GlideSpoofer.this.simpleFakePlayerManager != null) {
               for(SimpleFakePlayerManager.FakePlayerData data : GlideSpoofer.this.simpleFakePlayerManager.getAllFakePlayers()) {
                  names.add(data.getName());
               }
            }

            return names;
         }

         public boolean isFakePlayer(String playerName) {
            return GlideSpoofer.this.simpleFakePlayerManager != null && GlideSpoofer.this.simpleFakePlayerManager.hasFakePlayer(playerName);
         }

         public void broadcastChat(String playerName, String message) {
            Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', this.cfg().getString("chat-format", "&7{player}: &f{message}").replace("{player}", playerName).replace("{message}", message)));
         }

         public void scheduleSyncTask(Runnable task) {
            GlideSpoofer.this.getServer().getScheduler().runTask(GlideSpoofer.this, task);
         }

         public void scheduleSyncTask(Runnable task, long delay) {
            GlideSpoofer.this.getServer().getScheduler().runTaskLater(GlideSpoofer.this, task, delay);
         }

         public List<String> getFallbackMentionResponses() {
            return this.cfg().getStringList("fallback-responses.mention");
         }

         public List<String> getFallbackQuestionResponses() {
            return this.cfg().getStringList("fallback-responses.question");
         }

         public List<String> getFallbackGreetingResponses() {
            return this.cfg().getStringList("fallback-responses.greeting");
         }

         public List<String> getFallbackGeneralResponses() {
            return this.cfg().getStringList("fallback-responses.general");
         }

         public List<String> getFallbackAiToAiResponses() {
            return this.cfg().getStringList("fallback-responses.ai-to-ai");
         }

         public List<String> getFallbackAutoChatMessages() {
            return this.cfg().getStringList("fallback-responses.auto-chat");
         }
      };
   }

   private void printBanner() {
      this.getLogger().info("═══════════════════════════════════════════════════════════════");
      this.getLogger().info("   GlideSpoofer v4.1.0 - REAL Fake Players with REAL AI");
      this.getLogger().info("   Supports: Minecraft 1.8 - 1.21.10+");
      this.getLogger().info("═══════════════════════════════════════════════════════════════");
   }

   private void startHeartbeatScheduler(String licenseKey) {
      if (isFolia) {
         Bukkit.getGlobalRegionScheduler().runDelayed(this, (task) -> {
            try {
               UltimateLicenseVerify.sendHeartbeat(licenseKey, Bukkit.getOnlinePlayers().size());
               this.getLogger().fine("GlideSpoofer license heartbeat sent successfully");
            } catch (Exception var4) {
               this.getLogger().log(Level.WARNING, "Failed to send license heartbeat", var4);
            }

            if (!task.isCancelled()) {
               Bukkit.getGlobalRegionScheduler().runDelayed(this, (t) -> this.startHeartbeatScheduler(licenseKey), 9000L);
            }

         }, 1L);
      } else {
         this.heartbeatTaskId = Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> {
            try {
               UltimateLicenseVerify.sendHeartbeat(licenseKey, Bukkit.getOnlinePlayers().size());
               this.getLogger().fine("GlideSpoofer license heartbeat sent successfully");
            } catch (Exception var3) {
               this.getLogger().log(Level.WARNING, "Failed to send license heartbeat", var3);
            }

         }, 9000L, 9000L).getTaskId();
      }

      this.getLogger().info("License heartbeat scheduler started (every 15 minutes)");
   }

   private void registerCommands() {
      GlideCommand cmd = new GlideCommand(this);
      if (this.guiListener != null) {
         cmd.setGUIListener(this.guiListener);
      }

      this.getCommand("glidespoofer").setExecutor(cmd);
      this.getCommand("glidespoofer").setTabCompleter(cmd);
      this.getCommand("gs").setExecutor(cmd);
      this.getCommand("gs").setTabCompleter(cmd);
      LicenceCommand licenceCmd = new LicenceCommand();
      this.getCommand("licence").setExecutor(licenceCmd);
      this.getCommand("licence").setTabCompleter(licenceCmd);
      if (this.fakeVoteManager != null) {
         FakeVotesCommand votesCmd = new FakeVotesCommand(this);
         this.getCommand("fakevotes").setExecutor(votesCmd);
         this.getCommand("fakevotes").setTabCompleter(votesCmd);
      }

   }

   private void loadFakePlayers() {
      boolean serverSideEnabled = this.configManager.getConfig().getBoolean("fake-players.server-side.enabled", false);
      this.getLogger().info("[DEBUG] server-side.enabled = " + serverSideEnabled);
      this.getLogger().info("[DEBUG] serverSideFakePlayerManager = " + (this.serverSideFakePlayerManager != null ? "NOT NULL" : "NULL"));
      if (serverSideEnabled && this.serverSideFakePlayerManager != null) {
         this.getLogger().info("Using SERVER-SIDE fake player mode (ServerSideBots style)");
         this.loadFakePlayersServerSide();
      } else if (this.simpleFakePlayerManager != null) {
         this.getLogger().info("Using NORMAL fake player mode");
         this.loadFakePlayersNormal();
      } else {
         this.getLogger().warning("No fake player manager available!");
      }

   }

   private void loadFakePlayersServerSide() {
      ConfigurationSection fakes = this.configManager.getFakesConfig().getConfigurationSection("fakes");
      if (fakes == null) {
         this.getLogger().warning("No fake players in fakes.yml");
      } else {
         int loaded = 0;

         for(String key : fakes.getKeys(false)) {
            ConfigurationSection sec = fakes.getConfigurationSection(key);
            if (sec != null) {
               String name = sec.getString("name", key);
               String skin = sec.getString("skin", "random");
               String rank = sec.getString("rank", "default");
               Map<String, String> tracks = new HashMap();
               ConfigurationSection tracksSec = sec.getConfigurationSection("tracks");
               if (tracksSec != null) {
                  for(String trackName : tracksSec.getKeys(false)) {
                     String trackValue = tracksSec.getString(trackName);
                     if (trackValue != null && !trackValue.isEmpty()) {
                        tracks.put(trackName, trackValue);
                     }
                  }

                  this.getLogger().info("[ServerSide] Parsed tracks for " + name + ": " + String.valueOf(tracks));
               }

               UUID skinUUID = null;
               if (skin != null && !skin.isEmpty() && !skin.equalsIgnoreCase("random")) {
                  try {
                     skinUUID = UUID.fromString(skin);
                  } catch (IllegalArgumentException var14) {
                  }
               }

               ServerSideFakePlayer fakePlayer = this.serverSideFakePlayerManager.addFakePlayer(name, skinUUID, rank, tracks.isEmpty() ? null : tracks);
               if (fakePlayer != null) {
                  ++loaded;
                  this.getLogger().info("[ServerSide] Added fake player: " + name + " with rank: " + rank);
               }
            }
         }

         this.getLogger().info("Loaded " + loaded + " SERVER-SIDE fake players");
         if (loaded > 0 && this.luckPermsHook != null && this.luckPermsHook.isEnabled()) {
            Bukkit.getScheduler().runTaskLater(this, () -> this.luckPermsHook.warmUpUserStorage(), 40L);
         }

      }
   }

   private void loadFakePlayersNormal() {
      ConfigurationSection fakes = this.configManager.getFakesConfig().getConfigurationSection("fakes");
      if (fakes == null) {
         this.getLogger().warning("No fake players in fakes.yml");
      } else {
         boolean useUltraSpoofStyle = this.ultraSpoofStyleSpawner != null;
         if (useUltraSpoofStyle) {
            this.getLogger().info("Using UltraSpoof-style spawning for proper player list injection!");
         }

         Location defaultSpawn = this.getDefaultSpawn();
         int loaded = 0;

         for(String key : fakes.getKeys(false)) {
            ConfigurationSection sec = fakes.getConfigurationSection(key);
            if (sec != null) {
               String name = sec.getString("name", key);
               String skin = sec.getString("skin", "random");
               String rank = sec.getString("rank", "default");
               boolean movement = sec.getBoolean("movement", false);
               boolean lookAtPlayers = sec.getBoolean("look-at-players", false);
               boolean visibleInWorld = sec.getBoolean("visible-in-world", true);
               Map<String, String> tracks = new HashMap();
               ConfigurationSection tracksSec = sec.getConfigurationSection("tracks");
               if (tracksSec != null) {
                  for(String trackName : tracksSec.getKeys(false)) {
                     String trackValue = tracksSec.getString(trackName);
                     if (trackValue != null && !trackValue.isEmpty()) {
                        tracks.put(trackName, trackValue);
                     }
                  }
               }

               Location loc = defaultSpawn;
               ConfigurationSection locSec = sec.getConfigurationSection("location");
               if (locSec != null) {
                  World world = Bukkit.getWorld(locSec.getString("world", "world"));
                  if (world != null) {
                     loc = new Location(world, locSec.getDouble("x", (double)0.0F), locSec.getDouble("y", (double)64.0F), locSec.getDouble("z", (double)0.0F), (float)locSec.getDouble("yaw", (double)0.0F), (float)locSec.getDouble("pitch", (double)0.0F));
                  }
               }

               SimpleFakePlayerManager.FakePlayerData data;
               if (useUltraSpoofStyle) {
                  data = this.simpleFakePlayerManager.spawnFakePlayerUltraSpoofStyle(name, loc, skin, rank, movement, false, tracks.isEmpty() ? null : tracks);
               } else {
                  data = this.simpleFakePlayerManager.spawnFakePlayer(name, loc, skin, rank, movement, false, tracks.isEmpty() ? null : tracks);
               }

               if (data != null) {
                  ++loaded;
                  data.setLookAtPlayers(lookAtPlayers);
                  if (lookAtPlayers) {
                     this.simpleFakePlayerManager.setLookAtPlayers(data.getUuid(), true);
                  }

                  this.simpleFakePlayerManager.getNMSHandler().setVisibleInWorld(data.getUuid(), visibleInWorld);
               }
            }
         }

         this.getLogger().info("Loaded " + loaded + " fake players" + (useUltraSpoofStyle ? " (UltraSpoof-style)" : ""));
         if (loaded > 0 && this.luckPermsHook != null && this.luckPermsHook.isEnabled()) {
            Bukkit.getScheduler().runTaskLater(this, () -> this.luckPermsHook.warmUpUserStorage(), 40L);
         }

      }
   }

   private Location getDefaultSpawn() {
      World world = Bukkit.getWorlds().isEmpty() ? null : (World)Bukkit.getWorlds().get(0);
      return world != null ? world.getSpawnLocation() : new Location((World)null, (double)0.0F, (double)64.0F, (double)0.0F);
   }

   public static GlideSpoofer getInstance() {
      return instance;
   }

   public static boolean isFolia() {
      return isFolia;
   }

   public static void teleportSafe(Player player, Location location) {
      if (player != null && location != null) {
         if (isFolia) {
            player.teleportAsync(location).whenComplete((result, throwable) -> {
               if (throwable != null) {
               }

            });
         } else {
            player.teleport(location);
         }
      }

   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public SimpleFakePlayerManager getSimpleFakePlayerManager() {
      return this.simpleFakePlayerManager;
   }

   public FakePlayerDamageListener getDamageListener() {
      return this.damageListener;
   }

   public FakePlayerGUIListener getGuiListener() {
      return this.guiListener;
   }

   public PlayerTakeoverData getTakeoverData() {
      return this.takeoverData;
   }

   public FakePlayerFluctuationManager getFluctuationManager() {
      return this.fluctuationManager;
   }

   public FakeVoteManager getFakeVoteManager() {
      return this.fakeVoteManager;
   }

   public FakeChatManager getFakeChatManager() {
      return this.fakeChatManager;
   }

   public LuckPermsHook getLuckPermsHook() {
      return this.luckPermsHook;
   }

   public WorldGuardHook getWorldGuardHook() {
      return this.worldGuardHook;
   }

   public TABHook getTabHook() {
      return this.tabHook;
   }

   public SuperiorSkyblockHook getSuperiorSkyblockHook() {
      return this.superiorSkyblockHook;
   }

   public InteractiveChatHook getInteractiveChatHook() {
      return this.interactiveChatHook;
   }

   public LPCHook getLPCHook() {
      return this.lpcHook;
   }

   public ViaVersionHook getViaVersionHook() {
      return this.viaVersionHook;
   }

   public RustHook getRustHook() {
      return this.rustHook;
   }

   public EssentialsHook getEssentialsHook() {
      return this.essentialsHook;
   }

   public AuthMeHook getAuthMeHook() {
      return this.authMeHook;
   }

   public ZelChatHook getZelChatHook() {
      return this.zelChatHook;
   }

   public LifestealCoreHook getLifestealCoreHook() {
      return this.lifestealCoreHook;
   }

   public LifeStealZHook getLifeStealZHook() {
      return this.lifeStealZHook;
   }

   public FakePlayerPathfinding getPathfinding() {
      return this.pathfinding;
   }

   public FollowModeManager getFollowModeManager() {
      return this.followModeManager;
   }

   public ProxyMessenger getProxyMessenger() {
      return this.proxyMessenger;
   }

   public String getMinecraftVersion() {
      return this.minecraftVersion;
   }

   public boolean isUsingNMS() {
      return true;
   }

   public boolean isUsingPacketEvents() {
      return false;
   }

   public FakePlayerManager getFakePlayerManager() {
      return null;
   }

   public FakePlayerCommandExecutor getCommandExecutor() {
      return this.commandExecutor;
   }

   public RealPlayerProximityChecker getProximityChecker() {
      return this.proximityChecker;
   }

   public DatabaseManager getDatabaseManager() {
      return this.databaseManager;
   }

   public AIManager getAIManager() {
      return this.aiManager;
   }

   public MovementAIService getMovementAI() {
      return this.movementAI;
   }

   public boolean isLicenceValid() {
      return UltimateLicenseVerify.isValid();
   }

   public ServerSideFakePlayerManager getServerSideFakePlayerManager() {
      return this.serverSideFakePlayerManager;
   }

   public UltraSpoofIntegration getUltraSpoofSpawner() {
      return this.serverSideFakePlayerManager != null ? this.serverSideFakePlayerManager.getUltraSpoofIntegration() : null;
   }

   public UltraSpoofStyleSpawner getUltraSpoofStyleSpawner() {
      return this.ultraSpoofStyleSpawner;
   }

   static {
      isFolia = detectFolia();
   }
}
