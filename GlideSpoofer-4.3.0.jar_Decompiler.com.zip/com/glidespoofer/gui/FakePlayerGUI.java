package com.glidespoofer.gui;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import com.glidespoofer.listener.FakePlayerDamageListener;
import com.glidespoofer.nms.NMSHandler;
import com.glidespoofer.pathfinding.FakePlayerPathfinding;
import com.glidespoofer.pathfinding.FollowModeManager;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

public class FakePlayerGUI implements Listener {
   private final GlideSpoofer plugin;
   private final FakePlayerPathfinding pathfinding;
   private final FollowModeManager followModeManager;
   private final Map<String, Boolean> movementEnabled = new ConcurrentHashMap();
   private final Map<String, BukkitTask> movementTasks = new ConcurrentHashMap();
   private final Map<String, Boolean> swingArmEnabled = new ConcurrentHashMap();
   private final Map<String, BukkitTask> swingArmTasks = new ConcurrentHashMap();
   private final Map<String, Boolean> physicsEnabled = new ConcurrentHashMap();
   private final Map<String, Boolean> noDamageEnabled = new ConcurrentHashMap();
   private boolean globalMovementEnabled = true;
   private boolean globalLookCloseEnabled = true;
   private boolean globalSwingArmEnabled = true;
   private boolean globalPhysicsEnabled = true;
   private boolean globalNoDamageEnabled = false;
   private boolean globalHideBodiesEnabled = false;
   private boolean globalFollowModeEnabled = false;
   private boolean globalHeadMovementEnabled = true;
   private boolean globalJoinLeaveMessagesEnabled = true;
   private int maxPing = 200;
   private static final int MOVEMENT_SLOT = 10;
   private static final int LOOK_CLOSE_SLOT = 11;
   private static final int SWING_ARM_SLOT = 12;
   private static final int PHYSICS_SLOT = 13;
   private static final int NO_DAMAGE_SLOT = 14;
   private static final int FOLLOW_MODE_SLOT = 15;
   private static final int INFO_SLOT = 22;
   private static final int REMOVE_SLOT = 31;
   private static final int BACK_SLOT = 40;
   private static final int GLOBAL_MOVEMENT_SLOT = 10;
   private static final int GLOBAL_LOOK_CLOSE_SLOT = 11;
   private static final int GLOBAL_SWING_ARM_SLOT = 12;
   private static final int GLOBAL_PHYSICS_SLOT = 13;
   private static final int GLOBAL_NO_DAMAGE_SLOT = 14;
   private static final int GLOBAL_HIDE_BODIES_SLOT = 15;
   private static final int GLOBAL_FOLLOW_MODE_SLOT = 16;
   private static final int GLOBAL_HEAD_MOVEMENT_SLOT = 17;
   private static final int GLOBAL_JOIN_LEAVE_SLOT = 19;
   private static final int GLOBAL_MAX_PING_SLOT = 2;
   private static final int GLOBAL_TP_ALL_SLOT = 20;
   private static final int GLOBAL_ENABLE_ALL_SLOT = 51;
   private static final int GLOBAL_DISABLE_ALL_SLOT = 52;
   private static final int GLOBAL_BACK_SLOT = 53;
   private static final int HOOKS_START_SLOT = 10;
   private static final int HOOKS_BACK_SLOT = 49;
   private static final int SET_SPAWN_SLOT = 10;
   private static final int ADD_FLUCTUATION_POINT_SLOT = 11;
   private static final int VIEW_POINTS_SLOT = 12;
   private static final int SETLOCATION_BACK_SLOT = 49;
   private static final int POINTS_START_SLOT = 10;
   private static final int POINTS_BACK_SLOT = 49;
   private static final int FLUCT_ENABLED_SLOT = 10;
   private static final int FLUCT_MIN_ONLINE_SLOT = 11;
   private static final int FLUCT_MAX_ONLINE_SLOT = 12;
   private static final int FLUCT_MIN_PLAYERS_SLOT = 13;
   private static final int FLUCT_CHECK_INTERVAL_SLOT = 14;
   private static final int FLUCT_MAX_PER_CHECK_SLOT = 15;
   private static final int FLUCT_ALLOW_LEAVING_SLOT = 16;
   private static final int FLUCT_STARTUP_ENABLED_SLOT = 19;
   private static final int FLUCT_STARTUP_BATCH_SIZE_SLOT = 20;
   private static final int FLUCT_BACK_SLOT = 49;
   private final List<String> fluctuationSpawnPoints = new CopyOnWriteArrayList();
   private final Map<String, Integer> spawnPointUsage = new ConcurrentHashMap();
   private final Map<String, Boolean> intendedHookStates = new ConcurrentHashMap();
   private final Map<String, Boolean> hooksRequireRestart = new ConcurrentHashMap();

   public FakePlayerGUI(GlideSpoofer plugin, FakePlayerPathfinding pathfinding, FollowModeManager followModeManager) {
      this.plugin = plugin;
      this.pathfinding = pathfinding;
      this.followModeManager = followModeManager;
      this.loadGlobalSettings();
      this.loadFluctuationPoints();
   }

   public boolean isGlobalSwingArmEnabled() {
      return this.globalSwingArmEnabled;
   }

   public boolean isGlobalMovementEnabled() {
      return this.globalMovementEnabled;
   }

   public boolean isGlobalJoinLeaveMessagesEnabled() {
      return this.globalJoinLeaveMessagesEnabled;
   }

   public int getMaxPing() {
      return this.maxPing;
   }

   public boolean isGlobalLookCloseEnabled() {
      return this.globalLookCloseEnabled;
   }

   public boolean isGlobalPhysicsEnabled() {
      return this.globalPhysicsEnabled;
   }

   public boolean isGlobalNoDamageEnabled() {
      return this.globalNoDamageEnabled;
   }

   public boolean isGlobalHideBodiesEnabled() {
      return this.globalHideBodiesEnabled;
   }

   public boolean isGlobalFollowModeEnabled() {
      return this.globalFollowModeEnabled;
   }

   public boolean isGlobalHeadMovementEnabled() {
      return this.globalHeadMovementEnabled;
   }

   public void applyGlobalSettingsToFakePlayer(String fakeName, UUID uuid, SimpleFakePlayerManager.FakePlayerData fake) {
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager != null) {
         manager.getNMSHandler().setSwingArmEnabled(uuid, this.globalSwingArmEnabled);
         manager.getNMSHandler().setHeadMovementEnabled(uuid, this.globalHeadMovementEnabled);
         manager.setLookAtPlayers(uuid, this.globalLookCloseEnabled);
         this.physicsEnabled.put(fakeName, this.globalPhysicsEnabled);
         this.noDamageEnabled.put(fakeName, this.globalNoDamageEnabled);
         if (this.globalMovementEnabled) {
            manager.getNMSHandler().setGuiMovementEnabled(uuid, true);
         }

         if (this.globalHideBodiesEnabled) {
            manager.getNMSHandler().setVisibleInWorld(uuid, false);
         }

         if (this.globalSwingArmEnabled && fake != null) {
            this.startSwingingArm(fakeName, fake);
         }
      }

   }

   public void openMainGUI(Player player) {
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager == null) {
         player.sendMessage(String.valueOf(ChatColor.RED) + "Fake player manager not available!");
      } else {
         String var10000 = String.valueOf(ChatColor.DARK_AQUA);
         String title = var10000 + "Fake Players (" + manager.getFakePlayerCount() + ")";
         Inventory inv = Bukkit.createInventory((InventoryHolder)null, 54, title);
         int slot = 0;

         for(SimpleFakePlayerManager.FakePlayerData fake : manager.getAllFakePlayers()) {
            if (slot >= 45) {
               break;
            }

            ItemStack item = this.createPlayerItem(fake);
            inv.setItem(slot, item);
            ++slot;
         }

         inv.setItem(45, this.createControlItem(Material.BARRIER, String.valueOf(ChatColor.RED) + "Close", ""));
         inv.setItem(46, this.createControlItem(Material.COMMAND_BLOCK, String.valueOf(ChatColor.AQUA) + "Global Settings", "Edit settings for ALL fake players"));
         inv.setItem(47, this.createControlItem(Material.REDSTONE, String.valueOf(ChatColor.LIGHT_PURPLE) + "Hooks", "View and toggle plugin hooks"));
         inv.setItem(48, this.createControlItem(Material.COMPASS, String.valueOf(ChatColor.GREEN) + "Refresh", ""));
         inv.setItem(49, this.createControlItem(Material.END_CRYSTAL, String.valueOf(ChatColor.GOLD) + "SetLocation", "Set spawn and fluctuation points"));
         inv.setItem(50, this.createControlItem(Material.REPEATER, String.valueOf(ChatColor.YELLOW) + "Fluctuation", "Configure fluctuation system"));
         inv.setItem(53, this.createControlItem(Material.ARROW, String.valueOf(ChatColor.YELLOW) + "Back", ""));
         player.openInventory(inv);
      }

   }

   public void openGlobalSettings(Player player) {
      String var10000 = String.valueOf(ChatColor.DARK_AQUA);
      String title = var10000 + "Global Settings";
      Inventory inv = Bukkit.createInventory((InventoryHolder)null, 54, title);
      Material var10003 = Material.LEATHER_BOOTS;
      String var10004 = String.valueOf(ChatColor.GREEN);
      inv.setItem(10, this.createToggleItem(var10003, var10004 + "Movement", "Fake players move around randomly", this.globalMovementEnabled));
      var10003 = Material.ENDER_EYE;
      var10004 = String.valueOf(ChatColor.LIGHT_PURPLE);
      inv.setItem(11, this.createToggleItem(var10003, var10004 + "Look at Players", "Fake players look at nearby real players", this.globalLookCloseEnabled));
      var10003 = Material.DIAMOND_SWORD;
      var10004 = String.valueOf(ChatColor.GOLD);
      inv.setItem(12, this.createToggleItem(var10003, var10004 + "Swing Arm", "Fake players periodically swing arm", this.globalSwingArmEnabled));
      var10003 = Material.SHIELD;
      var10004 = String.valueOf(ChatColor.RED);
      inv.setItem(13, this.createToggleItem(var10003, var10004 + "Knockback Mode", "Fake players take knockback when hit", this.globalPhysicsEnabled));
      var10003 = Material.GOLDEN_APPLE;
      var10004 = String.valueOf(ChatColor.AQUA);
      inv.setItem(14, this.createToggleItem(var10003, var10004 + "No Damage", "Fake players take no damage at all", this.globalNoDamageEnabled));
      var10003 = Material.GLASS;
      var10004 = String.valueOf(ChatColor.WHITE);
      inv.setItem(15, this.createToggleItem(var10003, var10004 + "Hide Bodies", "Make fake players invisible (only names show)", this.globalHideBodiesEnabled));
      var10003 = Material.COMPASS;
      var10004 = String.valueOf(ChatColor.AQUA);
      inv.setItem(16, this.createToggleItem(var10003, var10004 + "Follow Mode", "All fake players follow YOU", this.globalFollowModeEnabled));
      var10003 = Material.PLAYER_HEAD;
      var10004 = String.valueOf(ChatColor.LIGHT_PURPLE);
      inv.setItem(17, this.createToggleItem(var10003, var10004 + "Head Movement", "Random head movement/looking around", this.globalHeadMovementEnabled));
      var10003 = Material.LIME_STAINED_GLASS_PANE;
      var10004 = String.valueOf(ChatColor.GREEN);
      inv.setItem(18, this.createControlItem(var10003, var10004 + String.valueOf(ChatColor.BOLD) + " MOVEMENT & ANIMATION", ""));
      inv.setItem(22, this.createControlItem(Material.LIME_STAINED_GLASS_PANE, " ", ""));
      inv.setItem(26, this.createControlItem(Material.LIME_STAINED_GLASS_PANE, " ", ""));
      ItemStack joinLeaveItem = new ItemStack(this.globalJoinLeaveMessagesEnabled ? Material.WRITABLE_BOOK : Material.WRITTEN_BOOK);
      ItemMeta joinLeaveMeta = joinLeaveItem.getItemMeta();
      if (joinLeaveMeta != null) {
         joinLeaveMeta.setDisplayName(String.valueOf(ChatColor.AQUA) + "Join/Leave Messages");
         List<String> joinLeaveLore = new ArrayList();
         joinLeaveLore.add(String.valueOf(ChatColor.GRAY) + "Toggle fake player join/leave messages");
         joinLeaveLore.add("");
         String var10001 = String.valueOf(ChatColor.YELLOW);
         joinLeaveLore.add(var10001 + "Status: " + (this.globalJoinLeaveMessagesEnabled ? String.valueOf(ChatColor.GREEN) + "Enabled" : String.valueOf(ChatColor.RED) + "Disabled"));
         joinLeaveLore.add("");
         var10001 = String.valueOf(ChatColor.GREEN);
         joinLeaveLore.add(var10001 + "Click" + String.valueOf(ChatColor.GRAY) + " to toggle");
         joinLeaveMeta.setLore(joinLeaveLore);
         joinLeaveItem.setItemMeta(joinLeaveMeta);
      }

      inv.setItem(19, joinLeaveItem);
      inv.setItem(20, this.createControlItem(Material.ENDER_PEARL, String.valueOf(ChatColor.GOLD) + "TP All Here", String.valueOf(ChatColor.GRAY) + "Teleport all fake players to your location"));
      inv.setItem(2, this.createControlItem(Material.EMERALD, String.valueOf(ChatColor.GREEN) + "Max Ping", "&fCurrent: &e" + this.maxPing + " ms\n&7Maximum ping for fake players\n&7Lower = more realistic\n&8Left click: -25 | Right click: +25"));
      inv.setItem(51, this.createControlItem(Material.LIME_WOOL, String.valueOf(ChatColor.GREEN) + "Enable All Features", "Enable everything"));
      inv.setItem(52, this.createControlItem(Material.RED_WOOL, String.valueOf(ChatColor.RED) + "Disable All Features", "Disable all modules"));
      inv.setItem(53, this.createControlItem(Material.ARROW, String.valueOf(ChatColor.YELLOW) + "Back", "Return to main menu"));
      player.openInventory(inv);
   }

   public void openHooksGUI(Player player) {
      String title = String.valueOf(ChatColor.DARK_PURPLE) + "Plugin Hooks";
      Inventory inv = Bukkit.createInventory((InventoryHolder)null, 54, title);
      List<Object[]> hooks = Arrays.asList(new Object[]{"LuckPerms", Material.GOLDEN_HELMET, "Provides rank/group support for fake players", this.plugin.getLuckPermsHook()}, new Object[]{"WorldGuard", Material.IRON_BARS, "Respects region protection rules", this.plugin.getWorldGuardHook()}, new Object[]{"TAB", Material.PAPER, "Integrates with TAB plugin for tab list", this.plugin.getTabHook()}, new Object[]{"SuperiorSkyblock", Material.GRASS_BLOCK, "Creates islands for fake players", this.plugin.getSuperiorSkyblockHook()}, new Object[]{"InteractiveChat", Material.BOOK, "Adds hover events to chat messages", this.plugin.getInteractiveChatHook()}, new Object[]{"LPC", Material.WRITABLE_BOOK, "Formats chat messages with placeholders", this.plugin.getLPCHook()}, new Object[]{"ViaVersion", Material.COMPARATOR, "Handles cross-version packet translation", this.plugin.getViaVersionHook()}, new Object[]{"RustHook", Material.REDSTONE_BLOCK, "External library integration", this.plugin.getRustHook()}, new Object[]{"Essentials", Material.CHEST, "Custom join/leave messages", this.plugin.getEssentialsHook()}, new Object[]{"AuthMe", Material.TRIPWIRE_HOOK, "Auto-authenticates fake players", this.plugin.getAuthMeHook()}, new Object[]{"ZelChat", Material.OAK_SIGN, "Chat formatting and channels", this.plugin.getZelChatHook()}, new Object[]{"LifeStealCore", Material.RED_DYE, "Hearts display for LifeSteal servers", this.plugin.getLifestealCoreHook()}, new Object[]{"LifeStealZ", Material.APPLE, "Hearts fluctation for LifeStealZ", this.plugin.getLifeStealZHook()});
      int slot = 10;

      for(Object[] hookData : hooks) {
         if (slot >= 44) {
            break;
         }

         String name = (String)hookData[0];
         Material material = (Material)hookData[1];
         String description = (String)hookData[2];
         Object hookObj = hookData[3];
         boolean enabled = false;
         boolean hasIntendedState = this.intendedHookStates.containsKey(name);
         if (hookObj != null) {
            try {
               Method isEnabledMethod = hookObj.getClass().getMethod("isEnabled");
               enabled = (Boolean)isEnabledMethod.invoke(hookObj);
            } catch (Exception var21) {
               enabled = true;
            }
         }

         boolean displayEnabled = hasIntendedState ? (Boolean)this.intendedHookStates.get(name) : enabled;
         ItemStack item = new ItemStack(displayEnabled ? Material.LIME_DYE : Material.GRAY_DYE);
         ItemMeta meta = item.getItemMeta();
         if (meta != null) {
            ChatColor statusColor = displayEnabled ? ChatColor.GREEN : ChatColor.RED;
            String statusText = displayEnabled ? "ON" : "OFF";
            String var10001 = String.valueOf(ChatColor.YELLOW);
            meta.setDisplayName(var10001 + name + ": " + String.valueOf(statusColor) + statusText);
            List<String> lore = new ArrayList();
            var10001 = String.valueOf(ChatColor.GRAY);
            lore.add(var10001 + description);
            lore.add("");
            boolean needsRestart = this.hooksRequireRestart.containsKey(name) && (Boolean)this.hooksRequireRestart.get(name);
            if (hookObj == null) {
               lore.add(String.valueOf(ChatColor.RED) + "Plugin not installed");
            } else if (needsRestart) {
               lore.add(String.valueOf(ChatColor.GOLD) + "⚠ Requires restart to apply");
               lore.add(String.valueOf(ChatColor.YELLOW) + "Click to toggle (restart needed)");
            } else if (displayEnabled) {
               lore.add(String.valueOf(ChatColor.GREEN) + "Click to disable");
            } else {
               lore.add(String.valueOf(ChatColor.YELLOW) + "Click to enable");
            }

            meta.setLore(lore);
            item.setItemMeta(meta);
         }

         inv.setItem(slot, item);
         ++slot;
         if ((slot - 10) % 7 == 0) {
            slot += 2;
         }
      }

      inv.setItem(36, this.createControlItem(Material.PURPLE_STAINED_GLASS_PANE, String.valueOf(ChatColor.LIGHT_PURPLE) + String.valueOf(ChatColor.BOLD) + " PLUGIN HOOKS", ""));
      inv.setItem(49, this.createControlItem(Material.ARROW, String.valueOf(ChatColor.YELLOW) + "Back", "Return to main menu"));
      player.openInventory(inv);
   }

   private void toggleHook(Player player, String hookName) {
      Object hookObj = null;
      String configPath = null;
      switch (hookName) {
         case "LuckPerms":
            hookObj = this.plugin.getLuckPermsHook();
            configPath = "hooks.luckperms.enabled";
            break;
         case "WorldGuard":
            hookObj = this.plugin.getWorldGuardHook();
            configPath = "hooks.worldguard.enabled";
            break;
         case "TAB":
            hookObj = this.plugin.getTabHook();
            configPath = "hooks.tab.enabled";
            break;
         case "SuperiorSkyblock":
            hookObj = this.plugin.getSuperiorSkyblockHook();
            configPath = "hooks.superiorskyblock.enabled";
            break;
         case "InteractiveChat":
            hookObj = this.plugin.getInteractiveChatHook();
            configPath = "hooks.interactivechat.enabled";
            break;
         case "LPC":
            hookObj = this.plugin.getLPCHook();
            configPath = "hooks.lpc.enabled";
            break;
         case "ViaVersion":
            hookObj = this.plugin.getViaVersionHook();
            configPath = "hooks.viaversion.enabled";
            break;
         case "RustHook":
            hookObj = this.plugin.getRustHook();
            configPath = "rust-hook.enabled";
            break;
         case "Essentials":
            hookObj = this.plugin.getEssentialsHook();
            configPath = "hooks.essentials.enabled";
            break;
         case "AuthMe":
            hookObj = this.plugin.getAuthMeHook();
            configPath = "hooks.authme.enabled";
            break;
         case "ZelChat":
            hookObj = this.plugin.getZelChatHook();
            configPath = "chat-hooks.zelchat.enabled";
            break;
         case "LifeStealCore":
            hookObj = this.plugin.getLifestealCoreHook();
            configPath = "hooks.lifestealcore.enabled";
            break;
         case "LifeStealZ":
            hookObj = this.plugin.getLifeStealZHook();
            configPath = "hooks.lifestealz.enabled";
      }

      if (hookObj == null) {
         String var10001 = String.valueOf(ChatColor.RED);
         player.sendMessage(var10001 + "Hook '" + hookName + "' is not available (plugin not installed)");
      } else {
         boolean currentState = false;
         if (this.intendedHookStates.containsKey(hookName)) {
            currentState = (Boolean)this.intendedHookStates.get(hookName);
         } else {
            try {
               Method isEnabledMethod = hookObj.getClass().getMethod("isEnabled");
               currentState = (Boolean)isEnabledMethod.invoke(hookObj);
            } catch (Exception var8) {
               String var14 = String.valueOf(ChatColor.RED);
               player.sendMessage(var14 + "Cannot toggle hook '" + hookName + "'");
               return;
            }
         }

         newState = !currentState;

         try {
            Method setEnabledMethod = hookObj.getClass().getMethod("setEnabled", Boolean.TYPE);
            setEnabledMethod.invoke(hookObj, newState);
            this.intendedHookStates.put(hookName, newState);
            this.hooksRequireRestart.remove(hookName);
            player.sendMessage(String.valueOf(newState ? ChatColor.GREEN : ChatColor.RED) + hookName + " " + (newState ? "enabled" : "disabled"));
         } catch (NoSuchMethodException var9) {
            if (configPath != null) {
               this.plugin.getConfig().set(configPath, newState);
               this.plugin.saveConfig();
               this.intendedHookStates.put(hookName, newState);
               this.hooksRequireRestart.put(hookName, true);
               String var16 = String.valueOf(ChatColor.YELLOW);
               player.sendMessage(var16 + hookName + " " + (newState ? "enabled" : "disabled") + String.valueOf(ChatColor.GOLD) + " (requires restart)");
            } else {
               player.sendMessage(String.valueOf(ChatColor.RED) + "This hook cannot be toggled");
            }
         } catch (Exception var10) {
            String var15 = String.valueOf(ChatColor.RED);
            player.sendMessage(var15 + "Error toggling hook: " + var10.getMessage());
         }
      }

   }

   public void openSetLocationGUI(Player player) {
      String title = String.valueOf(ChatColor.GOLD) + "SetLocation";
      Inventory inv = Bukkit.createInventory((InventoryHolder)null, 54, title);
      inv.setItem(10, this.createControlItem(Material.GREEN_BED, String.valueOf(ChatColor.GREEN) + "Set Spawn Location", "Set spawn to your current position\n&eAll fake players will spawn here"));
      inv.setItem(11, this.createControlItem(Material.BEACON, String.valueOf(ChatColor.AQUA) + "Add Fluctuation Point", "Add your position as a spawn point\n&eFake players spawn randomly at these points"));
      int pointCount = this.fluctuationSpawnPoints.size();
      inv.setItem(12, this.createControlItem(Material.MAP, String.valueOf(ChatColor.YELLOW) + "View Spawn Points", "&fCurrent points: &e" + pointCount + "\n&7Click to view and remove points"));
      inv.setItem(22, this.createControlItem(Material.BOOK, String.valueOf(ChatColor.WHITE) + "Info", "&eSpawn Location: &fDefault spawn for all fake players\n&eFluctuation Points: &fRandom spawn locations\n&7If no fluctuation points are set,\n&7the default spawn is used."));
      inv.setItem(49, this.createControlItem(Material.ARROW, String.valueOf(ChatColor.YELLOW) + "Back", "Return to main menu"));
      player.openInventory(inv);
   }

   public void openViewPointsGUI(Player player) {
      String title = String.valueOf(ChatColor.YELLOW) + "Spawn Points";
      Inventory inv = Bukkit.createInventory((InventoryHolder)null, 54, title);
      int slot = 10;

      for(int i = 0; i < this.fluctuationSpawnPoints.size() && slot < 45; ++i) {
         String point = (String)this.fluctuationSpawnPoints.get(i);
         String[] parts = point.split(":");
         String displayPoint = point;
         if (parts.length >= 4) {
            displayPoint = parts[0] + ": " + parts[1] + ", " + parts[2] + ", " + parts[3];
         }

         inv.setItem(slot, this.createControlItem(Material.REDSTONE_LAMP, String.valueOf(ChatColor.AQUA) + "Point #" + (i + 1), "&f" + displayPoint + "\n&cClick to remove"));
         ++slot;
      }

      inv.setItem(49, this.createControlItem(Material.ARROW, String.valueOf(ChatColor.YELLOW) + "Back", "Return to SetLocation menu"));
      player.openInventory(inv);
   }

   public void openFluctuationGUI(Player player) {
      String title = String.valueOf(ChatColor.YELLOW) + "Fluctuation Settings";
      Inventory inv = Bukkit.createInventory((InventoryHolder)null, 54, title);
      FileConfiguration fakesConfig = this.plugin.getConfigManager().getFakesConfig();
      boolean enabled = fakesConfig.getBoolean("fluctuation.enabled", true);
      int minOnline = fakesConfig.getInt("fluctuation.min-online", 2);
      int maxOnline = fakesConfig.getInt("fluctuation.max-online", 15);
      int minPlayersOnline = fakesConfig.getInt("fluctuation.min-players-online", 2);
      int checkInterval = fakesConfig.getInt("fluctuation.check-interval", 600);
      int maxPerCheck = fakesConfig.getInt("fluctuation.max-players-per-check", 1);
      boolean allowLeaving = fakesConfig.getBoolean("fluctuation.allow-leaving", true);
      boolean startupEnabled = fakesConfig.getBoolean("fluctuation.startup.enabled", true);
      int startupBatchSize = fakesConfig.getInt("fluctuation.startup.batch-size", 2);
      inv.setItem(10, this.createToggleItem(Material.REPEATER, String.valueOf(ChatColor.GREEN) + "Fluctuation Enabled", "Enable/disable the fluctuation system\n&7Fake players randomly join/leave", enabled));
      inv.setItem(11, this.createControlItem(Material.PLAYER_HEAD, String.valueOf(ChatColor.AQUA) + "Min Online", "&fCurrent: &e" + minOnline + "\n&7Minimum fake players online\n&8Left click: -1 | Right click: +1"));
      inv.setItem(12, this.createControlItem(Material.PLAYER_HEAD, String.valueOf(ChatColor.LIGHT_PURPLE) + "Max Online", "&fCurrent: &e" + maxOnline + "\n&7Maximum fake players online\n&8Left click: -5 | Right click: +5"));
      inv.setItem(13, this.createControlItem(Material.IRON_DOOR, String.valueOf(ChatColor.GOLD) + "Min Real Players", "&fCurrent: &e" + minPlayersOnline + "\n&7Min real players needed\n&7for fluctuation to work\n&8Left click: -1 | Right click: +1"));
      inv.setItem(14, this.createControlItem(Material.CLOCK, String.valueOf(ChatColor.YELLOW) + "Check Interval", "&fCurrent: &e" + checkInterval + " ticks\n&7How often to check\n&7(20 ticks = 1 second)\n&8Left click: -100 | Right click: +100"));
      inv.setItem(15, this.createControlItem(Material.HOPPER, String.valueOf(ChatColor.WHITE) + "Max Per Check", "&fCurrent: &e" + maxPerCheck + "\n&7Max players that can\n&7join/leave per check\n&8Left click: -1 | Right click: +1"));
      inv.setItem(16, this.createToggleItem(Material.OAK_DOOR, String.valueOf(ChatColor.RED) + "Allow Leaving", "Allow fake players to leave\n&7Disable to keep all fake\n&7players online (join only)", allowLeaving));
      inv.setItem(19, this.createToggleItem(Material.LIME_DYE, String.valueOf(ChatColor.GREEN) + "Startup Gradual Spawn", "Spawn fake players gradually\n&7on server startup instead of all at once", startupEnabled));
      inv.setItem(20, this.createControlItem(Material.CHEST, String.valueOf(ChatColor.AQUA) + "Startup Batch Size", "&fCurrent: &e" + startupBatchSize + "\n&7Players per batch on startup\n&8Left click: -1 | Right click: +1"));
      inv.setItem(22, this.createControlItem(Material.BOOK, String.valueOf(ChatColor.WHITE) + "Fluctuation Info", "&eFluctuation makes fake players\n&erandomly join and leave like\n&ereal players would.\n\n&7Settings are saved to fakes.yml"));
      inv.setItem(49, this.createControlItem(Material.ARROW, String.valueOf(ChatColor.YELLOW) + "Back", "Return to main menu"));
      player.openInventory(inv);
   }

   private void updateFluctuationSetting(String path, Object value) {
      FileConfiguration fakesConfig = this.plugin.getConfigManager().getFakesConfig();
      fakesConfig.set(path, value);
      this.plugin.getConfigManager().saveFakesConfig();
   }

   private void setSpawnLocation(Player player) {
      Location loc = player.getLocation();
      String worldName = loc.getWorld().getName();
      double x = loc.getX();
      double y = loc.getY();
      double z = loc.getZ();
      float yaw = loc.getYaw();
      float pitch = loc.getPitch();
      String basePath = "spawn-location";
      this.plugin.getConfig().set(basePath + ".world", worldName);
      this.plugin.getConfig().set(basePath + ".x", x);
      this.plugin.getConfig().set(basePath + ".y", y);
      this.plugin.getConfig().set(basePath + ".z", z);
      this.plugin.getConfig().set(basePath + ".yaw", yaw);
      this.plugin.getConfig().set(basePath + ".pitch", pitch);
      this.plugin.saveConfig();
      String var10001 = String.valueOf(ChatColor.GREEN);
      player.sendMessage(var10001 + "Spawn location set to: " + String.valueOf(ChatColor.WHITE) + worldName + " at " + String.format("%.1f", x) + ", " + String.format("%.1f", y) + ", " + String.format("%.1f", z));
   }

   private void addFluctuationPoint(Player player) {
      Location loc = player.getLocation();
      String var10000 = loc.getWorld().getName();
      String point = var10000 + ":" + String.format("%.1f", loc.getX()) + ":" + String.format("%.1f", loc.getY()) + ":" + String.format("%.1f", loc.getZ());
      this.fluctuationSpawnPoints.add(point);
      this.saveFluctuationPoints();
      String var10001 = String.valueOf(ChatColor.AQUA);
      player.sendMessage(var10001 + "Added fluctuation point #" + this.fluctuationSpawnPoints.size() + String.valueOf(ChatColor.WHITE) + " at " + point);
   }

   private void removeFluctuationPoint(int index) {
      if (index >= 0 && index < this.fluctuationSpawnPoints.size()) {
         this.fluctuationSpawnPoints.remove(index);
         this.saveFluctuationPoints();
      }

   }

   private void saveFluctuationPoints() {
      this.plugin.getConfig().set("fluctuation-spawn-points", (Object)null);

      for(int i = 0; i < this.fluctuationSpawnPoints.size(); ++i) {
         this.plugin.getConfig().set("fluctuation-spawn-points." + i, this.fluctuationSpawnPoints.get(i));
      }

      this.plugin.saveConfig();
   }

   public void loadFluctuationPoints() {
      this.fluctuationSpawnPoints.clear();
      ConfigurationSection section = this.plugin.getConfig().getConfigurationSection("fluctuation-spawn-points");
      if (section != null) {
         for(String key : section.getKeys(false)) {
            String point = section.getString(key);
            if (point != null && !point.isEmpty()) {
               this.fluctuationSpawnPoints.add(point);
            }
         }
      }

   }

   public void saveGlobalSettings() {
      this.plugin.getConfig().set("global-settings.movement", this.globalMovementEnabled);
      this.plugin.getConfig().set("global-settings.look-close", this.globalLookCloseEnabled);
      this.plugin.getConfig().set("global-settings.swing-arm", this.globalSwingArmEnabled);
      this.plugin.getConfig().set("global-settings.physics", this.globalPhysicsEnabled);
      this.plugin.getConfig().set("global-settings.no-damage", this.globalNoDamageEnabled);
      this.plugin.getConfig().set("global-settings.hide-bodies", this.globalHideBodiesEnabled);
      this.plugin.getConfig().set("global-settings.head-movement", this.globalHeadMovementEnabled);
      this.plugin.getConfig().set("global-settings.join-leave-messages", this.globalJoinLeaveMessagesEnabled);
      this.plugin.getConfig().set("global-settings.max-ping", this.maxPing);
      this.plugin.saveConfig();
   }

   public void loadGlobalSettings() {
      ConfigurationSection section = this.plugin.getConfig().getConfigurationSection("global-settings");
      if (section != null) {
         this.globalMovementEnabled = section.getBoolean("movement", true);
         if (section.contains("look-close")) {
            this.globalLookCloseEnabled = section.getBoolean("look-close");
         } else {
            this.globalLookCloseEnabled = true;
         }

         this.globalSwingArmEnabled = section.getBoolean("swing-arm", true);
         this.globalPhysicsEnabled = section.getBoolean("physics", true);
         this.globalNoDamageEnabled = section.getBoolean("no-damage", false);
         this.globalHideBodiesEnabled = section.getBoolean("hide-bodies", false);
         if (section.contains("head-movement")) {
            this.globalHeadMovementEnabled = section.getBoolean("head-movement");
         } else {
            this.globalHeadMovementEnabled = true;
         }

         if (section.contains("join-leave-messages")) {
            this.globalJoinLeaveMessagesEnabled = section.getBoolean("join-leave-messages");
         } else {
            this.globalJoinLeaveMessagesEnabled = this.plugin.getConfigManager().isBroadcastJoinEnabled();
         }

         this.maxPing = section.getInt("max-ping", 200);
      }

   }

   public Location getRandomFluctuationPoint() {
      if (this.fluctuationSpawnPoints.isEmpty()) {
         return null;
      } else {
         String selectedPoint = null;
         int lowestUsage = Integer.MAX_VALUE;

         for(String point : this.fluctuationSpawnPoints) {
            int usage = (Integer)this.spawnPointUsage.getOrDefault(point, 0);
            if (usage < lowestUsage) {
               lowestUsage = usage;
               selectedPoint = point;
            }
         }

         if (selectedPoint == null && !this.fluctuationSpawnPoints.isEmpty()) {
            selectedPoint = (String)this.fluctuationSpawnPoints.get(0);
         }

         if (selectedPoint == null) {
            return null;
         } else {
            this.spawnPointUsage.put(selectedPoint, (Integer)this.spawnPointUsage.getOrDefault(selectedPoint, 0) + 1);
            String[] parts = selectedPoint.split(":");
            if (parts.length >= 4) {
               try {
                  World world = Bukkit.getWorld(parts[0]);
                  if (world != null) {
                     double x = Double.parseDouble(parts[1]);
                     double y = Double.parseDouble(parts[2]);
                     double z = Double.parseDouble(parts[3]);
                     return new Location(world, x, y, z);
                  }
               } catch (NumberFormatException var11) {
               }
            }

            return null;
         }
      }
   }

   public Location getConfiguredSpawnLocation() {
      String basePath = "spawn-location";
      String worldName = this.plugin.getConfig().getString(basePath + ".world", (String)null);
      if (worldName != null) {
         World world = Bukkit.getWorld(worldName);
         if (world != null) {
            double x = this.plugin.getConfig().getDouble(basePath + ".x", world.getSpawnLocation().getX());
            double y = this.plugin.getConfig().getDouble(basePath + ".y", world.getSpawnLocation().getY());
            double z = this.plugin.getConfig().getDouble(basePath + ".z", world.getSpawnLocation().getZ());
            float yaw = (float)this.plugin.getConfig().getDouble(basePath + ".yaw", (double)0.0F);
            float pitch = (float)this.plugin.getConfig().getDouble(basePath + ".pitch", (double)0.0F);
            return new Location(world, x, y, z, yaw, pitch);
         }
      }

      World defaultWorld = (World)Bukkit.getWorlds().get(0);
      return defaultWorld.getSpawnLocation();
   }

   public void openPlayerSettings(Player player, String fakePlayerName) {
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager != null) {
         SimpleFakePlayerManager.FakePlayerData fake = manager.getFakePlayer(fakePlayerName);
         if (fake == null) {
            player.sendMessage(String.valueOf(ChatColor.RED) + "Fake player not found!");
         } else {
            UUID uuid = fake.getUuid();
            String var10000 = String.valueOf(ChatColor.DARK_AQUA);
            String title = var10000 + "Settings: " + fake.getName();
            Inventory inv = Bukkit.createInventory((InventoryHolder)null, 45, title);
            boolean hasMovement = (Boolean)this.movementEnabled.getOrDefault(fakePlayerName, false);
            inv.setItem(10, this.createToggleItem(Material.LEATHER_BOOTS, String.valueOf(ChatColor.GREEN) + "Movement", "Allow the fake player to move around", hasMovement));
            boolean lookClose = this.plugin.getSimpleFakePlayerManager().isLookingAtPlayers(uuid);
            inv.setItem(11, this.createToggleItem(Material.ENDER_EYE, String.valueOf(ChatColor.LIGHT_PURPLE) + "Look at Players", "Look at nearby real players", lookClose));
            boolean swingArm = (Boolean)this.swingArmEnabled.getOrDefault(fakePlayerName, true);
            inv.setItem(12, this.createToggleItem(Material.DIAMOND_SWORD, String.valueOf(ChatColor.GOLD) + "Swing Arm", "Periodically swing arm", swingArm));
            boolean physics = (Boolean)this.physicsEnabled.getOrDefault(fakePlayerName, this.globalPhysicsEnabled);
            inv.setItem(13, this.createToggleItem(Material.SHIELD, String.valueOf(ChatColor.RED) + "Knockback Mode", "Fake player takes knockback when hit", physics));
            boolean noDamage = (Boolean)this.noDamageEnabled.getOrDefault(fakePlayerName, false);
            inv.setItem(14, this.createToggleItem(Material.GOLDEN_APPLE, String.valueOf(ChatColor.AQUA) + "No Damage", "Fake player takes no damage at all", noDamage));
            boolean isFollowing = this.followModeManager != null && this.followModeManager.isFollowing(uuid);
            Player targetPlayer = this.followModeManager != null ? this.followModeManager.getTarget(uuid) : null;
            String followStatus = isFollowing && targetPlayer != null ? "&aFollowing: &f" + targetPlayer.getName() : "&cNot following anyone";
            String followInstruction = isFollowing ? "&eClick to stop following" : "&eClick to choose who to follow";
            String followDescription = followStatus + "\n" + followInstruction;
            inv.setItem(15, this.createControlItem(Material.COMPASS, String.valueOf(ChatColor.AQUA) + "Follow Mode", followDescription));
            inv.setItem(22, this.createInfoItem(fake));
            inv.setItem(31, this.createControlItem(Material.BARRIER, String.valueOf(ChatColor.RED) + "Remove Fake Player", "Click to remove this fake player"));
            inv.setItem(40, this.createControlItem(Material.ARROW, String.valueOf(ChatColor.YELLOW) + "Back", "Return to main menu"));
            player.openInventory(inv);
         }
      }

   }

   private ItemStack createPlayerItem(SimpleFakePlayerManager.FakePlayerData fake) {
      Material material = Material.PLAYER_HEAD;
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         String var10001 = String.valueOf(ChatColor.AQUA);
         meta.setDisplayName(var10001 + fake.getName());
         String var10000 = String.valueOf(ChatColor.GRAY);
         String lore = var10000 + "UUID: " + fake.getUuid().toString().substring(0, 8) + "...\n" + String.valueOf(ChatColor.GRAY) + "Rank: " + (fake.getRank() != null ? fake.getRank() : "default") + "\n" + String.valueOf(ChatColor.GRAY) + "Movement: " + ((Boolean)this.movementEnabled.getOrDefault(fake.getName(), true) ? String.valueOf(ChatColor.GREEN) + "Enabled" : String.valueOf(ChatColor.RED) + "Disabled") + "\n" + String.valueOf(ChatColor.YELLOW) + "Click to edit settings";
         List<String> loreList = Arrays.asList(lore.split("\n"));
         meta.setLore(loreList);
         item.setItemMeta(meta);
      }

      return item;
   }

   private ItemStack createToggleItem(Material material, String name, String description, boolean enabled) {
      ItemStack item = new ItemStack(enabled ? Material.LIME_DYE : Material.GRAY_DYE);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(name + ": " + (enabled ? String.valueOf(ChatColor.GREEN) + "ON" : String.valueOf(ChatColor.RED) + "OFF"));
         List<String> loreList = Arrays.asList(ChatColor.translateAlternateColorCodes('&', description).split("\n"));
         meta.setLore(loreList);
         item.setItemMeta(meta);
      }

      return item;
   }

   private ItemStack createInfoItem(SimpleFakePlayerManager.FakePlayerData fake) {
      ItemStack item = new ItemStack(Material.BOOK);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(String.valueOf(ChatColor.WHITE) + "Player Info");
         String var10000 = String.valueOf(ChatColor.GRAY);
         String lore = var10000 + "Name: " + String.valueOf(ChatColor.WHITE) + fake.getName() + "\n" + String.valueOf(ChatColor.GRAY) + "UUID: " + String.valueOf(ChatColor.WHITE) + fake.getUuid().toString() + "\n" + String.valueOf(ChatColor.GRAY) + "Skin: " + String.valueOf(ChatColor.WHITE) + fake.getSkinName() + "\n" + String.valueOf(ChatColor.GRAY) + "Rank: " + String.valueOf(ChatColor.WHITE) + (fake.getRank() != null ? fake.getRank() : "default") + "\n" + String.valueOf(ChatColor.GRAY) + "World: " + String.valueOf(ChatColor.WHITE) + (fake.getSpawnLocation().getWorld() != null ? fake.getSpawnLocation().getWorld().getName() : "unknown") + "\n" + String.valueOf(ChatColor.GRAY) + "Position: " + String.valueOf(ChatColor.WHITE) + String.format("%.0f, %.0f, %.0f", fake.getSpawnLocation().getX(), fake.getSpawnLocation().getY(), fake.getSpawnLocation().getZ());
         List<String> loreList = Arrays.asList(lore.split("\n"));
         meta.setLore(loreList);
         item.setItemMeta(meta);
      }

      return item;
   }

   private ItemStack createControlItem(Material material, String name, String description) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(name);
         if (!description.isEmpty()) {
            List<String> loreList = Arrays.asList(ChatColor.translateAlternateColorCodes('&', description).split("\n"));
            meta.setLore(loreList);
         }

         item.setItemMeta(meta);
      }

      return item;
   }

   public void openFollowTargetSelector(Player player, String fakePlayerName) {
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager != null) {
         SimpleFakePlayerManager.FakePlayerData fake = manager.getFakePlayer(fakePlayerName);
         if (fake == null) {
            player.sendMessage(String.valueOf(ChatColor.RED) + "Fake player not found!");
         } else {
            String[] var10000 = String.valueOf(ChatColor.DARK_AQUA);
            String title = var10000 + "Select Target for " + fake.getName();
            Inventory inv = Bukkit.createInventory((InventoryHolder)null, 54, title);
            int slot = 0;

            for(Player onlinePlayer : Bukkit.getOnlinePlayers()) {
               boolean isFake = false;

               for(SimpleFakePlayerManager.FakePlayerData fakeData : manager.getAllFakePlayers()) {
                  if (fakeData.getUuid().equals(onlinePlayer.getUniqueId())) {
                     isFake = true;
                     break;
                  }
               }

               if (!isFake) {
                  ItemStack playerItem = new ItemStack(Material.PLAYER_HEAD);
                  ItemMeta meta = playerItem.getItemMeta();
                  if (meta != null) {
                     String var10001 = String.valueOf(ChatColor.GREEN);
                     meta.setDisplayName(var10001 + onlinePlayer.getName());
                     String playerWorld = onlinePlayer.getWorld() != null ? onlinePlayer.getWorld().getName() : "unknown";
                     var10000 = new String[4];
                     String var10003 = String.valueOf(ChatColor.GRAY);
                     var10000[0] = var10003 + "World: " + String.valueOf(ChatColor.WHITE) + playerWorld;
                     var10003 = String.valueOf(ChatColor.GRAY);
                     var10000[1] = var10003 + "Health: " + String.valueOf(ChatColor.RED) + String.format("%.1f", onlinePlayer.getHealth()) + "/" + String.format("%.1f", onlinePlayer.getMaxHealth());
                     var10000[2] = "";
                     var10003 = String.valueOf(ChatColor.YELLOW);
                     var10000[3] = var10003 + "Click to make " + fake.getName() + " follow this player";
                     List<String> lore = Arrays.asList(var10000);
                     meta.setLore(lore);
                     playerItem.setItemMeta(meta);
                  }

                  inv.setItem(slot, playerItem);
                  ++slot;
                  if (slot >= 45) {
                     break;
                  }
               }
            }

            if (slot == 0) {
               inv.setItem(22, this.createControlItem(Material.BARRIER, String.valueOf(ChatColor.RED) + "No Players Found", "There are no real players online"));
            }

            inv.setItem(49, this.createControlItem(Material.ARROW, String.valueOf(ChatColor.YELLOW) + "Back", "Return to player settings"));
            player.openInventory(inv);
         }
      }

   }

   public boolean handleFollowTargetClick(Player player, String title, int slot, ItemStack clickedItem) {
      if (!title.startsWith(String.valueOf(ChatColor.DARK_AQUA) + "Select Target for ")) {
         return false;
      } else {
         String fakePlayerName = title.substring((String.valueOf(ChatColor.DARK_AQUA) + "Select Target for ").length());
         if (slot == 49) {
            this.openPlayerSettings(player, fakePlayerName);
            return true;
         } else if (clickedItem != null && clickedItem.getType() == Material.PLAYER_HEAD) {
            String targetPlayerName = ChatColor.stripColor(clickedItem.getItemMeta().getDisplayName());
            Player targetPlayer = Bukkit.getPlayer(targetPlayerName);
            if (targetPlayer != null && targetPlayer.isOnline()) {
               SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
               if (manager == null) {
                  return false;
               } else {
                  SimpleFakePlayerManager.FakePlayerData fake = manager.getFakePlayer(fakePlayerName);
                  if (fake == null) {
                     player.sendMessage(String.valueOf(ChatColor.RED) + "Fake player not found!");
                     return true;
                  } else {
                     if (this.followModeManager != null) {
                        this.followModeManager.startFollowing(fake.getPlayer(), targetPlayer);
                        String var10001 = String.valueOf(ChatColor.GREEN);
                        player.sendMessage(var10001 + fake.getName() + " is now following " + targetPlayer.getName() + "!");
                     }

                     this.openPlayerSettings(player, fakePlayerName);
                     return true;
                  }
               }
            } else {
               player.sendMessage(String.valueOf(ChatColor.RED) + "That player is no longer online!");
               this.openFollowTargetSelector(player, fakePlayerName);
               return true;
            }
         } else {
            return false;
         }
      }
   }

   public boolean handleClick(Player player, String title, int slot, ItemStack clickedItem, boolean isRightClick) {
      if (title.startsWith(String.valueOf(ChatColor.DARK_AQUA) + "Fake Players")) {
         if (clickedItem != null && clickedItem.getType() == Material.PLAYER_HEAD) {
            String fakeName = ChatColor.stripColor(clickedItem.getItemMeta().getDisplayName());
            this.openPlayerSettings(player, fakeName);
            return true;
         }

         if (slot == 46) {
            this.openGlobalSettings(player);
            return true;
         }

         if (slot == 47) {
            this.openHooksGUI(player);
            return true;
         }

         if (slot == 48) {
            this.openMainGUI(player);
            return true;
         }

         if (slot == 49) {
            this.openSetLocationGUI(player);
            return true;
         }

         if (slot == 50) {
            this.openFluctuationGUI(player);
            return true;
         }
      } else if (title.startsWith(String.valueOf(ChatColor.GOLD) + "SetLocation")) {
         switch (slot) {
            case 10:
               this.setSpawnLocation(player);
               this.openSetLocationGUI(player);
               return true;
            case 11:
               this.addFluctuationPoint(player);
               this.openSetLocationGUI(player);
               return true;
            case 12:
               this.openViewPointsGUI(player);
               return true;
            case 49:
               this.openMainGUI(player);
               return true;
         }
      } else if (title.startsWith(String.valueOf(ChatColor.YELLOW) + "Spawn Points")) {
         if (slot == 49) {
            this.openSetLocationGUI(player);
            return true;
         }

         if (slot >= 10 && slot < 45 && clickedItem != null) {
            int pointIndex = slot - 10;
            if (pointIndex < this.fluctuationSpawnPoints.size()) {
               String removed = (String)this.fluctuationSpawnPoints.get(pointIndex);
               this.removeFluctuationPoint(pointIndex);
               String var64 = String.valueOf(ChatColor.RED);
               player.sendMessage(var64 + "Removed spawn point: " + String.valueOf(ChatColor.WHITE) + removed);
               this.openViewPointsGUI(player);
               return true;
            }
         }
      } else if (title.startsWith(String.valueOf(ChatColor.YELLOW) + "Fluctuation Settings")) {
         FileConfiguration fakesConfig = this.plugin.getConfigManager().getFakesConfig();
         switch (slot) {
            case 10:
               boolean enabled = !fakesConfig.getBoolean("fluctuation.enabled", true);
               this.updateFluctuationSetting("fluctuation.enabled", enabled);
               String var63 = String.valueOf(enabled ? ChatColor.GREEN : ChatColor.RED);
               player.sendMessage(var63 + "Fluctuation " + (enabled ? "enabled" : "disabled"));
               this.openFluctuationGUI(player);
               return true;
            case 11:
               int minOnline = fakesConfig.getInt("fluctuation.min-online", 2);
               minOnline = isRightClick ? minOnline + 1 : Math.max(0, minOnline - 1);
               this.updateFluctuationSetting("fluctuation.min-online", minOnline);
               String var62 = String.valueOf(ChatColor.AQUA);
               player.sendMessage(var62 + "Min Online set to: " + String.valueOf(ChatColor.WHITE) + minOnline);
               this.openFluctuationGUI(player);
               return true;
            case 12:
               int maxOnline = fakesConfig.getInt("fluctuation.max-online", 15);
               maxOnline = isRightClick ? maxOnline + 5 : Math.max(1, maxOnline - 5);
               this.updateFluctuationSetting("fluctuation.max-online", maxOnline);
               String var61 = String.valueOf(ChatColor.LIGHT_PURPLE);
               player.sendMessage(var61 + "Max Online set to: " + String.valueOf(ChatColor.WHITE) + maxOnline);
               this.openFluctuationGUI(player);
               return true;
            case 13:
               int minPlayers = fakesConfig.getInt("fluctuation.min-players-online", 2);
               minPlayers = isRightClick ? minPlayers + 1 : Math.max(0, minPlayers - 1);
               this.updateFluctuationSetting("fluctuation.min-players-online", minPlayers);
               String var60 = String.valueOf(ChatColor.GOLD);
               player.sendMessage(var60 + "Min Real Players set to: " + String.valueOf(ChatColor.WHITE) + minPlayers);
               this.openFluctuationGUI(player);
               return true;
            case 14:
               int checkInterval = fakesConfig.getInt("fluctuation.check-interval", 600);
               checkInterval = isRightClick ? checkInterval + 100 : Math.max(20, checkInterval - 100);
               this.updateFluctuationSetting("fluctuation.check-interval", checkInterval);
               String var59 = String.valueOf(ChatColor.YELLOW);
               player.sendMessage(var59 + "Check Interval set to: " + String.valueOf(ChatColor.WHITE) + checkInterval + " ticks");
               this.openFluctuationGUI(player);
               return true;
            case 15:
               int maxPerCheck = fakesConfig.getInt("fluctuation.max-players-per-check", 1);
               maxPerCheck = isRightClick ? maxPerCheck + 1 : Math.max(1, maxPerCheck - 1);
               this.updateFluctuationSetting("fluctuation.max-players-per-check", maxPerCheck);
               String var58 = String.valueOf(ChatColor.WHITE);
               player.sendMessage(var58 + "Max Per Check set to: " + String.valueOf(ChatColor.YELLOW) + maxPerCheck);
               this.openFluctuationGUI(player);
               return true;
            case 16:
               boolean allowLeaving = !fakesConfig.getBoolean("fluctuation.allow-leaving", true);
               this.updateFluctuationSetting("fluctuation.allow-leaving", allowLeaving);
               String var57 = String.valueOf(allowLeaving ? ChatColor.GREEN : ChatColor.RED);
               player.sendMessage(var57 + "Fake player leaving " + (allowLeaving ? "enabled" : "disabled"));
               if (this.plugin.getFluctuationManager() != null) {
                  this.plugin.getFluctuationManager().reloadSettings();
               }

               this.openFluctuationGUI(player);
               return true;
            case 17:
            case 18:
            case 21:
            case 22:
            case 23:
            case 24:
            case 25:
            case 26:
            case 27:
            case 28:
            case 29:
            case 30:
            case 31:
            case 32:
            case 33:
            case 34:
            case 35:
            case 36:
            case 37:
            case 38:
            case 39:
            case 40:
            case 41:
            case 42:
            case 43:
            case 44:
            case 45:
            case 46:
            case 47:
            case 48:
            default:
               break;
            case 19:
               boolean startupEnabled = !fakesConfig.getBoolean("fluctuation.startup.enabled", true);
               this.updateFluctuationSetting("fluctuation.startup.enabled", startupEnabled);
               String var56 = String.valueOf(startupEnabled ? ChatColor.GREEN : ChatColor.RED);
               player.sendMessage(var56 + "Startup Gradual Spawn " + (startupEnabled ? "enabled" : "disabled"));
               this.openFluctuationGUI(player);
               return true;
            case 20:
               int batchSize = fakesConfig.getInt("fluctuation.startup.batch-size", 2);
               batchSize = isRightClick ? batchSize + 1 : Math.max(1, batchSize - 1);
               this.updateFluctuationSetting("fluctuation.startup.batch-size", batchSize);
               String var55 = String.valueOf(ChatColor.AQUA);
               player.sendMessage(var55 + "Startup Batch Size set to: " + String.valueOf(ChatColor.WHITE) + batchSize);
               this.openFluctuationGUI(player);
               return true;
            case 49:
               this.openMainGUI(player);
               return true;
         }
      } else if (title.startsWith(String.valueOf(ChatColor.DARK_AQUA) + "Global Settings")) {
         SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
         if (manager == null) {
            return false;
         }

         switch (slot) {
            case 2:
               this.maxPing = isRightClick ? Math.min(1000, this.maxPing + 25) : Math.max(25, this.maxPing - 25);
               this.plugin.getConfig().set("global-settings.max-ping", this.maxPing);
               this.plugin.saveConfig();
               String var54 = String.valueOf(ChatColor.GREEN);
               player.sendMessage(var54 + "Max Ping set to: " + String.valueOf(ChatColor.WHITE) + this.maxPing + " ms");
               this.openGlobalSettings(player);
               return true;
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 18:
            case 21:
            case 22:
            case 23:
            case 24:
            case 25:
            case 26:
            case 27:
            case 28:
            case 29:
            case 30:
            case 31:
            case 32:
            case 33:
            case 34:
            case 35:
            case 36:
            case 37:
            case 38:
            case 39:
            case 40:
            case 41:
            case 42:
            case 43:
            case 44:
            case 45:
            case 46:
            case 47:
            case 48:
            case 49:
            case 50:
            default:
               break;
            case 10:
               this.globalMovementEnabled = !this.globalMovementEnabled;
               this.applyGlobalMovement(player, this.globalMovementEnabled);
               this.saveGlobalSettings();
               this.openGlobalSettings(player);
               return true;
            case 11:
               this.globalLookCloseEnabled = !this.globalLookCloseEnabled;
               this.applyGlobalLookClose(player, this.globalLookCloseEnabled);
               this.saveGlobalSettings();
               this.openGlobalSettings(player);
               return true;
            case 12:
               this.globalSwingArmEnabled = !this.globalSwingArmEnabled;
               this.applyGlobalSwingArm(player, this.globalSwingArmEnabled);
               this.saveGlobalSettings();
               this.openGlobalSettings(player);
               return true;
            case 13:
               this.globalPhysicsEnabled = !this.globalPhysicsEnabled;
               this.applyGlobalPhysics(player, this.globalPhysicsEnabled);
               this.saveGlobalSettings();
               this.openGlobalSettings(player);
               return true;
            case 14:
               this.globalNoDamageEnabled = !this.globalNoDamageEnabled;
               this.applyGlobalNoDamage(player, this.globalNoDamageEnabled);
               this.saveGlobalSettings();
               this.openGlobalSettings(player);
               return true;
            case 15:
               this.globalHideBodiesEnabled = !this.globalHideBodiesEnabled;
               this.applyGlobalHideBodies(player, this.globalHideBodiesEnabled);
               this.saveGlobalSettings();
               this.openGlobalSettings(player);
               return true;
            case 16:
               this.globalFollowModeEnabled = !this.globalFollowModeEnabled;
               this.applyGlobalFollowMode(player, this.globalFollowModeEnabled);
               this.saveGlobalSettings();
               this.openGlobalSettings(player);
               return true;
            case 17:
               this.globalHeadMovementEnabled = !this.globalHeadMovementEnabled;
               this.applyGlobalHeadMovement(player, this.globalHeadMovementEnabled);
               this.saveGlobalSettings();
               this.openGlobalSettings(player);
               return true;
            case 19:
               this.globalJoinLeaveMessagesEnabled = !this.globalJoinLeaveMessagesEnabled;
               this.plugin.getConfigManager().setBroadcastJoinEnabled(this.globalJoinLeaveMessagesEnabled);
               this.plugin.getConfigManager().setBroadcastQuitEnabled(this.globalJoinLeaveMessagesEnabled);
               String var53 = String.valueOf(ChatColor.GREEN);
               player.sendMessage(var53 + "Join/Leave messages: " + (this.globalJoinLeaveMessagesEnabled ? "Enabled" : "Disabled"));
               this.saveGlobalSettings();
               this.openGlobalSettings(player);
               return true;
            case 20:
               SimpleFakePlayerManager mgr = this.plugin.getSimpleFakePlayerManager();
               if (mgr != null) {
                  Location targetLoc = player.getLocation();
                  int teleported = 0;

                  for(Player fakePlayer : Bukkit.getOnlinePlayers()) {
                     if (mgr.isFakePlayer(fakePlayer.getUniqueId())) {
                        fakePlayer.teleport(targetLoc);
                        ++teleported;
                     }
                  }

                  String var52 = String.valueOf(ChatColor.GREEN);
                  player.sendMessage(var52 + "Teleported " + teleported + " fake players to your location!");
               }

               this.openGlobalSettings(player);
               return true;
            case 51:
               this.applyGlobalMovement(player, true);
               this.globalMovementEnabled = true;
               this.applyGlobalLookClose(player, true);
               this.globalLookCloseEnabled = true;
               this.applyGlobalSwingArm(player, true);
               this.globalSwingArmEnabled = true;
               this.applyGlobalPhysics(player, true);
               this.globalPhysicsEnabled = true;
               this.applyGlobalNoDamage(player, true);
               this.globalNoDamageEnabled = true;
               this.saveGlobalSettings();
               player.sendMessage(String.valueOf(ChatColor.GREEN) + "All features enabled!");
               this.openGlobalSettings(player);
               return true;
            case 52:
               this.applyGlobalMovement(player, false);
               this.applyGlobalLookClose(player, false);
               this.applyGlobalSwingArm(player, false);
               this.applyGlobalPhysics(player, false);
               this.applyGlobalNoDamage(player, false);
               this.globalMovementEnabled = false;
               this.globalLookCloseEnabled = false;
               this.globalSwingArmEnabled = false;
               this.globalPhysicsEnabled = false;
               this.globalNoDamageEnabled = false;
               this.saveGlobalSettings();
               player.sendMessage(String.valueOf(ChatColor.RED) + "All features disabled!");
               this.openGlobalSettings(player);
               return true;
            case 53:
               this.openMainGUI(player);
               return true;
         }
      } else if (title.startsWith(String.valueOf(ChatColor.DARK_AQUA) + "Settings: ")) {
         String fakeName = title.substring((String.valueOf(ChatColor.DARK_AQUA) + "Settings: ").length());
         SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
         if (manager == null) {
            return false;
         }

         SimpleFakePlayerManager.FakePlayerData fake = manager.getFakePlayer(fakeName);
         if (fake == null) {
            return false;
         }

         UUID uuid = fake.getUuid();
         switch (slot) {
            case 10:
               boolean newState = !(Boolean)this.movementEnabled.getOrDefault(fakeName, true);
               this.movementEnabled.put(fakeName, newState);
               if (newState) {
                  this.startMovement(fakeName, fake);
                  this.plugin.getSimpleFakePlayerManager().getNMSHandler().setGuiMovementEnabled(uuid, true);
               } else {
                  this.stopMovement(fakeName);
                  this.plugin.getSimpleFakePlayerManager().getNMSHandler().setGuiMovementEnabled(uuid, false);
               }

               String var51 = String.valueOf(ChatColor.GREEN);
               player.sendMessage(var51 + "Movement " + (newState ? "enabled" : "disabled") + " for " + fakeName);
               this.openPlayerSettings(player, fakeName);
               return true;
            case 11:
               boolean currentLookState = this.plugin.getSimpleFakePlayerManager().isLookingAtPlayers(uuid);
               boolean newLookState = !currentLookState;
               this.plugin.getSimpleFakePlayerManager().setLookAtPlayers(uuid, newLookState);
               String var50 = String.valueOf(ChatColor.YELLOW);
               player.sendMessage(var50 + "Look at players " + (newLookState ? "enabled" : "disabled") + " for " + fakeName);
               this.openPlayerSettings(player, fakeName);
               return true;
            case 12:
               boolean newSwingState = !(Boolean)this.swingArmEnabled.getOrDefault(fakeName, true);
               this.swingArmEnabled.put(fakeName, newSwingState);
               this.plugin.getSimpleFakePlayerManager().getNMSHandler().setSwingArmEnabled(uuid, newSwingState);
               if (newSwingState) {
                  this.startSwingingArm(fakeName, fake);
               } else {
                  this.stopSwingingArm(fakeName);
               }

               String var49 = String.valueOf(ChatColor.YELLOW);
               player.sendMessage(var49 + "Swing arm " + (newSwingState ? "enabled" : "disabled") + " for " + fakeName);
               this.openPlayerSettings(player, fakeName);
               return true;
            case 13:
               boolean newPhysicsState = !(Boolean)this.physicsEnabled.getOrDefault(fakeName, false);
               this.physicsEnabled.put(fakeName, newPhysicsState);
               ChatColor color = newPhysicsState ? ChatColor.GREEN : ChatColor.RED;
               String var48 = String.valueOf(color);
               player.sendMessage(var48 + "Knockback mode " + (newPhysicsState ? "enabled" : "disabled") + " for " + fakeName);
               this.openPlayerSettings(player, fakeName);
               return true;
            case 14:
               boolean newNoDamageState = !(Boolean)this.noDamageEnabled.getOrDefault(fakeName, false);
               this.noDamageEnabled.put(fakeName, newNoDamageState);
               ChatColor noDmgColor = newNoDamageState ? ChatColor.GREEN : ChatColor.RED;
               String var47 = String.valueOf(noDmgColor);
               player.sendMessage(var47 + "No damage " + (newNoDamageState ? "enabled" : "disabled") + " for " + fakeName);
               this.openPlayerSettings(player, fakeName);
               return true;
            case 15:
               if (this.followModeManager != null) {
                  boolean isCurrentlyFollowing = this.followModeManager.isFollowing(uuid);
                  if (isCurrentlyFollowing) {
                     this.followModeManager.stopFollowing(uuid);
                     String var46 = String.valueOf(ChatColor.YELLOW);
                     player.sendMessage(var46 + fakeName + " is no longer following anyone.");
                     this.openPlayerSettings(player, fakeName);
                  } else {
                     this.openFollowTargetSelector(player, fakeName);
                  }
               }

               return true;
            case 31:
               this.stopMovement(fakeName);
               this.movementEnabled.remove(fakeName);
               this.plugin.getSimpleFakePlayerManager().getNMSHandler().setGuiMovementEnabled(uuid, false);
               this.swingArmEnabled.remove(fakeName);
               this.stopSwingingArm(fakeName);
               this.pathfinding.stopPathfinding(uuid);
               if (this.followModeManager != null) {
                  this.followModeManager.stopFollowing(uuid);
               }

               manager.despawnFakePlayer(fakeName);
               String var10001 = String.valueOf(ChatColor.RED);
               player.sendMessage(var10001 + "Removed fake player: " + fakeName);
               this.openMainGUI(player);
               return true;
            case 40:
               this.openMainGUI(player);
               return true;
         }
      } else if (title.startsWith(String.valueOf(ChatColor.DARK_PURPLE) + "Plugin Hooks")) {
         if (slot == 49) {
            this.openMainGUI(player);
            return true;
         }

         if (clickedItem != null && (clickedItem.getType() == Material.LIME_DYE || clickedItem.getType() == Material.GRAY_DYE)) {
            String displayName = clickedItem.getItemMeta() != null ? clickedItem.getItemMeta().getDisplayName() : "";
            String hookName = ChatColor.stripColor(displayName).split(":")[0].trim();
            this.toggleHook(player, hookName);
            this.openHooksGUI(player);
            return true;
         }
      }

      return false;
   }

   private void startMovement(String fakeName, SimpleFakePlayerManager.FakePlayerData fake) {
      this.stopMovement(fakeName);
      Random rng = new Random();
      double[] target = new double[]{(double)0.0F, (double)0.0F, (double)0.0F};
      double[] vel = new double[]{(double)0.0F};
      double[] preJumpY = new double[]{Double.NaN};
      boolean[] state = new boolean[]{true, false};
      int[] counters = new int[]{0, 0, 0, 0, 0};
      Location[] prev = new Location[]{fake.getPlayer().getLocation().clone()};
      Location spawnLoc = fake.getPlayer().getLocation().clone();
      int MOVE_TICKS = 240;
      int PAUSE_TICKS = 100;
      int SPRINT_TICKS = 120;
      int TOTAL_CYCLE = 460;
      this.pickNewTarget(target, spawnLoc, rng);
      BukkitTask task = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
         SimpleFakePlayerManager.FakePlayerData data = this.plugin.getSimpleFakePlayerManager().getFakePlayer(fakeName);
         if (data != null && (Boolean)this.movementEnabled.getOrDefault(fakeName, true)) {
            Player fp = data.getPlayer();
            if (fp != null && fp.isOnline()) {
               Location loc = fp.getLocation().clone();
               World world = loc.getWorld();
               if (world != null) {
                  int var10002 = counters[0]++;
                  if (counters[1] > 0) {
                     var10002 = counters[1]--;
                  }

                  int cyclePos = counters[0] % 460;
                  boolean paused = cyclePos >= 240 && cyclePos < 340;
                  boolean sprinting = cyclePos >= 340;
                  double speed = sprinting ? 0.19 : 0.12;
                  if (paused) {
                     state[0] = false;
                     double newY = this.applyWanderVertical(world, loc.getX(), loc.getY(), loc.getZ(), vel, state, preJumpY, fakeName, fp);
                     Location standLoc = loc.clone();
                     standLoc.setY(newY);
                     this.plugin.getSimpleFakePlayerManager().getNMSHandler().updatePosition(fp, standLoc, false);
                     prev[0] = standLoc;
                  } else {
                     state[0] = true;
                     double dx = target[0] - loc.getX();
                     double dz = target[1] - loc.getZ();
                     double distToTarget = Math.sqrt(dx * dx + dz * dz);
                     if (distToTarget < (double)1.0F) {
                        this.pickNewTarget(target, loc, rng);
                        dx = target[0] - loc.getX();
                        dz = target[1] - loc.getZ();
                        distToTarget = Math.sqrt(dx * dx + dz * dz);
                     }

                     double dirX = distToTarget > 0.01 ? dx / distToTarget : (double)0.0F;
                     double dirZ = distToTarget > 0.01 ? dz / distToTarget : (double)0.0F;
                     double moveX = dirX * speed;
                     double moveZ = dirZ * speed;
                     double newX = loc.getX() + moveX;
                     double newZ = loc.getZ() + moveZ;
                     double curY = loc.getY();
                     boolean onLadder = this.isClimbableBlock(world, loc.getX(), curY, loc.getZ()) || this.isClimbableBlock(world, loc.getX(), curY + (double)0.5F, loc.getZ());
                     boolean inWater = this.isWaterBlock(world, loc.getX(), curY, loc.getZ()) || this.isWaterBlock(world, loc.getX(), curY + (double)0.5F, loc.getZ());
                     if (onLadder) {
                        double ladderSpeed = 0.09;
                        double newY = curY + ladderSpeed;
                        if (!this.isClimbableBlock(world, loc.getX(), newY + (double)1.0F, loc.getZ())) {
                           newY = curY + ladderSpeed;
                        }

                        newX = loc.getX() + moveX * 0.2;
                        newZ = loc.getZ() + moveZ * 0.2;
                        vel[0] = (double)0.0F;
                        state[1] = false;
                        var10002 = counters[3]--;
                        if (counters[3] <= 0) {
                           world.playSound(new Location(world, newX, newY, newZ), Sound.BLOCK_LADDER_STEP, 0.35F, 0.9F + rng.nextFloat() * 0.2F);
                           counters[3] = 6;
                        }

                        float yaw = this.calcMovementYaw(dirX, dirZ, loc.getYaw());
                        Location newLoc = new Location(world, newX, newY, newZ, yaw, 0.0F);
                        this.plugin.getSimpleFakePlayerManager().getNMSHandler().updatePosition(fp, newLoc, false);
                        prev[0] = newLoc;
                     } else if (inWater) {
                        var10002 = counters[4]++;
                        double waterSurface = this.findWaterSurface(world, loc.getX(), curY, loc.getZ());
                        double targetWaterY = waterSurface + 0.4;
                        double bob = Math.sin((double)counters[4] * 0.3) * 0.04;
                        double newYx;
                        if (curY < targetWaterY - 0.1) {
                           newYx = curY + 0.08;
                        } else if (curY > targetWaterY + 0.2) {
                           newYx = curY - 0.04;
                        } else {
                           newYx = targetWaterY + bob;
                        }

                        vel[0] = (double)0.0F;
                        state[1] = false;
                        speed *= 0.6;
                        newX = loc.getX() + dirX * speed;
                        newZ = loc.getZ() + dirZ * speed;
                        float yaw = this.calcMovementYaw(dirX, dirZ, loc.getYaw());
                        Location newLoc = new Location(world, newX, newYx, newZ, yaw, 0.0F);
                        this.plugin.getSimpleFakePlayerManager().getNMSHandler().updatePosition(fp, newLoc, false);
                        prev[0] = newLoc;
                     } else {
                        boolean feetBlocked = this.isSolidBlock(world, newX, curY + 0.1, newZ) || this.isSolidBlock(world, newX, curY + (double)0.5F, newZ);
                        if (feetBlocked && !state[1] && counters[1] <= 0) {
                           double destGY = this.findWanderGroundY(world, newX, curY + (double)3.0F, newZ);
                           double heightDiff = destGY - curY;
                           boolean clearAbove = !this.isSolidBlock(world, loc.getX(), curY + (double)1.0F, loc.getZ()) && !this.isSolidBlock(world, loc.getX(), curY + (double)2.0F, loc.getZ());
                           boolean canJump = heightDiff > 0.1 && heightDiff <= 1.05 && clearAbove && !this.isSolidBlock(world, newX, destGY + (double)1.0F, newZ);
                           if (canJump) {
                              preJumpY[0] = curY;
                              vel[0] = 0.42;
                              state[1] = true;
                              counters[1] = 15;
                              if (sprinting) {
                                 moveX *= 1.2;
                                 moveZ *= 1.2;
                              }

                              newX = loc.getX() + moveX;
                              newZ = loc.getZ() + moveZ;
                           } else {
                              this.pickNewTarget(target, loc, rng);
                              newX = loc.getX();
                              newZ = loc.getZ();
                           }
                        } else if (feetBlocked) {
                           double leftX = loc.getX() + -dirZ * speed;
                           double leftZ = loc.getZ() + dirX * speed;
                           if (!this.isSolidBlock(world, leftX, curY + 0.1, leftZ) && !this.isSolidBlock(world, leftX, curY + (double)1.0F, leftZ)) {
                              newX = leftX;
                              newZ = leftZ;
                           } else {
                              double rightX = loc.getX() + dirZ * speed;
                              double rightZ = loc.getZ() + -dirX * speed;
                              if (!this.isSolidBlock(world, rightX, curY + 0.1, rightZ) && !this.isSolidBlock(world, rightX, curY + (double)1.0F, rightZ)) {
                                 newX = rightX;
                                 newZ = rightZ;
                              } else {
                                 this.pickNewTarget(target, loc, rng);
                                 newX = loc.getX();
                                 newZ = loc.getZ();
                              }
                           }
                        }

                        if (!state[1]) {
                           boolean groundAhead1 = this.isSolidBlock(world, newX, curY - (double)1.0F, newZ);
                           boolean groundAhead2 = this.isSolidBlock(world, newX, curY - (double)2.0F, newZ);
                           boolean groundAhead3 = this.isSolidBlock(world, newX, curY - (double)3.0F, newZ);
                           if (!groundAhead1 && !groundAhead2 && !groundAhead3) {
                              this.pickNewTarget(target, loc, rng);
                              newX = loc.getX();
                              newZ = loc.getZ();
                           }
                        }

                        if (sprinting && !state[1] && counters[1] <= 0 && !feetBlocked && !inWater && rng.nextInt(40) == 0) {
                           preJumpY[0] = curY;
                           vel[0] = 0.42;
                           state[1] = true;
                           counters[1] = 15;
                           newX = loc.getX() + moveX * 1.2;
                           newZ = loc.getZ() + moveZ * 1.2;
                        }

                        double newYx = this.applyWanderVertical(world, newX, curY, newZ, vel, state, preJumpY, fakeName, fp);
                        float yaw = this.calcMovementYaw(dirX, dirZ, loc.getYaw());
                        Location newLoc = new Location(world, newX, newYx, newZ, yaw, 0.0F);
                        if (prev[0] != null && prev[0].distanceSquared(newLoc) < 4.0E-4) {
                           var10002 = counters[2]++;
                           if (counters[2] > 40) {
                              this.pickNewTarget(target, loc, rng);
                              counters[2] = 0;
                              if (!state[1] && counters[1] <= 0) {
                                 preJumpY[0] = curY;
                                 vel[0] = 0.42;
                                 state[1] = true;
                                 counters[1] = 10;
                              }
                           }
                        } else {
                           counters[2] = 0;
                        }

                        double distFromSpawn = Math.sqrt(Math.pow(newX - spawnLoc.getX(), (double)2.0F) + Math.pow(newZ - spawnLoc.getZ(), (double)2.0F));
                        if (distFromSpawn > (double)30.0F) {
                           target[0] = spawnLoc.getX() + (rng.nextDouble() - (double)0.5F) * (double)10.0F;
                           target[1] = spawnLoc.getZ() + (rng.nextDouble() - (double)0.5F) * (double)10.0F;
                        }

                        prev[0] = newLoc;
                        this.plugin.getSimpleFakePlayerManager().getNMSHandler().updatePosition(fp, newLoc, false);
                     }
                  }
               }
            }
         } else {
            this.stopMovement(fakeName);
         }

      }, 1L, 1L);
      this.movementTasks.put(fakeName, task);
   }

   private void pickNewTarget(double[] target, Location from, Random rng) {
      double angle = rng.nextDouble() * Math.PI * (double)2.0F;
      double dist = (double)5.0F + rng.nextDouble() * (double)12.0F;
      target[0] = from.getX() + Math.cos(angle) * dist;
      target[1] = from.getZ() + Math.sin(angle) * dist;
   }

   private double applyWanderVertical(World world, double x, double curY, double z, double[] vel, boolean[] state, double[] preJumpY, String fakeName, Player fakePlayer) {
      double newY = curY;
      if (!state[1] && vel[0] == (double)0.0F) {
         double groundY = this.findWanderGroundY(world, x, curY + (double)2.0F, z);
         double diff = groundY - curY;
         if (diff < -0.15) {
            state[1] = true;
            vel[0] = (double)0.0F;
            FakePlayerDamageListener dl = this.getDamageListener();
            if (dl != null) {
               dl.setFallStart(fakeName, curY);
            }
         } else if (diff > 0.01 && diff <= 0.6) {
            newY = curY + Math.min(0.12, diff);
         } else if (diff > 0.6) {
            newY = curY;
         } else {
            newY = groundY;
         }
      } else {
         vel[0] -= 0.08;
         if (vel[0] < -3.92) {
            vel[0] = -3.92;
         }

         newY = curY + vel[0];
         double groundY = this.findWanderGroundY(world, x, curY + (double)2.0F, z);
         FakePlayerDamageListener dl = this.getDamageListener();
         if (dl != null && vel[0] < -0.1) {
            dl.setFallStart(fakeName, curY);
         }

         if (!Double.isNaN(preJumpY[0]) && groundY > preJumpY[0] + (double)1.25F) {
            if (newY <= curY && vel[0] <= (double)0.0F) {
               double lowerG = this.findWanderGroundY(world, x, preJumpY[0] + (double)1.5F, z);
               if (lowerG <= preJumpY[0] + (double)1.25F && lowerG >= (double)world.getMinHeight()) {
                  newY = lowerG;
                  vel[0] = (double)0.0F;
                  state[1] = false;
                  preJumpY[0] = Double.NaN;
                  if (dl != null && fakePlayer != null) {
                     dl.applyFallDamage(fakeName, fakePlayer, lowerG);
                  }
               }
            }
         } else if (newY <= groundY && vel[0] <= (double)0.0F) {
            newY = groundY;
            vel[0] = (double)0.0F;
            state[1] = false;
            preJumpY[0] = Double.NaN;
            if (dl != null && fakePlayer != null) {
               dl.applyFallDamage(fakeName, fakePlayer, groundY);
            }
         }

         if (vel[0] > (double)0.0F && this.isSolidBlock(world, x, newY + 1.8, z)) {
            vel[0] = (double)0.0F;
            Block ceil = world.getBlockAt((int)Math.floor(x), (int)Math.floor(newY + 1.85), (int)Math.floor(z));
            if (ceil.getType().isSolid()) {
               try {
                  world.spawnParticle(Particle.BLOCK, x, newY + 1.8, z, 5, 0.15, 0.02, 0.15, (double)0.0F, ceil.getBlockData());
               } catch (Exception var20) {
               }
            }
         }
      }

      if (newY < (double)(world.getMinHeight() + 1)) {
         newY = this.findWanderGroundY(world, x, (double)world.getMaxHeight(), z);
         vel[0] = (double)0.0F;
         state[1] = false;
         preJumpY[0] = Double.NaN;
      }

      return newY;
   }

   private double findWanderGroundY(World world, double x, double startY, double z) {
      double best = (double)world.getMinHeight();
      double hw = (double)0.25F;
      double[][] corners = new double[][]{{x - hw, z - hw}, {x + hw, z - hw}, {x - hw, z + hw}, {x + hw, z + hw}, {x, z}};

      for(double[] c : corners) {
         int sx = (int)Math.floor(c[0]);
         int sz = (int)Math.floor(c[1]);
         int sy = (int)Math.floor(startY);
         int minY = Math.max(world.getMinHeight(), sy - 25);

         for(int y = sy; y >= minY; --y) {
            Block at = world.getBlockAt(sx, y, sz);
            Block below = world.getBlockAt(sx, y - 1, sz);
            if (below.getType().isSolid() && !this.isActuallySolid(at)) {
               if ((double)y > best) {
                  best = (double)y;
               }
               break;
            }
         }
      }

      return best == (double)world.getMinHeight() ? startY : best;
   }

   private boolean isActuallySolid(Block block) {
      Material m = block.getType();
      if (!m.isAir() && m != Material.WATER && m != Material.LAVA) {
         if (m != Material.LADDER && m != Material.VINE) {
            if (!m.name().contains("TORCH") && !m.name().contains("SIGN") && !m.name().contains("BANNER")) {
               if (!m.name().contains("PRESSURE_PLATE") && !m.name().contains("BUTTON") && !m.name().contains("CARPET")) {
                  return m.name().contains("RAIL") ? false : m.isSolid();
               } else {
                  return false;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean isSolidBlock(World world, double x, double y, double z) {
      Block b = world.getBlockAt((int)Math.floor(x), (int)Math.floor(y), (int)Math.floor(z));
      return this.isActuallySolid(b);
   }

   private boolean isClimbableBlock(World world, double x, double y, double z) {
      Material m = world.getBlockAt((int)Math.floor(x), (int)Math.floor(y), (int)Math.floor(z)).getType();
      return m == Material.LADDER || m == Material.VINE || m.name().contains("CAVE_VINES") || m.name().contains("TWISTING_VINES") || m.name().contains("WEEPING_VINES");
   }

   private boolean isWaterBlock(World world, double x, double y, double z) {
      Material m = world.getBlockAt((int)Math.floor(x), (int)Math.floor(y), (int)Math.floor(z)).getType();
      return m == Material.WATER || m.name().equals("BUBBLE_COLUMN");
   }

   private double findWaterSurface(World world, double x, double y, double z) {
      int bx = (int)Math.floor(x);
      int bz = (int)Math.floor(z);
      int by = (int)Math.floor(y);

      for(int cy = by; cy < by + 10; ++cy) {
         if (world.getBlockAt(bx, cy, bz).getType() == Material.WATER && world.getBlockAt(bx, cy + 1, bz).getType() != Material.WATER) {
            return (double)cy;
         }
      }

      return y;
   }

   private float calcMovementYaw(double dirX, double dirZ, float fallback) {
      if (Double.isFinite(dirX) && Double.isFinite(dirZ) && (dirX != (double)0.0F || dirZ != (double)0.0F)) {
         float yaw = (float)Math.toDegrees(Math.atan2(-dirX, dirZ));
         return Float.isFinite(yaw) ? yaw : fallback;
      } else {
         return fallback;
      }
   }

   private void stopMovement(String fakeName) {
      BukkitTask task = (BukkitTask)this.movementTasks.remove(fakeName);
      if (task != null) {
         task.cancel();
      }

      SimpleFakePlayerManager.FakePlayerData fake = this.plugin.getSimpleFakePlayerManager().getFakePlayer(fakeName);
      if (fake != null) {
         this.plugin.getSimpleFakePlayerManager().getNMSHandler().setGuiMovementEnabled(fake.getUuid(), false);
      }

   }

   private void startSwingingArm(String fakeName, SimpleFakePlayerManager.FakePlayerData fake) {
      this.stopSwingingArm(fakeName);
      BukkitTask task = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
         SimpleFakePlayerManager.FakePlayerData data = this.plugin.getSimpleFakePlayerManager().getFakePlayer(fakeName);
         if (data != null && (Boolean)this.swingArmEnabled.getOrDefault(fakeName, false)) {
            this.plugin.getSimpleFakePlayerManager().getNMSHandler().performAction(data.getPlayer(), NMSHandler.FakePlayerAction.SWING_MAIN_ARM);
         } else {
            this.stopSwingingArm(fakeName);
         }

      }, 10L, 30L);
      this.swingArmTasks.put(fakeName, task);
   }

   private void stopSwingingArm(String fakeName) {
      BukkitTask task = (BukkitTask)this.swingArmTasks.remove(fakeName);
      if (task != null) {
         task.cancel();
      }

   }

   private void sendPacket(Player player, Object packet) {
      try {
         Object handle = player.getClass().getMethod("getHandle").invoke(player);
         Object connection = null;

         try {
            connection = handle.getClass().getField("connection").get(handle);
         } catch (Exception var9) {
            connection = handle.getClass().getField("playerConnection").get(handle);
         }

         if (connection != null) {
            for(Method m : connection.getClass().getMethods()) {
               if (m.getName().equals("send") && m.getParameterCount() == 1) {
                  m.invoke(connection, packet);
                  return;
               }
            }
         }
      } catch (Exception var10) {
      }

   }

   private FakePlayerDamageListener getDamageListener() {
      return this.plugin.getDamageListener();
   }

   private boolean hasFullCollision(Location loc) {
      double halfWidth = 0.3;
      double height = 1.8;
      double[] xOffsets = new double[]{-halfWidth + 0.05, halfWidth - 0.05};
      double[] zOffsets = new double[]{-halfWidth + 0.05, halfWidth - 0.05};

      for(int y = 0; (double)y < height; ++y) {
         for(double xOffset : xOffsets) {
            for(double zOffset : zOffsets) {
               Location checkLoc = new Location(loc.getWorld(), loc.getX() + xOffset, loc.getY() + (double)y, loc.getZ() + zOffset);
               if (checkLoc.getBlock().getType().isSolid()) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private boolean isOnGround(Location loc) {
      double groundY = this.getGroundHeight(loc);
      return Math.abs(loc.getY() - groundY) < 0.15;
   }

   private double getGroundHeight(Location loc) {
      double halfWidth = 0.3;
      double maxGroundY = Double.MIN_VALUE;
      boolean foundAnyGround = false;

      for(double xOffset = -halfWidth; xOffset <= halfWidth; xOffset += halfWidth * (double)2.0F) {
         for(double zOffset = -halfWidth; zOffset <= halfWidth; zOffset += halfWidth * (double)2.0F) {
            Location checkLoc = new Location(loc.getWorld(), loc.getX() + xOffset, loc.getY(), loc.getZ() + zOffset);

            for(int y = (int)Math.floor(loc.getY()); (double)y >= Math.floor(loc.getY()) - (double)5.0F; --y) {
               Location blockCheck = new Location(loc.getWorld(), checkLoc.getX(), (double)y, checkLoc.getZ());
               if (blockCheck.getBlock().getType().isSolid()) {
                  if ((double)(y + 1) > maxGroundY) {
                     maxGroundY = (double)(y + 1);
                     foundAnyGround = true;
                  }
                  break;
               }
            }
         }
      }

      return foundAnyGround ? maxGroundY : (double)(loc.getWorld().getMinHeight() + 1);
   }

   public boolean isPhysicsEnabled(String fakePlayerName) {
      return (Boolean)this.physicsEnabled.getOrDefault(fakePlayerName, this.globalPhysicsEnabled);
   }

   public boolean isNoDamageEnabled(String fakePlayerName) {
      return (Boolean)this.noDamageEnabled.getOrDefault(fakePlayerName, false);
   }

   private void applyGlobalMovement(Player player, boolean enabled) {
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager != null) {
         int count = 0;

         for(SimpleFakePlayerManager.FakePlayerData fake : manager.getAllFakePlayers()) {
            String fakeName = fake.getName();
            this.movementEnabled.put(fakeName, enabled);
            if (enabled) {
               this.startMovement(fakeName, fake);
               this.plugin.getSimpleFakePlayerManager().getNMSHandler().setGuiMovementEnabled(fake.getUuid(), true);
            } else {
               this.stopMovement(fakeName);
               this.plugin.getSimpleFakePlayerManager().getNMSHandler().setGuiMovementEnabled(fake.getUuid(), false);
            }

            ++count;
         }

         String var10001 = String.valueOf(ChatColor.GREEN);
         player.sendMessage(var10001 + "Movement " + (enabled ? "enabled" : "disabled") + " for " + count + " fake players");
      }

   }

   private void applyGlobalLookClose(Player player, boolean enabled) {
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager != null) {
         int count = 0;

         for(SimpleFakePlayerManager.FakePlayerData fake : manager.getAllFakePlayers()) {
            this.plugin.getSimpleFakePlayerManager().setLookAtPlayers(fake.getUuid(), enabled);
            ++count;
         }

         String var10001 = String.valueOf(ChatColor.YELLOW);
         player.sendMessage(var10001 + "Look at players " + (enabled ? "enabled" : "disabled") + " for " + count + " fake players");
      }

   }

   private void applyGlobalSwingArm(Player player, boolean enabled) {
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager != null) {
         int count = 0;

         for(SimpleFakePlayerManager.FakePlayerData fake : manager.getAllFakePlayers()) {
            String fakeName = fake.getName();
            UUID uuid = fake.getUuid();
            this.swingArmEnabled.put(fakeName, enabled);
            manager.getNMSHandler().setSwingArmEnabled(uuid, enabled);
            if (enabled) {
               this.startSwingingArm(fakeName, fake);
            } else {
               this.stopSwingingArm(fakeName);
            }

            ++count;
         }

         String var10001 = String.valueOf(ChatColor.GOLD);
         player.sendMessage(var10001 + "Swing arm " + (enabled ? "enabled" : "disabled") + " for " + count + " fake players");
      }

   }

   private void applyGlobalPhysics(Player player, boolean enabled) {
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager != null) {
         int count = 0;

         for(SimpleFakePlayerManager.FakePlayerData fake : manager.getAllFakePlayers()) {
            this.physicsEnabled.put(fake.getName(), enabled);
            ++count;
         }

         String var10001 = String.valueOf(ChatColor.RED);
         player.sendMessage(var10001 + "Knockback mode " + (enabled ? "enabled" : "disabled") + " for " + count + " fake players");
      }

   }

   private void applyGlobalNoDamage(Player player, boolean enabled) {
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager != null) {
         int count = 0;

         for(SimpleFakePlayerManager.FakePlayerData fake : manager.getAllFakePlayers()) {
            this.noDamageEnabled.put(fake.getName(), enabled);
            ++count;
         }

         String var10001 = String.valueOf(ChatColor.AQUA);
         player.sendMessage(var10001 + "No damage " + (enabled ? "enabled" : "disabled") + " for " + count + " fake players");
      }

   }

   private void applyGlobalHideBodies(Player player, boolean enabled) {
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager != null) {
         int count = 0;

         for(SimpleFakePlayerManager.FakePlayerData fake : manager.getAllFakePlayers()) {
            manager.getNMSHandler().setVisibleInWorld(fake.getUuid(), !enabled);
            ++count;
         }

         String var10001 = String.valueOf(ChatColor.GRAY);
         player.sendMessage(var10001 + "Bodies " + (enabled ? "hidden" : "shown") + " for " + count + " fake players");
      }

   }

   private void applyGlobalFollowMode(Player player, boolean enabled) {
      if (this.followModeManager == null) {
         player.sendMessage(String.valueOf(ChatColor.RED) + "Follow mode manager not available!");
      } else {
         SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
         if (manager != null) {
            int count = 0;

            for(SimpleFakePlayerManager.FakePlayerData fake : manager.getAllFakePlayers()) {
               if (enabled) {
                  this.followModeManager.startFollowing(fake.getPlayer(), player);
                  ++count;
               } else {
                  this.followModeManager.stopFollowing(fake.getUuid());
                  ++count;
               }
            }

            String var10001 = String.valueOf(ChatColor.AQUA);
            player.sendMessage(var10001 + "All fake players " + (enabled ? "are now following you!" : "stopped following."));
         }
      }

   }

   private void applyGlobalHeadMovement(Player player, boolean enabled) {
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager != null) {
         int count = 0;

         for(SimpleFakePlayerManager.FakePlayerData fake : manager.getAllFakePlayers()) {
            manager.getNMSHandler().setHeadMovementEnabled(fake.getUuid(), enabled);
            ++count;
         }

         String var10001 = String.valueOf(ChatColor.LIGHT_PURPLE);
         player.sendMessage(var10001 + "Head movement " + (enabled ? "enabled" : "disabled") + " for " + count + " fake players");
      }

   }

   private void applyGlobalFluctuation(Player player, boolean enabled) {
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager != null) {
         this.plugin.getConfig().set("fluctuation.enabled", enabled);
         this.plugin.saveConfig();
         this.plugin.reloadConfig();
         String var10001 = String.valueOf(ChatColor.LIGHT_PURPLE);
         player.sendMessage(var10001 + "Fluctuation " + (enabled ? "enabled" : "disabled"));
      }

   }
}
