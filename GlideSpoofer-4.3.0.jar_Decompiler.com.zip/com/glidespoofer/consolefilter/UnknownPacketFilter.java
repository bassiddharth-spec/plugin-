package com.glidespoofer.consolefilter;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class UnknownPacketFilter implements MessageFilter {
   private final List<Pattern> patterns = new ArrayList();
   private final List<String> simpleContains = new ArrayList();

   public UnknownPacketFilter() {
      this.patterns.add(Pattern.compile(".*unknown packet.*0x[0-9a-f]+.*", 2));
      this.patterns.add(Pattern.compile(".*unregistered packet.*", 2));
      this.patterns.add(Pattern.compile(".*unhandled packet id.*", 2));
      this.patterns.add(Pattern.compile(".*packet id.*not found.*", 2));
      this.patterns.add(Pattern.compile(".*failed to process packet.*", 2));
      this.patterns.add(Pattern.compile(".*packet serialization failed.*", 2));
      this.patterns.add(Pattern.compile(".*received.*packet.*with unexpected.*", 2));
      this.patterns.add(Pattern.compile(".*invalid packet.*", 2));
      this.patterns.add(Pattern.compile(".*PacketPlayOut.*failed.*", 2));
      this.patterns.add(Pattern.compile(".*Clientbound.*failed.*", 2));
      this.patterns.add(Pattern.compile(".*Serverbound.*failed.*", 2));
      this.simpleContains.add("unknown packet");
      this.simpleContains.add("unregistered packet");
      this.simpleContains.add("unhandled packet");
      this.simpleContains.add("unexpected packet");
      this.simpleContains.add("invalid packet");
      this.simpleContains.add("packet 0x");
      this.simpleContains.add("unknown packet id");
      this.simpleContains.add("packet processing");
      this.simpleContains.add("packet handling");
      this.simpleContains.add("packet serializer");
      this.simpleContains.add("packetplayout");
      this.simpleContains.add("packetplayin");
      this.simpleContains.add("clientbound");
      this.simpleContains.add("serverbound");
      this.simpleContains.add("protocol error");
      this.simpleContains.add("packet decode");
      this.simpleContains.add("packet encode");
   }

   public boolean filter(String message) {
      if (message == null) {
         return false;
      } else {
         String lowerMessage = message.toLowerCase();
         if (!lowerMessage.contains("crash") && !lowerMessage.contains("corruption") && !lowerMessage.contains("critical") && !lowerMessage.contains("severe")) {
            if (!lowerMessage.contains("real player") && !lowerMessage.contains("actual player")) {
               for(String keyword : this.simpleContains) {
                  if (lowerMessage.contains(keyword)) {
                     return true;
                  }
               }

               for(Pattern pattern : this.patterns) {
                  if (pattern.matcher(message).matches()) {
                     return true;
                  }
               }

               return false;
            } else {
               return false;
            }
         } else {
            return false;
         }
      }
   }

   public String getName() {
      return "UnknownPacketFilter";
   }
}
