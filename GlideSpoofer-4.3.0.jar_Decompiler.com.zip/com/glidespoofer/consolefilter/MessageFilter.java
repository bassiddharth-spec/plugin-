package com.glidespoofer.consolefilter;

public interface MessageFilter {
   boolean filter(String message);

   default String getName() {
      return this.getClass().getSimpleName();
   }
}
