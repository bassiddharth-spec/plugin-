package com.glidespoofer.consolefilter;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.core.Filter;
import org.apache.logging.log4j.core.LifeCycle;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.core.Filter.Result;
import org.apache.logging.log4j.core.LifeCycle.State;
import org.apache.logging.log4j.message.Message;

public class GlideSpooferConsoleFilter implements Filter {
   private final ConsoleFilterManager consoleFilterManager;
   private final Filter.Result onMatch;
   private final Filter.Result onMismatch;

   public GlideSpooferConsoleFilter(ConsoleFilterManager consoleFilterManager) {
      this.onMatch = Result.NEUTRAL;
      this.onMismatch = Result.NEUTRAL;
      this.consoleFilterManager = consoleFilterManager;
   }

   public Filter.Result filter(LogEvent event) {
      Message message = event.getMessage();
      if (message == null) {
         return Result.NEUTRAL;
      } else {
         String formattedMessage = message.getFormattedMessage();
         if (formattedMessage == null) {
            return Result.NEUTRAL;
         } else {
            return this.consoleFilterManager.shouldFilter(formattedMessage) ? Result.DENY : Result.NEUTRAL;
         }
      }
   }

   public Filter.Result filter(Logger logger, Level level, Marker marker, String message, Object... params) {
      return this.consoleFilterManager.shouldFilter(message) ? Result.DENY : Result.NEUTRAL;
   }

   public Filter.Result filter(Logger logger, Level level, Marker marker, String message, Object param) {
      return this.consoleFilterManager.shouldFilter(message) ? Result.DENY : Result.NEUTRAL;
   }

   public Filter.Result filter(Logger logger, Level level, Marker marker, String message, Object p1, Object p2) {
      return this.consoleFilterManager.shouldFilter(message) ? Result.DENY : Result.NEUTRAL;
   }

   public Filter.Result filter(Logger logger, Level level, Marker marker, String message, Object p1, Object p2, Object p3) {
      return this.consoleFilterManager.shouldFilter(message) ? Result.DENY : Result.NEUTRAL;
   }

   public Filter.Result filter(Logger logger, Level level, Marker marker, String message, Object p1, Object p2, Object p3, Object p4) {
      return this.consoleFilterManager.shouldFilter(message) ? Result.DENY : Result.NEUTRAL;
   }

   public Filter.Result filter(Logger logger, Level level, Marker marker, String message, Object p1, Object p2, Object p3, Object p4, Object p5) {
      return this.consoleFilterManager.shouldFilter(message) ? Result.DENY : Result.NEUTRAL;
   }

   public Filter.Result filter(Logger logger, Level level, Marker marker, String message, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
      return this.consoleFilterManager.shouldFilter(message) ? Result.DENY : Result.NEUTRAL;
   }

   public Filter.Result filter(Logger logger, Level level, Marker marker, String message, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
      return this.consoleFilterManager.shouldFilter(message) ? Result.DENY : Result.NEUTRAL;
   }

   public Filter.Result filter(Logger logger, Level level, Marker marker, String message, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
      return this.consoleFilterManager.shouldFilter(message) ? Result.DENY : Result.NEUTRAL;
   }

   public Filter.Result filter(Logger logger, Level level, Marker marker, String message, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
      return this.consoleFilterManager.shouldFilter(message) ? Result.DENY : Result.NEUTRAL;
   }

   public Filter.Result filter(Logger logger, Level level, Marker marker, String message, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9, Object p10) {
      return this.consoleFilterManager.shouldFilter(message) ? Result.DENY : Result.NEUTRAL;
   }

   public Filter.Result filter(Logger logger, Level level, Marker marker, Message message, Throwable t) {
      String formattedMessage = message.getFormattedMessage();
      return this.consoleFilterManager.shouldFilter(formattedMessage) ? Result.DENY : Result.NEUTRAL;
   }

   public Filter.Result filter(Logger logger, Level level, Marker marker, Object message, Throwable t) {
      return message != null && this.consoleFilterManager.shouldFilter(message.toString()) ? Result.DENY : Result.NEUTRAL;
   }

   public Filter.Result getOnMatch() {
      return this.onMatch;
   }

   public Filter.Result getOnMismatch() {
      return this.onMismatch;
   }

   public void initialize() {
   }

   public void start() {
   }

   public void stop() {
   }

   public boolean isStarted() {
      return true;
   }

   public boolean isStopped() {
      return false;
   }

   public LifeCycle.State getState() {
      return State.STARTED;
   }
}
