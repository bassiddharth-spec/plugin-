package com.glidespoofer.consolefilter;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class ViaVersionFilter implements MessageFilter {
   private final List<Pattern> patterns = new ArrayList();
   private final List<String> simpleContains = new ArrayList();

   public ViaVersionFilter() {
      this.patterns.add(Pattern.compile(".*\\[ViaVersion\\].*client connected.*", 2));
      this.patterns.add(Pattern.compile(".*\\[ViaVersion\\].*outdated server.*", 2));
      this.patterns.add(Pattern.compile(".*\\[ViaVersion\\].*outdated client.*", 2));
      this.patterns.add(Pattern.compile(".*\\[ViaVersion\\].*server version.*", 2));
      this.patterns.add(Pattern.compile(".*\\[ViaVersion\\].*player .* has version.*", 2));
      this.patterns.add(Pattern.compile(".*\\[ViaVersion\\].*Could not load class.*", 2));
      this.patterns.add(Pattern.compile(".*ViaVersion.*incompatible version.*", 2));
      this.patterns.add(Pattern.compile(".*failed to load protocol.*", 2));
      this.patterns.add(Pattern.compile(".*\\[ViaVersion\\].*Could not find UserConnection.*", 2));
      this.patterns.add(Pattern.compile(".*ViaVersion.*UserConnection.*logging-in.*", 2));
      this.patterns.add(Pattern.compile(".*Could not find UserConnection.*logging-in player.*", 2));
      this.patterns.add(Pattern.compile(".*WARN.*ViaVersion.*UserConnection.*", 2));
      this.simpleContains.add("could not find userconnection");
      this.simpleContains.add("userconnection for logging-in");
      this.patterns.add(Pattern.compile(".*backend error.*", 2));
      this.patterns.add(Pattern.compile(".*already connected.*", 2));
      this.patterns.add(Pattern.compile(".*protocol version.*", 2));
      this.simpleContains.add("[ViaVersion]");
      this.simpleContains.add("viaversion");
      this.simpleContains.add("via version");
      this.simpleContains.add("via-loading");
      this.simpleContains.add("via-backwards");
      this.simpleContains.add("via-rewind");
      this.simpleContains.add("client version");
      this.simpleContains.add("server version");
      this.simpleContains.add("protocol version");
      this.simpleContains.add("version mismatch");
      this.simpleContains.add("protocol translation");
      this.simpleContains.add("transforming packet");
      this.simpleContains.add("packet translator");
      this.simpleContains.add("backend server");
      this.simpleContains.add("forwarded packet");
      this.simpleContains.add("maximum players");
      this.simpleContains.add("player count");
      this.simpleContains.add("outdated");
   }

   public boolean filter(String message) {
      if (message == null) {
         return false;
      } else {
         String lowerMessage = message.toLowerCase();
         boolean hasViaKeyword = false;

         for(String keyword : this.simpleContains) {
            if (lowerMessage.contains(keyword.toLowerCase())) {
               hasViaKeyword = true;
               break;
            }
         }

         if (hasViaKeyword) {
            if (lowerMessage.contains("fake") || lowerMessage.contains("npc") || lowerMessage.contains("bot") || lowerMessage.contains("glide")) {
               return true;
            }

            if (lowerMessage.contains("connection") || lowerMessage.contains("login") || lowerMessage.contains("disconnect") || lowerMessage.contains("joined")) {
               return true;
            }

            if (lowerMessage.contains("packet") && (lowerMessage.contains("unknown") || lowerMessage.contains("failed") || lowerMessage.contains("error"))) {
               return true;
            }
         }

         for(Pattern pattern : this.patterns) {
            if (pattern.matcher(message).matches()) {
               return true;
            }
         }

         return false;
      }
   }

   public String getName() {
      return "ViaVersionFilter";
   }
}
