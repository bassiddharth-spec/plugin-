package com.glidespoofer.consolefilter;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class FakePlayerConnectionFilter implements MessageFilter {
   private final List<Pattern> patterns = new ArrayList();
   private final List<String> simpleContains = new ArrayList();

   public FakePlayerConnectionFilter() {
      this.patterns.add(Pattern.compile(".*Connection reset.*", 2));
      this.patterns.add(Pattern.compile(".*IOException.*Connection reset.*", 2));
      this.patterns.add(Pattern.compile(".*An existing connection.*", 2));
      this.patterns.add(Pattern.compile(".*handleDisconnection.*", 2));
      this.patterns.add(Pattern.compile(".*unknown packet.*0x[0-9a-f]+.*", 2));
      this.patterns.add(Pattern.compile(".*unhandled packet.*", 2));
      this.patterns.add(Pattern.compile(".*failed to serialize packet.*", 2));
      this.patterns.add(Pattern.compile(".*Channel closed.*", 2));
      this.patterns.add(Pattern.compile(".*socket closed.*", 2));
      this.patterns.add(Pattern.compile(".*connection closed.*", 2));
      this.patterns.add(Pattern.compile(".*Cannot.*packet.*", 2));
      this.patterns.add(Pattern.compile(".*Error reading packet.*", 2));
      this.patterns.add(Pattern.compile(".*kicked.*for reason.*disconnect\\.player\\.overflow.*", 2));
      this.patterns.add(Pattern.compile(".*logged in during entity removal.*", 2));
      this.patterns.add(Pattern.compile(".*Entity.*tracker.*", 2));
      this.patterns.add(Pattern.compile(".*failed to track entity.*", 2));
      this.patterns.add(Pattern.compile(".*PlaceholderAPI.*fake.*", 2));
      this.patterns.add(Pattern.compile(".*player.*not found.*", 2));
      this.simpleContains.add("connection reset");
      this.simpleContains.add("connection closed");
      this.simpleContains.add("channel closed");
      this.simpleContains.add("socket closed");
      this.simpleContains.add("broken pipe");
      this.simpleContains.add("an existing connection");
      this.simpleContains.add("ioexception");
      this.simpleContains.add("network error");
      this.simpleContains.add("read timed out");
      this.simpleContains.add("entity tracker");
      this.simpleContains.add("failed to track");
      this.simpleContains.add("entity removal");
      this.simpleContains.add("packet serialization");
      this.simpleContains.add("packet handling");
      this.simpleContains.add("player overflow");
      this.simpleContains.add("too many players");
      this.simpleContains.add("connection throttle");
      this.simpleContains.add("logged in during");
      this.simpleContains.add("join failed");
   }

   public boolean filter(String message) {
      if (message == null) {
         return false;
      } else {
         String lowerMessage = message.toLowerCase();
         if (!lowerMessage.contains("exception") && !lowerMessage.contains("error")) {
            if (!lowerMessage.contains("crash") && !lowerMessage.contains("corruption") && !lowerMessage.contains("critical") && !lowerMessage.contains("severe")) {
               for(String keyword : this.simpleContains) {
                  if (lowerMessage.contains(keyword)) {
                     return true;
                  }
               }

               for(Pattern pattern : this.patterns) {
                  if (pattern.matcher(message).matches()) {
                     return true;
                  }
               }

               return false;
            } else {
               return false;
            }
         } else {
            return lowerMessage.contains("fake player") || lowerMessage.contains("glidespoofer") || lowerMessage.contains("npc") || lowerMessage.contains("bot");
         }
      }
   }

   public String getName() {
      return "FakePlayerConnectionFilter";
   }
}
