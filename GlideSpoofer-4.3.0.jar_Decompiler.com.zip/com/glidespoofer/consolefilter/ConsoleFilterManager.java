package com.glidespoofer.consolefilter;

import com.glidespoofer.core.GlideSpoofer;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.LoggerConfig;

public class ConsoleFilterManager {
   private final GlideSpoofer plugin;
   private final List<MessageFilter> filters;
   private GlideSpooferConsoleFilter consoleFilter;
   private boolean enabled = false;

   public ConsoleFilterManager(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.filters = new ArrayList();
      this.registerDefaultFilters();
   }

   private void registerDefaultFilters() {
      if (this.plugin.getConfigManager().getConfig().getBoolean("hooks.viaversion.enabled", true)) {
         this.addFilter(new ViaVersionFilter());
      }

      this.addFilter(new FakePlayerConnectionFilter());
      this.addFilter(new UnknownPacketFilter());
   }

   public void addFilter(MessageFilter filter) {
      this.filters.add(filter);
      this.plugin.getLogger().info("Added console filter: " + filter.getName());
   }

   public void enable() {
      if (this.enabled) {
         this.plugin.getLogger().info("Console filter is already enabled");
      } else {
         try {
            Logger rootLogger = (Logger)LogManager.getRootLogger();
            this.consoleFilter = new GlideSpooferConsoleFilter(this);
            rootLogger.addFilter(this.consoleFilter);
            this.enabled = true;
            this.plugin.getLogger().info("Console filter enabled - filtering " + this.filters.size() + " filter types");
         } catch (Exception e) {
            this.plugin.getLogger().warning("Failed to enable console filter: " + e.getMessage());
            e.printStackTrace();
         }

      }
   }

   public void disable() {
      if (this.enabled) {
         try {
            Logger rootLogger = (Logger)LogManager.getRootLogger();
            if (this.consoleFilter != null) {
               try {
                  LoggerConfig loggerConfig = rootLogger.get();
                  if (loggerConfig != null) {
                     loggerConfig.removeFilter(this.consoleFilter);
                  }
               } catch (Exception var6) {
                  try {
                     LoggerContext context = rootLogger.getContext();
                     if (context != null) {
                        Configuration configuration = context.getConfiguration();
                        if (configuration != null) {
                           configuration.removeFilter(this.consoleFilter);
                        }
                     }
                  } catch (Exception ex) {
                     this.plugin.getLogger().fine("Could not remove filter via config: " + ex.getMessage());
                  }
               }
            }

            this.enabled = false;
            this.plugin.getLogger().info("Console filter disabled");
         } catch (Exception e) {
            this.plugin.getLogger().warning("Failed to disable console filter: " + e.getMessage());
         }

      }
   }

   public boolean shouldFilter(String message) {
      if (!this.enabled) {
         return false;
      } else {
         for(MessageFilter filter : this.filters) {
            try {
               if (filter.filter(message)) {
                  return true;
               }
            } catch (Exception e) {
               java.util.logging.Logger var10000 = this.plugin.getLogger();
               String var10001 = filter.getName();
               var10000.warning("Error in filter " + var10001 + ": " + e.getMessage());
            }
         }

         return false;
      }
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public List<MessageFilter> getFilters() {
      return new ArrayList(this.filters);
   }

   public GlideSpoofer getPlugin() {
      return this.plugin;
   }
}
