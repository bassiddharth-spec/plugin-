package com.glidespoofer.physics;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class AdvancedKnockbackSystem {
   private final Plugin plugin;
   private final Map<UUID, KnockbackState> activeKnockback = new ConcurrentHashMap();
   private final Map<UUID, BukkitTask> knockbackTasks = new ConcurrentHashMap();
   private Consumer<PositionUpdate> positionUpdateCallback;
   private static final boolean DEBUG_KNOCKBACK = false;
   private static final double PLAYER_WIDTH = 0.6;
   private static final double PLAYER_HALF_WIDTH = 0.3;
   private static final double GRAVITY = 0.08;
   private static final double TERMINAL_VELOCITY = (double)-3.0F;
   private static final double AIR_FRICTION = 0.91;
   private static final double GROUND_FRICTION = 0.6;
   private static final double CEILING_BOUNCE = (double)0.0F;
   private static final double GROUND_BOUNCE = 0.1;
   private static final int STEPS_PER_TICK = 8;

   public AdvancedKnockbackSystem(Plugin plugin) {
      this.plugin = plugin;
   }

   public void setPositionUpdateCallback(Consumer<PositionUpdate> callback) {
      this.positionUpdateCallback = callback;
   }

   public void applyKnockback(Player player, double dx, double dz, double strength, Runnable onComplete) {
      UUID uuid = player.getUniqueId();
      this.cancelKnockback(uuid);
      Location startLoc = player.getLocation().clone();
      boolean onGround = isOnGroundAt(startLoc, this.plugin);
      double horizontalSpeed = strength * 0.6;
      double vx = dx * horizontalSpeed;
      double vz = dz * horizontalSpeed;
      double vy = onGround ? 0.35 : 0.2;
      if (!onGround) {
         vx *= (double)0.5F;
         vz *= (double)0.5F;
         vy *= (double)0.5F;
      }

      KnockbackState state = new KnockbackState(uuid, startLoc, vx, vy, vz, System.currentTimeMillis(), onComplete, this.plugin);
      this.activeKnockback.put(uuid, state);
      BukkitTask task = (new KnockbackTask(state)).runTaskTimer(this.plugin, 0L, 1L);
      this.knockbackTasks.put(uuid, task);
   }

   public void cancelKnockback(UUID uuid) {
      BukkitTask task = (BukkitTask)this.knockbackTasks.remove(uuid);
      if (task != null) {
         task.cancel();
      }

      KnockbackState state = (KnockbackState)this.activeKnockback.remove(uuid);
      if (state != null && state.onComplete != null) {
         state.onComplete.run();
      }

   }

   public boolean isKnockedBack(UUID uuid) {
      return this.activeKnockback.containsKey(uuid);
   }

   public KnockbackState getKnockbackState(UUID uuid) {
      return (KnockbackState)this.activeKnockback.get(uuid);
   }

   private void processPhysics(KnockbackState state) {
      double stepVx = state.vx / (double)8.0F;
      double stepVy = state.vy / (double)8.0F;
      double stepVz = state.vz / (double)8.0F;

      for(int step = 0; step < 8; ++step) {
         state.updateLastValid();
         if (step == 0) {
            this.applyGravity(state);
         }

         this.moveWithCollision(state, stepVx, stepVy, stepVz);
      }

      this.applyFriction(state);
   }

   private void applyGravity(KnockbackState state) {
      if (!state.onGround) {
         state.vy -= 0.08;
         if (state.vy < (double)-3.0F) {
            state.vy = (double)-3.0F;
         }
      }

   }

   private void applyFriction(KnockbackState state) {
      double friction = state.onGround ? 0.6 : 0.91;
      state.vx *= friction;
      state.vz *= friction;
      if (Math.abs(state.vx) < 0.001) {
         state.vx = (double)0.0F;
      }

      if (Math.abs(state.vz) < 0.001) {
         state.vz = (double)0.0F;
      }

      if (Math.abs(state.vy) < 0.001) {
         state.vy = (double)0.0F;
      }

   }

   private void moveWithCollision(KnockbackState state, double vx, double vy, double vz) {
      int tick = state.getTick();
      double beforeX = state.x;
      double beforeY = state.y;
      double beforeZ = state.z;
      if (Math.abs(vx) > 1.0E-4) {
         double newX = state.x + vx;
         boolean canMove = this.canMoveTo(state.world, newX, state.y, state.z, state.onGround);
         if (canMove) {
            state.x = newX;
         } else {
            double oldVx = state.vx;
            state.vx = (double)0.0F;
         }
      }

      if (Math.abs(vz) > 1.0E-4) {
         double newZ = state.z + vz;
         boolean canMove = this.canMoveTo(state.world, state.x, state.y, newZ, state.onGround);
         if (canMove) {
            state.z = newZ;
         } else {
            double oldVz = state.vz;
            state.vz = (double)0.0F;
         }
      }

      double newY = state.y + vy;
      if (vy > (double)0.0F) {
         state.onGround = false;
         boolean hitCeiling = this.checkCeilingCollision(state.world, state.x, state.y, state.z, newY);
         if (hitCeiling) {
            state.vy = (double)0.0F;
            newY = state.y;
         }
      } else if (vy < (double)0.0F) {
         double groundY = this.findGroundAt(state.world, state.x, state.y, state.z);
         if (newY <= groundY) {
            if (state.y - groundY > 0.3) {
               state.vy = -state.vy * 0.1;
               if (Math.abs(state.vy) < 0.05) {
                  state.vy = (double)0.0F;
               }
            } else {
               state.vy = (double)0.0F;
            }

            newY = groundY;
            state.onGround = true;
         } else {
            state.onGround = false;
         }
      } else {
         state.onGround = isOnGroundAt(new Location(state.world, state.x, state.y, state.z), this.plugin);
      }

      boolean canMove = this.canMoveTo(state.world, state.x, newY, state.z, state.onGround);
      if (canMove) {
         state.y = newY;
      } else {
         state.vy = (double)0.0F;
      }

      double dx = state.x - beforeX;
      double dy = state.y - beforeY;
      double dz = state.z - beforeZ;
      double distanceMoved = Math.sqrt(dx * dx + dy * dy + dz * dz);
      double positionChange = Math.sqrt(Math.pow(state.x - state.prevX, (double)2.0F) + Math.pow(state.y - state.prevY, (double)2.0F) + Math.pow(state.z - state.prevZ, (double)2.0F));
      if (positionChange < 0.001 && distanceMoved < 0.001) {
         ++state.stuckCounter;
         if (state.stuckCounter >= 3) {
            state.vx = (double)0.0F;
            state.vy = (double)0.0F;
            state.vz = (double)0.0F;
         }
      } else {
         state.stuckCounter = 0;
      }

      state.prevX = state.x;
      state.prevY = state.y;
      state.prevZ = state.z;
   }

   private boolean canMoveTo(World world, double x, double y, double z, boolean checkGround) {
      double[] checkHeights = new double[]{(double)0.0F, 0.3, 0.6, 0.9, 1.2, (double)1.5F, 1.8};
      double[][] hitboxCorners = new double[][]{{(double)0.0F, (double)0.0F}, {-0.3, (double)0.0F}, {0.3, (double)0.0F}, {(double)0.0F, -0.3}, {(double)0.0F, 0.3}, {-0.3, -0.3}, {0.3, -0.3}, {-0.3, 0.3}, {0.3, 0.3}};

      for(double height : checkHeights) {
         if (!(y + height < (double)0.0F)) {
            for(double[] corner : hitboxCorners) {
               double checkX = x + corner[0];
               double checkZ = z + corner[1];
               if (isSolidAt(world, checkX, y + height, checkZ)) {
                  return false;
               }
            }
         }
      }

      return true;
   }

   private boolean checkCeilingCollision(World world, double x, double y, double z, double newY) {
      double headY = newY + 1.6;
      double eyeY = newY + 1.62;
      return isSolidAt(world, x, headY, z) || isSolidAt(world, x, eyeY, z);
   }

   private double findGroundAt(World world, double x, double y, double z) {
      for(int dy = 0; dy <= 30; ++dy) {
         double checkY = y - (double)dy * 0.1;
         int blockY = (int)Math.floor(checkY);
         if (blockY < world.getMinHeight()) {
            return (double)(world.getMinHeight() + 1);
         }

         BlockCheck below = getBlockAt(world, x, (double)(blockY - 1), z);
         BlockCheck at = getBlockAt(world, x, (double)blockY, z);
         BlockCheck above = getBlockAt(world, x, (double)(blockY + 1), z);
         if (below.solid && !at.solid && !above.solid) {
            return (double)blockY;
         }

         if (below.solid && at.solid) {
            return (double)blockY;
         }
      }

      return y;
   }

   private static boolean isSolidAt(World world, double x, double y, double z) {
      BlockCheck block = getBlockAt(world, x, y, z);
      return block.solid && !block.passthrough;
   }

   private static BlockCheck getBlockAt(World world, double x, double y, double z) {
      try {
         int bx = (int)Math.floor(x);
         int by = (int)Math.floor(y);
         int bz = (int)Math.floor(z);
         if (by >= world.getMinHeight() && by <= world.getMaxHeight()) {
            Material type = world.getBlockAt(bx, by, bz).getType();
            boolean solid = type.isSolid();
            boolean passthrough = isPassthrough(type);
            return new BlockCheck(solid, passthrough);
         } else {
            return new BlockCheck(false, false);
         }
      } catch (Exception var13) {
         return new BlockCheck(false, false);
      }
   }

   private static boolean isPassthrough(Material material) {
      if (material.isAir()) {
         return true;
      } else {
         String name = material.name();
         return name.contains("TORCH") || name.contains("SIGN") || name.contains("CARPET") || name.contains("BUTTON") || name.contains("PRESSURE_PLATE") || name.contains("RAIL") || name.contains("VINE") || name.contains("LADDER") || name.contains("BANNER") || name.contains("FLOWER") || name.contains("GRASS") || name.contains("FERN") || name.contains("SAPLING") || name.contains("MUSHROOM") || name.contains("DEAD_BUSH") || name.contains("SEAGRASS") || name.contains("KELP") || name.contains("LEAVES") || name.contains("FENCE_GATE") || name.contains("DOOR") || name.contains("GATE") || name.contains("TRAPDOOR");
      }
   }

   private static boolean isOnGroundAt(Location loc, Plugin plugin) {
      World world = loc.getWorld();
      double x = loc.getX();
      double y = loc.getY();
      double z = loc.getZ();
      double[][] offsets = new double[][]{{(double)0.0F, (double)0.0F}, {-0.3, (double)0.0F}, {0.3, (double)0.0F}, {(double)0.0F, -0.3}, {(double)0.0F, 0.3}, {-0.3, -0.3}, {0.3, -0.3}, {-0.3, 0.3}, {0.3, 0.3}};
      boolean foundGround = false;

      for(double[] offset : offsets) {
         boolean solid = isSolidAt(world, x + offset[0], y - 0.05, z + offset[1]);
         if (solid) {
            foundGround = true;
            break;
         }
      }

      return foundGround;
   }

   private boolean shouldEndKnockback(KnockbackState state) {
      double horizontalSpeed = Math.sqrt(state.vx * state.vx + state.vz * state.vz);
      boolean isSlow = horizontalSpeed < 0.02 && Math.abs(state.vy) < 0.1;
      boolean hasRunLongEnough = state.tick > 10;
      return state.onGround && isSlow && hasRunLongEnough ? true : state.tick > 30;
   }

   private void updatePosition(Player player, Location newLoc, boolean onGround) {
      if (this.positionUpdateCallback != null) {
         this.positionUpdateCallback.accept(new PositionUpdate(player.getUniqueId(), newLoc, onGround));
      } else {
         try {
            player.teleport(newLoc);
         } catch (Exception var5) {
         }
      }

   }

   private static class BlockCheck {
      final boolean solid;
      final boolean passthrough;

      BlockCheck(boolean solid, boolean passthrough) {
         this.solid = solid;
         this.passthrough = passthrough;
      }
   }

   public static class KnockbackState {
      private final UUID playerUuid;
      private final Location startLocation;
      private final World world;
      private double x;
      private double y;
      private double z;
      private double vx;
      private double vy;
      private double vz;
      private boolean onGround;
      private int tick;
      private final long startTime;
      private final Runnable onComplete;
      private double lastValidX;
      private double lastValidY;
      private double lastValidZ;
      private double prevX;
      private double prevY;
      private double prevZ;
      private int stuckCounter = 0;
      private final Plugin plugin;

      public KnockbackState(UUID playerUuid, Location startLoc, double vx, double vy, double vz, long startTime, Runnable onComplete, Plugin plugin) {
         this.playerUuid = playerUuid;
         this.startLocation = startLoc.clone();
         this.world = startLoc.getWorld();
         this.x = startLoc.getX();
         this.y = startLoc.getY();
         this.z = startLoc.getZ();
         this.vx = vx;
         this.vy = vy;
         this.vz = vz;
         this.startTime = startTime;
         this.onComplete = onComplete;
         this.plugin = plugin;
         this.onGround = AdvancedKnockbackSystem.isOnGroundAt(startLoc, plugin);
         this.lastValidX = this.x;
         this.lastValidY = this.y;
         this.lastValidZ = this.z;
         this.prevX = this.x;
         this.prevY = this.y;
         this.prevZ = this.z;
      }

      public UUID getPlayerUuid() {
         return this.playerUuid;
      }

      public Location getStartLocation() {
         return this.startLocation.clone();
      }

      public World getWorld() {
         return this.world;
      }

      public double getX() {
         return this.x;
      }

      public double getY() {
         return this.y;
      }

      public double getZ() {
         return this.z;
      }

      public double getVx() {
         return this.vx;
      }

      public double getVy() {
         return this.vy;
      }

      public double getVz() {
         return this.vz;
      }

      public boolean isOnGround() {
         return this.onGround;
      }

      public int getTick() {
         return this.tick;
      }

      public long getStartTime() {
         return this.startTime;
      }

      public void setPosition(double x, double y, double z) {
         this.x = x;
         this.y = y;
         this.z = z;
      }

      public void setVelocity(double vx, double vy, double vz) {
         this.vx = vx;
         this.vy = vy;
         this.vz = vz;
      }

      public void setOnGround(boolean onGround) {
         this.onGround = onGround;
      }

      public void incrementTick() {
         ++this.tick;
      }

      public void updateLastValid() {
         this.lastValidX = this.x;
         this.lastValidY = this.y;
         this.lastValidZ = this.z;
      }

      public void revertToLastValid() {
         this.x = this.lastValidX;
         this.y = this.lastValidY;
         this.z = this.lastValidZ;
      }
   }

   private class KnockbackTask extends BukkitRunnable {
      private final KnockbackState state;

      public KnockbackTask(KnockbackState state) {
         this.state = state;
      }

      public void run() {
         Player player = AdvancedKnockbackSystem.this.plugin.getServer().getPlayer(this.state.playerUuid);
         if (player != null && player.isOnline()) {
            this.state.incrementTick();
            int tick = this.state.getTick();
            AdvancedKnockbackSystem.this.processPhysics(this.state);
            Location newLoc = new Location(this.state.world, this.state.x, this.state.y, this.state.z, player.getLocation().getYaw(), player.getLocation().getPitch());
            AdvancedKnockbackSystem.this.updatePosition(player, newLoc, this.state.onGround);
            if (AdvancedKnockbackSystem.this.shouldEndKnockback(this.state)) {
               this.cancel();
               this.finish();
            }
         } else {
            this.cancel();
            this.finish();
         }

      }

      private void finish() {
         AdvancedKnockbackSystem.this.knockbackTasks.remove(this.state.playerUuid);
         AdvancedKnockbackSystem.this.activeKnockback.remove(this.state.playerUuid);

         try {
            Player player = AdvancedKnockbackSystem.this.plugin.getServer().getPlayer(this.state.playerUuid);
            if (player != null && player.isOnline()) {
               Object serverPlayer = player.getClass().getMethod("getHandle").invoke(player);
               if (serverPlayer != null) {
                  try {
                     Method setDeltaMovement = serverPlayer.getClass().getMethod("setDeltaMovement", Class.forName("org.bukkit.util.Vector"));
                     setDeltaMovement.invoke(serverPlayer, new Vector(0, 0, 0));
                  } catch (Exception var11) {
                     try {
                        Class<?> vec3Class = Class.forName("net.minecraft.world.phys.Vec3");
                        Method setDeltaMovementx = serverPlayer.getClass().getMethod("setDeltaMovement", vec3Class);
                        Object zeroVec = null;

                        try {
                           zeroVec = vec3Class.getField("ZERO").get((Object)null);
                        } catch (Exception var9) {
                        }

                        if (zeroVec != null) {
                           setDeltaMovementx.invoke(serverPlayer, zeroVec);
                        }
                     } catch (Exception var10) {
                        try {
                           Method setDeltaMovementx = serverPlayer.getClass().getMethod("setDeltaMovement", Double.TYPE, Double.TYPE, Double.TYPE);
                           setDeltaMovementx.invoke(serverPlayer, (double)0.0F, (double)0.0F, (double)0.0F);
                        } catch (Exception var8) {
                        }
                     }
                  }
               }
            }
         } catch (Exception var12) {
         }

         if (this.state.onComplete != null) {
            this.state.onComplete.run();
         }

      }
   }

   public static class PositionUpdate {
      private final UUID playerUuid;
      private final Location newLocation;
      private final boolean onGround;

      public PositionUpdate(UUID playerUuid, Location newLocation, boolean onGround) {
         this.playerUuid = playerUuid;
         this.newLocation = newLocation;
         this.onGround = onGround;
      }

      public UUID getPlayerUuid() {
         return this.playerUuid;
      }

      public Location getNewLocation() {
         return this.newLocation;
      }

      public boolean isOnGround() {
         return this.onGround;
      }
   }
}
