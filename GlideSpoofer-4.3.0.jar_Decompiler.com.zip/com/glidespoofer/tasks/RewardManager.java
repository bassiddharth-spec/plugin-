package com.glidespoofer.tasks;

import com.glidespoofer.core.GlideSpoofer;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.RegisteredServiceProvider;

public class RewardManager {
   private final GlideSpoofer plugin;
   private final Random random;
   private boolean vaultEnabled;
   private Object economy;

   public RewardManager(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.random = new Random();
      this.setupVault();
   }

   private void setupVault() {
      if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
         this.plugin.getLogger().info("[Rewards] Vault not found - money rewards disabled");
      } else {
         try {
            Class<?> rspClass = Class.forName("net.milkbowl.vault.economy.Economy");
            RegisteredServiceProvider<?> rsp = Bukkit.getServicesManager().getRegistration(rspClass);
            if (rsp != null) {
               this.economy = rsp.getProvider();
               this.vaultEnabled = true;
               this.plugin.getLogger().info("[Rewards] Vault economy found!");
            }
         } catch (Exception var3) {
            this.plugin.getLogger().warning("[Rewards] Failed to setup Vault: " + var3.getMessage());
         }
      }

   }

   public void giveRewards(Player killer, String fakePlayerName) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("random-rewards.enabled", false)) {
         double chance = this.plugin.getConfigManager().getConfig().getDouble("random-rewards.chance", (double)0.5F);
         if (!(this.random.nextDouble() > chance)) {
            this.giveItemRewards(killer);
            if (this.vaultEnabled && this.plugin.getConfigManager().getConfig().getBoolean("random-rewards.money.enabled", true)) {
               this.giveMoneyReward(killer);
            }

            if (this.plugin.getConfigManager().getConfig().getBoolean("random-rewards.xp.enabled", true)) {
               this.giveXPReward(killer);
            }

            this.giveCurrencyRewards(killer);
            this.executeRewardCommands(killer, fakePlayerName);
         }
      }

   }

   private void giveItemRewards(Player killer) {
      List<String> items = this.plugin.getConfigManager().getConfig().getStringList("random-rewards.items");
      if (!items.isEmpty()) {
         String itemConfig = (String)items.get(this.random.nextInt(items.size()));

         try {
            String[] parts = itemConfig.split(":");
            Material material = Material.valueOf(parts[0].toUpperCase());
            int amount = 1;
            if (parts.length > 1) {
               if (parts[1].contains("-")) {
                  String[] range = parts[1].split("-");
                  int min = Integer.parseInt(range[0]);
                  int max = Integer.parseInt(range[1]);
                  amount = min + this.random.nextInt(max - min + 1);
               } else {
                  amount = Integer.parseInt(parts[1]);
               }
            }

            ItemStack item = new ItemStack(material, amount);
            killer.getInventory().addItem(new ItemStack[]{item});
            this.plugin.getLogger().fine("[Rewards] Gave " + amount + "x " + String.valueOf(material) + " to " + killer.getName());
         } catch (Exception var10) {
            this.plugin.getLogger().warning("[Rewards] Invalid item config: " + itemConfig);
         }
      }

   }

   private void giveMoneyReward(Player killer) {
      if (this.vaultEnabled && this.economy != null) {
         try {
            int min = this.plugin.getConfigManager().getConfig().getInt("random-rewards.money.min", 50);
            int max = this.plugin.getConfigManager().getConfig().getInt("random-rewards.money.max", 500);
            double amount = (double)min + this.random.nextDouble() * (double)(max - min);
            amount = (double)Math.round(amount * (double)100.0F) / (double)100.0F;
            this.economy.getClass().getMethod("depositPlayer", Player.class, Double.TYPE).invoke(this.economy, killer, amount);
            Object[] var10002 = new Object[]{amount};
            killer.sendMessage("§a+$" + String.format("%.2f", var10002));
            this.plugin.getLogger().fine("[Rewards] Gave $" + amount + " to " + killer.getName());
         } catch (Exception var6) {
            this.plugin.getLogger().log(Level.WARNING, "[Rewards] Failed to give money", var6);
         }
      }

   }

   private void giveXPReward(Player killer) {
      int min = this.plugin.getConfigManager().getConfig().getInt("random-rewards.xp.min", 10);
      int max = this.plugin.getConfigManager().getConfig().getInt("random-rewards.xp.max", 100);
      int xp = min + this.random.nextInt(max - min + 1);
      killer.giveExp(xp);
      killer.sendMessage("§a+" + xp + " XP");
      this.plugin.getLogger().fine("[Rewards] Gave " + xp + " XP to " + killer.getName());
   }

   private void giveCurrencyRewards(Player killer) {
      List<String> currencies = this.plugin.getConfigManager().getConfig().getStringList("random-rewards.currencies");
      if (!currencies.isEmpty()) {
         for(String currencyConfig : currencies) {
            try {
               String[] parts = currencyConfig.split(":");
               if (parts.length >= 3) {
                  String pluginName = parts[0];
                  String currencyName = parts[1];
                  String rangeStr = parts[2];
                  int min = 0;
                  int max = 0;
                  if (rangeStr.contains("-")) {
                     String[] range = rangeStr.split("-");
                     min = Integer.parseInt(range[0]);
                     max = Integer.parseInt(range[1]);
                  } else {
                     min = max = Integer.parseInt(rangeStr);
                  }

                  int amount = min + this.random.nextInt(max - min + 1);
                  switch (pluginName.toLowerCase()) {
                     case "coinsengine":
                        this.giveCoinsEngine(killer, currencyName, amount);
                        break;
                     case "playerpoints":
                        this.givePlayerPoints(killer, amount);
                        break;
                     default:
                        String cmd = pluginName + " give " + killer.getName() + " " + currencyName + " " + amount;
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
                  }
               }
            } catch (Exception var16) {
               this.plugin.getLogger().fine("[Rewards] Failed to give currency: " + currencyConfig);
            }
         }
      }

   }

   private void giveCoinsEngine(Player player, String currency, int amount) {
      try {
         Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "coinsengine give " + player.getName() + " " + currency + " " + amount);
      } catch (Exception var5) {
         this.plugin.getLogger().fine("[Rewards] Failed to give CoinsEngine currency");
      }

   }

   private void givePlayerPoints(Player player, int amount) {
      try {
         ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
         String var10001 = player.getName();
         Bukkit.dispatchCommand(var10000, "points give " + var10001 + " " + amount);
      } catch (Exception var4) {
         this.plugin.getLogger().fine("[Rewards] Failed to give PlayerPoints");
      }

   }

   private void executeRewardCommands(Player killer, String fakePlayerName) {
      for(String command : this.plugin.getConfigManager().getConfig().getStringList("random-rewards.commands")) {
         try {
            String processed = command.replace("%player%", fakePlayerName).replace("%killer%", killer.getName()).replace("%reward%", "rewards");
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processed);
         } catch (Exception var6) {
            this.plugin.getLogger().warning("[Rewards] Failed to execute command: " + command);
         }
      }

   }

   public boolean isVaultEnabled() {
      return this.vaultEnabled;
   }
}
