package com.glidespoofer.tasks;

import com.glidespoofer.config.ConfigManager;
import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

public class RealPlayerProximityChecker {
   private final GlideSpoofer plugin;
   private final ConfigManager config;
   private Object checkTask;
   private final Map<UUID, DespawnedFakePlayer> despawnedFakes = new ConcurrentHashMap();

   public RealPlayerProximityChecker(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.config = plugin.getConfigManager();
   }

   public void start() {
      if (this.config.isProximityCheckEnabled()) {
         this.cancelTask(this.checkTask);
         this.checkTask = null;
         long intervalTicks = (long)this.config.getProximityCheckInterval();
         if (GlideSpoofer.isFolia()) {
            this.checkTask = Bukkit.getGlobalRegionScheduler().runAtFixedRate(this.plugin, (task) -> this.checkProximity(), intervalTicks, intervalTicks);
         } else {
            this.checkTask = Bukkit.getScheduler().runTaskTimer(this.plugin, this::checkProximity, intervalTicks, intervalTicks);
         }
      }

   }

   public void stop() {
      this.cancelTask(this.checkTask);
      this.checkTask = null;
      this.despawnedFakes.clear();
   }

   private void cancelTask(Object task) {
      if (task != null) {
         try {
            if (task instanceof BukkitTask) {
               ((BukkitTask)task).cancel();
            } else if (task.getClass().getName().contains("ScheduledTask")) {
               task.getClass().getMethod("cancel").invoke(task);
            }
         } catch (Exception var3) {
         }
      }

   }

   private void checkProximity() {
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager != null) {
         double radius = (double)this.config.getProximityRadius();
         List<Player> realPlayers = this.getRealPlayers();

         for(SimpleFakePlayerManager.FakePlayerData fake : new ArrayList(manager.getAllFakePlayers())) {
            Location fakeLoc = fake.getPlayer().getLocation();

            for(Player realPlayer : realPlayers) {
               if (realPlayer.getWorld().equals(fakeLoc.getWorld())) {
                  double distance = realPlayer.getLocation().distance(fakeLoc);
                  if (distance <= radius) {
                     this.despawnFakePlayer(fake);
                     break;
                  }
               }
            }
         }

         this.checkRespawn(realPlayers);
      }

   }

   private void despawnFakePlayer(SimpleFakePlayerManager.FakePlayerData fake) {
      DespawnedFakePlayer data = new DespawnedFakePlayer(fake.getName(), fake.getSpawnLocation().clone(), fake.getSkinName(), fake.getRank());
      this.despawnedFakes.put(fake.getUuid(), data);
      boolean silent = !this.config.isProximityBroadcastQuit();
      this.plugin.getSimpleFakePlayerManager().despawnFakePlayer(fake.getName(), silent);
      if (this.config.getConfig().getBoolean("debug.enabled", false)) {
         this.plugin.getLogger().info("[Proximity] Despawned " + fake.getName() + " due to nearby real player");
      }

   }

   private void checkRespawn(List<Player> realPlayers) {
      int respawnDelaySeconds = this.config.getProximityRespawnDelay();
      if (respawnDelaySeconds > 0) {
         long respawnDelayMs = (long)respawnDelaySeconds * 1000L;
         long currentTime = System.currentTimeMillis();
         double radius = (double)this.config.getProximityRadius();
         this.despawnedFakes.entrySet().removeIf((entry) -> {
            DespawnedFakePlayer data = (DespawnedFakePlayer)entry.getValue();
            if (currentTime - data.despawnTime < respawnDelayMs) {
               return false;
            } else {
               boolean realPlayerNearby = false;

               for(Player realPlayer : realPlayers) {
                  if (realPlayer.getWorld().equals(data.location.getWorld())) {
                     double distance = realPlayer.getLocation().distance(data.location);
                     if (distance <= radius) {
                        realPlayerNearby = true;
                        break;
                     }
                  }
               }

               if (!realPlayerNearby) {
                  this.plugin.getSimpleFakePlayerManager().spawnFakePlayer(data.name, data.location, data.skinName, data.rank, false, true);
                  if (this.config.getConfig().getBoolean("debug.enabled", false)) {
                     this.plugin.getLogger().info("[Proximity] Respawned " + data.name);
                  }

                  return true;
               } else {
                  return false;
               }
            }
         });
      }

   }

   private List<Player> getRealPlayers() {
      List<Player> realPlayers = new ArrayList();
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager == null) {
         realPlayers.addAll(Bukkit.getOnlinePlayers());
      } else {
         for(Player player : Bukkit.getOnlinePlayers()) {
            if (!manager.isFakePlayer(player)) {
               realPlayers.add(player);
            }
         }
      }

      return realPlayers;
   }

   public void restart() {
      this.stop();
      this.start();
   }

   public void clearDespawnedFakes() {
      this.despawnedFakes.clear();
   }

   private static class DespawnedFakePlayer {
      final String name;
      final Location location;
      final String skinName;
      final String rank;
      final long despawnTime;

      DespawnedFakePlayer(String name, Location location, String skinName, String rank) {
         this.name = name;
         this.location = location;
         this.skinName = skinName;
         this.rank = rank;
         this.despawnTime = System.currentTimeMillis();
      }
   }
}
