package com.glidespoofer.tasks;

import com.glidespoofer.config.ConfigManager;
import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

public class FakePlayerCommandExecutor {
   private final GlideSpoofer plugin;
   private final ConfigManager config;
   private final Random random;
   private Object executionTask;
   private final Map<UUID, Long> lastExecutionTime = new ConcurrentHashMap();

   public FakePlayerCommandExecutor(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.config = plugin.getConfigManager();
      this.random = new Random();
   }

   public void start() {
      if (this.config.isRandomCommandsEnabled()) {
         this.cancelTask(this.executionTask);
         this.executionTask = null;
         long intervalTicks = (long)((this.config.getRandomCommandsMinInterval() + this.config.getRandomCommandsMaxInterval()) / 2) * 20L;
         if (GlideSpoofer.isFolia()) {
            this.executionTask = Bukkit.getGlobalRegionScheduler().runAtFixedRate(this.plugin, (task) -> this.executeRandomCommands(), intervalTicks, intervalTicks);
         } else {
            this.executionTask = Bukkit.getScheduler().runTaskTimer(this.plugin, this::executeRandomCommands, intervalTicks, intervalTicks);
         }
      }

   }

   public void stop() {
      this.cancelTask(this.executionTask);
      this.executionTask = null;
      this.lastExecutionTime.clear();
   }

   private void cancelTask(Object task) {
      if (task != null) {
         try {
            if (task instanceof BukkitTask) {
               ((BukkitTask)task).cancel();
            } else if (task.getClass().getName().contains("ScheduledTask")) {
               task.getClass().getMethod("cancel").invoke(task);
            }
         } catch (Exception var3) {
         }
      }

   }

   private void executeRandomCommands() {
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager != null) {
         List<String> commands = new ArrayList(this.config.getRandomCommands());
         List<String> targetCommands = new ArrayList(this.config.getRandomTargetCommands());
         if (!commands.isEmpty() || !targetCommands.isEmpty()) {
            int chance = this.config.getRandomCommandsChance();
            long cooldownMs = (long)this.config.getRandomCommandsMinInterval() * 1000L;
            long currentTime = System.currentTimeMillis();

            for(SimpleFakePlayerManager.FakePlayerData fake : manager.getAllFakePlayers()) {
               Long lastExecution = (Long)this.lastExecutionTime.get(fake.getUuid());
               if ((lastExecution == null || currentTime - lastExecution >= cooldownMs) && this.random.nextInt(100) < chance) {
                  List<Player> realPlayers = this.getRealPlayers();
                  String command;
                  if (!targetCommands.isEmpty() && !realPlayers.isEmpty() && this.random.nextBoolean()) {
                     String template = (String)targetCommands.get(this.random.nextInt(targetCommands.size()));
                     Player target = (Player)realPlayers.get(this.random.nextInt(realPlayers.size()));
                     command = template.replace("%player%", fake.getName()).replace("%random_player%", target.getName());
                  } else {
                     if (commands.isEmpty()) {
                        continue;
                     }

                     String template = (String)commands.get(this.random.nextInt(commands.size()));
                     command = template.replace("%player%", fake.getName());
                  }

                  manager.executeCommand(fake.getName(), command);
                  this.lastExecutionTime.put(fake.getUuid(), currentTime);
                  if (this.config.getConfig().getBoolean("debug.enabled", false)) {
                     Logger var10000 = this.plugin.getLogger();
                     String var10001 = fake.getName();
                     var10000.info("[RandomCommands] " + var10001 + " executed: " + command);
                  }
               }
            }
         }
      }

   }

   private List<Player> getRealPlayers() {
      List<Player> realPlayers = new ArrayList();
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (manager == null) {
         realPlayers.addAll(Bukkit.getOnlinePlayers());
      } else {
         for(Player player : Bukkit.getOnlinePlayers()) {
            if (!manager.isFakePlayer(player)) {
               realPlayers.add(player);
            }
         }
      }

      return realPlayers;
   }

   public void restart() {
      this.stop();
      this.start();
   }
}
