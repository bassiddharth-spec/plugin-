package com.glidespoofer.tasks;

import com.glidespoofer.core.GlideSpoofer;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class PVPZoneManager {
   private final GlideSpoofer plugin;
   private final Set<String> pvpZones;
   private final Set<String> worldGuardRegions;
   private boolean worldGuardEnabled;
   private double damageMultiplier;

   public PVPZoneManager(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.pvpZones = new HashSet();
      this.worldGuardRegions = new HashSet();
      this.loadConfig();
      this.checkWorldGuard();
   }

   private void loadConfig() {
      if (this.plugin.getConfigManager().getConfig().getBoolean("pvp-zones.enabled", false)) {
         List<String> zones = this.plugin.getConfigManager().getConfig().getStringList("pvp-zones.zones");
         this.pvpZones.addAll(zones);
         List<String> regions = this.plugin.getConfigManager().getConfig().getStringList("pvp-zones.worldguard-regions");
         this.worldGuardRegions.addAll(regions);
         this.damageMultiplier = this.plugin.getConfigManager().getConfig().getDouble("pvp-zones.damage-multiplier", (double)1.0F);
         Logger var10000 = this.plugin.getLogger();
         int var10001 = this.pvpZones.size();
         var10000.info("[PVP Zones] Loaded " + var10001 + " zones and " + this.worldGuardRegions.size() + " WorldGuard regions");
      }

   }

   private void checkWorldGuard() {
      this.worldGuardEnabled = Bukkit.getPluginManager().getPlugin("WorldGuard") != null;
      if (this.worldGuardEnabled) {
         this.plugin.getLogger().info("[PVP Zones] WorldGuard integration enabled");
      }

   }

   public boolean isInPVPZone(Location location) {
      if (!this.plugin.getConfigManager().getConfig().getBoolean("pvp-zones.enabled", false)) {
         return false;
      } else {
         if (this.worldGuardEnabled && !this.worldGuardRegions.isEmpty()) {
            try {
               if (this.isInWorldGuardPVPRegion(location)) {
                  return true;
               }
            } catch (Exception var5) {
               this.plugin.getLogger().fine("[PVP Zones] WorldGuard check failed: " + var5.getMessage());
            }
         }

         String worldName = location.getWorld() != null ? location.getWorld().getName().toLowerCase() : "";

         for(String zone : this.pvpZones) {
            if (worldName.contains(zone.toLowerCase())) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean isInWorldGuardPVPRegion(Location location) {
      if (this.worldGuardEnabled && location.getWorld() != null) {
         try {
            Class<?> worldGuardClass = Class.forName("com.sk89q.worldguard.WorldGuard");
            Object worldGuard = worldGuardClass.getMethod("getInstance").invoke((Object)null);
            Object platform = worldGuard.getClass().getMethod("getPlatform").invoke(worldGuard);
            Object regionContainer = platform.getClass().getMethod("getRegionContainer").invoke(platform);
            Class<?> bukkitAdapterClass = Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter");
            Object weWorld = bukkitAdapterClass.getMethod("adapt", World.class).invoke((Object)null, location.getWorld());
            Object regionManager = regionContainer.getClass().getMethod("get", Class.forName("com.sk89q.worldedit.world.World")).invoke(regionContainer, weWorld);
            if (regionManager == null) {
               return false;
            }

            Object blockVector = Class.forName("com.sk89q.worldedit.math.BlockVector3").getMethod("at", Integer.TYPE, Integer.TYPE, Integer.TYPE).invoke((Object)null, location.getBlockX(), location.getBlockY(), location.getBlockZ());

            for(Object region : (Set)regionManager.getClass().getMethod("getApplicableRegions", blockVector.getClass()).invoke(regionManager, blockVector).getClass().getMethod("getRegions").invoke(regionManager.getClass().getMethod("getApplicableRegions", blockVector.getClass()).invoke(regionManager, blockVector))) {
               String regionId = (String)region.getClass().getMethod("getId").invoke(region);
               if (this.worldGuardRegions.contains(regionId.toLowerCase())) {
                  return true;
               }
            }
         } catch (Exception var14) {
            this.plugin.getLogger().fine("[PVP Zones] WorldGuard API error: " + var14.getMessage());
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean canDamage(Player attacker, Location fakePlayerLocation) {
      if (!this.plugin.getConfigManager().getConfig().getBoolean("pvp-zones.enabled", false)) {
         return true;
      } else {
         return this.isInPVPZone(fakePlayerLocation) ? true : this.isInPVPZone(attacker.getLocation());
      }
   }

   public double getDamageMultiplier() {
      return this.damageMultiplier;
   }

   public boolean shouldDropItems() {
      return this.plugin.getConfigManager().getConfig().getBoolean("pvp-zones.drop-items", false);
   }

   public int getRespawnDelay() {
      return this.plugin.getConfigManager().getConfig().getInt("pvp-zones.respawn-delay", 100);
   }

   public void addZone(String zone) {
      this.pvpZones.add(zone.toLowerCase());
   }

   public void removeZone(String zone) {
      this.pvpZones.remove(zone.toLowerCase());
   }

   public Set<String> getZones() {
      return new HashSet(this.pvpZones);
   }

   public boolean isWorldGuardEnabled() {
      return this.worldGuardEnabled;
   }

   public void reload() {
      this.pvpZones.clear();
      this.worldGuardRegions.clear();
      this.loadConfig();
   }
}
