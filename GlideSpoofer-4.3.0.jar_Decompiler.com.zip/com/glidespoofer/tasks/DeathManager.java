package com.glidespoofer.tasks;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.FakePlayer;
import com.glidespoofer.fake.FakePlayerManager;
import com.glidespoofer.packet.PacketManager;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

public class DeathManager {
   private final GlideSpoofer plugin;
   private final FakePlayerManager fakePlayerManager;
   private final PacketManager packetManager;
   private BukkitTask respawnCheckTask;
   private static final long LAY_DOWN_TICKS = 20L;
   private static final long INVISIBLE_DELAY_TICKS = 20L;
   private static final long RESPAWN_DELAY_TICKS = 80L;

   public DeathManager(GlideSpoofer plugin, FakePlayerManager fakePlayerManager, PacketManager packetManager) {
      this.plugin = plugin;
      this.fakePlayerManager = fakePlayerManager;
      this.packetManager = packetManager;
   }

   public void start() {
      this.respawnCheckTask = Bukkit.getScheduler().runTaskTimer(this.plugin, this::checkRespawns, 20L, 20L);
   }

   public void stop() {
      if (this.respawnCheckTask != null) {
         this.respawnCheckTask.cancel();
         this.respawnCheckTask = null;
      }

   }

   private void checkRespawns() {
      long currentTime = System.currentTimeMillis();

      for(FakePlayer fake : this.fakePlayerManager.getFakePlayers()) {
         if (fake.isDead()) {
            long deathTime = fake.getDeathTime();
            long timeSinceDeath = currentTime - deathTime;
            long respawnTimeMillis = 5000L;
            if (timeSinceDeath >= respawnTimeMillis) {
               this.respawnFakePlayer(fake);
            }
         }
      }

   }

   public void killFakePlayer(FakePlayer fake) {
      if (fake.isSpawned() && !fake.isDead()) {
         Location deathLoc = fake.getLocation();
         if (fake.hasInventory()) {
            for(ItemStack item : fake.getInventory().getItems()) {
               if (item != null && !item.getType().isAir()) {
                  deathLoc.getWorld().dropItemNaturally(deathLoc, item.clone());
               }
            }

            fake.getInventory().clear();
         }

         fake.die();
         deathLoc.getWorld().playSound(deathLoc, Sound.ENTITY_PLAYER_DEATH, 1.0F, 1.0F);

         for(Player viewer : Bukkit.getOnlinePlayers()) {
            Integer entityId = fake.getViewerEntityId(viewer);
            if (entityId != null) {
               this.sendDeathStatusPacket(viewer, entityId);
               this.packetManager.sendHurtAnimation(viewer, entityId);
            }
         }

         Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            for(Player viewerx : Bukkit.getOnlinePlayers()) {
               Integer entityIdx = fake.getViewerEntityId(viewerx);
               if (entityIdx != null) {
                  this.packetManager.sendEntityRotation(viewerx, entityIdx, deathLoc.getYaw(), 90.0F);
                  this.packetManager.sendHeadRotation(viewerx, entityIdx, deathLoc.getYaw());
                  this.sendDyingPoseMetadata(viewerx, fake, entityIdx);
               }
            }

         }, 1L);
         Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            for(Player viewerx : Bukkit.getOnlinePlayers()) {
               Integer entityIdx = fake.getViewerEntityId(viewerx);
               if (entityIdx != null) {
                  this.sendInvisibleMetadata(viewerx, fake, entityIdx);
               }
            }

            deathLoc.getWorld().spawnParticle(Particle.CLOUD, deathLoc.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 20, (double)0.5F, (double)0.5F, (double)0.5F, 0.05);
         }, 20L);
         Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            for(Player viewerx : Bukkit.getOnlinePlayers()) {
               Integer entityIdx = fake.getViewerEntityId(viewerx);
               if (entityIdx != null) {
                  this.packetManager.sendDestroyEntity(viewerx, entityIdx);
               }
            }

         }, 40L);
      }

   }

   private void sendDeathStatusPacket(Player viewer, int entityId) {
      try {
         Object packet = null;

         try {
            Class<?> packetClass = Class.forName("net.minecraft.network.protocol.game.ClientboundEntityEventPacket");
            Constructor<?> c = packetClass.getConstructor(Integer.TYPE, Byte.TYPE);
            packet = c.newInstance(entityId, 2);
         } catch (Exception var8) {
            try {
               Class<?> packetClassx = Class.forName("net.minecraft.server.network.PacketPlayOutEntityStatus");
               Constructor<?> cx = packetClassx.getConstructor(Integer.TYPE, Byte.TYPE);
               packet = cx.newInstance(entityId, 2);
            } catch (Exception var7) {
            }
         }

         if (packet != null) {
            this.sendPacketToViewer(viewer, packet);
         }
      } catch (Exception var9) {
      }

   }

   private void sendDyingPoseMetadata(Player viewer, FakePlayer fake, int entityId) {
   }

   private void sendInvisibleMetadata(Player viewer, FakePlayer fake, int entityId) {
      try {
         this.sendMetadataPacket(viewer, entityId, 0, (byte)32);
      } catch (Exception var5) {
      }

   }

   private void sendMetadataPacket(Player viewer, int entityId, int index, Object value) {
      try {
         Object packet = null;

         try {
            Class<?> packetClass = Class.forName("net.minecraft.network.protocol.game.ClientboundSetEntityDataPacket");
            Class<?> dataItemClass = Class.forName("net.minecraft.network.syncher.SynchedEntityData$DataItem");
            Class<?> entityDataClass = Class.forName("net.minecraft.network.syncher.EntityData");
            Class<?> entityDataTypesClass = Class.forName("net.minecraft.network.syncher.EntityDataTypes");
            Object dataType = null;
            if (value instanceof Byte) {
               try {
                  dataType = entityDataTypesClass.getDeclaredField("BYTE").get((Object)null);
               } catch (Exception var14) {
               }
            } else if (value instanceof Enum) {
               try {
                  dataType = entityDataTypesClass.getDeclaredField("POSE").get((Object)null);
               } catch (Exception var13) {
               }
            }

            if (dataType != null) {
               Object dataItemConstructor = dataItemClass.getConstructor(entityDataClass, Object.class);
               Object dataItem = ((Constructor)dataItemConstructor).newInstance(this.createEntityDataAccessor(index, dataType), value);
               packet = packetClass.getConstructor(Integer.TYPE, List.class).newInstance(entityId, Collections.singletonList(dataItem));
            }
         } catch (Exception var15) {
            Class<?> packetClassx = Class.forName("net.minecraft.server.network.PacketPlayOutEntityMetadata");
            Constructor<?> c = packetClassx.getConstructor(Integer.TYPE, List.class);
            packet = c.newInstance(entityId, Collections.singletonList(this.createLegacyDataItem(index, value)));
         }

         if (packet != null) {
            this.sendPacketToViewer(viewer, packet);
         }
      } catch (Exception var16) {
      }

   }

   private Object createEntityDataAccessor(int index, Object dataType) {
      try {
         Class<?> accessorClass = Class.forName("net.minecraft.network.syncher.EntityDataAccessor");
         Class<?> entityDataClass = Class.forName("net.minecraft.network.syncher.EntityData");
         Constructor<?> c = entityDataClass.getDeclaredConstructor(Integer.TYPE, Class.forName("net.minecraft.network.syncher.EntityDataTypes"));
         c.setAccessible(true);
         return c.newInstance(index, dataType);
      } catch (Exception var6) {
         return null;
      }
   }

   private Object createLegacyDataItem(int index, Object value) {
      try {
         Class<?> dataWatcherClass = Class.forName("net.minecraft.network.syncher.DataWatcher");
         Class<?> dataItemClass = Class.forName("net.minecraft.network.syncher.DataWatcher$WatchableObject");
         int typeIndex = value instanceof Byte ? 0 : (value instanceof Integer ? 1 : 2);
         return dataItemClass.getConstructor(Integer.TYPE, Integer.TYPE, Object.class).newInstance(typeIndex, index, value);
      } catch (Exception var6) {
         return null;
      }
   }

   private void sendPacketToViewer(Player viewer, Object packet) {
      try {
         Object handle = viewer.getClass().getMethod("getHandle").invoke(viewer);
         Object connection = null;

         try {
            connection = handle.getClass().getField("connection").get(handle);
         } catch (Exception var9) {
            connection = handle.getClass().getField("playerConnection").get(handle);
         }

         if (connection != null) {
            for(Method m : connection.getClass().getMethods()) {
               if (m.getName().equals("send") && m.getParameterCount() == 1) {
                  m.invoke(connection, packet);
                  return;
               }
            }
         }
      } catch (Exception var10) {
      }

   }

   private void respawnFakePlayer(FakePlayer fake) {
      if (fake.isDead()) {
         fake.respawn();
         Location spawnLoc = this.findSafeSpawnLocation(fake);
         fake.setLocation(spawnLoc);

         for(Player viewer : Bukkit.getOnlinePlayers()) {
            Integer entityId = fake.getViewerEntityId(viewer);
            if (entityId == null) {
               entityId = this.packetManager.getNextEntityId();
               fake.setViewerEntityId(viewer, entityId);
            }

            this.packetManager.sendSpawnPlayer(viewer, fake, entityId);
            this.packetManager.sendEquipment(viewer, fake, entityId);
            this.packetManager.sendEntityMetadata(viewer, fake, entityId);
            this.packetManager.sendTeleport(viewer, entityId, spawnLoc);
         }
      }

   }

   private Location findSafeSpawnLocation(FakePlayer fake) {
      Location originalLoc = fake.getLocation();
      if (originalLoc != null && originalLoc.getWorld() != null) {
         int searchRadius = 10;

         for(int r = 0; r <= searchRadius; ++r) {
            for(int dx = -r; dx <= r; ++dx) {
               for(int dz = -r; dz <= r; ++dz) {
                  if (Math.abs(dx) == r || Math.abs(dz) == r) {
                     Location testLoc = originalLoc.clone();
                     testLoc.setX(originalLoc.getX() + (double)dx);
                     testLoc.setZ(originalLoc.getZ() + (double)dz);
                     int safeY = this.findSafeYLevel(testLoc);
                     testLoc.setY((double)safeY);
                     if (this.isSafeLocation(testLoc)) {
                        return testLoc;
                     }
                  }
               }
            }
         }
      }

      return originalLoc != null && originalLoc.getWorld() != null ? originalLoc.getWorld().getSpawnLocation() : originalLoc;
   }

   private int findSafeYLevel(Location loc) {
      int startY = loc.getBlockY();
      int minY = Math.max(0, startY - 10);

      for(int y = startY; y >= minY; --y) {
         Block below = loc.getWorld().getBlockAt(loc.getBlockX(), y - 1, loc.getBlockZ());
         Block at = loc.getWorld().getBlockAt(loc.getBlockX(), y, loc.getBlockZ());
         Block above = loc.getWorld().getBlockAt(loc.getBlockX(), y + 1, loc.getBlockZ());
         if (below.getType().isSolid() && !at.getType().isSolid() && !above.getType().isSolid()) {
            return y;
         }
      }

      return startY;
   }

   private boolean isSafeLocation(Location loc) {
      if (loc != null && loc.getWorld() != null) {
         Block below = loc.getWorld().getBlockAt(loc.getBlockX(), loc.getBlockY() - 1, loc.getBlockZ());
         Block at = loc.getWorld().getBlockAt(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
         Block above = loc.getWorld().getBlockAt(loc.getBlockX(), loc.getBlockY() + 1, loc.getBlockZ());
         return below.getType().isSolid() && !at.getType().isSolid() && !above.getType().isSolid() && !at.getType().name().contains("LAVA") && !at.getType().name().contains("FIRE") && !below.getType().name().contains("LAVA") && !below.getType().name().contains("FIRE");
      } else {
         return false;
      }
   }
}
