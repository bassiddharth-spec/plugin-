package com.glidespoofer.events;

import com.glidespoofer.fake.FakePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class PlayerInteractFakeEntityEvent extends Event implements Cancellable {
   private static final HandlerList HANDLERS = new HandlerList();
   private final Player player;
   private final FakePlayer fakePlayer;
   private final boolean rightClick;
   private boolean cancelled;

   public PlayerInteractFakeEntityEvent(Player player, FakePlayer fakePlayer, boolean rightClick) {
      this.player = player;
      this.fakePlayer = fakePlayer;
      this.rightClick = rightClick;
      this.cancelled = false;
   }

   public Player getPlayer() {
      return this.player;
   }

   public FakePlayer getFakePlayer() {
      return this.fakePlayer;
   }

   public boolean isRightClick() {
      return this.rightClick;
   }

   public boolean isLeftClick() {
      return !this.rightClick;
   }

   public boolean isCancelled() {
      return this.cancelled;
   }

   public void setCancelled(boolean cancel) {
      this.cancelled = cancel;
   }

   public HandlerList getHandlers() {
      return HANDLERS;
   }

   public static HandlerList getHandlerList() {
      return HANDLERS;
   }
}
