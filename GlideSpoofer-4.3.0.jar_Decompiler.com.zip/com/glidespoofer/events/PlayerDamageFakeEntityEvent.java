package com.glidespoofer.events;

import com.glidespoofer.fake.FakePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class PlayerDamageFakeEntityEvent extends Event implements Cancellable {
   private static final HandlerList HANDLERS = new HandlerList();
   private final Player player;
   private final FakePlayer fakePlayer;
   private int damage;
   private boolean cancelled;

   public PlayerDamageFakeEntityEvent(Player player, FakePlayer fakePlayer, int damage) {
      this.player = player;
      this.fakePlayer = fakePlayer;
      this.damage = damage;
      this.cancelled = false;
   }

   public Player getPlayer() {
      return this.player;
   }

   public FakePlayer getFakePlayer() {
      return this.fakePlayer;
   }

   public int getDamage() {
      return this.damage;
   }

   public void setDamage(int damage) {
      this.damage = damage;
   }

   public boolean isCancelled() {
      return this.cancelled;
   }

   public void setCancelled(boolean cancel) {
      this.cancelled = cancel;
   }

   public HandlerList getHandlers() {
      return HANDLERS;
   }

   public static HandlerList getHandlerList() {
      return HANDLERS;
   }
}
