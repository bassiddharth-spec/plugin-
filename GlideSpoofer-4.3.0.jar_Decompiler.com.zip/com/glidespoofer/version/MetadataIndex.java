package com.glidespoofer.version;

public class MetadataIndex {
   public static int getSkinLayersIndex(ServerVersion version) {
      if (version.isOlderThanOrEquals(ServerVersion.V1_13)) {
         return 10;
      } else if (version.isOlderThanOrEquals(ServerVersion.V1_16)) {
         return 15;
      } else {
         return version.isNewerThanOrEquals(ServerVersion.V1_21_2) ? 18 : 17;
      }
   }

   public static int getCustomNameIndex(ServerVersion version) {
      if (version.isNewerThanOrEquals(ServerVersion.V1_21_2)) {
         return 2;
      } else {
         return version.isOlderThanOrEquals(ServerVersion.V1_8) ? 2 : 3;
      }
   }

   public static int getCustomNameVisibleIndex(ServerVersion version) {
      if (version.isNewerThanOrEquals(ServerVersion.V1_21_2)) {
         return 3;
      } else {
         return version.isOlderThanOrEquals(ServerVersion.V1_8) ? 3 : 4;
      }
   }

   public static byte getAllSkinLayersVisible() {
      return 127;
   }

   public static byte getBaseSkinOnly() {
      return 0;
   }

   public static byte createSkinLayers(boolean cape, boolean jacket, boolean leftSleeve, boolean rightSleeve, boolean leftPants, boolean rightPants, boolean hat) {
      byte value = 0;
      if (cape) {
         value = (byte)(value | 1);
      }

      if (jacket) {
         value = (byte)(value | 2);
      }

      if (leftSleeve) {
         value = (byte)(value | 4);
      }

      if (rightSleeve) {
         value = (byte)(value | 8);
      }

      if (leftPants) {
         value = (byte)(value | 16);
      }

      if (rightPants) {
         value = (byte)(value | 32);
      }

      if (hat) {
         value = (byte)(value | 64);
      }

      return value;
   }
}
