package com.glidespoofer.version;

import com.glidespoofer.fake.FakePlayer;
import org.bukkit.entity.Player;

public interface VersionAdapter {
   void sendPlayerInfoAdd(Player var1, FakePlayer var2);

   void sendPlayerInfoRemove(Player var1, FakePlayer var2);

   void sendPlayerInfoUpdatePing(Player var1, FakePlayer var2);

   void sendSpawnPlayer(Player var1, FakePlayer var2, int var3);

   void sendEntityMetadata(Player var1, FakePlayer var2, int var3);

   ServerVersion getSupportedVersion();
}
