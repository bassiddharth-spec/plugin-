package com.glidespoofer.version;

import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.protocol.player.ClientVersion;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class VersionManager {
   private static ServerVersion cachedServerVersion;

   public static ServerVersion getServerVersion() {
      if (cachedServerVersion == null) {
         cachedServerVersion = parseServerVersion();
      }

      return cachedServerVersion;
   }

   public static ServerVersion getClientVersion(Player player) {
      try {
         ClientVersion clientVersion = PacketEvents.getAPI().getProtocolManager().getClientVersion(player);
         return ServerVersion.fromClientVersion(clientVersion);
      } catch (Exception var2) {
         return getServerVersion();
      }
   }

   private static ServerVersion parseServerVersion() {
      String bukkitVersion = Bukkit.getBukkitVersion();
      String versionPart = bukkitVersion.split("-")[0];
      String majorMinor = versionPart;
      if (versionPart.contains(".")) {
         String[] parts = versionPart.split("\\.");
         if (parts.length >= 2) {
            majorMinor = parts[0] + "." + parts[1];
         }
      }

      if (versionPart.startsWith("1.19.")) {
         String[] versionParts = versionPart.split("\\.");
         String patch = versionParts.length >= 3 ? versionParts[2] : "0";
         int patchNum = Integer.parseInt(patch);
         if (patchNum >= 3) {
            return ServerVersion.V1_19_3;
         }
      }

      if (versionPart.startsWith("1.21.")) {
         String[] versionParts = versionPart.split("\\.");
         String patch = versionParts.length >= 3 ? versionParts[2] : "0";
         int patchNum = Integer.parseInt(patch);
         if (patchNum >= 4) {
            return ServerVersion.V1_21_4;
         }

         if (patchNum >= 2) {
            return ServerVersion.V1_21_2;
         }
      }

      for(ServerVersion version : ServerVersion.values()) {
         if (version.getVersionName().equals(majorMinor)) {
            return version;
         }
      }

      int serverVersionId = extractVersionId(versionPart);

      for(ServerVersion versionx : ServerVersion.values()) {
         if (versionx.getVersionId() == serverVersionId) {
            return versionx;
         }
      }

      return ServerVersion.V1_8;
   }

   private static int extractVersionId(String version) {
      try {
         String[] parts = version.split("\\.");
         if (parts.length >= 2) {
            return Integer.parseInt(parts[1]);
         }
      } catch (NumberFormatException var2) {
      }

      return 8;
   }

   public static boolean isServerPlayerInfoUpdate() {
      return getServerVersion().isPlayerInfoUpdate();
   }

   public static boolean isClientPlayerInfoUpdate(Player player) {
      return getClientVersion(player).isPlayerInfoUpdate();
   }

   public static void clearCache() {
      cachedServerVersion = null;
   }
}
