package com.glidespoofer.version.impl;

import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.protocol.chat.RemoteChatSession;
import com.github.retrooper.packetevents.protocol.entity.data.EntityData;
import com.github.retrooper.packetevents.protocol.entity.data.EntityDataTypes;
import com.github.retrooper.packetevents.protocol.entity.type.EntityTypes;
import com.github.retrooper.packetevents.protocol.player.GameMode;
import com.github.retrooper.packetevents.protocol.player.TextureProperty;
import com.github.retrooper.packetevents.protocol.player.UserProfile;
import com.github.retrooper.packetevents.util.Vector3d;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityMetadata;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPlayerInfoRemove;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPlayerInfoUpdate;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSpawnEntity;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPlayerInfoUpdate.Action;
import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.FakePlayer;
import com.glidespoofer.version.MetadataIndex;
import com.glidespoofer.version.ServerVersion;
import com.glidespoofer.version.VersionAdapter;
import com.glidespoofer.version.VersionManager;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class ModernPacketAdapter implements VersionAdapter {
   private final GlideSpoofer plugin;

   public ModernPacketAdapter(GlideSpoofer plugin) {
      this.plugin = plugin;
   }

   public void sendPlayerInfoAdd(Player viewer, FakePlayer fake) {
      try {
         UserProfile profile = this.createUserProfile(fake);
         Component displayName = LegacyComponentSerializer.legacySection().deserialize(fake.getFormattedDisplayName());
         WrapperPlayServerPlayerInfoUpdate.PlayerInfo info = new WrapperPlayServerPlayerInfoUpdate.PlayerInfo(profile, fake.isVisibleInTab(), fake.getPing(), GameMode.SURVIVAL, displayName, (RemoteChatSession)null);
         WrapperPlayServerPlayerInfoUpdate packet = new WrapperPlayServerPlayerInfoUpdate(EnumSet.of(Action.ADD_PLAYER, Action.UPDATE_LISTED, Action.UPDATE_LATENCY, Action.UPDATE_GAME_MODE, Action.UPDATE_DISPLAY_NAME), new WrapperPlayServerPlayerInfoUpdate.PlayerInfo[]{info});
         PacketEvents.getAPI().getPlayerManager().sendPacket(viewer, packet);
      } catch (Exception var7) {
         this.plugin.getLogger().warning("Failed to send modern PlayerInfoAdd: " + var7.getMessage());
      }

   }

   public void sendPlayerInfoRemove(Player viewer, FakePlayer fake) {
      try {
         WrapperPlayServerPlayerInfoRemove packet = new WrapperPlayServerPlayerInfoRemove(new UUID[]{fake.getUuid()});
         PacketEvents.getAPI().getPlayerManager().sendPacket(viewer, packet);
      } catch (Exception var4) {
         this.plugin.getLogger().warning("Failed to send modern PlayerInfoRemove: " + var4.getMessage());
      }

   }

   public void sendPlayerInfoUpdatePing(Player viewer, FakePlayer fake) {
      try {
         UserProfile profile = this.createUserProfile(fake);
         WrapperPlayServerPlayerInfoUpdate.PlayerInfo info = new WrapperPlayServerPlayerInfoUpdate.PlayerInfo(profile, true, fake.getPing(), GameMode.SURVIVAL, (Component)null, (RemoteChatSession)null);
         WrapperPlayServerPlayerInfoUpdate packet = new WrapperPlayServerPlayerInfoUpdate(EnumSet.of(Action.UPDATE_LATENCY), new WrapperPlayServerPlayerInfoUpdate.PlayerInfo[]{info});
         PacketEvents.getAPI().getPlayerManager().sendPacket(viewer, packet);
      } catch (Exception var6) {
      }

   }

   public void sendSpawnPlayer(Player viewer, FakePlayer fake, int entityId) {
      try {
         Location loc = fake.getLocation();
         if (loc == null) {
            return;
         }

         WrapperPlayServerSpawnEntity packet = new WrapperPlayServerSpawnEntity(entityId, Optional.of(fake.getUuid()), EntityTypes.PLAYER, new Vector3d(loc.getX(), loc.getY(), loc.getZ()), loc.getPitch(), loc.getYaw(), loc.getYaw(), 0, Optional.empty());
         PacketEvents.getAPI().getPlayerManager().sendPacket(viewer, packet);
      } catch (Exception var6) {
         this.plugin.getLogger().warning("Failed to send modern SpawnPlayer: " + var6.getMessage());
      }

   }

   public void sendEntityMetadata(Player viewer, FakePlayer fake, int entityId) {
      try {
         ServerVersion version = VersionManager.getClientVersion(viewer);
         List<EntityData<?>> metadata = new ArrayList();
         int customNameIndex = MetadataIndex.getCustomNameIndex(version);
         int customNameVisibleIndex = MetadataIndex.getCustomNameVisibleIndex(version);
         String formattedName = fake.getFormattedDisplayName();
         if (!formattedName.isEmpty()) {
            Component nameComponent = LegacyComponentSerializer.legacySection().deserialize(formattedName);
            metadata.add(new EntityData(customNameIndex, EntityDataTypes.OPTIONAL_COMPONENT, Optional.of(nameComponent)));
            metadata.add(new EntityData(customNameVisibleIndex, EntityDataTypes.BOOLEAN, true));
         }

         byte skinFlags = MetadataIndex.getAllSkinLayersVisible();
         int skinLayersIndex = MetadataIndex.getSkinLayersIndex(version);
         metadata.add(new EntityData(skinLayersIndex, EntityDataTypes.BYTE, skinFlags));
         WrapperPlayServerEntityMetadata packet = new WrapperPlayServerEntityMetadata(entityId, metadata);
         PacketEvents.getAPI().getPlayerManager().sendPacket(viewer, packet);
      } catch (Exception var12) {
         this.plugin.getLogger().warning("Failed to send modern EntityMetadata: " + var12.getMessage());
      }

   }

   public ServerVersion getSupportedVersion() {
      return ServerVersion.V1_19_3;
   }

   private UserProfile createUserProfile(FakePlayer fake) {
      List<TextureProperty> properties = new ArrayList();
      if (fake.hasSkin()) {
         properties.add(new TextureProperty("textures", fake.getSkinValue(), fake.getSkinSignature()));
      }

      return new UserProfile(fake.getUuid(), fake.getName(), properties);
   }
}
