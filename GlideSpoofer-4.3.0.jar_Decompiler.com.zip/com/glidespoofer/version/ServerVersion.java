package com.glidespoofer.version;

import com.github.retrooper.packetevents.protocol.player.ClientVersion;

public enum ServerVersion {
   V1_8(8, "1.8", ClientVersion.V_1_8),
   V1_9(9, "1.9", ClientVersion.V_1_9),
   V1_10(10, "1.10", ClientVersion.V_1_10),
   V1_11(11, "1.11", ClientVersion.V_1_11),
   V1_12(12, "1.12", ClientVersion.V_1_12),
   V1_13(13, "1.13", ClientVersion.V_1_13),
   V1_14(14, "1.14", ClientVersion.V_1_14),
   V1_15(15, "1.15", ClientVersion.V_1_15),
   V1_16(16, "1.16", ClientVersion.V_1_16),
   V1_17(17, "1.17", ClientVersion.V_1_17),
   V1_18(18, "1.18", ClientVersion.V_1_18),
   V1_19(19, "1.19", ClientVersion.V_1_19),
   V1_19_3(19, "1.19.3", ClientVersion.V_1_19_3),
   V1_20(20, "1.20", ClientVersion.V_1_20),
   V1_21(21, "1.21", ClientVersion.V_1_21),
   V1_21_2(21, "1.21.2", ClientVersion.V_1_21_2),
   V1_21_4(21, "1.21.4", ClientVersion.V_1_21_4),
   V1_21_8(21, "1.21.8", ClientVersion.V_1_21_4);

   private final int versionId;
   private final String versionName;
   private final ClientVersion clientVersion;

   private ServerVersion(int versionId, String versionName, ClientVersion clientVersion) {
      this.versionId = versionId;
      this.versionName = versionName;
      this.clientVersion = clientVersion;
   }

   public int getVersionId() {
      return this.versionId;
   }

   public String getVersionName() {
      return this.versionName;
   }

   public ClientVersion getClientVersion() {
      return this.clientVersion;
   }

   public boolean isLegacy() {
      return this.versionId <= 12;
   }

   public boolean isModern() {
      return this.versionId >= 13;
   }

   public boolean isNewerThanOrEquals(ServerVersion other) {
      return this.ordinal() >= other.ordinal();
   }

   public boolean isOlderThanOrEquals(ServerVersion other) {
      return this.ordinal() <= other.ordinal();
   }

   public boolean isPlayerInfoUpdate() {
      return this.isNewerThanOrEquals(V1_19_3);
   }

   public static ServerVersion fromClientVersion(ClientVersion clientVersion) {
      for(ServerVersion version : values()) {
         if (version.clientVersion == clientVersion) {
            return version;
         }
      }

      for(ServerVersion versionx : values()) {
         if (clientVersion.isNewerThan(versionx.clientVersion)) {
            return versionx;
         }
      }

      return V1_8;
   }

   public String toString() {
      return this.versionName;
   }

   // $FF: synthetic method
   private static ServerVersion[] $values() {
      return new ServerVersion[]{V1_8, V1_9, V1_10, V1_11, V1_12, V1_13, V1_14, V1_15, V1_16, V1_17, V1_18, V1_19, V1_19_3, V1_20, V1_21, V1_21_2, V1_21_4, V1_21_8};
   }
}
