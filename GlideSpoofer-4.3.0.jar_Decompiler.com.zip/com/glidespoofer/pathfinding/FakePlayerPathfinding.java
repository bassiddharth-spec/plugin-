package com.glidespoofer.pathfinding;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.nms.SimpleNMSHandler;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class FakePlayerPathfinding {
   private final GlideSpoofer plugin;
   private final ConcurrentHashMap<UUID, PathfindingTask> activeTasks = new ConcurrentHashMap();
   private static final double BASE_MOVE_SPEED = 0.15;
   private static final double SPRINT_MOVE_SPEED = 0.2;
   private static final double JUMP_SPEED = 0.3;

   public FakePlayerPathfinding(GlideSpoofer plugin) {
      this.plugin = plugin;
   }

   public void pathfindTo(Player player, Location target, PathfindingCallback callback) {
      if (player != null && target != null) {
         UUID uuid = player.getUniqueId();
         PathfindingTask existing = (PathfindingTask)this.activeTasks.get(uuid);
         if (existing != null) {
            existing.cancel();
         }

         Runnable pathfindingTask = () -> {
            AStarPathfinder finder = new AStarPathfinder(player.getWorld());
            List<Location> path = finder.findPath(player.getLocation(), target);
            Runnable movementTask = () -> {
               if (path.isEmpty()) {
                  if (callback != null) {
                     callback.onComplete(false);
                  }
               } else {
                  PathfindingTask task = new PathfindingTask(this.plugin, player, path, callback);
                  this.activeTasks.put(uuid, task);
                  task.start();
               }

            };
            if (GlideSpoofer.isFolia()) {
               movementTask.run();
            } else {
               Bukkit.getScheduler().runTask(this.plugin, movementTask);
            }

         };
         if (GlideSpoofer.isFolia()) {
            pathfindingTask.run();
         } else {
            Bukkit.getScheduler().runTaskAsynchronously(this.plugin, pathfindingTask);
         }
      } else if (callback != null) {
         callback.onComplete(false);
      }

   }

   public void wander(Player player, double range) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         PathfindingTask existing = (PathfindingTask)this.activeTasks.get(uuid);
         if (existing != null) {
            existing.cancel();
         }

         PathfindingTask task = new PathfindingTask(this.plugin, player, range);
         this.activeTasks.put(uuid, task);
         task.start();
      }

   }

   public void stopPathfinding(UUID uuid) {
      PathfindingTask task = (PathfindingTask)this.activeTasks.remove(uuid);
      if (task != null) {
         task.cancel();
      }

   }

   public void stopAll() {
      this.activeTasks.forEach((uuid, task) -> task.cancel());
      this.activeTasks.clear();
   }

   public boolean isPathfinding(UUID uuid) {
      PathfindingTask task = (PathfindingTask)this.activeTasks.get(uuid);
      return task != null && task.isRunning();
   }

   public class PathfindingTask {
      private final GlideSpoofer plugin;
      private final Player player;
      private final List<Location> path;
      private final double wanderRange;
      private final PathfindingCallback callback;
      private BukkitTask movementTask;
      private int pathIndex = 0;
      private boolean running = false;
      private boolean isSprinting = false;
      private int jumpTicks = 0;
      private boolean isJumping = false;
      private int jumpCooldown = 0;
      private int jumpTicksActive = 0;
      private Method jumpFromGroundMethod = null;
      private static final long MOVEMENT_TICK_RATE = 1L;

      PathfindingTask(GlideSpoofer plugin, Player player, List<Location> path, PathfindingCallback callback) {
         this.plugin = plugin;
         this.player = player;
         this.path = path;
         this.wanderRange = (double)0.0F;
         this.callback = callback;
      }

      PathfindingTask(GlideSpoofer plugin, Player player, double wanderRange) {
         this.plugin = plugin;
         this.player = player;
         this.path = new ArrayList();
         this.wanderRange = wanderRange;
         this.callback = null;
      }

      void start() {
         this.running = true;
         if (this.wanderRange > (double)0.0F) {
            this.startWanderTask();
         } else if (this.path != null && !this.path.isEmpty()) {
            this.startMovementTask();
         }

      }

      private void startWanderTask() {
         this.pickWanderTarget();
      }

      private void pickWanderTarget() {
         if (this.running && this.player.isOnline()) {
            Location current = this.player.getLocation();
            double angle = Math.random() * Math.PI * (double)2.0F;
            double distance = (double)5.0F + Math.random() * (this.wanderRange - (double)5.0F);
            Location target = current.clone();
            target.setX(current.getX() + Math.cos(angle) * distance);
            target.setZ(current.getZ() + Math.sin(angle) * distance);
            int safeY = this.findSafeY(target);
            target.setY((double)safeY);
            Runnable pathfindingTask = () -> {
               AStarPathfinder finder = new AStarPathfinder(this.player.getWorld());
               List<Location> newPath = finder.findPath(this.player.getLocation(), target);
               Runnable applyPathTask = () -> {
                  if (this.running) {
                     if (newPath.isEmpty()) {
                        Bukkit.getScheduler().runTaskLater(this.plugin, this::pickWanderTarget, 60L);
                     } else {
                        this.path.clear();
                        this.path.addAll(newPath);
                        this.pathIndex = 0;
                        if (this.movementTask != null) {
                           this.movementTask.cancel();
                        }

                        this.startMovementTask();
                     }
                  }

               };
               if (GlideSpoofer.isFolia()) {
                  applyPathTask.run();
               } else {
                  Bukkit.getScheduler().runTask(this.plugin, applyPathTask);
               }

            };
            if (GlideSpoofer.isFolia()) {
               pathfindingTask.run();
            } else {
               Bukkit.getScheduler().runTaskAsynchronously(this.plugin, pathfindingTask);
            }
         }

      }

      private void startMovementTask() {
         this.movementTask = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
            if (this.running && this.player.isOnline()) {
               if (this.path != null && this.pathIndex < this.path.size()) {
                  Location target = (Location)this.path.get(this.pathIndex);
                  Location current = this.player.getLocation();
                  double distance = current.distance(target);
                  if (distance < (double)0.5F) {
                     ++this.pathIndex;
                  } else {
                     double dx = target.getX() - current.getX();
                     double dz = target.getZ() - current.getZ();
                     double dy = target.getY() - current.getY();
                     float targetYaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
                     if (!this.moveWithNMS(this.player, current, target, targetYaw, dy)) {
                        double speed = this.isSprinting ? 0.2 : 0.15;
                        Vector direction = target.toVector().subtract(current.toVector());
                        direction.setY(0);
                        float yaw = current.getYaw();
                        if (direction.lengthSquared() > 1.0E-4) {
                           direction.normalize();
                           yaw = (float)Math.toDegrees(Math.atan2(-direction.getX(), direction.getZ()));
                        } else {
                           direction = new Vector(0, 0, 0);
                        }

                        Location newLoc = current.clone();
                        newLoc.setX(newLoc.getX() + direction.getX() * speed);
                        newLoc.setZ(newLoc.getZ() + direction.getZ() * speed);
                        newLoc.setY(target.getY());
                        newLoc.setYaw(yaw);
                        newLoc.setPitch(0.0F);
                        GlideSpoofer.teleportSafe(this.player, newLoc);
                     }
                  }
               } else {
                  this.clearNMSMovement();
                  if (this.wanderRange > (double)0.0F) {
                     this.pickWanderTarget();
                  } else {
                     if (this.callback != null) {
                        this.callback.onComplete(true);
                     }

                     this.cancel();
                  }
               }
            } else {
               this.cancel();
            }

         }, 1L, 1L);
      }

      private boolean moveWithNMS(Player player, Location current, Location target, float targetYaw, double dy) {
         try {
            Method getHandle = player.getClass().getMethod("getHandle");
            Object handle = getHandle.invoke(player);
            if (handle == null) {
               return false;
            } else {
               Class<?> clazz = handle.getClass();
               Field zzaField = null;
               Field xxaField = null;
               Field jumpingField = null;
               Field onGroundField = null;
               Method setYRotMethod = null;
               Method setXRotMethod = null;
               Method setSprintingMethod = null;
               Method jumpMethod = null;

               for(Class<?> c = clazz; c != null && c != Object.class; c = c.getSuperclass()) {
                  for(Field f : c.getDeclaredFields()) {
                     if (f.getType() == Float.TYPE && !Modifier.isStatic(f.getModifiers())) {
                        if (f.getName().equals("zza")) {
                           zzaField = f;
                           f.setAccessible(true);
                        } else if (f.getName().equals("xxa")) {
                           xxaField = f;
                           f.setAccessible(true);
                        }
                     }
                  }

                  if (jumpingField == null) {
                     try {
                        jumpingField = c.getDeclaredField("jumping");
                        if (jumpingField.getType() == Boolean.TYPE) {
                           jumpingField.setAccessible(true);
                        } else {
                           jumpingField = null;
                        }
                     } catch (NoSuchFieldException var39) {
                     }
                  }

                  if (onGroundField == null) {
                     try {
                        onGroundField = c.getDeclaredField("onGround");
                        if (onGroundField.getType() == Boolean.TYPE) {
                           onGroundField.setAccessible(true);
                        } else {
                           onGroundField = null;
                        }
                     } catch (NoSuchFieldException var38) {
                     }
                  }

                  if (setYRotMethod == null) {
                     try {
                        setYRotMethod = c.getDeclaredMethod("setYRot", Float.TYPE);
                        setYRotMethod.setAccessible(true);
                     } catch (NoSuchMethodException var37) {
                     }
                  }

                  if (setXRotMethod == null) {
                     try {
                        setXRotMethod = c.getDeclaredMethod("setXRot", Float.TYPE);
                        setXRotMethod.setAccessible(true);
                     } catch (NoSuchMethodException var36) {
                     }
                  }

                  if (setSprintingMethod == null) {
                     try {
                        setSprintingMethod = c.getDeclaredMethod("setSprinting", Boolean.TYPE);
                        setSprintingMethod.setAccessible(true);
                     } catch (NoSuchMethodException var35) {
                     }
                  }

                  if (this.jumpFromGroundMethod == null) {
                     try {
                        this.jumpFromGroundMethod = c.getDeclaredMethod("jumpFromGround");
                        this.jumpFromGroundMethod.setAccessible(true);
                     } catch (NoSuchMethodException var34) {
                     }
                  }

                  if (jumpMethod == null) {
                     try {
                        jumpMethod = c.getDeclaredMethod("jump");
                        jumpMethod.setAccessible(true);
                     } catch (NoSuchMethodException var33) {
                     }
                  }
               }

               if (zzaField == null) {
                  return false;
               } else {
                  float currentYaw = current.getYaw();

                  float yawDiff;
                  for(yawDiff = targetYaw - currentYaw; yawDiff > 180.0F; yawDiff -= 360.0F) {
                  }

                  while(yawDiff < -180.0F) {
                     yawDiff += 360.0F;
                  }

                  float maxTurn = 25.0F;
                  if (Math.abs(yawDiff) > maxTurn) {
                     yawDiff = yawDiff > 0.0F ? maxTurn : -maxTurn;
                  }

                  float newYaw = currentYaw + yawDiff;
                  if (setYRotMethod != null) {
                     setYRotMethod.invoke(handle, newYaw);
                  }

                  if (setXRotMethod != null) {
                     double horizDist = Math.sqrt((target.getX() - current.getX()) * (target.getX() - current.getX()) + (target.getZ() - current.getZ()) * (target.getZ() - current.getZ()));
                     float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horizDist)));
                     pitch = Math.max(-45.0F, Math.min(45.0F, pitch));
                     setXRotMethod.invoke(handle, pitch);
                  }

                  float speed = this.isSprinting ? 1.3F : 0.98F;
                  float absYawDiff = Math.abs(yawDiff);
                  if (absYawDiff > 60.0F) {
                     speed *= 0.3F;
                  } else if (absYawDiff > 30.0F) {
                     speed *= 0.7F;
                  }

                  zzaField.setFloat(handle, speed);
                  if (xxaField != null) {
                     xxaField.setFloat(handle, 0.0F);
                  }

                  if (setSprintingMethod != null) {
                     setSprintingMethod.invoke(handle, this.isSprinting);
                  }

                  boolean onGround = false;
                  if (onGroundField != null) {
                     onGround = onGroundField.getBoolean(handle);
                  }

                  boolean blockBelowIsSolid = false;
                  Block below = current.getWorld().getBlockAt(current.getBlockX(), current.getBlockY() - 1, current.getBlockZ());
                  if (below != null && below.getType().isSolid()) {
                     blockBelowIsSolid = true;
                  }

                  boolean shouldJump = this.needsJump(current, newYaw);
                  if (this.jumpCooldown > 0) {
                     --this.jumpCooldown;
                  }

                  if (this.jumpTicksActive > 0) {
                     if (jumpingField != null) {
                        jumpingField.setBoolean(handle, true);
                     }

                     --this.jumpTicksActive;
                  } else if (shouldJump && (onGround || blockBelowIsSolid) && this.jumpCooldown == 0) {
                     this.jumpCooldown = 5;
                     this.jumpTicksActive = 5;
                     if (jumpingField != null) {
                        jumpingField.setBoolean(handle, true);
                     }

                     if (this.jumpFromGroundMethod != null) {
                        try {
                           this.jumpFromGroundMethod.invoke(handle);
                        } catch (Exception var40) {
                           if (jumpMethod != null) {
                              try {
                                 jumpMethod.invoke(handle);
                              } catch (Exception var32) {
                              }
                           }
                        }
                     } else if (jumpMethod != null) {
                        try {
                           jumpMethod.invoke(handle);
                        } catch (Exception var31) {
                        }
                     }
                  } else if (jumpingField != null) {
                     jumpingField.setBoolean(handle, false);
                  }

                  Location updatedLoc = current.clone();
                  updatedLoc.setYaw(newYaw);

                  try {
                     SimpleNMSHandler nmsHandler = this.plugin.getSimpleFakePlayerManager().getNMSHandler();
                     if (nmsHandler != null) {
                        nmsHandler.updatePosition(player, updatedLoc, true);
                     }
                  } catch (Exception var30) {
                  }

                  return true;
               }
            }
         } catch (Exception var411) {
            return false;
         }
      }

      private boolean needsJump(Location loc, float yaw) {
         if (loc != null && loc.getWorld() != null) {
            World world = loc.getWorld();
            int feetY = loc.getBlockY();
            int headY = feetY + 1;
            double rad = Math.toRadians((double)yaw);
            double sin = -Math.sin(rad);
            double cos = Math.cos(rad);
            double checkDist = 1.2;
            double checkX = loc.getX() + sin * checkDist;
            double checkZ = loc.getZ() + cos * checkDist;
            int bx = (int)Math.floor(checkX);
            int bz = (int)Math.floor(checkZ);
            Block blockAhead = world.getBlockAt(bx, feetY, bz);
            Block blockAboveAhead = world.getBlockAt(bx, headY, bz);
            if (blockAhead.getType().isSolid() && !blockAboveAhead.getType().isSolid()) {
               return true;
            } else if (blockAboveAhead.getType().isSolid()) {
               return true;
            } else {
               Block groundAhead = world.getBlockAt(bx, feetY - 1, bz);
               Block currentGround = world.getBlockAt(loc.getBlockX(), feetY - 1, loc.getBlockZ());
               if (groundAhead.getType().isSolid() && !currentGround.getType().isSolid()) {
                  return true;
               } else {
                  double checkDist2 = 2.4;
                  double checkX2 = loc.getX() + sin * checkDist2;
                  double checkZ2 = loc.getZ() + cos * checkDist2;
                  int bx2 = (int)Math.floor(checkX2);
                  int bz2 = (int)Math.floor(checkZ2);
                  Block blockAhead2 = world.getBlockAt(bx2, feetY, bz2);
                  Block blockAboveAhead2 = world.getBlockAt(bx2, headY, bz2);
                  return blockAhead2.getType().isSolid() && !blockAboveAhead2.getType().isSolid();
               }
            }
         } else {
            return false;
         }
      }

      private void clearNMSMovement() {
         this.jumpCooldown = 0;
         this.jumpTicksActive = 0;

         try {
            Method getHandle = this.player.getClass().getMethod("getHandle");
            Object handle = getHandle.invoke(this.player);
            if (handle == null) {
               return;
            }

            for(Class<?> c = handle.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
               for(Field f : c.getDeclaredFields()) {
                  if (f.getType() == Float.TYPE && !Modifier.isStatic(f.getModifiers()) && (f.getName().equals("zza") || f.getName().equals("xxa"))) {
                     f.setAccessible(true);
                     f.setFloat(handle, 0.0F);
                  }
               }

               try {
                  Field jf = c.getDeclaredField("jumping");
                  if (jf.getType() == Boolean.TYPE) {
                     jf.setAccessible(true);
                     jf.setBoolean(handle, false);
                  }
               } catch (NoSuchFieldException var9) {
               }

               try {
                  Method m = c.getDeclaredMethod("setSprinting", Boolean.TYPE);
                  m.setAccessible(true);
                  m.invoke(handle, false);
               } catch (NoSuchMethodException var8) {
               }
            }
         } catch (Exception var10) {
         }

      }

      private Location findValidNearbyLocation(Location current, Vector direction, double speed) {
         if (this.canStandAt(current)) {
            return current;
         } else {
            Location up = current.clone().add((double)0.0F, (double)0.5F, (double)0.0F);
            if (this.canStandAt(up)) {
               up.setX(up.getX() + direction.getX() * speed);
               up.setZ(up.getZ() + direction.getZ() * speed);
               if (this.canStandAt(up)) {
                  return up;
               }
            }

            for(int dy = -2; dy <= 2; ++dy) {
               Location test = current.clone().add((double)0.0F, (double)dy, (double)0.0F);
               if (this.canStandAt(test)) {
                  return test;
               }
            }

            return current;
         }
      }

      private boolean isInBlock(Location loc) {
         Block feet = loc.getBlock();
         Block head = loc.clone().add((double)0.0F, (double)1.0F, (double)0.0F).getBlock();
         return this.isSolidBlock(feet) || this.isSolidBlock(head);
      }

      private boolean isBlocked(Location loc) {
         return loc != null && !(loc.getY() < (double)-64.0F) && !(loc.getY() > (double)320.0F) ? this.isSolidBlock(loc.getBlock()) : true;
      }

      private boolean canStandAt(Location loc) {
         if (loc != null && !(loc.getY() < (double)-64.0F) && !(loc.getY() > (double)320.0F)) {
            Block feet = loc.getBlock();
            Block head = loc.clone().add((double)0.0F, (double)1.0F, (double)0.0F).getBlock();
            Block below = loc.clone().add((double)0.0F, (double)-0.5F, (double)0.0F).getBlock();
            return !this.isSolidBlock(feet) && !this.isSolidBlock(head) ? below.getType().isSolid() || this.isLiquid(below) : false;
         } else {
            return false;
         }
      }

      private boolean isSolidBlock(Block block) {
         if (block == null) {
            return false;
         } else {
            Material type = block.getType();
            if (type != Material.AIR && type != Material.CAVE_AIR) {
               if (type != Material.WATER && type != Material.SEAGRASS && type != Material.TALL_SEAGRASS) {
                  if (type.name().contains("CARPET")) {
                     return false;
                  } else if (type != Material.SHORT_GRASS && type != Material.FERN && type != Material.DEAD_BUSH && type != Material.VINE) {
                     if (type.name().contains("SIGN")) {
                        return false;
                     } else if (type == Material.LADDER) {
                        return false;
                     } else if (type.name().contains("DOOR") && !type.name().contains("BLOCK")) {
                        return false;
                     } else if (type.name().contains("PLATE")) {
                        return false;
                     } else {
                        return type != Material.TRIPWIRE && type != Material.TRIPWIRE_HOOK ? type.isSolid() : false;
                     }
                  } else {
                     return false;
                  }
               } else {
                  return false;
               }
            } else {
               return false;
            }
         }
      }

      private boolean isLiquid(Block block) {
         return block == null ? false : block.isLiquid();
      }

      private int findSafeY(Location loc) {
         int startY = loc.getBlockY();
         int minY = Math.max(0, startY - 10);

         for(int y = startY; y >= minY; --y) {
            Block below = loc.getWorld().getBlockAt(loc.getBlockX(), y - 1, loc.getBlockZ());
            Block at = loc.getWorld().getBlockAt(loc.getBlockX(), y, loc.getBlockZ());
            Block above = loc.getWorld().getBlockAt(loc.getBlockX(), y + 1, loc.getBlockZ());
            if (below.getType().isSolid() && !at.getType().isSolid() && !above.getType().isSolid()) {
               return y;
            }
         }

         return startY;
      }

      void cancel() {
         this.running = false;
         this.clearNMSMovement();
         if (this.movementTask != null) {
            this.movementTask.cancel();
            this.movementTask = null;
         }

         FakePlayerPathfinding.this.activeTasks.remove(this.player.getUniqueId());
      }

      boolean isRunning() {
         return this.running;
      }
   }

   public interface PathfindingCallback {
      void onComplete(boolean var1);
   }
}
