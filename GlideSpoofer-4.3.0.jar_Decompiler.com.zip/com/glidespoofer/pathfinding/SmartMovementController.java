package com.glidespoofer.pathfinding;

import java.util.List;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

public class SmartMovementController {
   private final UUID fakePlayerUUID;
   private MovementGoal currentGoal;
   private Location guardPosition;
   private LivingEntity combatTarget;
   private String targetBlockType;
   private double reachDistance = (double)4.0F;
   private double attackRange = (double)3.5F;
   private boolean autoAttack = true;
   private boolean autoEquip = true;
   private List<Location> currentPath;
   private int pathIndex = 0;
   private long lastPathUpdate = 0L;
   private static final long PATH_UPDATE_INTERVAL = 500L;

   public SmartMovementController(UUID fakePlayerUUID) {
      this.fakePlayerUUID = fakePlayerUUID;
   }

   public void goToBlock(String blockType) {
      this.targetBlockType = blockType;
      this.currentGoal = SmartMovementController.MovementGoal.GO_TO_BLOCK;
      this.currentPath = null;
   }

   public void goTo(Location location) {
      AStarPathfinder pathfinder = new AStarPathfinder(location.getWorld());
      this.currentPath = pathfinder.findPath(new Location(location.getWorld(), (double)0.0F, (double)0.0F, (double)0.0F), location);
      this.currentGoal = SmartMovementController.MovementGoal.GO_TO_BLOCK;
      this.pathIndex = 0;
   }

   public void guard(Location position) {
      this.guardPosition = position.clone();
      this.currentGoal = SmartMovementController.MovementGoal.GUARD;
   }

   public void stop() {
      this.currentGoal = SmartMovementController.MovementGoal.NONE;
      this.guardPosition = null;
      this.combatTarget = null;
      this.currentPath = null;
   }

   public void attack(LivingEntity target) {
      this.combatTarget = target;
      this.currentGoal = SmartMovementController.MovementGoal.COMBAT;
   }

   public Location getNextMove(Location currentLoc) {
      if (currentLoc == null) {
         return null;
      } else {
         switch (this.currentGoal.ordinal()) {
            case 1 -> {
               return this.getGoToBlockMove(currentLoc);
            }
            case 2 -> {
               return this.getGuardMove(currentLoc);
            }
            case 3 -> {
               return this.getCombatMove(currentLoc);
            }
            default -> {
               return null;
            }
         }
      }
   }

   public boolean shouldAttack() {
      if (this.currentGoal == SmartMovementController.MovementGoal.COMBAT && this.combatTarget != null && this.combatTarget.isValid()) {
         return this.currentGoal == SmartMovementController.MovementGoal.COMBAT && this.combatTarget != null && this.combatTarget.isValid() && !this.combatTarget.isDead();
      } else {
         if (this.currentGoal == SmartMovementController.MovementGoal.GUARD && this.autoAttack) {
            LivingEntity nearest = this.findNearestHostile(this.currentGuardLocation());
            if (nearest != null && nearest.getLocation().distance(this.currentGuardLocation()) < (double)16.0F) {
               this.combatTarget = nearest;
               this.currentGoal = SmartMovementController.MovementGoal.COMBAT;
               return true;
            }
         }

         return false;
      }
   }

   public LivingEntity getCombatTarget() {
      return this.combatTarget;
   }

   public void autoEquip(Player fakePlayer) {
      if (this.autoEquip && fakePlayer != null) {
         ItemStack bestSword = null;
         int bestDamage = 0;

         for(ItemStack item : fakePlayer.getInventory().getContents()) {
            if (item != null && item.getType().name().contains("SWORD")) {
               int damage = this.estimateSwordDamage(item.getType().name());
               if (damage > bestDamage) {
                  bestDamage = damage;
                  bestSword = item;
               }
            }
         }

         if (bestSword != null) {
            fakePlayer.getInventory().setItemInMainHand(bestSword);
         }

         for(ItemStack itemx : fakePlayer.getInventory().getContents()) {
            if (itemx != null && itemx.getType().name().contains("SHIELD")) {
               fakePlayer.getInventory().setItemInOffHand(itemx);
               break;
            }
         }
      }

   }

   private Location getGoToBlockMove(Location currentLoc) {
      if (this.targetBlockType != null) {
         Location blockLoc = this.findNearestBlock(currentLoc, this.targetBlockType, 32);
         if (blockLoc != null) {
            double distance = currentLoc.distance(blockLoc);
            if (distance <= (double)2.0F) {
               this.stop();
               return null;
            }

            long now = System.currentTimeMillis();
            if (this.currentPath == null || now - this.lastPathUpdate > 500L) {
               AStarPathfinder pathfinder = new AStarPathfinder(currentLoc.getWorld());
               this.currentPath = pathfinder.findPath(currentLoc, blockLoc);
               this.pathIndex = 0;
               this.lastPathUpdate = now;
            }

            if (this.currentPath != null && this.pathIndex < this.currentPath.size()) {
               Location next = (Location)this.currentPath.get(this.pathIndex);
               if (currentLoc.distance(next) < (double)0.5F) {
                  ++this.pathIndex;
               }

               return next;
            }
         }
      }

      return null;
   }

   private Location getGuardMove(Location currentLoc) {
      if (this.guardPosition == null) {
         this.stop();
         return null;
      } else {
         double distance = currentLoc.distance(this.guardPosition);
         if (distance > (double)3.0F) {
            long now = System.currentTimeMillis();
            if (this.currentPath == null || now - this.lastPathUpdate > 500L) {
               AStarPathfinder pathfinder = new AStarPathfinder(currentLoc.getWorld());
               this.currentPath = pathfinder.findPath(currentLoc, this.guardPosition);
               this.pathIndex = 0;
               this.lastPathUpdate = now;
            }

            if (this.currentPath != null && this.pathIndex < this.currentPath.size()) {
               Location next = (Location)this.currentPath.get(this.pathIndex);
               if (currentLoc.distance(next) < (double)0.5F) {
                  ++this.pathIndex;
               }

               return next;
            }
         }

         return null;
      }
   }

   private Location getCombatMove(Location currentLoc) {
      if (this.combatTarget != null && this.combatTarget.isValid() && !this.combatTarget.isDead()) {
         Location targetLoc = this.combatTarget.getLocation();
         double distance = currentLoc.distance(targetLoc);
         if (distance > this.attackRange) {
            return this.getBestDirection(currentLoc, targetLoc);
         } else {
            return distance < (double)2.0F ? this.circleAround(currentLoc, targetLoc) : null;
         }
      } else {
         if (this.guardPosition != null) {
            this.currentGoal = SmartMovementController.MovementGoal.GUARD;
         } else {
            this.currentGoal = SmartMovementController.MovementGoal.NONE;
         }

         this.combatTarget = null;
         return null;
      }
   }

   private Location getBestDirection(Location from, Location to) {
      World world = from.getWorld();
      if (world == null) {
         return null;
      } else {
         int dx = Integer.compare(to.getBlockX(), from.getBlockX());
         int dz = Integer.compare(to.getBlockZ(), from.getBlockZ());
         Location direct = from.clone().add((double)dx * (double)0.5F, (double)0.0F, (double)dz * (double)0.5F);
         if (this.isSafe(direct) && this.hasGroundBelow(direct)) {
            return direct;
         } else {
            Location sprintJump = from.clone();
            sprintJump.setY(sprintJump.getY() + (double)1.0F);
            sprintJump.add((double)dx * 0.7, (double)0.0F, (double)dz * 0.7);
            if (this.isSafe(sprintJump) && this.hasSupport(sprintJump)) {
               return sprintJump;
            } else {
               int[][] diagonals = new int[][]{{1, 1}, {1, -1}, {-1, 1}, {-1, -1}};

               for(int[] diag : diagonals) {
                  Location diagLoc = from.clone().add((double)diag[0] * (double)0.5F, (double)0.0F, (double)diag[1] * (double)0.5F);
                  double currentDist = from.distance(to);
                  double diagDist = diagLoc.distance(to);
                  if (diagDist < currentDist && this.isSafe(diagLoc) && this.hasGroundBelow(diagLoc)) {
                     return diagLoc;
                  }
               }

               return null;
            }
         }
      }
   }

   private Location circleAround(Location from, Location target) {
      Vector toTarget = target.toVector().subtract(from.toVector()).setY(0);
      Vector perpendicular = (new Vector(-toTarget.getZ(), (double)0.0F, toTarget.getX())).normalize();
      return from.clone().add(perpendicular.multiply(0.3));
   }

   private Location findNearestBlock(Location start, String blockType, int maxDistance) {
      World world = start.getWorld();
      if (world == null) {
         return null;
      } else {
         Location nearest = null;
         double closestDist = (double)maxDistance;
         int sx = start.getBlockX();
         int sy = start.getBlockY();
         int sz = start.getBlockZ();

         for(int radius = 1; radius <= maxDistance; ++radius) {
            for(int x = -radius; x <= radius; ++x) {
               for(int y = Math.max(-64, sy - radius); y <= Math.min(320, sy + radius); ++y) {
                  for(int z = -radius; z <= radius; ++z) {
                     Block block = world.getBlockAt(sx + x, sy + y, sz + z);
                     if (block.getType().name().contains(blockType)) {
                        Location loc = block.getLocation();
                        double dist = start.distance(loc);
                        if (dist < closestDist) {
                           nearest = loc;
                           closestDist = dist;
                        }
                     }
                  }
               }
            }
         }

         return nearest;
      }
   }

   private LivingEntity findNearestHostile(Location guardLoc) {
      if (guardLoc == null) {
         return null;
      } else {
         World world = guardLoc.getWorld();
         if (world == null) {
            return null;
         } else {
            LivingEntity nearest = null;
            double closestDist = (double)16.0F;

            for(LivingEntity entity : world.getLivingEntities()) {
               if (!entity.getUniqueId().equals(this.fakePlayerUUID) && (!(entity instanceof Player) || this.isPvPEnabled(entity)) && (entity instanceof Player || this.isHostileMob(entity))) {
                  double dist = entity.getLocation().distance(guardLoc);
                  if (dist < closestDist) {
                     closestDist = dist;
                     nearest = entity;
                  }
               }
            }

            return nearest;
         }
      }
   }

   private boolean isHostileMob(LivingEntity entity) {
      String type = entity.getType().name();
      return type.contains("SKELETON") || type.contains("SPIDER") || type.contains("CREEPER") || type.contains("ENDERMAN") || type.contains("WITCH") || type.contains("SLIME") || type.contains("PHANTOM") || type.contains("PILLAGER") || type.contains("RAVAGER") || type.contains("VINDICATOR") || type.contains("EVOKER");
   }

   private boolean isPvPEnabled(Entity entity) {
      return true;
   }

   private Location currentGuardLocation() {
      return this.guardPosition;
   }

   private boolean isSafe(Location loc) {
      if (loc != null && loc.getWorld() != null) {
         Block feet = loc.getBlock();
         Block head = loc.clone().add((double)0.0F, (double)1.0F, (double)0.0F).getBlock();
         if (!feet.getType().isSolid() && !head.getType().isSolid()) {
            String name = feet.getType().name();
            return !name.contains("LAVA") && !name.contains("FIRE") && !name.contains("MAGMA") && !name.contains("CAMPFIRE");
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean hasGroundBelow(Location loc) {
      if (loc != null && loc.getWorld() != null) {
         Block below = loc.getWorld().getBlockAt(loc.getBlockX(), loc.getBlockY() - 1, loc.getBlockZ());
         return below.getType().isSolid();
      } else {
         return false;
      }
   }

   private boolean hasSupport(Location loc) {
      if (this.hasGroundBelow(loc)) {
         return true;
      } else if (loc != null && loc.getWorld() != null) {
         Block below = loc.getWorld().getBlockAt(loc.getBlockX(), loc.getBlockY() - 1, loc.getBlockZ());
         String type = below.getType().name();
         return type.contains("WATER") || type.contains("LAVA");
      } else {
         return false;
      }
   }

   private int estimateSwordDamage(String swordType) {
      if (swordType.contains("DIAMOND")) {
         return 7;
      } else if (swordType.contains("IRON")) {
         return 6;
      } else if (swordType.contains("STONE")) {
         return 5;
      } else if (swordType.contains("GOLD")) {
         return 4;
      } else if (swordType.contains("WOODEN")) {
         return 4;
      } else {
         return swordType.contains("NETHERITE") ? 8 : 3;
      }
   }

   public MovementGoal getCurrentGoal() {
      return this.currentGoal;
   }

   public Location getGuardPosition() {
      return this.guardPosition;
   }

   public void setAttackRange(double range) {
      this.attackRange = range;
   }

   public void setAutoAttack(boolean enabled) {
      this.autoAttack = enabled;
   }

   public void setAutoEquip(boolean enabled) {
      this.autoEquip = enabled;
   }

   public void setCombatTarget(LivingEntity target) {
      this.combatTarget = target;
      if (target != null) {
         this.currentGoal = SmartMovementController.MovementGoal.COMBAT;
      }

   }

   public static enum MovementGoal {
      NONE,
      GO_TO_BLOCK,
      GUARD,
      COMBAT,
      PATROL;

      // $FF: synthetic method
      private static MovementGoal[] $values() {
         return new MovementGoal[]{NONE, GO_TO_BLOCK, GUARD, COMBAT, PATROL};
      }
   }
}
