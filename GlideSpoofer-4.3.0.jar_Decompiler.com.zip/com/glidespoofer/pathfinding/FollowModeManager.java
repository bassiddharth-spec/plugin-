package com.glidespoofer.pathfinding;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import com.glidespoofer.listener.FakePlayerDamageListener;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

public class FollowModeManager {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer");
   private final GlideSpoofer plugin;
   private final ConcurrentHashMap<UUID, FT> tasks = new ConcurrentHashMap();
   private static Method setYRotMethod;
   private static Method setXRotMethod;
   private static Method setSprintingMethod;
   private static Method setPosMethod;
   private static Method doTickMethod_Entity;
   private static Method doTickMethod_ServerPlayer;
   private static Method getHandleMethod_CraftPlayer;
   private static Method jumpMethod;
   private static Method jumpFromGroundMethod;
   private static Field zzaField;
   private static Field xxaField;
   private static Field jumpingField;
   private static Field onGroundField;
   private static Field deltaMovementField;
   private static Method moveRelativeMethod;
   private static Method moveMethod;
   private static Object moverTypeSelf;
   private static Method getDeltaMovementMethod;
   private static Constructor<?> vec3Constructor;
   private static Class<?> vec3Class;
   private static Method getAttributesMethod;
   private static Field movementSpeedAttributeField;
   private static Method getAttributeValueMethod;
   private static Method isSprintingMethod;
   private static Method isShiftKeyDownMethod;
   private static boolean moveInit = false;
   private static boolean nmsInit = false;
   private static boolean nmsOK = false;
   private static final double MOVE_SPEED = 0.15;
   private static final double JUMP_VELOCITY = 0.42;
   private static final double JUMP_BOOST = 0.7;
   private static final double SPRINT_JUMP_BOOST = 0.7;
   private static final double STEP_HEIGHT = 0.6;
   private static final double PLAYER_HEIGHT = 1.8;
   private static final double PLAYER_WIDTH = 0.6;
   private static final double GRAVITY = 0.08;
   private static final double GROUND_SEARCH = (double)5.0F;
   private static final double STOP_DISTANCE = (double)2.0F;
   private static final double PATHFIND_DIST = (double)25.0F;
   private static final int STUCK_THRESHOLD = 10;
   private static final int TELEPORT_THRESHOLD = 60;
   private static final int PATH_RECALC_TICKS = 40;

   public FollowModeManager(GlideSpoofer plugin) {
      this.plugin = plugin;
   }

   private Player findFake(UUID uuid) {
      SimpleFakePlayerManager fpm = this.plugin.getSimpleFakePlayerManager();
      if (fpm == null) {
         return null;
      } else {
         for(SimpleFakePlayerManager.FakePlayerData d : fpm.getAllFakePlayers()) {
            if (d.getUuid().equals(uuid)) {
               return d.getPlayer();
            }
         }

         return null;
      }
   }

   public void startFollowing(Player fake, Player target) {
      UUID fid = fake.getUniqueId();
      this.stopFollowing(fid);
      FT ft = new FT(fid, target.getUniqueId());
      this.tasks.put(fid, ft);
      ft.start();
   }

   public void stopFollowing(UUID fid) {
      FT ft = (FT)this.tasks.remove(fid);
      if (ft != null) {
         ft.stop();
      }

   }

   public boolean isFollowing(UUID fid) {
      FT ft = (FT)this.tasks.get(fid);
      return ft != null && ft.on;
   }

   public Player getTarget(UUID fid) {
      FT ft = (FT)this.tasks.get(fid);
      return ft == null ? null : Bukkit.getPlayer(ft.tid);
   }

   public double getPreviousX(UUID fid) {
      FT ft = (FT)this.tasks.get(fid);
      return ft == null ? (double)0.0F : ft.lastX;
   }

   public double getPreviousZ(UUID fid) {
      FT ft = (FT)this.tasks.get(fid);
      return ft == null ? (double)0.0F : ft.lastZ;
   }

   public int getJumpCooldown(UUID fid) {
      FT ft = (FT)this.tasks.get(fid);
      return ft == null ? 0 : ft.jumpCooldown;
   }

   public void setJumpCooldown(UUID fid, int cooldown) {
      FT ft = (FT)this.tasks.get(fid);
      if (ft != null) {
         ft.jumpCooldown = cooldown;
      }

   }

   public boolean isFirstMoveDone(UUID fid) {
      FT ft = (FT)this.tasks.get(fid);
      return ft != null && ft.firstMoveDone;
   }

   public void setFirstMoveDone(UUID fid) {
      FT ft = (FT)this.tasks.get(fid);
      if (ft != null) {
         ft.firstMoveDone = true;
      }

   }

   public void updateLastPos(UUID fid, Object nmsEntity) {
      FT ft = (FT)this.tasks.get(fid);
      if (ft != null) {
         ft.updateLastPos(nmsEntity);
      }

   }

   public List<UUID> getFollowersOf(UUID tid) {
      List<UUID> r = new ArrayList();

      for(Map.Entry<UUID, FT> e : this.tasks.entrySet()) {
         if (((FT)e.getValue()).tid.equals(tid) && ((FT)e.getValue()).on) {
            r.add((UUID)e.getKey());
         }
      }

      return r;
   }

   public void stopAll() {
      this.tasks.values().forEach(FT::stop);
      this.tasks.clear();
   }

   private static Object getHandle(Player p) throws Exception {
      return getHandleMethod_CraftPlayer != null ? getHandleMethod_CraftPlayer.invoke(p) : p.getClass().getMethod("getHandle").invoke(p);
   }

   private static void initNMS() {
      if (!nmsInit || !nmsOK) {
         nmsInit = true;
         nmsOK = false;

         try {
            Class<?> spc;
            Class<?> entityClass;
            Class<?> livingEntityClass;
            Class<?> craftPlayerClass;
            try {
               spc = Class.forName("net.minecraft.server.level.ServerPlayer");
               livingEntityClass = Class.forName("net.minecraft.world.entity.LivingEntity");
               entityClass = Class.forName("net.minecraft.world.entity.Entity");
               craftPlayerClass = Class.forName("org.bukkit.craftbukkit.entity.CraftPlayer");
            } catch (ClassNotFoundException var38) {
               String v = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
               spc = Class.forName("net.minecraft.server." + v + ".EntityPlayer");
               livingEntityClass = Class.forName("net.minecraft.server." + v + ".EntityLiving");
               entityClass = Class.forName("net.minecraft.server." + v + ".Entity");
               craftPlayerClass = Class.forName("org.bukkit.craftbukkit." + v + ".entity.CraftPlayer");
            }

            try {
               getHandleMethod_CraftPlayer = craftPlayerClass.getMethod("getHandle");
               getHandleMethod_CraftPlayer.setAccessible(true);
            } catch (Exception var28) {
               LOGGER.warning("[FollowMode] Could not find CraftPlayer.getHandle: " + var28.getMessage());
            }

            try {
               doTickMethod_Entity = entityClass.getMethod("doTick");
               doTickMethod_Entity.setAccessible(true);
            } catch (Exception var36) {
               LOGGER.fine("[FollowMode] Entity.doTick not found");
            }

            try {
               doTickMethod_ServerPlayer = spc.getMethod("doTick");
               doTickMethod_ServerPlayer.setAccessible(true);
            } catch (Exception var35) {
               LOGGER.fine("[FollowMode] ServerPlayer.doTick not found");
            }

            Class<?> c = spc;

            for(int iterations = 0; c != null && c != Object.class && iterations < 20; c = c.getSuperclass()) {
               ++iterations;

               try {
                  if (setYRotMethod == null) {
                     try {
                        setYRotMethod = c.getDeclaredMethod("setYRot", Float.TYPE);
                        setYRotMethod.setAccessible(true);
                     } catch (NoSuchMethodException var33) {
                        try {
                           setYRotMethod = c.getMethod("setYRot", Float.TYPE);
                        } catch (Exception var32) {
                        }
                     }
                  }

                  if (setXRotMethod == null) {
                     try {
                        setXRotMethod = c.getDeclaredMethod("setXRot", Float.TYPE);
                        setXRotMethod.setAccessible(true);
                     } catch (NoSuchMethodException var31) {
                        try {
                           setXRotMethod = c.getMethod("setXRot", Float.TYPE);
                        } catch (Exception var301) {
                        }
                     }
                  }

                  if (setSprintingMethod == null) {
                     try {
                        setSprintingMethod = c.getDeclaredMethod("setSprinting", Boolean.TYPE);
                        setSprintingMethod.setAccessible(true);
                     } catch (NoSuchMethodException var291) {
                        try {
                           setSprintingMethod = c.getMethod("setSprinting", Boolean.TYPE);
                        } catch (Exception var281) {
                        }
                     }
                  }

                  if (setPosMethod == null) {
                     try {
                        setPosMethod = c.getDeclaredMethod("setPos", Double.TYPE, Double.TYPE, Double.TYPE);
                        setPosMethod.setAccessible(true);
                     } catch (NoSuchMethodException var27) {
                        try {
                           setPosMethod = c.getMethod("setPos", Double.TYPE, Double.TYPE, Double.TYPE);
                        } catch (Exception var26) {
                        }
                     }
                  }

                  if (onGroundField == null) {
                     try {
                        onGroundField = c.getDeclaredField("onGround");
                        onGroundField.setAccessible(true);
                     } catch (NoSuchFieldException var25) {
                     }
                  }

                  if (deltaMovementField == null) {
                     try {
                        deltaMovementField = c.getDeclaredField("deltaMovement");
                        deltaMovementField.setAccessible(true);
                     } catch (NoSuchFieldException var241) {
                        try {
                           deltaMovementField = c.getDeclaredField("mot");
                           deltaMovementField.setAccessible(true);
                        } catch (NoSuchFieldException var23) {
                        }
                     }
                  }
               } catch (Exception var34) {
               }
            }

            c = livingEntityClass;

            for(int var33 = 0; c != null && c != Object.class && var33 < 20; c = c.getSuperclass()) {
               ++var33;

               try {
                  if (zzaField == null) {
                     try {
                        zzaField = c.getDeclaredField("zza");
                        zzaField.setAccessible(true);
                     } catch (NoSuchFieldException var21) {
                     }
                  }

                  if (xxaField == null) {
                     try {
                        xxaField = c.getDeclaredField("xxa");
                        xxaField.setAccessible(true);
                     } catch (NoSuchFieldException var20) {
                     }
                  }

                  if (jumpingField == null) {
                     try {
                        jumpingField = c.getDeclaredField("jumping");
                        jumpingField.setAccessible(true);
                     } catch (NoSuchFieldException var19) {
                     }
                  }

                  if (jumpMethod == null) {
                     try {
                        jumpMethod = c.getDeclaredMethod("jump");
                        jumpMethod.setAccessible(true);
                     } catch (NoSuchMethodException var18) {
                     }
                  }

                  if (jumpFromGroundMethod == null) {
                     try {
                        jumpFromGroundMethod = c.getDeclaredMethod("jumpFromGround");
                        jumpFromGroundMethod.setAccessible(true);
                     } catch (NoSuchMethodException var17) {
                     }
                  }
               } catch (Exception var22) {
               }
            }

            try {
               vec3Class = Class.forName("net.minecraft.world.phys.Vec3");
               vec3Constructor = vec3Class.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE);

               try {
                  getDeltaMovementMethod = entityClass.getMethod("getDeltaMovement");
               } catch (Exception var16) {
               }

               for(Class<?> ec = entityClass; ec != null && ec != Object.class; ec = ec.getSuperclass()) {
                  try {
                     moveRelativeMethod = ec.getDeclaredMethod("moveRelative", Float.TYPE, vec3Class);
                     moveRelativeMethod.setAccessible(true);
                     break;
                  }
               }

               Class<?> moverTypeClass = Class.forName("net.minecraft.world.entity.MoverType");
               Field selfField = moverTypeClass.getDeclaredField("SELF");
               selfField.setAccessible(true);
               moverTypeSelf = selfField.get((Object)null);

               for(Class<?> ec = entityClass; ec != null && ec != Object.class; ec = ec.getSuperclass()) {
                  try {
                     moveMethod = ec.getDeclaredMethod("move", moverTypeClass, vec3Class);
                     moveMethod.setAccessible(true);
                     break;
                  }
               }

               Class<?> attributesClass = Class.forName("net.minecraft.world.entity.ai.attributes.AttributeInstance");
               getAttributesMethod = livingEntityClass.getMethod("getAttributes");
               getAttributeValueMethod = attributesClass.getMethod("getValue");
               Class<?> attributesHolderClass = null;

               try {
                  attributesHolderClass = Class.forName("net.minecraft.world.entity.ai.attributes.Attributes");
               } catch (ClassNotFoundException var15) {
                  try {
                     String[] var10000 = Bukkit.getServer().getClass().getPackage().getName().split("\\.");
                     attributesHolderClass = Class.forName("net.minecraft.server." + var10000[3] + ".GenericAttributes");
                  } catch (ClassNotFoundException var14) {
                  }
               }

               if (attributesHolderClass != null) {
                  try {
                     movementSpeedAttributeField = attributesHolderClass.getDeclaredField("MOVEMENT_SPEED");
                     movementSpeedAttributeField.setAccessible(true);
                  } catch (NoSuchFieldException var13) {
                  }
               }

               try {
                  isSprintingMethod = livingEntityClass.getMethod("isSprinting");
               } catch (Exception var12) {
               }

               try {
                  isShiftKeyDownMethod = entityClass.getMethod("isShiftKeyDown");
               } catch (Exception var11) {
               }

               moveInit = moveRelativeMethod != null && moveMethod != null && moverTypeSelf != null;
               boolean var10001 = moveRelativeMethod != null;
               LOGGER.info("[FollowMode] moveInit: moveRelative=" + var10001 + " move=" + (moveMethod != null) + " MoverType.SELF=" + (moverTypeSelf != null) + " vec3=" + (vec3Class != null) + " getDelta=" + (getDeltaMovementMethod != null || deltaMovementField != null) + " attributes=" + (getAttributesMethod != null) + " sprint=" + (isSprintingMethod != null) + " shift=" + (isShiftKeyDownMethod != null) + " OK=" + moveInit);
            } catch (Exception e) {
               LOGGER.warning("[FollowMode] moveInit failed: " + e.getMessage());
               e.printStackTrace();
               moveInit = false;
            }

            nmsOK = setPosMethod != null || doTickMethod_Entity != null || doTickMethod_ServerPlayer != null;
            boolean var49 = setYRotMethod != null;
            LOGGER.info("[FollowMode] NMS init: yRot=" + var49 + " xRot=" + (setXRotMethod != null) + " setPos=" + (setPosMethod != null) + " setSprinting=" + (setSprintingMethod != null) + " onGround=" + (onGroundField != null) + " zza=" + (zzaField != null) + " xxa=" + (xxaField != null) + " jump=" + (jumpMethod != null) + " jumpFromGround=" + (jumpFromGroundMethod != null) + " doTick=" + (doTickMethod_Entity != null || doTickMethod_ServerPlayer != null) + " OK=" + nmsOK);
            if (jumpFromGroundMethod != null) {
               LOGGER.info("[FollowMode] jumpFromGround() method FOUND: " + String.valueOf(jumpFromGroundMethod));
            } else {
               LOGGER.warning("[FollowMode] jumpFromGround() NOT FOUND! Will use jumping field instead.");
            }
         } catch (Exception var30) {
            LOGGER.warning("[FollowMode] NMS init failed: " + var30.getMessage());
            var30.printStackTrace();
            nmsOK = false;
         }
      }

   }

   class FT {
      final UUID fid;
      final UUID tid;
      BukkitTask task;
      volatile boolean on;
      double lastX;
      double lastZ;
      boolean wasKnockedBack = false;
      int stuckTicks = 0;
      int jumpCooldown = 0;
      long lastDebugTime = 0L;
      volatile boolean firstMoveDone = false;

      FT(UUID fid, UUID tid) {
         this.fid = fid;
         this.tid = tid;
      }

      void start() {
         this.on = true;
         FollowModeManager.initNMS();

         try {
            Player fake = FollowModeManager.this.findFake(this.fid);
            if (fake != null && fake.isOnline()) {
               Object nms = FollowModeManager.getHandle(fake);
               if (nms != null) {
                  this.lastX = (Double)nms.getClass().getMethod("getX").invoke(nms);
                  this.lastZ = (Double)nms.getClass().getMethod("getZ").invoke(nms);
               }

               this.snapToGround(fake);
            }
         } catch (Exception var3) {
         }

         this.task = Bukkit.getScheduler().runTaskTimer(FollowModeManager.this.plugin, this::tick, 1L, 1L);
      }

      void stop() {
         this.on = false;
         if (this.task != null) {
            this.task.cancel();
            this.task = null;
         }

         try {
            Player fake = FollowModeManager.this.findFake(this.fid);
            if (fake != null && fake.isOnline()) {
               this.clearInputs(fake);
            }
         } catch (Exception var2) {
         }

      }

      void tick() {
         try {
            if (this.jumpCooldown > 0) {
               --this.jumpCooldown;
            }

            Player fake = FollowModeManager.this.findFake(this.fid);
            Player target = Bukkit.getPlayer(this.tid);
            if (fake == null || !fake.isOnline() || target == null || !target.isOnline()) {
               this.stop();
               FollowModeManager.this.tasks.remove(this.fid);
               return;
            }

            Location fl = fake.getLocation();
            Location tl = target.getLocation();
            if (!fl.getWorld().equals(tl.getWorld())) {
               this.setZza(fake, 0.0F);
               this.stuckTicks = 0;
               return;
            }

            double dist = fl.distance(tl);
            if (!FollowModeManager.nmsOK) {
               FollowModeManager.initNMS();
            }

            FakePlayerDamageListener dl = FollowModeManager.this.plugin.getDamageListener();
            if (dl != null && dl.isKnockedBack(fake.getName())) {
               this.wasKnockedBack = true;
               this.setZza(fake, 0.0F);
               return;
            }

            if (this.wasKnockedBack) {
               this.wasKnockedBack = false;
            }

            if (dl != null && dl.isDead(fake.getName())) {
               this.setZza(fake, 0.0F);
               return;
            }

            Object nmsEntity = FollowModeManager.getHandle(fake);
            if (nmsEntity == null) {
               return;
            }

            if (dist < (double)2.5F) {
               this.stuckTicks = 0;
            }

            if (this.isBlocked(nmsEntity)) {
               ++this.stuckTicks;
            } else {
               this.stuckTicks = 0;
            }

            if (this.stuckTicks >= 120) {
               this.stuckTicks = 0;
               double tdx = tl.getX() - fl.getX();
               double tdz = tl.getZ() - fl.getZ();
               double horizontalDist = Math.sqrt(tdx * tdx + tdz * tdz);
               if (horizontalDist > (double)10.0F) {
                  double ratio = (double)10.0F / horizontalDist;
                  Location nearTarget = new Location(fl.getWorld(), fl.getX() + tdx * ratio, tl.getY(), fl.getZ() + tdz * ratio);
                  this.setPosition(fake, nearTarget);
                  this.snapToGround(fake);
               }

               FollowModeManager.LOGGER.info("[FollowMode] " + fake.getName() + " was stuck for 120 ticks, teleporting toward target");
            }

            long now = System.currentTimeMillis();
            if (now - this.lastDebugTime > 5000L) {
               this.lastDebugTime = now;
               double currentX = (double)0.0F;
               double currentZ = (double)0.0F;

               try {
                  currentX = (Double)nmsEntity.getClass().getMethod("getX").invoke(nmsEntity);
                  currentZ = (Double)nmsEntity.getClass().getMethod("getZ").invoke(nmsEntity);
               } catch (Exception var18) {
               }

               double movedDist = Math.sqrt((currentX - this.lastX) * (currentX - this.lastX) + (currentZ - this.lastZ) * (currentZ - this.lastZ));
               Logger var24 = FollowModeManager.LOGGER;
               String var25 = fake.getName();
               var24.info("[FollowMode] " + var25 + " dist=" + String.format("%.1f", dist) + " movedPerTick=" + String.format("%.3f", movedDist) + " pos=(" + String.format("%.1f", fl.getX()) + "," + String.format("%.1f", fl.getY()) + "," + String.format("%.1f", fl.getZ()) + ")");
            }
         } catch (Exception var11) {
            Logger var10000 = FollowModeManager.LOGGER;
            String var10001 = String.valueOf(this.fid);
            var10000.warning("[FollowMode] Error in tick for " + var10001 + ": " + var11.getMessage());
         }

      }

      void updateLastPos(Object nmsEntity) {
         try {
            this.lastX = (Double)nmsEntity.getClass().getMethod("getX").invoke(nmsEntity);
            this.lastZ = (Double)nmsEntity.getClass().getMethod("getZ").invoke(nmsEntity);
         } catch (Exception var3) {
         }

      }

      boolean isOnGround(Object nmsEntity) {
         try {
            if (FollowModeManager.onGroundField != null) {
               return FollowModeManager.onGroundField.getBoolean(nmsEntity);
            }
         } catch (Exception var3) {
         }

         return false;
      }

      boolean isBlocked(Object nmsEntity) {
         try {
            double currentX = (Double)nmsEntity.getClass().getMethod("getX").invoke(nmsEntity);
            double currentZ = (Double)nmsEntity.getClass().getMethod("getZ").invoke(nmsEntity);
            double ddx = currentX - this.lastX;
            double ddz = currentZ - this.lastZ;
            boolean zzaActive = false;
            if (FollowModeManager.zzaField != null) {
               zzaActive = FollowModeManager.zzaField.getFloat(nmsEntity) != 0.0F;
            }

            return ddx * ddx + ddz * ddz < 0.001 && zzaActive;
         } catch (Exception var11) {
            return false;
         }
      }

      void setZza(Player fake, float value) {
         try {
            Object nmsEntity = FollowModeManager.getHandle(fake);
            if (nmsEntity != null && FollowModeManager.zzaField != null) {
               FollowModeManager.zzaField.setFloat(nmsEntity, value);
            }
         } catch (Exception var4) {
         }

      }

      void snapToGround(Player fake) {
         Location loc = fake.getLocation();
         double groundY = this.findGroundY(loc);
         if (Math.abs(loc.getY() - groundY) > (double)0.5F) {
            Location groundLoc = loc.clone();
            groundLoc.setY(groundY);
            this.setPosition(fake, groundLoc);
         }

      }

      double findGroundY(Location loc) {
         World world = loc.getWorld();
         int x = (int)Math.floor(loc.getX());
         int z = (int)Math.floor(loc.getZ());
         int start = (int)Math.floor(loc.getY());
         int minY = Math.max(world.getMinHeight(), start - 10);

         for(int y = start; y >= minY; --y) {
            Block below = world.getBlockAt(x, y - 1, z);
            Block feet = world.getBlockAt(x, y, z);
            Block head = world.getBlockAt(x, y + 1, z);
            if (below.getType().isSolid() && !feet.getType().isSolid() && !head.getType().isSolid()) {
               return (double)y;
            }
         }

         return loc.getY();
      }

      void setDeltaMovement(Object nmsEntity, double dx, double dy, double dz) {
         try {
            try {
               Class<?> vec3Class = Class.forName("net.minecraft.world.phys.Vec3");
               Method setDeltaMovementMethod = nmsEntity.getClass().getMethod("setDeltaMovement", vec3Class);
               Object vec3 = vec3Class.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE).newInstance(dx, dy, dz);
               setDeltaMovementMethod.invoke(nmsEntity, vec3);
               return;
            } catch (Exception var211) {
               if (FollowModeManager.deltaMovementField != null) {
                  try {
                     Object vec3x = Class.forName("net.minecraft.world.phys.Vec3").getConstructor(Double.TYPE, Double.TYPE, Double.TYPE).newInstance(dx, dy, dz);
                     FollowModeManager.deltaMovementField.set(nmsEntity, vec3x);
                  } catch (Exception var20) {
                     try {
                        Class<?> entityClass = Class.forName("net.minecraft.server.level.Entity");
                        Object existingDelta = FollowModeManager.deltaMovementField.get(nmsEntity);
                        if (existingDelta != null) {
                           Class<?> vec3Classx = existingDelta.getClass();
                           Object newDelta = vec3Classx.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE).newInstance(dx, dy, dz);
                           FollowModeManager.deltaMovementField.set(nmsEntity, newDelta);
                        }
                     } catch (Exception var19) {
                        try {
                           Field motField = nmsEntity.getClass().getDeclaredField("mot");
                           motField.setAccessible(true);

                           try {
                              double[] mot = (double[])motField.get(nmsEntity);
                              mot[0] = dx;
                              mot[1] = dy;
                              mot[2] = dz;
                           } catch (ClassCastException var17) {
                              try {
                                 Field motX = nmsEntity.getClass().getDeclaredField("motX");
                                 Field motY = nmsEntity.getClass().getDeclaredField("motY");
                                 Field motZ = nmsEntity.getClass().getDeclaredField("motZ");
                                 motX.setAccessible(true);
                                 motY.setAccessible(true);
                                 motZ.setAccessible(true);
                                 motX.setDouble(nmsEntity, dx);
                                 motY.setDouble(nmsEntity, dy);
                                 motZ.setDouble(nmsEntity, dz);
                              } catch (Exception var16) {
                              }
                           }
                        } catch (Exception var18) {
                        }
                     }
                  }
               }
            }
         } catch (Exception var21) {
            FollowModeManager.LOGGER.fine("[FollowMode] setDeltaMovement failed: " + var21.getMessage());
         }

      }

      void jumpWithFallback(Object nmsEntity, Player fake) {
         try {
            if (FollowModeManager.jumpFromGroundMethod != null) {
               try {
                  FollowModeManager.jumpFromGroundMethod.invoke(nmsEntity);
                  FollowModeManager.LOGGER.fine("[FollowMode] jumpFromGround() succeeded");
               } catch (Exception var5) {
                  FollowModeManager.LOGGER.fine("[FollowMode] jumpFromGround() failed: " + var5.getMessage());
               }
            }

            if (FollowModeManager.jumpingField != null) {
               try {
                  FollowModeManager.jumpingField.setBoolean(nmsEntity, true);
               } catch (Exception var4) {
               }
            }
         } catch (Exception var6) {
            FollowModeManager.LOGGER.warning("[FollowMode] jumpWithFallback failed: " + var6.getMessage());
         }

      }

      void setPosition(Player fake, Location loc) {
         try {
            Object handle = FollowModeManager.getHandle(fake);
            if (handle == null) {
               FollowModeManager.this.plugin.getSimpleFakePlayerManager().getNMSHandler().updatePosition(fake, loc, true);
               return;
            }

            boolean success = false;
            if (FollowModeManager.setPosMethod != null) {
               try {
                  FollowModeManager.setPosMethod.invoke(handle, loc.getX(), loc.getY(), loc.getZ());
                  success = true;
               } catch (Exception var8) {
               }
            }

            if (!success) {
               try {
                  Method moveTo = handle.getClass().getMethod("moveTo", Double.TYPE, Double.TYPE, Double.TYPE);
                  moveTo.invoke(handle, loc.getX(), loc.getY(), loc.getZ());
                  success = true;
               } catch (Exception var7) {
               }
            }

            if (!success) {
               try {
                  Method teleport = handle.getClass().getMethod("teleport", Double.TYPE, Double.TYPE, Double.TYPE);
                  teleport.invoke(handle, loc.getX(), loc.getY(), loc.getZ());
                  success = true;
               } catch (Exception var6) {
               }
            }

            FollowModeManager.this.plugin.getSimpleFakePlayerManager().getNMSHandler().updatePosition(fake, loc, true);
         } catch (Exception var9) {
            FollowModeManager.LOGGER.warning("[FollowMode] Failed to set position: " + var9.getMessage());
         }

      }

      void setLocation(Player fake, double x, double y, double z) {
         try {
            Object handle = FollowModeManager.getHandle(fake);
            if (handle == null) {
               return;
            }

            if (FollowModeManager.setPosMethod != null) {
               FollowModeManager.setPosMethod.invoke(handle, x, y, z);
            }
         } catch (Exception var9) {
            FollowModeManager.LOGGER.warning("[FollowMode] Failed to set location: " + var9.getMessage());
         }

      }

      void setRotation(Player fake, float yaw, float pitch) {
         try {
            Object handle = FollowModeManager.getHandle(fake);
            if (handle == null) {
               return;
            }

            if (FollowModeManager.setYRotMethod != null) {
               FollowModeManager.setYRotMethod.invoke(handle, yaw);
            }

            if (FollowModeManager.setXRotMethod != null) {
               FollowModeManager.setXRotMethod.invoke(handle, pitch);
            }

            try {
               Method setRot = handle.getClass().getMethod("setRot", Float.TYPE, Float.TYPE);
               setRot.invoke(handle, yaw, pitch);
            } catch (Exception var6) {
            }
         } catch (Exception var7) {
            FollowModeManager.LOGGER.warning("[FollowMode] Failed to set rotation: " + var7.getMessage());
         }

      }

      void setSprinting(Player fake, boolean sprinting) {
         try {
            Object handle = FollowModeManager.getHandle(fake);
            if (handle == null) {
               return;
            }

            if (FollowModeManager.setSprintingMethod != null) {
               FollowModeManager.setSprintingMethod.invoke(handle, sprinting);
            }

            try {
               Method setSharedFlag = handle.getClass().getMethod("setSharedFlag", Integer.TYPE, Boolean.TYPE);
               setSharedFlag.invoke(handle, 3, sprinting);
            } catch (Exception var5) {
            }
         } catch (Exception var6) {
            FollowModeManager.LOGGER.warning("[FollowMode] Failed to set sprinting: " + var6.getMessage());
         }

      }

      void lookAt(Player fake, Location tl) {
         Location current = fake.getLocation();
         double dx = tl.getX() - current.getX();
         double dz = tl.getZ() - current.getZ();
         float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));

         try {
            Object nmsEntity = FollowModeManager.getHandle(fake);
            if (nmsEntity != null && FollowModeManager.setYRotMethod != null) {
               FollowModeManager.setYRotMethod.invoke(nmsEntity, yaw);
            }
         } catch (Exception var10) {
         }

      }

      void clearInputs(Player fake) {
         SmoothMovement.stopMovement(fake);
         this.setSprinting(fake, false);
      }

      boolean isOnLadder(Location loc) {
         if (loc != null && loc.getWorld() != null) {
            Block block = loc.getBlock();
            return block.getType() == Material.LADDER;
         } else {
            return false;
         }
      }

      boolean isOnClimbable(Location loc) {
         if (loc != null && loc.getWorld() != null) {
            Block block = loc.getBlock();
            Material type = block.getType();
            return type == Material.LADDER || type == Material.VINE || type == Material.SCAFFOLDING || type.name().contains("POLE");
         } else {
            return false;
         }
      }
   }
}
