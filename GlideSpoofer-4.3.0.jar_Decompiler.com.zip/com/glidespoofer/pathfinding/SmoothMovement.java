package com.glidespoofer.pathfinding;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

public class SmoothMovement {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer");
   private static Field zzaField;
   private static Field xxaField;
   private static Field jumpingField;
   private static Field yRotField;
   private static Method setForwardMethod;
   private static Method setBackwardMethod;
   private static Method setLeftMethod;
   private static Method setRightMethod;
   private static Method setJumpMethod;
   private static Method setSprintMethod;
   private static Field lastClientInputField;
   private static Method setYRotMethod;
   private static Method setXRotMethod;
   private static Method getHandleMethod;
   private static boolean initialized = false;
   private static boolean useModernInput = false;
   private static boolean initSuccess = false;
   private static final ThreadLocal<Float> storedZza = ThreadLocal.withInitial(() -> 0.0F);
   private static final ThreadLocal<Float> storedXxa = ThreadLocal.withInitial(() -> 0.0F);
   private static final ThreadLocal<Boolean> storedJump = ThreadLocal.withInitial(() -> false);

   private static void init() {
      if (!initialized) {
         initialized = true;

         try {
            Class<?> serverPlayerClass;
            Class<?> livingEntityClass;
            Class<?> entityClass;
            try {
               serverPlayerClass = Class.forName("net.minecraft.server.level.ServerPlayer");
               livingEntityClass = Class.forName("net.minecraft.world.entity.LivingEntity");
               entityClass = Class.forName("net.minecraft.world.entity.Entity");
            } catch (ClassNotFoundException var101) {
               String version = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
               serverPlayerClass = Class.forName("net.minecraft.server." + version + ".EntityPlayer");
               livingEntityClass = Class.forName("net.minecraft.server." + version + ".EntityLiving");
               entityClass = Class.forName("net.minecraft.server." + version + ".Entity");
            }

            try {
               Class<?> craftPlayerClass = Class.forName("org.bukkit.craftbukkit.entity.CraftPlayer");
               getHandleMethod = craftPlayerClass.getMethod("getHandle");
               getHandleMethod.setAccessible(true);
            } catch (ClassNotFoundException var9) {
               try {
                  String version = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
                  Class<?> craftPlayerClassx = Class.forName("org.bukkit.craftbukkit." + version + ".entity.CraftPlayer");
                  getHandleMethod = craftPlayerClassx.getMethod("getHandle");
                  getHandleMethod.setAccessible(true);
               } catch (ClassNotFoundException var8) {
                  LOGGER.warning("[SmoothMovement] Could not find CraftPlayer class");
                  throw var8;
               }
            }

            try {
               lastClientInputField = findFieldInHierarchy(serverPlayerClass, "lastClientInput");
               if (lastClientInputField != null) {
                  lastClientInputField.setAccessible(true);
                  LOGGER.info("[SmoothMovement] Found lastClientInput field - using 1.21.3+ input system");
                  Class<?> inputClass = lastClientInputField.getType();
                  setForwardMethod = findBooleanSetter(inputClass, "forward");
                  setBackwardMethod = findBooleanSetter(inputClass, "backward");
                  setLeftMethod = findBooleanSetter(inputClass, "left");
                  setRightMethod = findBooleanSetter(inputClass, "right");
                  setJumpMethod = findBooleanSetter(inputClass, "jump");
                  setSprintMethod = findBooleanSetter(inputClass, "sprint");
                  if (setForwardMethod == null && setBackwardMethod == null && setLeftMethod == null && setRightMethod == null) {
                     LOGGER.warning("[SmoothMovement] lastClientInput found but no setter methods available");
                     lastClientInputField = null;
                  } else {
                     useModernInput = true;
                     initSuccess = true;
                     LOGGER.info("[SmoothMovement] Modern input system initialized successfully");
                  }
               }
            } catch (Exception var13) {
               LOGGER.fine("[SmoothMovement] lastClientInput not found: " + var13.getMessage());
            }

            if (!useModernInput) {
               LOGGER.info("[SmoothMovement] Trying pre-1.21.3 input system (zza/xxa)");
               zzaField = findFieldInHierarchy(livingEntityClass, "zza");
               xxaField = findFieldInHierarchy(livingEntityClass, "xxa");
               jumpingField = findFieldInHierarchy(livingEntityClass, "jumping");
               yRotField = findFieldInHierarchy(entityClass, "yRot");
               if (zzaField != null) {
                  zzaField.setAccessible(true);
               }

               if (xxaField != null) {
                  xxaField.setAccessible(true);
               }

               if (jumpingField != null) {
                  jumpingField.setAccessible(true);
               }

               if (yRotField != null) {
                  yRotField.setAccessible(true);
               }

               if (zzaField != null && xxaField != null) {
                  useModernInput = false;
                  initSuccess = true;
                  Logger var10000 = LOGGER;
                  String var10001 = zzaField.getName();
                  var10000.info("[SmoothMovement] Legacy input system initialized: zza=" + var10001 + " xxa=" + xxaField.getName());
               } else {
                  LOGGER.warning("[SmoothMovement] Could not find zza/xxa fields!");
               }
            }

            try {
               setYRotMethod = serverPlayerClass.getMethod("setYRot", Float.TYPE);
            } catch (NoSuchMethodException var12) {
               try {
                  setYRotMethod = entityClass.getMethod("setYRot", Float.TYPE);
               } catch (NoSuchMethodException var11) {
                  if (yRotField == null) {
                     yRotField = findFieldInHierarchy(entityClass, "yRot");
                     if (yRotField != null) {
                        yRotField.setAccessible(true);
                     }
                  }
               }
            }

            try {
               setXRotMethod = serverPlayerClass.getMethod("setXRot", Float.TYPE);
            } catch (NoSuchMethodException var7) {
               try {
                  setXRotMethod = entityClass.getMethod("setXRot", Float.TYPE);
               } catch (NoSuchMethodException var6) {
               }
            }

            LOGGER.info("[SmoothMovement] Init complete: modern=" + useModernInput + " success=" + initSuccess + " zza=" + (zzaField != null) + " xxa=" + (xxaField != null) + " lastClientInput=" + (lastClientInputField != null));
         } catch (Exception var14) {
            LOGGER.warning("[SmoothMovement] Init failed: " + var14.getMessage());
            var14.printStackTrace();
         }
      }

   }

   public static boolean moveTowards(Player player, Location target, double speed) {
      if (player != null && target != null) {
         if (!player.getWorld().equals(target.getWorld())) {
            return false;
         } else {
            init();
            if (!initSuccess) {
               LOGGER.warning("[SmoothMovement] Cannot move - initialization failed");
               return false;
            } else {
               Location current = player.getLocation();
               Vector dir = target.toVector().subtract(current.toVector());
               dir.setY(0);
               double distance = dir.length();
               if (distance < 0.01) {
                  stopMovement(player);
                  return false;
               } else {
                  dir.normalize();
                  float yaw = (float)Math.toDegrees(Math.atan2(-dir.getX(), dir.getZ()));
                  setRotation(player, yaw);

                  try {
                     Object nmsEntity = getHandleMethod.invoke(player);
                     if (nmsEntity == null) {
                        return false;
                     } else {
                        if (useModernInput) {
                           setModernMovement(nmsEntity, true, false, false, false, speed > 0.8, false);
                        } else {
                           setLegacyMovement(nmsEntity, (float)speed, 0.0F, false);
                        }

                        return true;
                     }
                  } catch (Exception var10) {
                     LOGGER.warning("[SmoothMovement] moveTowards failed: " + var10.getMessage());
                     return false;
                  }
               }
            }
         }
      } else {
         return false;
      }
   }

   public static boolean setMovementInput(Player player, float forward, float strafe, boolean jump) {
      init();
      if (!initSuccess) {
         LOGGER.warning("[SmoothMovement] Cannot set movement input - initialization failed");
         return false;
      } else {
         try {
            Object nmsEntity = getHandleMethod.invoke(player);
            if (nmsEntity == null) {
               LOGGER.warning("[SmoothMovement] getHandle returned null");
               return false;
            } else {
               boolean result;
               if (useModernInput) {
                  boolean forwardPressed = forward > 0.1F;
                  boolean backwardPressed = forward < -0.1F;
                  boolean leftPressed = strafe > 0.1F;
                  boolean rightPressed = strafe < -0.1F;
                  boolean sprinting = Math.abs(forward) > 0.8F || Math.abs(strafe) > 0.8F;
                  result = setModernMovement(nmsEntity, forwardPressed, backwardPressed, leftPressed, rightPressed, sprinting, jump);
                  if (sprinting) {
                     setSprinting(nmsEntity, true);
                  }
               } else {
                  result = setLegacyMovement(nmsEntity, forward, strafe, jump);
               }

               return result;
            }
         } catch (Exception var11) {
            LOGGER.warning("[SmoothMovement] setMovementInput failed: " + var11.getMessage());
            var11.printStackTrace();
            return false;
         }
      }
   }

   private static void setSprinting(Object nmsEntity, boolean sprinting) {
      try {
         try {
            Method setSprintingMethod = nmsEntity.getClass().getMethod("setSprinting", Boolean.TYPE);
            setSprintingMethod.invoke(nmsEntity, sprinting);
         } catch (NoSuchMethodException var4) {
            Field sprintingField = findFieldInHierarchy(nmsEntity.getClass(), "sprinting");
            if (sprintingField != null) {
               sprintingField.setAccessible(true);
               sprintingField.setBoolean(nmsEntity, sprinting);
            }
         }
      } catch (Exception var5) {
      }

   }

   public static void stopMovement(Player player) {
      init();
      if (initSuccess) {
         try {
            Object nmsEntity = getHandleMethod.invoke(player);
            if (nmsEntity == null) {
               return;
            }

            if (useModernInput) {
               setModernMovement(nmsEntity, false, false, false, false, false, false);
            } else {
               setLegacyMovement(nmsEntity, 0.0F, 0.0F, false);
            }
         } catch (Exception var2) {
            LOGGER.warning("[SmoothMovement] stopMovement failed: " + var2.getMessage());
         }
      }

   }

   public static void setRotation(Player player, float yaw, float pitch) {
      init();

      try {
         Object nmsEntity = getHandleMethod.invoke(player);
         if (nmsEntity == null) {
            return;
         }

         if (setYRotMethod != null) {
            setYRotMethod.invoke(nmsEntity, yaw);
         } else if (yRotField != null) {
            yRotField.setFloat(nmsEntity, yaw);
         }

         Location loc = player.getLocation();
         Location newLoc = new Location(loc.getWorld(), loc.getX(), loc.getY(), loc.getZ(), yaw, pitch);
         player.teleport(newLoc);
      } catch (Exception var6) {
         LOGGER.fine("[SmoothMovement] Set rotation failed: " + var6.getMessage());
      }

   }

   public static void setRotation(Player player, float yaw) {
      setRotation(player, yaw, 0.0F);
   }

   public static void lookAt(Player player, Location target) {
      if (player != null && target != null) {
         Location current = player.getLocation();
         double dx = target.getX() - current.getX();
         double dy = target.getY() - current.getY();
         double dz = target.getZ() - current.getZ();
         float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
         float pitch = (float)Math.toDegrees(Math.atan2(-dy, Math.sqrt(dx * dx + dz * dz)));
         pitch = Math.max(-90.0F, Math.min(90.0F, pitch));
         setRotation(player, yaw, pitch);
      }

   }

   private static boolean setLegacyMovement(Object nmsEntity, float forward, float strafe, boolean jump) {
      try {
         if (zzaField != null) {
            zzaField.setFloat(nmsEntity, forward);
         }

         if (xxaField != null) {
            xxaField.setFloat(nmsEntity, strafe);
         }

         if (jumpingField != null && jump) {
            jumpingField.setBoolean(nmsEntity, true);
         }

         LOGGER.fine("[SmoothMovement] Set legacy input: zza=" + forward + " xxa=" + strafe);
         return true;
      } catch (Exception var5) {
         LOGGER.warning("[SmoothMovement] Legacy input failed: " + var5.getMessage());
         return false;
      }
   }

   private static boolean setModernMovement(Object nmsEntity, boolean forward, boolean backward, boolean left, boolean right, boolean sprint, boolean jump) {
      try {
         if (lastClientInputField == null) {
            LOGGER.warning("[SmoothMovement] lastClientInputField is null");
            return false;
         } else {
            Object input = lastClientInputField.get(nmsEntity);
            if (input == null) {
               input = lastClientInputField.getType().getConstructor().newInstance();
               lastClientInputField.set(nmsEntity, input);
            }

            if (setForwardMethod != null) {
               setForwardMethod.invoke(input, forward);
            }

            if (setBackwardMethod != null) {
               setBackwardMethod.invoke(input, backward);
            }

            if (setLeftMethod != null) {
               setLeftMethod.invoke(input, left);
            }

            if (setRightMethod != null) {
               setRightMethod.invoke(input, right);
            }

            if (setSprintMethod != null) {
               setSprintMethod.invoke(input, sprint);
            }

            if (setJumpMethod != null && jump) {
               setJumpMethod.invoke(input, true);
            }

            LOGGER.fine("[SmoothMovement] Set modern input: fwd=" + forward + " back=" + backward + " left=" + left + " right=" + right);
            return true;
         }
      } catch (Exception var8) {
         LOGGER.warning("[SmoothMovement] Modern input failed: " + var8.getMessage());
         var8.printStackTrace();
         return false;
      }
   }

   private static Method findBooleanSetter(Class<?> clazz, String fieldName) {
      if (clazz == null) {
         return null;
      } else {
         try {
            char var6 = Character.toUpperCase(fieldName.charAt(0));
            String methodName = "set" + var6 + fieldName.substring(1);
            return clazz.getMethod(methodName, Boolean.TYPE);
         } catch (NoSuchMethodException var5) {
            try {
               char var10000 = Character.toUpperCase(fieldName.charAt(0));
               String methodNamex = "is" + var10000 + fieldName.substring(1);
               return clazz.getMethod(methodNamex, Boolean.TYPE);
            } catch (NoSuchMethodException var4) {
               return null;
            }
         }
      }
   }

   private static Field findFieldInHierarchy(Class<?> clazz, String fieldName) {
      while(clazz != null && clazz != Object.class) {
         try {
            return clazz.getDeclaredField(fieldName);
         } catch (NoSuchFieldException var3) {
            clazz = clazz.getSuperclass();
         }
      }

      return null;
   }

   private static boolean setFloatField(Object nmsEntity, Field field, float value) {
      if (field != null && nmsEntity != null) {
         try {
            field.setFloat(nmsEntity, value);
            return true;
         } catch (Exception var4) {
            return false;
         }
      } else {
         return false;
      }
   }

   private static boolean setBooleanField(Object nmsEntity, Field field, boolean value) {
      if (field != null && nmsEntity != null) {
         try {
            field.setBoolean(nmsEntity, value);
            return true;
         } catch (Exception var4) {
            return false;
         }
      } else {
         return false;
      }
   }

   public static boolean isAvailable() {
      init();
      return initSuccess;
   }

   public static String getMethod() {
      init();
      if (!initSuccess) {
         return "Not available";
      } else {
         return useModernInput ? "lastClientInput (1.21.3+)" : "zza/xxa (pre-1.21.3)";
      }
   }

   public static boolean isUsingModernInput() {
      init();
      return useModernInput && initSuccess;
   }

   public static String debugGetInputs(Player player) {
      init();
      if (!initSuccess) {
         return "Not initialized";
      } else {
         try {
            Object nmsEntity = getHandleMethod.invoke(player);
            if (nmsEntity == null) {
               return "No NMS entity";
            } else if (useModernInput) {
               Object input = lastClientInputField.get(nmsEntity);
               return input == null ? "lastClientInput is null" : "input=" + input.toString();
            } else {
               float zza = zzaField != null ? zzaField.getFloat(nmsEntity) : 0.0F;
               float xxa = xxaField != null ? xxaField.getFloat(nmsEntity) : 0.0F;
               return "zza=" + zza + " xxa=" + xxa;
            }
         } catch (Exception var4) {
            return "Error: " + var4.getMessage();
         }
      }
   }
}
