package com.glidespoofer.pathfinding;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.PriorityQueue;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.util.Vector;

public class AStarPathfinder {
   private final World world;
   private final int maxIterations;
   private final double maxDistance;
   private static final double HEURISTIC_MULTIPLIER = (double)1.5F;
   private static final double DIAGONAL_COST = 1.414;

   public AStarPathfinder(World world) {
      this(world, 2000, (double)50.0F);
   }

   public AStarPathfinder(World world, int maxIterations, double maxDistance) {
      this.world = world;
      this.maxIterations = maxIterations;
      this.maxDistance = maxDistance;
   }

   public static AStarPathfinder forFollowMode(World world) {
      return new AStarPathfinder(world, 1500, (double)30.0F);
   }

   public List<Location> findPath(Location start, Location target) {
      return this.findPath(start, target, (double)2.0F);
   }

   public List<Location> findPath(Location start, Location target, double distanceThreshold) {
      if (!this.world.equals(target.getWorld())) {
         return Collections.emptyList();
      } else {
         if (!this.isSafe(target)) {
            target = this.findNearestSafeLocation(target);
            if (target == null) {
               return Collections.emptyList();
            }
         }

         PriorityQueue<PathNode> openSet = new PriorityQueue();
         Map<PathNode, PathNode> cameFrom = new HashMap();
         Map<PathNode, Double> gScore = new HashMap();
         PathNode startNode = new PathNode(start);
         PathNode targetNode = new PathNode(target);
         openSet.add(startNode);
         gScore.put(startNode, (double)0.0F);
         startNode.g = (double)0.0F;
         startNode.f = this.heuristic(start, target);
         int iterations = 0;

         while(!openSet.isEmpty() && iterations < this.maxIterations) {
            ++iterations;
            PathNode current = (PathNode)openSet.poll();
            if (current.location.distance(target) <= distanceThreshold) {
               return this.reconstructPath(cameFrom, current);
            }

            if (current.equals(targetNode)) {
               return this.reconstructPath(cameFrom, current);
            }

            for(PathNode neighbor : this.getNeighbors(current)) {
               double moveCost = this.getMoveCost(current, neighbor);
               double tentativeGScore = (Double)gScore.getOrDefault(current, Double.MAX_VALUE) + moveCost;
               if (tentativeGScore < (Double)gScore.getOrDefault(neighbor, Double.MAX_VALUE)) {
                  cameFrom.put(neighbor, current);
                  gScore.put(neighbor, tentativeGScore);
                  neighbor.g = tentativeGScore;
                  neighbor.f = tentativeGScore + this.heuristic(neighbor.location, target) * (double)1.5F;
                  openSet.remove(neighbor);
                  openSet.add(neighbor);
               }
            }
         }

         return Collections.emptyList();
      }
   }

   private List<Location> reconstructPath(Map<PathNode, PathNode> cameFrom, PathNode current) {
      List<Location> path = new ArrayList();
      path.add(current.location);

      while(cameFrom.containsKey(current)) {
         current = (PathNode)cameFrom.get(current);
         path.add(0, current.location);
      }

      return this.smoothPath(path);
   }

   private List<Location> smoothPath(List<Location> path) {
      if (path.size() <= 2) {
         return path;
      } else {
         List<Location> smoothed = new ArrayList();
         smoothed.add((Location)path.get(0));

         for(int i = 1; i < path.size() - 1; ++i) {
            Location prev = (Location)smoothed.get(smoothed.size() - 1);
            Location curr = (Location)path.get(i);
            Location next = (Location)path.get(i + 1);
            if (!this.hasDirectLineOfSight(prev, next)) {
               smoothed.add(curr);
            }
         }

         smoothed.add((Location)path.get(path.size() - 1));
         return smoothed;
      }
   }

   private boolean hasDirectLineOfSight(Location from, Location to) {
      Vector direction = to.clone().subtract(from).toVector();
      double distance = direction.length();
      direction.normalize();
      int steps = (int)(distance * (double)2.0F);

      for(int i = 1; i < steps; ++i) {
         Location check = from.clone().add(direction.clone().multiply((double)i * (double)0.5F));
         if (!this.isPassable(check)) {
            return false;
         }
      }

      return true;
   }

   private List<PathNode> getNeighbors(PathNode node) {
      List<PathNode> neighbors = new ArrayList();
      Location loc = node.location;
      int[] dx = new int[]{0, 0, 1, -1};
      int[] dz = new int[]{1, -1, 0, 0};

      for(int i = 0; i < 4; ++i) {
         Location neighbor = loc.clone().add((double)dx[i], (double)0.0F, (double)dz[i]);
         if (this.isWalkable(neighbor)) {
            neighbors.add(new PathNode(neighbor));
         }

         Location climbUp = neighbor.clone().add((double)0.0F, (double)1.0F, (double)0.0F);
         if (this.isWalkable(climbUp) && this.canJumpTo(loc, climbUp)) {
            neighbors.add(new PathNode(climbUp));
         }

         for(int drop = 1; drop <= 3; ++drop) {
            Location dropDown = neighbor.clone().add((double)0.0F, (double)(-drop), (double)0.0F);
            if (this.isWalkable(dropDown)) {
               neighbors.add(new PathNode(dropDown));
               break;
            }
         }

         Location ahead = loc.clone().add((double)dx[i], (double)0.0F, (double)dz[i]);
         Location aheadUp = ahead.clone().add((double)0.0F, (double)1.0F, (double)0.0F);
         Location jumpTarget = ahead.clone().add((double)dx[i], (double)0.0F, (double)dz[i]);
         if (this.isBlocked(ahead) && !this.isBlocked(aheadUp) && this.isWalkable(jumpTarget)) {
            neighbors.add(new PathNode(jumpTarget));
         }
      }

      int[] diagDx = new int[]{1, 1, -1, -1};
      int[] diagDz = new int[]{1, -1, 1, -1};

      for(int i = 0; i < 4; ++i) {
         Location diagonal = loc.clone().add((double)diagDx[i], (double)0.0F, (double)diagDz[i]);
         Location corner1 = loc.clone().add((double)diagDx[i], (double)0.0F, (double)0.0F);
         Location corner2 = loc.clone().add((double)0.0F, (double)0.0F, (double)diagDz[i]);
         if (this.isWalkable(diagonal) && (!this.isBlocked(corner1) || !this.isBlocked(corner2))) {
            neighbors.add(new PathNode(diagonal));
         }
      }

      return neighbors;
   }

   private boolean canJumpTo(Location from, Location to) {
      double yDiff = to.getY() - from.getY();
      return yDiff >= (double)0.0F && yDiff <= (double)1.5F;
   }

   private double getMoveCost(PathNode from, PathNode to) {
      double dx = Math.abs(to.location.getX() - from.location.getX());
      double dz = Math.abs(to.location.getZ() - from.location.getZ());
      double dy = to.location.getY() - from.location.getY();
      double baseCost = dx > (double)0.0F && dz > (double)0.0F ? 1.414 : (double)1.0F;
      if (dy > (double)0.0F) {
         baseCost += dy * (double)2.0F;
      } else if (dy < (double)0.0F) {
         baseCost += Math.abs(dy) * (double)0.5F;
      }

      return baseCost;
   }

   private double heuristic(Location from, Location to) {
      double dx = Math.abs(from.getX() - to.getX());
      double dy = Math.abs(from.getY() - to.getY());
      double dz = Math.abs(from.getZ() - to.getZ());
      return dx + dy + dz;
   }

   private Location findNearestSafeLocation(Location target) {
      int searchRadius = 10;

      for(int r = 0; r <= searchRadius; ++r) {
         for(int dx = -r; dx <= r; ++dx) {
            for(int dy = -r; dy <= r; ++dy) {
               for(int dz = -r; dz <= r; ++dz) {
                  if (Math.abs(dx) == r || Math.abs(dy) == r || Math.abs(dz) == r) {
                     Location test = target.clone().add((double)dx, (double)dy, (double)dz);
                     if (this.isSafe(test)) {
                        return test;
                     }
                  }
               }
            }
         }
      }

      return null;
   }

   private boolean isSafe(Location loc) {
      return this.isWalkable(loc) && !this.isDangerous(loc);
   }

   private boolean isWalkable(Location loc) {
      if (loc != null && !(loc.getY() < (double)-64.0F) && !(loc.getY() > (double)320.0F)) {
         Block below = loc.clone().add((double)0.0F, (double)-1.0F, (double)0.0F).getBlock();
         Block feet = loc.getBlock();
         Block head = loc.clone().add((double)0.0F, (double)1.0F, (double)0.0F).getBlock();
         if (!this.isSolidBlockForPathfinding(feet) && !this.isSolidBlockForPathfinding(head)) {
            return !below.getType().isSolid() && !below.isLiquid() ? false : !this.isDangerousBlock(feet) && !this.isDangerousBlock(head);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean isSolidBlockForPathfinding(Block block) {
      if (block == null) {
         return false;
      } else {
         String name = block.getType().name();
         if (!name.contains("AIR") && !name.contains("CAVE_AIR")) {
            if (!name.contains("WATER") && !name.contains("SEAGRASS") && !name.contains("KELP")) {
               if (name.contains("CARPET")) {
                  return false;
               } else if (!name.equals("SHORT_GRASS") && !name.equals("FERN") && !name.equals("DEAD_BUSH")) {
                  if (!name.equals("VINE") && !name.equals("TRIPWIRE") && !name.equals("TRIPWIRE_HOOK")) {
                     if (name.contains("SIGN")) {
                        return false;
                     } else if (name.contains("DOOR") && !name.contains("BLOCK")) {
                        return false;
                     } else if (name.contains("GATE") && name.contains("FENCE")) {
                        return false;
                     } else if (name.contains("PLATE")) {
                        return false;
                     } else if (name.contains("PRESSURE_PLATE")) {
                        return false;
                     } else if (!name.equals("LILY_PAD") && !name.equals("BIG_DRIPLEAF")) {
                        if (name.contains("SLAB") && name.contains("DOUBLE")) {
                           return true;
                        } else if (name.contains("SLAB") && !name.contains("DOUBLE")) {
                           return false;
                        } else if (name.contains("STAIRS")) {
                           return false;
                        } else {
                           return name.contains("HOPPER") ? false : block.getType().isSolid();
                        }
                     } else {
                        return false;
                     }
                  } else {
                     return false;
                  }
               } else {
                  return false;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      }
   }

   private boolean isPassable(Location loc) {
      if (loc == null) {
         return false;
      } else {
         Block block = loc.getBlock();
         return !block.getType().isSolid();
      }
   }

   private boolean isBlocked(Location loc) {
      return loc == null ? true : this.isSolidBlockForPathfinding(loc.getBlock()) || this.isSolidBlockForPathfinding(loc.clone().add((double)0.0F, (double)1.0F, (double)0.0F).getBlock());
   }

   private boolean isDangerous(Location loc) {
      if (loc == null) {
         return false;
      } else {
         Block block = loc.getBlock();
         return this.isDangerousBlock(block);
      }
   }

   private boolean isDangerousBlock(Block block) {
      if (block == null) {
         return false;
      } else {
         String name = block.getType().name();
         return name.contains("LAVA") || name.contains("FIRE") || name.contains("MAGMA") || name.contains("CAMPFIRE") || name.contains("BERRY") || name.contains("WITHER_ROSE") || name.contains("SWEET_BERRY");
      }
   }

   private static class PathNode implements Comparable<PathNode> {
      final Location location;
      double g;
      double f;

      PathNode(Location location) {
         this.location = location;
         this.g = Double.MAX_VALUE;
         this.f = Double.MAX_VALUE;
      }

      public int compareTo(PathNode other) {
         return Double.compare(this.f, other.f);
      }

      public boolean equals(Object obj) {
         if (this == obj) {
            return true;
         } else if (obj != null && this.getClass() == obj.getClass()) {
            PathNode pathNode = (PathNode)obj;
            return this.location.getBlockX() == pathNode.location.getBlockX() && this.location.getBlockY() == pathNode.location.getBlockY() && this.location.getBlockZ() == pathNode.location.getBlockZ();
         } else {
            return false;
         }
      }

      public int hashCode() {
         return Objects.hash(new Object[]{this.location.getBlockX(), this.location.getBlockY(), this.location.getBlockZ()});
      }
   }
}
