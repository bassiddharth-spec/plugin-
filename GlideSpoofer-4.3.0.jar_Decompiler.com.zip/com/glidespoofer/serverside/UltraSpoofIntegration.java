package com.glidespoofer.serverside;

import com.mojang.authlib.GameProfile;
import io.netty.channel.nio.NioEventLoopGroup;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.plugin.Plugin;
import org.spigotmc.event.player.PlayerSpawnLocationEvent;

public class UltraSpoofIntegration {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-UltraSpoofIntegration");
   private final Plugin plugin;
   private final int minorVersion;
   private final int patchVersion;
   private final String nmsVersion;
   private NioEventLoopGroup eventExecutors;
   private static Class<?> minecraftServerClass;
   private static Class<?> dedicatedServerClass;
   private static Class<?> worldServerClass;
   private static Class<?> entityPlayerClass;
   private static Class<?> playerConnectionClass;
   private static Class<?> serverCommonPacketListenerClass;
   private static Class<?> networkManagerClass;
   private static Class<?> playerListClass;
   private static Class<?> gameProfileClass;
   private static Class<?> clientInformationClass;
   private static Class<?> commonListenerCookieClass;
   private static Class<?> craftServerClass;
   private static Class<?> craftPlayerClass;
   private static Class<?> craftWorldClass;
   private static Class<?> packetClass;
   private static Class<?> playerInfoUpdatePacketClass;
   private static Class<?> addEntityPacketClass;
   private static Class<?> namedEntitySpawnPacketClass;
   private static Class<?> loginPacketClass;
   private static Class<?> serverDifficultyPacketClass;
   private static Class<?> abilitiesPacketClass;
   private static Class<?> heldItemSlotPacketClass;
   private static Class<?> recipeUpdatePacketClass;
   private static Class<?> gameRulesClass;
   private static Class<?> worldDataClass;
   private static Class<?> dimensionManagerClass;
   private static Class<?> craftingManagerClass;
   private static Class<?> serverPingClass;
   private static Class<?> userCacheClass;
   private static Class<?> enumChatFormatClass;
   private static Class<?> iChatBaseComponentClass;
   private static Class<?> registryFriendlyByteBufClass;
   private static Class<?> gameProtocolsClass;
   private static Class<?> resourceKeyClass;

   public UltraSpoofIntegration(Plugin plugin) {
      this.plugin = plugin;
      String version = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
      this.nmsVersion = version;
      int minor = 20;
      int patch = 0;

      try {
         String[] parts = version.replace("v", "").replace("R", "").split("_");
         if (parts.length >= 2) {
            minor = Integer.parseInt(parts[1]);
         }

         if (parts.length >= 3) {
            patch = Integer.parseInt(parts[2]);
         }
      } catch (Exception var6) {
         LOGGER.warning("[UltraSpoofIntegration] Could not parse version: " + version);
      }

      this.minorVersion = minor;
      this.patchVersion = patch;
      this.eventExecutors = new NioEventLoopGroup(5);
      LOGGER.info("[UltraSpoofIntegration] Initialized for version " + version + " (minor=" + minor + ", patch=" + patch + ")");
   }

   public void sendSpawnPacketToPlayer(Player target, Object serverPlayer) {
      try {
         Class<?> packetClass;
         if (this.minorVersion < 21 && (this.minorVersion != 20 || this.patchVersion < 2)) {
            packetClass = namedEntitySpawnPacketClass;
         } else {
            packetClass = addEntityPacketClass;
         }

         boolean sent = false;

         for(Constructor<?> c : packetClass.getDeclaredConstructors()) {
            try {
               if (c.getParameterCount() == 1) {
                  c.setAccessible(true);
                  Object packet = c.newInstance(serverPlayer);
                  this.sendPacketToPlayer(target, packet);
                  sent = true;
                  this.debug("[UltraSpoofIntegration] Sent spawn packet (1-param) to " + target.getName());
                  break;
               }
            } catch (Exception e) {
               this.debug("[UltraSpoofIntegration] Failed 1-param spawn packet: " + e.getMessage());
            }
         }

         if (!sent && (this.minorVersion >= 21 || this.minorVersion == 20 && this.patchVersion >= 2)) {
            sent = this.tryDetailedSpawnPacket(target, serverPlayer, packetClass);
         }

         if (sent) {
            this.sendMetadataPacket(target, serverPlayer);
         } else {
            LOGGER.warning("[UltraSpoofIntegration] Could not send spawn packet to " + target.getName() + " - no working constructor found");
         }
      } catch (Exception e) {
         this.debug("[UltraSpoofIntegration] Error in sendSpawnPacketToPlayer: " + e.getMessage());
         e.printStackTrace();
      }

   }

   private boolean tryDetailedSpawnPacket(Player target, Object serverPlayer, Class<?> packetClass) {
      try {
         int entityId = (Integer)this.invokeMethod(serverPlayer, "getId");
         UUID uuid = (UUID)this.invokeMethod(serverPlayer, "getUUID");
         double x = (double)0.0F;
         double y = (double)0.0F;
         double z = (double)0.0F;

         try {
            Object pos = this.invokeMethod(serverPlayer, "position");
            x = (Double)this.invokeMethod(pos, "x");
            y = (Double)this.invokeMethod(pos, "y");
            z = (Double)this.invokeMethod(pos, "z");
         } catch (Exception e) {
            this.debug("[UltraSpoofIntegration] Could not get position: " + e.getMessage());
         }

         Object entityType = null;

         try {
            entityType = this.invokeMethod(serverPlayer, "getType");
         } catch (Exception var20) {
            Class<?> entityTypesClass = Class.forName("net.minecraft.world.entity.EntityType");
            Field playerField = entityTypesClass.getField("PLAYER");
            entityType = playerField.get((Object)null);
         }

         for(Constructor<?> c : packetClass.getDeclaredConstructors()) {
            try {
               c.setAccessible(true);
               Class<?>[] paramTypes = c.getParameterTypes();
               if (paramTypes.length >= 6) {
                  Object packet = null;
                  if (paramTypes.length == 9) {
                     packet = c.newInstance(entityId, uuid, x, y, z, 0.0F, 0.0F, entityType, 0);
                  } else if (paramTypes.length == 10) {
                     packet = c.newInstance(entityId, uuid, x, y, z, 0.0F, 1.0F, entityType, 1, null);
                  } else if (paramTypes.length == 11) {
                     packet = c.newInstance(entityId, uuid, x, y, z, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, null);
                  }

                  if (packet != null) {
                     this.sendPacketToPlayer(target, packet);
                     String var10001 = target.getName();
                     this.debug("[UltraSpoofIntegration] Sent spawn packet (multi-param) to " + var10001 + " for entity " + String.valueOf(uuid));
                     return true;
                  }
               }
            } catch (Exception e) {
               this.debug("[UltraSpoofIntegration] Failed multi-param spawn packet: " + e.getMessage());
            }
         }
      } catch (Exception e) {
         this.debug("[UltraSpoofIntegration] Error building detailed spawn packet: " + e.getMessage());
      }

      return false;
   }

   private void sendMetadataPacket(Player target, Object serverPlayer) {
      try {
         Method getEntityDataMethod = entityPlayerClass.getMethod("getEntityData");
         Object entityData = getEntityDataMethod.invoke(serverPlayer);
         Class<?> metadataPacketClass = Class.forName("net.minecraft.network.protocol.game.PacketPlayOutEntityMetadata");
         Constructor<?> constructor = metadataPacketClass.getConstructor(Integer.TYPE, entityData.getClass(), Boolean.TYPE);
         int entityId = (Integer)this.invokeMethod(serverPlayer, "getId");
         Object packet = constructor.newInstance(entityId, entityData, true);
         this.sendPacketToPlayer(target, packet);
         this.debug("[UltraSpoofIntegration] Sent metadata packet to " + target.getName());
      } catch (Exception e) {
         this.debug("[UltraSpoofIntegration] Could not send metadata packet: " + e.getMessage());
      }

   }

   public Player spawnFakePlayer(String name, UUID uuid, Location location, String skinName) {
      Object result = this.spawnUltraSpoofStyle(name, uuid, location, "127.0.0.1", 25565, 40000);
      if (result != null) {
         try {
            Method getBukkitEntity = result.getClass().getMethod("getBukkitEntity");
            return (Player)getBukkitEntity.invoke(result);
         } catch (Exception var7) {
            return null;
         }
      } else {
         return null;
      }
   }

   public Object spawnUltraSpoofStyle(String name, UUID uuid, Location location, String ipAddress, int portStart, int portEnd) {
      try {
         Object dedicatedServer = this.getDedicatedServer();
         Object entityPlayer = this.createEntityPlayer(name, uuid, location);
         if (entityPlayer == null) {
            LOGGER.warning("[UltraSpoofIntegration] Failed to create EntityPlayer for " + name);
            return null;
         } else {
            if (location != null) {
               Method setPosMethod = entityPlayerClass.getMethod("b", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
               if (setPosMethod == null) {
                  setPosMethod = entityPlayerClass.getMethod("setPos", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
               }

               setPosMethod.invoke(entityPlayer, location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
            }

            int port = ThreadLocalRandom.current().nextInt(portStart, portEnd + 1);
            FakeNetworkManager fakeNetworkManager = new FakeNetworkManager(port, ipAddress);
            if (fakeNetworkManager.getFakeChannel() != null) {
               this.eventExecutors.register(fakeNetworkManager.getFakeChannel());
            }

            CompletableFuture<Boolean> preLoginFuture = CompletableFuture.supplyAsync(() -> {
               try {
                  AsyncPlayerPreLoginEvent preLoginEvent = new AsyncPlayerPreLoginEvent(name, InetAddress.getByName(ipAddress), uuid);
                  Bukkit.getPluginManager().callEvent(preLoginEvent);
                  return true;
               } catch (UnknownHostException e) {
                  e.printStackTrace();
                  return false;
               }
            });
            preLoginFuture.thenAcceptAsync((success) -> {
               if (success) {
                  this.completeSpawn(entityPlayer, name, uuid, ipAddress, dedicatedServer, fakeNetworkManager);
               }

            });
            return entityPlayer;
         }
      } catch (Exception e) {
         LOGGER.log(Level.SEVERE, "[UltraSpoofIntegration] Error in spawnUltraSpoofStyle", e);
         return null;
      }
   }

   private void completeSpawn(Object entityPlayer, String name, UUID uuid, String ipAddress, Object dedicatedServer, FakeNetworkManager fakeNetworkManager) {
      try {
         GameProfile gameProfile = (GameProfile)this.invokeMethod(entityPlayer, "getGameProfile");
         MojangAPI.setSkin(this.plugin, gameProfile, name, (updatedProfile) -> {
            this.updateGameProfile(entityPlayer, updatedProfile);
            Bukkit.getScheduler().runTask(this.plugin, () -> {
               try {
                  Player craftPlayer = this.getCraftPlayer(entityPlayer);
                  if (craftPlayer != null) {
                     InetAddress address = InetAddress.getByName(ipAddress);
                     PlayerLoginEvent loginEvent = new PlayerLoginEvent(craftPlayer, ipAddress, address);
                     Bukkit.getPluginManager().callEvent(loginEvent);
                  }

                  Object playerList = this.getPlayerList(dedicatedServer);
                  Object networkManager = fakeNetworkManager.getNetworkManager();
                  Object cookie = this.createCommonListenerCookie(gameProfile, true);
                  this.addPlayerToServer(playerList, dedicatedServer, networkManager, entityPlayer, cookie);
                  this.broadcastPlayerInfo(entityPlayer);
                  LOGGER.info("[UltraSpoofIntegration] Spawn complete for " + name);
               } catch (Exception e) {
                  LOGGER.log(Level.WARNING, "[UltraSpoofIntegration] Error completing spawn", e);
               }

            });
         });
      } catch (Exception e) {
         LOGGER.log(Level.WARNING, "[UltraSpoofIntegration] Error in completeSpawn", e);
      }

   }

   private void updateGameProfile(Object entityPlayer, GameProfile newProfile) {
      try {
         Field gameProfileField = null;

         for(Class<?> clazz = entityPlayer.getClass(); clazz != null && gameProfileField == null; clazz = clazz.getSuperclass()) {
            for(Field f : clazz.getDeclaredFields()) {
               if (f.getType() == gameProfileClass) {
                  gameProfileField = f;
                  break;
               }
            }
         }

         if (gameProfileField != null) {
            gameProfileField.setAccessible(true);

            try {
               Field modifiersField = Field.class.getDeclaredField("modifiers");
               modifiersField.setAccessible(true);
               modifiersField.setInt(gameProfileField, gameProfileField.getModifiers() & -17);
            } catch (NoSuchFieldException var9) {
            }

            gameProfileField.set(entityPlayer, newProfile);
         }
      } catch (Exception e) {
         LOGGER.warning("[UltraSpoofIntegration] Failed to update GameProfile: " + e.getMessage());
      }

   }

   public void addPlayerToServer(Object playerList, Object minecraftServer, Object networkManager, Object entityPlayer, Object commonListenerCookie) {
      try {
         GameProfile gameProfile = (GameProfile)this.invokeMethod(entityPlayer, "getGameProfile");
         Object userCache = this.invokeMethod(minecraftServer, "at");
         if (userCache != null) {
            try {
               Method cacheMethod = userCacheClass.getMethod("a", gameProfile.getClass());
               cacheMethod.invoke(userCache, gameProfile);
            } catch (Exception e) {
               this.debug("[UltraSpoofIntegration] Could not update user cache: " + e.getMessage());
            }
         }

         Optional<?> playerData = this.loadPlayerData(playerList, entityPlayer);
         Object worldServer = this.getWorldServer(minecraftServer, entityPlayer, playerData);
         if (worldServer == null) {
            LOGGER.warning("[UltraSpoofIntegration] Unknown respawn dimension, defaulting to overworld");
            worldServer = this.invokeMethod(minecraftServer, "J");
         }

         Method setWorldMethod = entityPlayerClass.getMethod("a", worldServerClass);
         setWorldMethod.invoke(entityPlayer, worldServer);
         Player craftPlayer = this.getCraftPlayer(entityPlayer);
         Location spawnLocation = craftPlayer.getLocation();
         PlayerSpawnLocationEvent spawnLocationEvent = new PlayerSpawnLocationEvent(craftPlayer, spawnLocation);
         Bukkit.getPluginManager().callEvent(spawnLocationEvent);
         Location finalLocation = spawnLocationEvent.getSpawnLocation();
         worldServer = this.getHandle(craftPlayer.getLocation().getWorld());
         Method spawnInMethod = entityPlayerClass.getMethod("spawnIn", Class.forName("net.minecraft.world.level.World"));
         spawnInMethod.invoke(entityPlayer, worldServer);
         Method setPosMethod = entityPlayerClass.getMethod("a", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
         setPosMethod.invoke(entityPlayer, finalLocation.getX(), finalLocation.getY(), finalLocation.getZ(), finalLocation.getYaw(), finalLocation.getPitch());
         Object worldData = this.invokeMethod(worldServer, "D_");
         FakeConnection fakeConnection = new FakeConnection(minecraftServer, networkManager, entityPlayer, commonListenerCookie);
         Object protocol = this.invokeMethod(gameProtocolsClass, "a");
         Method setProtocolMethod = networkManagerClass.getMethod("a", Class.forName("net.minecraft.network.ProtocolInfo"), Class.forName("net.minecraft.network.PacketListener"));
         Object registryAccess = this.invokeMethod(minecraftServer, "ba");
         this.invokeMethod(registryFriendlyByteBufClass, "a", registryAccess);
         setProtocolMethod.invoke(networkManager, protocol, fakeConnection);
         Object gameRules = this.invokeMethod(worldServer, "O");
         boolean doImmediateRespawn = this.getGameRule(gameRules, "E");
         boolean doLimitedCrafting = this.getGameRule(gameRules, "q");
         boolean doInsomnia = this.getGameRule(gameRules, "x");
         Object loginPacket = this.createLoginPacket(entityPlayer, worldData, minecraftServer, playerList, worldServer, doLimitedCrafting, !doImmediateRespawn, doInsomnia);
         this.sendPacket(fakeConnection, loginPacket);
         Object difficultyPacket = this.createDifficultyPacket(worldData);
         this.sendPacket(fakeConnection, difficultyPacket);
         Object abilitiesPacket = this.createAbilitiesPacket(entityPlayer);
         this.sendPacket(fakeConnection, abilitiesPacket);
         Object heldItemPacket = this.createHeldItemSlotPacket(entityPlayer);
         this.sendPacket(fakeConnection, heldItemPacket);
         Object recipePacket = this.createRecipeUpdatePacket(minecraftServer);
         this.sendPacket(fakeConnection, recipePacket);
         Method loadHookMethod = playerListClass.getMethod("e", entityPlayerClass);
         loadHookMethod.invoke(playerList, entityPlayer);
         Object inventory = this.invokeMethod(entityPlayer, "I");
         this.invokeMethod(inventory, "c");
         Object craftingContainer = this.invokeMethod(entityPlayer, "J");
         this.invokeMethod(craftingContainer, "a", entityPlayer);
         Method setGameModeMethod = playerListClass.getMethod("a", Class.forName("net.minecraft.world.level.EnumGamemode"), entityPlayerClass);
         Object gameMode = this.invokeMethod(worldServer, "g");
         setGameModeMethod.invoke(playerList, gameMode, entityPlayer);
         this.invokeMethod(minecraftServer, "av");
         Object chatComponent = this.createJoinMessage(gameProfile);
         String joinMessage = this.convertChatComponent(chatComponent);
         this.sendPacket(fakeConnection, chatComponent);
         Object serverPing = this.invokeMethod(minecraftServer, "au");
         if (serverPing != null && !this.isOfflineMode(commonListenerCookie)) {
            Method setPingMethod = entityPlayerClass.getMethod("a", serverPingClass);
            setPingMethod.invoke(entityPlayer, serverPing);
         }

         this.addToPlayerListMaps(playerList, entityPlayer);
         Method addToListMethod = playerListClass.getMethod("a", Class.forName("net.minecraft.network.Connection"), entityPlayerClass, commonListenerCookieClass);
         addToListMethod.invoke(playerList, networkManager, entityPlayer, commonListenerCookie);
         PlayerJoinEvent joinEvent = new PlayerJoinEvent(craftPlayer, joinMessage);
         Bukkit.getPluginManager().callEvent(joinEvent);
         if (this.isConnectionActive(entityPlayer)) {
            String finalJoinMessage = joinEvent.getJoinMessage();
            if (finalJoinMessage != null && !finalJoinMessage.isEmpty()) {
               for(Object component : this.convertStringToComponents(finalJoinMessage)) {
                  this.broadcastChatMessage(minecraftServer, component);
               }
            }

            Object[] infoPackets = this.createPlayerInfoPackets(entityPlayer);
            this.broadcastPacketsToPlayers(playerList, infoPackets, craftPlayer);
            Field sentListPacketField = entityPlayerClass.getDeclaredField("sentListPacket");
            sentListPacketField.setAccessible(true);
            sentListPacketField.setBoolean(entityPlayer, true);
            Method refreshMethod = entityPlayerClass.getMethod("refreshEntityData", entityPlayerClass);
            refreshMethod.invoke(entityPlayer, entityPlayer);
            if (!this.isEntityInWorld(worldServer, entityPlayer)) {
               this.addEntityToWorld(worldServer, entityPlayer);
               this.registerWithChunkMap(minecraftServer, entityPlayer);
            }

            LOGGER.info("[UltraSpoofIntegration] Player " + gameProfile.getName() + " added to server successfully");
         }
      } catch (Exception e) {
         LOGGER.log(Level.SEVERE, "[UltraSpoofIntegration] Error in addPlayerToServer", e);
      }

   }

   private Object getDedicatedServer() {
      try {
         Object craftServer = craftServerClass.cast(Bukkit.getServer());
         Method getServerMethod = craftServerClass.getMethod("getServer");
         return getServerMethod.invoke(craftServer);
      } catch (Exception var3) {
         return null;
      }
   }

   private Object createEntityPlayer(String name, UUID uuid, Location location) {
      try {
         Object minecraftServer = this.getDedicatedServer();
         Object worldServer = this.getHandle(location.getWorld());
         GameProfile gameProfile = new GameProfile(uuid, name);
         Object clientInfo = this.createDefaultClientInformation();
         Constructor<?> constructor = entityPlayerClass.getConstructor(minecraftServerClass, worldServerClass, gameProfileClass, clientInformationClass);
         return constructor.newInstance(minecraftServer, worldServer, gameProfile, clientInfo);
      } catch (Exception e) {
         LOGGER.warning("[UltraSpoofIntegration] Failed to create EntityPlayer: " + e.getMessage());
         return null;
      }
   }

   private Object createDefaultClientInformation() {
      try {
         Method createDefault = clientInformationClass.getMethod("a");
         return createDefault.invoke((Object)null);
      } catch (Exception var2) {
         return null;
      }
   }

   private Object getHandle(World world) {
      try {
         Object craftWorld = craftWorldClass.cast(world);
         Method getHandleMethod = craftWorldClass.getMethod("getHandle");
         return getHandleMethod.invoke(craftWorld);
      } catch (Exception var4) {
         return null;
      }
   }

   private Object getPlayerList(Object minecraftServer) {
      try {
         String[] methodNames = new String[]{"ag", "af", "ae", "ad", "ac", "getPlayerList"};

         for(String name : methodNames) {
            try {
               Method method = minecraftServer.getClass().getMethod(name);
               Object result = method.invoke(minecraftServer);
               if (result != null) {
                  return result;
               }
            } catch (NoSuchMethodException var9) {
            }
         }
      } catch (Exception e) {
         LOGGER.warning("[UltraSpoofIntegration] Could not get PlayerList: " + e.getMessage());
      }

      return null;
   }

   private Player getCraftPlayer(Object entityPlayer) {
      try {
         Method getBukkitEntityMethod = entityPlayerClass.getMethod("getBukkitEntity");
         return (Player)getBukkitEntityMethod.invoke(entityPlayer);
      } catch (Exception var3) {
         return null;
      }
   }

   public Object createCommonListenerCookie(GameProfile profile, boolean transfer) {
      try {
         Method createMethod = commonListenerCookieClass.getMethod("a", gameProfileClass, Boolean.TYPE);
         return createMethod.invoke((Object)null, profile, transfer);
      } catch (Exception var4) {
         return null;
      }
   }

   private void broadcastPlayerInfo(Object entityPlayer) {
      try {
         Method createPacketMethod = playerInfoUpdatePacketClass.getMethod("a", List.class);
         Object packet = createPacketMethod.invoke((Object)null, List.of(entityPlayer));

         for(Player player : Bukkit.getOnlinePlayers()) {
            Object craftPlayer = craftPlayerClass.cast(player);
            Object handle = craftPlayerClass.getMethod("getHandle").invoke(craftPlayer);
            Object connection = this.getConnection(handle);
            if (connection != null) {
               Method sendMethod = connection.getClass().getMethod("a", packetClass);
               sendMethod.invoke(connection, packet);
            }
         }
      } catch (Exception e) {
         this.debug("[UltraSpoofIntegration] Could not broadcast player info: " + e.getMessage());
      }

   }

   private Object getConnection(Object entityPlayer) {
      try {
         Field connectionField = entityPlayerClass.getDeclaredField("f");
         connectionField.setAccessible(true);
         return connectionField.get(entityPlayer);
      } catch (Exception var3) {
         return null;
      }
   }

   private void sendPacketToPlayer(Player target, Object packet) {
      try {
         Object craftPlayer = craftPlayerClass.cast(target);
         Object handle = craftPlayerClass.getMethod("getHandle").invoke(craftPlayer);
         Object connection = this.getConnection(handle);
         if (connection != null) {
            Method sendMethod = connection.getClass().getMethod("a", packetClass);
            sendMethod.invoke(connection, packet);
         }
      } catch (Exception e) {
         this.debug("[UltraSpoofIntegration] Could not send packet: " + e.getMessage());
      }

   }

   private Object invokeMethod(Object obj, String methodName, Object... args) {
      try {
         for(Class<?> clazz = obj.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
            for(Method method : clazz.getDeclaredMethods()) {
               if (method.getName().equals(methodName)) {
                  method.setAccessible(true);
                  return method.invoke(obj, args);
               }
            }
         }
      } catch (Exception var9) {
      }

      return null;
   }

   private boolean getGameRule(Object gameRules, String ruleName) {
      try {
         Method getMethod = gameRulesClass.getMethod("b", Class.forName("net.minecraft.world.level.GameRules$GameRuleKey"));
         return false;
      } catch (Exception var4) {
         return false;
      }
   }

   private Optional<?> loadPlayerData(Object playerList, Object entityPlayer) {
      try {
         Method loadMethod = playerListClass.getMethod("a", entityPlayerClass);
         return (Optional)loadMethod.invoke(playerList, entityPlayer);
      } catch (Exception var4) {
         return Optional.empty();
      }
   }

   private Object getWorldServer(Object minecraftServer, Object entityPlayer, Optional<?> playerData) {
      try {
         return this.invokeMethod(minecraftServer, "J");
      } catch (Exception var5) {
         return null;
      }
   }

   private Object createLoginPacket(Object entityPlayer, Object worldData, Object minecraftServer, Object playerList, Object worldServer, boolean limitedCrafting, boolean immediateRespawn, boolean insomnia) {
      try {
         int entityId = (Integer)this.invokeMethod(entityPlayer, "ar");
         Object gameType = this.invokeMethod(playerList, "n");
         int viewDistance = this.getViewDistance(worldServer);
         int simulationDistance = this.getSimulationDistance(worldServer);
         Constructor<?> constructor = loginPacketClass.getConstructor(Integer.TYPE, worldDataClass, resourceKeyClass, Integer.TYPE, Integer.TYPE, Integer.TYPE, Boolean.TYPE, Boolean.TYPE, Boolean.TYPE, Object.class, Object.class);
         return constructor.newInstance(entityId, worldData, gameType, viewDistance, simulationDistance, limitedCrafting, immediateRespawn, insomnia, null, null);
      } catch (Exception var14) {
         return null;
      }
   }

   private int getViewDistance(Object worldServer) {
      try {
         Field field = worldServer.getClass().getField("spigotConfig");
         Object spigotConfig = field.get(worldServer);
         return spigotConfig.getClass().getField("viewDistance").getInt(spigotConfig);
      } catch (Exception var4) {
         return 10;
      }
   }

   private int getSimulationDistance(Object worldServer) {
      try {
         Field field = worldServer.getClass().getField("spigotConfig");
         Object spigotConfig = field.get(worldServer);
         return spigotConfig.getClass().getField("simulationDistance").getInt(spigotConfig);
      } catch (Exception var4) {
         return 10;
      }
   }

   private Object createDifficultyPacket(Object worldData) {
      try {
         Constructor<?> constructor = serverDifficultyPacketClass.getConstructor(worldDataClass);
         return constructor.newInstance(worldData);
      } catch (Exception var3) {
         return null;
      }
   }

   private Object createAbilitiesPacket(Object entityPlayer) {
      try {
         Object abilities = this.invokeMethod(entityPlayer, "gj");
         Constructor<?> constructor = abilitiesPacketClass.getConstructor(abilities.getClass());
         return constructor.newInstance(abilities);
      } catch (Exception var4) {
         return null;
      }
   }

   private Object createHeldItemSlotPacket(Object entityPlayer) {
      try {
         Object inventory = this.invokeMethod(entityPlayer, "gi");
         int slot = inventory.getClass().getField("j").getInt(inventory);
         Constructor<?> constructor = heldItemSlotPacketClass.getConstructor(Integer.TYPE);
         return constructor.newInstance(slot);
      } catch (Exception var5) {
         return null;
      }
   }

   private Object createRecipeUpdatePacket(Object minecraftServer) {
      try {
         Object craftingManager = this.invokeMethod(minecraftServer, "aI");
         Method getRecipes = craftingManagerClass.getMethod("b");
         Method getHighlights = craftingManagerClass.getMethod("d");
         Constructor<?> constructor = recipeUpdatePacketClass.getConstructor(getRecipes.getReturnType(), getHighlights.getReturnType());
         return constructor.newInstance(getRecipes.invoke(craftingManager), getHighlights.invoke(craftingManager));
      } catch (Exception var6) {
         return null;
      }
   }

   private Object createJoinMessage(GameProfile profile) {
      try {
         Method createTranslatable = iChatBaseComponentClass.getMethod("a", String.class, Object[].class);
         Object component = createTranslatable.invoke((Object)null, "multiplayer.player.joined", new Object[]{this.invokeMethod(entityPlayerClass.cast(profile), "p_")});
         Method withStyleMethod = component.getClass().getMethod("a", enumChatFormatClass);
         return withStyleMethod.invoke(component, enumChatFormatClass.getField("o").get((Object)null));
      } catch (Exception var5) {
         return null;
      }
   }

   private String convertChatComponent(Object component) {
      try {
         Class<?> craftChatMessageClass = Class.forName(craftServerClass.getPackage().getName() + ".util.CraftChatMessage");
         Method fromComponent = craftChatMessageClass.getMethod("fromComponent", iChatBaseComponentClass);
         return (String)fromComponent.invoke((Object)null, component);
      } catch (Exception var4) {
         return "";
      }
   }

   private Object[] convertStringToComponents(String message) {
      try {
         Class<?> craftChatMessageClass = Class.forName(craftServerClass.getPackage().getName() + ".util.CraftChatMessage");
         Method fromString = craftChatMessageClass.getMethod("fromString", String.class);
         return fromString.invoke((Object)null, message);
      } catch (Exception var4) {
         return new Object[0];
      }
   }

   private void broadcastChatMessage(Object minecraftServer, Object component) {
      try {
         Object chatType = null;
         Method broadcastMethod = minecraftServerClass.getMethod("a", iChatBaseComponentClass, Boolean.TYPE);
         broadcastMethod.invoke(minecraftServer, component, false);
      } catch (Exception e) {
         this.debug("[UltraSpoofIntegration] Could not broadcast message: " + e.getMessage());
      }

   }

   private Object[] createPlayerInfoPackets(Object entityPlayer) {
      try {
         Method createPacketMethod = playerInfoUpdatePacketClass.getMethod("a", List.class);
         return new Object[]{createPacketMethod.invoke((Object)null, List.of(entityPlayer))};
      } catch (Exception var3) {
         return new Object[0];
      }
   }

   private void broadcastPacketsToPlayers(Object playerList, Object[] packets, Player sender) {
      try {
         Field playersField = playerListClass.getDeclaredField("l");
         playersField.setAccessible(true);

         for(Object player : (List)playersField.get(playerList)) {
            Object craftPlayer = this.getCraftPlayer(player);
            if (craftPlayer != null && ((Player)craftPlayer).canSee(sender)) {
               Object connection = this.getConnection(player);
               if (connection != null) {
                  for(Object packet : packets) {
                     Method sendMethod = connection.getClass().getMethod("a", packetClass);
                     sendMethod.invoke(connection, packet);
                  }
               }
            }
         }
      } catch (Exception e) {
         this.debug("[UltraSpoofIntegration] Could not broadcast packets: " + e.getMessage());
      }

   }

   private boolean isOfflineMode(Object cookie) {
      try {
         Method isOffline = commonListenerCookieClass.getMethod("d");
         return (Boolean)isOffline.invoke(cookie);
      } catch (Exception var3) {
         return false;
      }
   }

   private void addToPlayerListMaps(Object playerList, Object entityPlayer) {
      try {
         Field nameMapField = playerListClass.getDeclaredField("playersByName");
         nameMapField.setAccessible(true);
         Map<String, Object> nameMap = (Map)nameMapField.get(playerList);
         String name = (String)this.invokeMethod(entityPlayer, "cI");
         nameMap.put(name.toLowerCase(Locale.ROOT), entityPlayer);
         nameMapField.set(playerList, nameMap);
         Field uuidMapField = playerListClass.getDeclaredField("m");
         uuidMapField.setAccessible(true);
         Map<UUID, Object> uuidMap = (Map)uuidMapField.get(playerList);
         UUID uuid = (UUID)this.invokeMethod(entityPlayer, "cG");
         uuidMap.put(uuid, entityPlayer);
         uuidMapField.set(playerList, uuidMap);
      } catch (Exception e) {
         this.debug("[UltraSpoofIntegration] Could not add to player list maps: " + e.getMessage());
      }

   }

   private boolean isConnectionActive(Object entityPlayer) {
      try {
         Object connection = this.getConnection(entityPlayer);
         if (connection != null) {
            Method isConnected = connection.getClass().getMethod("c");
            return (Boolean)isConnected.invoke(connection);
         }
      } catch (Exception var4) {
      }

      return false;
   }

   private boolean isEntityInWorld(Object worldServer, Object entityPlayer) {
      try {
         Field entitiesField = worldServer.getClass().getDeclaredField("z");
         entitiesField.setAccessible(true);
         Object entityList = entitiesField.get(worldServer);
         Method containsMethod = entityList.getClass().getMethod("contains", Object.class);
         return (Boolean)containsMethod.invoke(entityList, entityPlayer);
      } catch (Exception var6) {
         return false;
      }
   }

   private void addEntityToWorld(Object worldServer, Object entityPlayer) {
      try {
         Method addMethod = worldServer.getClass().getMethod("a", entityPlayerClass);
         addMethod.invoke(worldServer, entityPlayer);
      } catch (Exception e) {
         this.debug("[UltraSpoofIntegration] Could not add entity to world: " + e.getMessage());
      }

   }

   private void registerWithChunkMap(Object minecraftServer, Object entityPlayer) {
      try {
         Object chunkMap = this.invokeMethod(minecraftServer, "aM");
         Method registerMethod = chunkMap.getClass().getMethod("a", entityPlayerClass);
         registerMethod.invoke(chunkMap, entityPlayer);
      } catch (Exception e) {
         this.debug("[UltraSpoofIntegration] Could not register with chunk map: " + e.getMessage());
      }

   }

   private void sendPacket(Object connection, Object packet) {
      try {
         Method sendMethod = connection.getClass().getMethod("a", packetClass);
         sendMethod.invoke(connection, packet);
      } catch (Exception e) {
         this.debug("[UltraSpoofIntegration] Could not send packet: " + e.getMessage());
      }

   }

   private void debug(String message) {
      LOGGER.fine(message);
   }

   public void shutdown() {
      if (this.eventExecutors != null) {
         this.eventExecutors.shutdownGracefully();
      }

   }

   static {
      try {
         minecraftServerClass = Class.forName("net.minecraft.server.MinecraftServer");
         dedicatedServerClass = Class.forName("net.minecraft.server.dedicated.DedicatedServer");
         worldServerClass = Class.forName("net.minecraft.server.level.WorldServer");
         entityPlayerClass = Class.forName("net.minecraft.server.level.EntityPlayer");
         playerConnectionClass = Class.forName("net.minecraft.server.network.PlayerConnection");
         serverCommonPacketListenerClass = Class.forName("net.minecraft.server.network.ServerCommonPacketListenerImpl");
         networkManagerClass = Class.forName("net.minecraft.network.Connection");
         playerListClass = Class.forName("net.minecraft.server.players.PlayerList");
         gameProfileClass = Class.forName("com.mojang.authlib.GameProfile");
         clientInformationClass = Class.forName("net.minecraft.server.level.ClientInformation");
         commonListenerCookieClass = Class.forName("net.minecraft.server.network.CommonListenerCookie");
         packetClass = Class.forName("net.minecraft.network.protocol.Packet");
         playerInfoUpdatePacketClass = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket");
         addEntityPacketClass = Class.forName("net.minecraft.network.protocol.game.ClientboundAddEntityPacket");
         namedEntitySpawnPacketClass = Class.forName("net.minecraft.network.protocol.game.PacketPlayOutNamedEntitySpawn");
         loginPacketClass = Class.forName("net.minecraft.network.protocol.game.PacketPlayOutLogin");
         serverDifficultyPacketClass = Class.forName("net.minecraft.network.protocol.game.PacketPlayOutServerDifficulty");
         abilitiesPacketClass = Class.forName("net.minecraft.network.protocol.game.PacketPlayOutAbilities");
         heldItemSlotPacketClass = Class.forName("net.minecraft.network.protocol.game.PacketPlayOutHeldItemSlot");
         recipeUpdatePacketClass = Class.forName("net.minecraft.network.protocol.game.PacketPlayOutRecipeUpdate");
         gameRulesClass = Class.forName("net.minecraft.world.level.GameRules");
         worldDataClass = Class.forName("net.minecraft.world.level.storage.WorldData");
         dimensionManagerClass = Class.forName("net.minecraft.world.level.dimension.DimensionManager");
         craftingManagerClass = Class.forName("net.minecraft.world.item.crafting.CraftingManager");
         serverPingClass = Class.forName("net.minecraft.network.protocol.status.ServerPing");
         userCacheClass = Class.forName("net.minecraft.server.players.UserCache");
         enumChatFormatClass = Class.forName("net.minecraft.EnumChatFormat");
         iChatBaseComponentClass = Class.forName("net.minecraft.network.chat.IChatBaseComponent");
         registryFriendlyByteBufClass = Class.forName("net.minecraft.network.RegistryFriendlyByteBuf");
         gameProtocolsClass = Class.forName("net.minecraft.network.protocol.game.GameProtocols");
         resourceKeyClass = Class.forName("net.minecraft.resources.ResourceKey");
         String[] versions = new String[]{"v1_21_R7", "v1_21_R6", "v1_21_R5", "v1_21_R4", "v1_21_R3", "v1_21_R2", "v1_21_R1", "v1_20_R4", "v1_20_R3", "v1_20_R2", "v1_20_R1"};

         for(String version : versions) {
            try {
               craftServerClass = Class.forName("org.bukkit.craftbukkit." + version + ".CraftServer");
               craftPlayerClass = Class.forName("org.bukkit.craftbukkit." + version + ".entity.CraftPlayer");
               craftWorldClass = Class.forName("org.bukkit.craftbukkit." + version + ".CraftWorld");
               break;
            } catch (ClassNotFoundException var6) {
            }
         }

         LOGGER.info("[UltraSpoofIntegration] NMS classes loaded successfully");
      } catch (ClassNotFoundException e) {
         LOGGER.warning("[UltraSpoofIntegration] Failed to load NMS classes: " + e.getMessage());
      }

   }
}
