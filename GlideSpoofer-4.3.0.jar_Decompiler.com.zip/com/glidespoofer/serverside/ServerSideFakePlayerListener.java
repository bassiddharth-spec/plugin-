package com.glidespoofer.serverside;

import com.glidespoofer.core.GlideSpoofer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class ServerSideFakePlayerListener implements Listener {
   private final GlideSpoofer plugin;
   private final ServerSideFakePlayerManager manager;

   public ServerSideFakePlayerListener(GlideSpoofer plugin, ServerSideFakePlayerManager manager) {
      this.plugin = plugin;
      this.manager = manager;
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onPlayerJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
         if (player.isOnline()) {
            this.manager.showAllToPlayer(player);
         }

      }, 10L);
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onPlayerQuit(PlayerQuitEvent event) {
   }
}
