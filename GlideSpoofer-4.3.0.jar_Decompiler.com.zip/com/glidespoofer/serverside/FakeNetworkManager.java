package com.glidespoofer.serverside;

import com.google.common.collect.Queues;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.nio.NioEventLoopGroup;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FakeNetworkManager {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-FakeNetworkManager");
   private static NioEventLoopGroup eventExecutors;
   private static Class<?> networkManagerClass;
   private static Class<?> packetFlowClass;
   private static Class<?> protocolInfoClass;
   private static Class<?> packetDecoderClass;
   private static Class<?> packetEncoderClass;
   private static Class<?> handshakeProtocolsClass;
   private static Constructor<?> networkManagerConstructor;
   private static Field channelField;
   private static Field addressField;
   private static Field preparingField;
   private static Field connectedField;
   private static Field packetListenerField;
   private static Field receivingField;
   private static Field queueField;
   private Object networkManager;
   private final FakeChannel fakeChannel;
   private final SocketAddress socketAddress;
   private final int port;
   private final String ipAddress;

   private static Field findField(Class<?> clazz, String... names) {
      for(String name : names) {
         try {
            Field field = clazz.getDeclaredField(name);
            field.setAccessible(true);
            return field;
         } catch (NoSuchFieldException var10) {
            Class<?> superClass = clazz.getSuperclass();
            if (superClass != null) {
               try {
                  Field field = superClass.getDeclaredField(name);
                  field.setAccessible(true);
                  return field;
               } catch (NoSuchFieldException var9) {
               }
            }
         }
      }

      return null;
   }

   public FakeNetworkManager() {
      this(ThreadLocalRandom.current().nextInt(40000, 60000), "127.0.0.1");
   }

   public FakeNetworkManager(int port, String ipAddress) {
      this.port = port;
      this.ipAddress = ipAddress;
      this.socketAddress = new InetSocketAddress(ipAddress, port);
      this.fakeChannel = this.createFakeChannel();
      if (networkManagerConstructor != null) {
         try {
            Object serverbound = null;

            for(Object constant : packetFlowClass.getEnumConstants()) {
               if (constant.toString().equals("SERVERBOUND")) {
                  serverbound = constant;
                  break;
               }
            }

            if (serverbound != null) {
               this.networkManager = networkManagerConstructor.newInstance(serverbound);
               if (channelField != null) {
                  channelField.set(this.networkManager, this.fakeChannel);
               }

               if (addressField != null) {
                  addressField.set(this.networkManager, this.socketAddress);
               }

               if (preparingField != null) {
                  preparingField.setBoolean(this.networkManager, false);
               }

               if (connectedField != null) {
                  connectedField.setBoolean(this.networkManager, true);
               }

               if (queueField != null) {
                  queueField.set(this.networkManager, Queues.newConcurrentLinkedQueue());
               }

               if (eventExecutors != null && this.fakeChannel != null) {
                  eventExecutors.register(this.fakeChannel);
               }

               LOGGER.fine("[FakeNetworkManager] Created network manager for " + ipAddress + ":" + port);
            }
         } catch (Exception e) {
            LOGGER.log(Level.WARNING, "[FakeNetworkManager] Failed to create network manager", e);
         }
      }

   }

   private FakeChannel createFakeChannel() {
      try {
         FakeChannel channel = new FakeChannel(this.socketAddress);
         this.setupChannelPipeline(channel);
         return channel;
      } catch (Exception e) {
         LOGGER.warning("[FakeNetworkManager] Failed to create fake channel: " + e.getMessage());
         return new FakeChannel();
      }
   }

   private void setupChannelPipeline(FakeChannel channel) {
      try {
         ChannelPipeline pipeline = channel.pipeline();
         if (this.networkManager != null) {
            pipeline.addLast("packet_handler", (ChannelHandler)this.networkManager);
         }

         if (handshakeProtocolsClass != null && packetDecoderClass != null && packetEncoderClass != null) {
            try {
               Field serverboundField = handshakeProtocolsClass.getDeclaredField("SERVERBOUND");
               if (serverboundField != null) {
                  Object serverbound = serverboundField.get((Object)null);
                  Constructor<?> decoderConstructor = packetDecoderClass.getConstructor(protocolInfoClass);
                  Constructor<?> encoderConstructor = packetEncoderClass.getConstructor(protocolInfoClass);
                  Object decoder = decoderConstructor.newInstance(serverbound);
                  Object encoder = encoderConstructor.newInstance(serverbound);
                  pipeline.addLast("decoder", (ChannelHandler)decoder);
                  pipeline.addLast("encoder", (ChannelHandler)encoder);
               }
            } catch (Exception e) {
               LOGGER.fine("[FakeNetworkManager] Could not add decoder/encoder: " + e.getMessage());
            }
         }
      } catch (Exception e) {
         LOGGER.warning("[FakeNetworkManager] Failed to setup pipeline: " + e.getMessage());
      }

   }

   public void initialize() {
      try {
         if (receivingField != null) {
            receivingField.setBoolean(this.networkManager, true);
         }

         if (this.fakeChannel != null && this.fakeChannel.isOpen()) {
            this.fakeChannel.close();
         }
      } catch (Exception e) {
         LOGGER.warning("[FakeNetworkManager] Failed to initialize: " + e.getMessage());
      }

   }

   public void setPacketListener(Object packetListener) {
      try {
         if (packetListenerField != null) {
            packetListenerField.set(this.networkManager, packetListener);
         }

         if (receivingField != null) {
            receivingField.set(this.networkManager, (Object)null);
         }
      } catch (Exception e) {
         LOGGER.warning("[FakeNetworkManager] Failed to set packet listener: " + e.getMessage());
      }

   }

   public Object getNetworkManager() {
      return this.networkManager;
   }

   public FakeChannel getFakeChannel() {
      return this.fakeChannel;
   }

   public SocketAddress getSocketAddress() {
      return this.socketAddress;
   }

   public int getPort() {
      return this.port;
   }

   public String getIpAddress() {
      return this.ipAddress;
   }

   public boolean isValid() {
      return this.networkManager != null;
   }

   public void stopReading() {
   }

   public void sendPacket(Object packet) {
   }

   public Channel getChannel() {
      return this.fakeChannel;
   }

   static {
      try {
         eventExecutors = new NioEventLoopGroup(5);
         networkManagerClass = Class.forName("net.minecraft.network.Connection");
         packetFlowClass = Class.forName("net.minecraft.network.protocol.PacketFlow");
         protocolInfoClass = Class.forName("net.minecraft.network.ProtocolInfo");
         packetDecoderClass = Class.forName("net.minecraft.network.PacketDecoder");
         packetEncoderClass = Class.forName("net.minecraft.network.PacketEncoder");
         handshakeProtocolsClass = Class.forName("net.minecraft.network.protocol.handshake.HandshakeProtocols");
         Object serverbound = null;

         for(Object constant : packetFlowClass.getEnumConstants()) {
            if (constant.toString().equals("SERVERBOUND")) {
               serverbound = constant;
               break;
            }
         }

         if (serverbound != null) {
            networkManagerConstructor = networkManagerClass.getConstructor(packetFlowClass);
            networkManagerConstructor.setAccessible(true);
         }

         channelField = findField(networkManagerClass, "channel", "m", "k");
         addressField = findField(networkManagerClass, "address", "n", "l");
         preparingField = findField(networkManagerClass, "preparing");
         connectedField = findField(networkManagerClass, "connected");
         packetListenerField = findField(networkManagerClass, "packetListener", "n", "m", "listener");
         receivingField = findField(networkManagerClass, "receiving", "q", "p");
         queueField = findField(networkManagerClass, "queue", "j");
         if (channelField != null) {
            channelField.setAccessible(true);
         }

         if (addressField != null) {
            addressField.setAccessible(true);
         }

         if (preparingField != null) {
            preparingField.setAccessible(true);
         }

         if (connectedField != null) {
            connectedField.setAccessible(true);
         }

         if (packetListenerField != null) {
            packetListenerField.setAccessible(true);
         }

         if (receivingField != null) {
            receivingField.setAccessible(true);
         }

         if (queueField != null) {
            queueField.setAccessible(true);
         }

         LOGGER.info("[FakeNetworkManager] Initialized reflection successfully");
      } catch (Exception e) {
         LOGGER.log(Level.WARNING, "[FakeNetworkManager] Failed to initialize reflection", e);
      }

   }
}
