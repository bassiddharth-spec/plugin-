package com.glidespoofer.serverside;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.hooks.ForcePackHook;
import com.glidespoofer.hooks.LoginEventManager;
import com.glidespoofer.hooks.LuckPermsHook;
import com.glidespoofer.hooks.TABHook;
import com.glidespoofer.hooks.ViaVersionHook;
import com.glidespoofer.hooks.VoiceChatHook;
import com.mojang.authlib.GameProfile;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class ServerSideFakePlayerManager {
   private final GlideSpoofer plugin;
   private final Map<String, ServerSideFakePlayer> fakePlayersByName;
   private final Map<UUID, ServerSideFakePlayer> fakePlayersByUUID;
   private List<Object> serverPlayerList;
   private Map<UUID, Object> serverPlayersByUUID;
   private Map<String, Object> serverPlayersByName;
   private Object dedicatedPlayerList;
   private PaperRealisticSpawner paperRealisticSpawner;
   private static Class<?> craftServerClass;
   private static Class<?> craftWorldClass;
   private static Class<?> craftPlayerClass;
   private static Class<?> dedicatedPlayerListClass;
   private static Class<?> playerListClass;
   private static Class<?> entityPlayerClass;
   private static Class<?> minecraftServerClass;
   private static Class<?> worldServerClass;
   private static Class<?> gameProfileClass;
   private static Class<?> playerInfoRemovePacketClass;
   private static Class<?> playerInfoUpdatePacketClass;
   private static Class<?> propertyClass;
   private static Class<?> connectionClass;
   private LoginEventManager loginEventManager;
   private VoiceChatHook voiceChatHook;
   private ForcePackHook forcePackHook;
   private ViaVersionHook viaVersionHook;
   private UltraSpoofIntegration ultraSpoofIntegration;

   public ServerSideFakePlayerManager(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.fakePlayersByName = new HashMap();
      this.fakePlayersByUUID = new HashMap();
      this.initializeReflection();
      this.initializeHooks();

      try {
         this.paperRealisticSpawner = new PaperRealisticSpawner(plugin);
         if (this.paperRealisticSpawner.isAvailable()) {
            plugin.getLogger().info("[ServerSideFakePlayer] PaperRealisticSpawner initialized - will use placeNewPlayer for realistic connections!");
         } else {
            plugin.getLogger().info("[ServerSideFakePlayer] PaperRealisticSpawner not available - using manual injection");
            this.paperRealisticSpawner = null;
         }
      } catch (Exception e) {
         plugin.getLogger().warning("[ServerSideFakePlayer] PaperRealisticSpawner failed: " + e.getMessage());
         this.paperRealisticSpawner = null;
      }

   }

   private void initializeReflection() {
      try {
         Object craftServer = craftServerClass.cast(Bukkit.getServer());
         Method getServerMethod = craftServerClass.getMethod("getServer");
         Object minecraftServer = getServerMethod.invoke(craftServer);
         this.dedicatedPlayerList = null;
         String[] getPlayerListMethodNames = new String[]{"bg", "bf", "be", "bd", "bc", "getPlayerList", "ah", "ag", "af"};

         for(String methodName : getPlayerListMethodNames) {
            try {
               Method getPlayerListMethod = minecraftServer.getClass().getMethod(methodName);
               Object result = getPlayerListMethod.invoke(minecraftServer);
               if (result != null && playerListClass.isInstance(result)) {
                  this.dedicatedPlayerList = result;
                  this.plugin.getLogger().info("[ServerSideFakePlayer] Found player list method: " + methodName);
                  break;
               }
            } catch (NoSuchMethodException var15) {
            }
         }

         if (this.dedicatedPlayerList == null) {
            for(Class<?> clazz = minecraftServer.getClass(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
               for(Field f : clazz.getDeclaredFields()) {
                  if (playerListClass.isAssignableFrom(f.getType())) {
                     f.setAccessible(true);
                     this.dedicatedPlayerList = f.get(minecraftServer);
                     if (this.dedicatedPlayerList != null) {
                        this.plugin.getLogger().info("[ServerSideFakePlayer] Found player list field: " + f.getName());
                        break;
                     }
                  }
               }

               if (this.dedicatedPlayerList != null) {
                  break;
               }
            }
         }

         if (this.dedicatedPlayerList != null) {
            for(Class<?> clazz = this.dedicatedPlayerList.getClass(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
               for(Field f : clazz.getDeclaredFields()) {
                  if (List.class.isAssignableFrom(f.getType())) {
                     try {
                        f.setAccessible(true);
                        Object value = f.get(this.dedicatedPlayerList);
                        if (value instanceof List) {
                           this.serverPlayerList = (List)value;
                           this.plugin.getLogger().info("[ServerSideFakePlayer] Found player list field: " + f.getName());
                           break;
                        }
                     } catch (Exception var14) {
                     }
                  }
               }

               if (this.serverPlayerList != null) {
                  break;
               }
            }
         }

         if (this.serverPlayerList == null) {
            try {
               Field fieldK = playerListClass.getDeclaredField("k");
               fieldK.setAccessible(true);
               this.serverPlayerList = (List)fieldK.get(this.dedicatedPlayerList);
               this.plugin.getLogger().info("[ServerSideFakePlayer] Using direct field 'k' for player list");
            } catch (Exception var12) {
            }
         }

         if (this.dedicatedPlayerList != null && this.serverPlayersByUUID == null) {
            for(Class<?> clazz = this.dedicatedPlayerList.getClass(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
               for(Field f : clazz.getDeclaredFields()) {
                  if (Map.class.isAssignableFrom(f.getType())) {
                     try {
                        f.setAccessible(true);
                        Object value = f.get(this.dedicatedPlayerList);
                        if (value instanceof Map) {
                           Map<?, ?> map = (Map)value;
                           if (!map.isEmpty() || f.getName().contains("uuid") || f.getName().contains("byName") || f.getName().length() <= 2) {
                              if (this.serverPlayersByUUID == null) {
                                 this.serverPlayersByUUID = (Map)value;
                                 this.plugin.getLogger().info("[ServerSideFakePlayer] Found playersByUUID field: " + f.getName());
                              } else if (this.serverPlayersByName == null) {
                                 this.serverPlayersByName = (Map)value;
                                 this.plugin.getLogger().info("[ServerSideFakePlayer] Found playersByName field: " + f.getName());
                              }
                           }
                        }
                     } catch (Exception var13) {
                     }
                  }
               }

               if (this.serverPlayersByUUID != null && this.serverPlayersByName != null) {
                  break;
               }
            }
         }

         this.plugin.getLogger().info("[ServerSideFakePlayer] Reflection initialized successfully");
         Logger var10000 = this.plugin.getLogger();
         boolean var10001 = this.serverPlayerList != null;
         var10000.info("[ServerSideFakePlayer] Player list ready: " + var10001);
         var10000 = this.plugin.getLogger();
         var10001 = this.serverPlayersByUUID != null;
         var10000.info("[ServerSideFakePlayer] UUID map ready: " + var10001);
         this.plugin.getLogger().info("[ServerSideFakePlayer] Name map ready: " + (this.serverPlayersByName != null));
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Failed to initialize reflection: " + e.getMessage());
         e.printStackTrace();
      }

   }

   private void initializeHooks() {
      try {
         this.loginEventManager = new LoginEventManager(this.plugin);
         this.plugin.getLogger().info("[ServerSideFakePlayer] LoginEventManager initialized");
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Failed to initialize LoginEventManager: " + e.getMessage());
      }

      try {
         this.voiceChatHook = new VoiceChatHook(this.plugin);
         this.plugin.getLogger().info("[ServerSideFakePlayer] VoiceChatHook initialized");
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Failed to initialize VoiceChatHook: " + e.getMessage());
      }

      try {
         this.forcePackHook = new ForcePackHook(this.plugin);
         this.plugin.getLogger().info("[ServerSideFakePlayer] ForcePackHook initialized");
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Failed to initialize ForcePackHook: " + e.getMessage());
      }

      try {
         this.viaVersionHook = new ViaVersionHook(this.plugin);
         this.plugin.getLogger().info("[ServerSideFakePlayer] ViaVersionHook initialized");
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Failed to initialize ViaVersionHook: " + e.getMessage());
      }

   }

   public ServerSideFakePlayer addFakePlayer(String name) {
      return this.addFakePlayer(name, (UUID)null, (String)null, (Map)null);
   }

   public ServerSideFakePlayer addFakePlayer(String name, UUID skinUUID, String rank) {
      return this.addFakePlayer(name, skinUUID, rank, (Map)null);
   }

   public ServerSideFakePlayer addFakePlayer(String name, UUID skinUUID, String rank, Map<String, String> tracks) {
      if (name != null && !name.isEmpty()) {
         if (name.length() > 16) {
            name = name.substring(0, 16);
         }

         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: addFakePlayer called for '" + name + "' with rank '" + rank + "'");
         if (this.fakePlayersByName.containsKey(name.toLowerCase())) {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] Player " + name + " already exists");
            return (ServerSideFakePlayer)this.fakePlayersByName.get(name.toLowerCase());
         } else {
            if (this.paperRealisticSpawner != null && this.paperRealisticSpawner.isAvailable()) {
               try {
                  this.plugin.getLogger().info("[ServerSideFakePlayer] Using PaperRealisticSpawner (placeNewPlayer) for " + name);
                  PaperRealisticSpawner.PlayerSpawnResult result = this.paperRealisticSpawner.spawnPlayer(name, skinUUID, rank);
                  if (result != null && result.craftPlayer != null) {
                     ServerSideFakePlayer fakePlayer = new ServerSideFakePlayer(this.plugin, name, rank, result.serverPlayer, result.craftPlayer, result.connection);
                     this.fakePlayersByName.put(name.toLowerCase(), fakePlayer);
                     this.fakePlayersByUUID.put(fakePlayer.getUUID(), fakePlayer);
                     String cachedPrefix = this.preCacheLuckPermsData(fakePlayer, tracks);
                     this.registerWithHooks(fakePlayer);
                     this.injectIntoTAB(fakePlayer, cachedPrefix);
                     this.plugin.getLogger().info("[ServerSideFakePlayer] PaperRealisticSpawner SUCCESS for " + name + " (ip=" + result.ipAddress + ", ping=" + result.ping + ")");
                     return fakePlayer;
                  }

                  this.plugin.getLogger().warning("[ServerSideFakePlayer] PaperRealisticSpawner returned null, falling back to manual injection");
               } catch (Exception e) {
                  this.plugin.getLogger().warning("[ServerSideFakePlayer] PaperRealisticSpawner failed: " + e.getMessage() + ", falling back to manual injection");
                  e.printStackTrace();
               }
            }

            this.plugin.getLogger().info("[ServerSideFakePlayer] Using manual injection for " + name);
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Creating ServerSideFakePlayer instance...");
            ServerSideFakePlayer fakePlayer = new ServerSideFakePlayer(this.plugin, name, skinUUID, rank);
            if (fakePlayer.getEntityPlayer() == null) {
               this.plugin.getLogger().severe("[ServerSideFakePlayer] DEBUG: EntityPlayer is NULL after creation!");
               return null;
            } else {
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: EntityPlayer created successfully");
               Player craftPlayer = fakePlayer.getCraftPlayer();
               if (craftPlayer == null) {
                  this.plugin.getLogger().severe("[ServerSideFakePlayer] DEBUG: CraftPlayer is NULL after creation!");
               } else {
                  Logger var10000 = this.plugin.getLogger();
                  String var10001 = craftPlayer.getName();
                  var10000.info("[ServerSideFakePlayer] DEBUG: CraftPlayer created: " + var10001 + " at " + String.valueOf(craftPlayer.getLocation()));
               }

               this.fakePlayersByName.put(name.toLowerCase(), fakePlayer);
               this.fakePlayersByUUID.put(fakePlayer.getUUID(), fakePlayer);
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Added to tracking maps. Total: " + this.fakePlayersByName.size());
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Pre-caching LuckPerms data...");
               String cachedPrefix = this.preCacheLuckPermsData(fakePlayer, tracks);
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: LuckPerms prefix: '" + cachedPrefix + "'");
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Firing AsyncPlayerPreLoginEvent...");
               boolean preLoginAllowed = this.fireAsyncPreLoginEvent(fakePlayer);
               if (!preLoginAllowed) {
                  this.plugin.getLogger().warning("[ServerSideFakePlayer] Pre-login denied for " + name);
                  this.fakePlayersByName.remove(name.toLowerCase());
                  this.fakePlayersByUUID.remove(fakePlayer.getUUID());
                  return null;
               } else {
                  this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Pre-login allowed");
                  this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Injecting into server list...");
                  this.injectIntoServerList(fakePlayer);
                  this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Server list injection complete");
                  this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Firing login event chain...");
                  this.fireLoginEventChain(fakePlayer);
                  this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Registering with hooks...");
                  this.registerWithHooks(fakePlayer);
                  this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Injecting into TAB...");
                  this.injectIntoTAB(fakePlayer, cachedPrefix);
                  this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: addFakePlayer complete for " + name);
                  return fakePlayer;
               }
            }
         }
      } else {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: addFakePlayer called with null/empty name");
         return null;
      }
   }

   private String preCacheLuckPermsData(ServerSideFakePlayer fakePlayer, Map<String, String> tracks) {
      LuckPermsHook luckPermsHook = this.plugin.getLuckPermsHook();
      if (luckPermsHook != null && luckPermsHook.isEnabled()) {
         UUID uuid = fakePlayer.getUUID();
         String name = fakePlayer.getName();
         String rank = fakePlayer.getRank();

         try {
            String prefix;
            if (tracks != null && !tracks.isEmpty()) {
               prefix = luckPermsHook.setupFakePlayerSync(uuid, name, tracks);
               this.plugin.getLogger().info("[ServerSideFakePlayer] Pre-cached LuckPerms data with tracks for " + name + ": " + String.valueOf(tracks));
            } else if (rank != null && !rank.isEmpty() && !rank.equals("default")) {
               prefix = (String)luckPermsHook.setupFakePlayer(uuid, name, rank).join();
               this.plugin.getLogger().info("[ServerSideFakePlayer] Pre-cached LuckPerms data with rank '" + rank + "' for " + name);
            } else {
               prefix = luckPermsHook.setupFakePlayerWithDefaultGroup(uuid, name);
               this.plugin.getLogger().info("[ServerSideFakePlayer] Pre-cached LuckPerms data with default group for " + name);
            }

            if (prefix != null && !prefix.isEmpty()) {
               this.plugin.getLogger().info("[ServerSideFakePlayer] Got prefix for " + name + ": " + prefix);
               return prefix;
            }
         } catch (Exception e) {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] Failed to pre-cache LuckPerms data for " + name + ": " + e.getMessage());
         }

         return "";
      } else {
         this.plugin.getLogger().fine("[ServerSideFakePlayer] LuckPerms not available, skipping prefix caching");
         return "";
      }
   }

   private void injectIntoTAB(ServerSideFakePlayer fakePlayer, String prefix) {
      TABHook tabHook = this.plugin.getTabHook();
      Player player = fakePlayer.getCraftPlayer();
      this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: injectIntoTAB called for " + fakePlayer.getName());
      Logger var10000 = this.plugin.getLogger();
      String var10001 = player != null ? player.getName() : "NULL";
      var10000.info("[ServerSideFakePlayer] DEBUG: CraftPlayer: " + var10001);
      var10000 = this.plugin.getLogger();
      var10001 = tabHook != null ? (tabHook.isEnabled() ? "ENABLED" : "DISABLED") : "NULL";
      var10000.info("[ServerSideFakePlayer] DEBUG: TABHook: " + var10001);
      this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Prefix: '" + prefix + "'");
      if (player == null) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Cannot inject into TAB - CraftPlayer is null for " + fakePlayer.getName());
      } else {
         if (tabHook != null && tabHook.isEnabled()) {
            try {
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Calling tabHook.injectFakePlayerTAB...");
               tabHook.injectFakePlayerTAB(player, fakePlayer.getUUID(), fakePlayer.getName());
               this.plugin.getLogger().info("[ServerSideFakePlayer] Injected " + fakePlayer.getName() + " into TAB");
               if (prefix != null && !prefix.isEmpty()) {
                  this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Updating player prefix in TAB...");
                  tabHook.updatePlayerPrefix(fakePlayer.getUUID(), fakePlayer.getName(), prefix);
               }
            } catch (Exception e) {
               this.plugin.getLogger().warning("[ServerSideFakePlayer] Failed to inject into TAB: " + e.getMessage());
               e.printStackTrace();
            }
         } else {
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: TAB not available, setting manual tab name...");
            if (prefix != null && !prefix.isEmpty()) {
               try {
                  String tabName = prefix + String.valueOf(ChatColor.RESET) + fakePlayer.getName();
                  player.setPlayerListName(tabName);
                  var10000 = this.plugin.getLogger();
                  var10001 = fakePlayer.getName();
                  var10000.info("[ServerSideFakePlayer] Set manual tab name for " + var10001 + ": " + tabName);
               } catch (Exception e) {
                  this.plugin.getLogger().warning("[ServerSideFakePlayer] Failed to set player list name: " + e.getMessage());
               }
            } else {
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: No prefix to set for " + fakePlayer.getName());
            }
         }

      }
   }

   private boolean fireAsyncPreLoginEvent(ServerSideFakePlayer fakePlayer) {
      if (this.loginEventManager == null) {
         return true;
      } else {
         try {
            InetAddress address = InetAddress.getLoopbackAddress();
            return this.loginEventManager.isPreLoginAllowed(fakePlayer.getName(), address, fakePlayer.getUUID());
         } catch (Exception e) {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] Error in pre-login check: " + e.getMessage());
            return true;
         }
      }
   }

   private void fireLoginEventChain(final ServerSideFakePlayer fakePlayer) {
      (new BukkitRunnable() {
         public void run() {
            try {
               ServerSideFakePlayerManager.this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: fireLoginEventChain starting for " + fakePlayer.getName());
               Player craftPlayer = fakePlayer.getCraftPlayer();
               if (craftPlayer == null) {
                  ServerSideFakePlayerManager.this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: CraftPlayer is NULL in fireLoginEventChain!");
                  return;
               }

               Logger var10000 = ServerSideFakePlayerManager.this.plugin.getLogger();
               String var10001 = craftPlayer.getName();
               var10000.info("[ServerSideFakePlayer] DEBUG: CraftPlayer OK: " + var10001 + " at " + String.valueOf(craftPlayer.getLocation()));
               if (ServerSideFakePlayerManager.this.loginEventManager != null) {
                  ServerSideFakePlayerManager.this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Firing login events via LoginEventManager...");
                  InetAddress address = InetAddress.getLoopbackAddress();
                  ServerSideFakePlayerManager.this.loginEventManager.fireLoginEventChain(craftPlayer, fakePlayer.getUUID(), fakePlayer.getName(), address);
               } else {
                  ServerSideFakePlayerManager.this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: LoginEventManager is null, using legacy join event...");
                  ServerSideFakePlayerManager.this.fireJoinEventLegacy(fakePlayer);
               }

               ServerSideFakePlayerManager.this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Enabling entity tracking...");
               ServerSideFakePlayerManager.this.enableEntityTracking(fakePlayer);
               ServerSideFakePlayerManager.this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Login event chain completed for " + fakePlayer.getName());
            } catch (Exception e) {
               ServerSideFakePlayerManager.this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Error firing login events: " + e.getMessage());
               e.printStackTrace();
            }

         }
      }).runTaskLater(this.plugin, 1L);
   }

   private void enableEntityTracking(ServerSideFakePlayer fakePlayer) {
      this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: enableEntityTracking called for " + fakePlayer.getName());

      try {
         Object entityPlayer = fakePlayer.getEntityPlayer();
         if (entityPlayer == null) {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: entityPlayer is NULL in enableEntityTracking!");
            return;
         }

         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: entityPlayer class: " + entityPlayer.getClass().getName());
         Field sentListPacketField = this.findField(entityPlayer.getClass(), "sentListPacket");
         if (sentListPacketField != null) {
            sentListPacketField.setAccessible(true);
            boolean oldValue = sentListPacketField.getBoolean(entityPlayer);
            sentListPacketField.setBoolean(entityPlayer, true);
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Set sentListPacket = true (was: " + oldValue + ") for " + fakePlayer.getName());
         } else {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: sentListPacket field NOT FOUND");
         }

         Field suppressTrackerField = this.findField(entityPlayer.getClass(), "suppressTrackerForLogin");
         if (suppressTrackerField != null) {
            suppressTrackerField.setAccessible(true);
            boolean oldValue = suppressTrackerField.getBoolean(entityPlayer);
            suppressTrackerField.setBoolean(entityPlayer, false);
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Set suppressTrackerForLogin = false (was: " + oldValue + ") for " + fakePlayer.getName());
         } else {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: suppressTrackerForLogin field NOT FOUND");
         }

         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Registering with chunk tracker...");
         this.registerWithChunkTracker(entityPlayer);
         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Setting joining = false...");
         this.setJoiningField(entityPlayer, false);
         this.setPlayerVisible(entityPlayer);
         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Spawning player entity for all online players...");
         this.spawnPlayerEntityForAll(fakePlayer);
         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Enabled entity tracking for " + fakePlayer.getName());
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Could not enable entity tracking: " + e.getMessage());
         e.printStackTrace();
      }

   }

   private void setPlayerVisible(Object entityPlayer) {
      try {
         Method setInvisibleMethod = entityPlayer.getClass().getMethod("setInvisible", Boolean.TYPE);
         setInvisibleMethod.invoke(entityPlayer, false);
         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Set player visible");
      } catch (Exception e) {
         this.plugin.getLogger().fine("[ServerSideFakePlayer] DEBUG: Could not set visible via setInvisible: " + e.getMessage());

         try {
            Field sharedFlagsField = this.findField(entityPlayer.getClass(), "sharedFlags", "ag", "ah", "ai");
            if (sharedFlagsField != null) {
               sharedFlagsField.setAccessible(true);
               byte flags = sharedFlagsField.getByte(entityPlayer);
               flags = (byte)(flags & -33);
               sharedFlagsField.setByte(entityPlayer, flags);
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Cleared invisible bit in shared flags");
            }
         } catch (Exception ex) {
            this.plugin.getLogger().fine("[ServerSideFakePlayer] DEBUG: Could not clear invisible bit: " + ex.getMessage());
         }
      }

   }

   private void spawnPlayerEntityForAll(ServerSideFakePlayer fakePlayer) {
      try {
         Object entityPlayer = fakePlayer.getEntityPlayer();
         if (entityPlayer == null) {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: entityPlayer is NULL in spawnPlayerEntityForAll!");
            return;
         }

         Class<?> addEntityPacketClass = Class.forName("net.minecraft.network.protocol.game.ClientboundAddEntityPacket");
         Class<?> addPlayerPacketClass = Class.forName("net.minecraft.network.protocol.game.ClientboundAddPlayerPacket");
         Object spawnPacket = null;

         try {
            Constructor<?> constructor = addPlayerPacketClass.getConstructor(entityPlayerClass);
            spawnPacket = constructor.newInstance(entityPlayer);
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Created ClientboundAddPlayerPacket");
         } catch (Exception e) {
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: ClientboundAddPlayerPacket failed, trying ClientboundAddEntityPacket: " + e.getMessage());

            try {
               Constructor<?> constructor = addEntityPacketClass.getConstructor(entityPlayerClass);
               spawnPacket = constructor.newInstance(entityPlayer);
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Created ClientboundAddEntityPacket");
            } catch (Exception ex) {
               this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Could not create spawn packet: " + ex.getMessage());
            }
         }

         if (spawnPacket == null) {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: spawnPacket is null, cannot spawn entity for players");
            return;
         }

         int count = 0;

         for(Player player : Bukkit.getOnlinePlayers()) {
            Object craftPlayer = craftPlayerClass.cast(player);
            Method getHandleMethod = craftPlayerClass.getMethod("getHandle");
            Object nmsPlayer = getHandleMethod.invoke(craftPlayer);
            Object connection = this.getConnectionFromPlayer(nmsPlayer);
            if (connection != null) {
               Method sendMethod = this.findSendMethod(connection.getClass());
               if (sendMethod != null) {
                  sendMethod.invoke(connection, spawnPacket);
                  ++count;
               }
            }
         }

         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Spawned player entity for " + count + " online players");
      } catch (ClassNotFoundException e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Packet class not found: " + e.getMessage());
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Error spawning player entity: " + e.getMessage());
         e.printStackTrace();
      }

   }

   private void registerWithChunkTracker(Object entityPlayer) {
      this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: registerWithChunkTracker called");

      try {
         Method getLevelMethod = entityPlayer.getClass().getMethod("level");
         Object serverLevel = getLevelMethod.invoke(entityPlayer);
         if (serverLevel == null) {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Server level is null!");
            return;
         }

         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Got server level: " + serverLevel.getClass().getName());
         Method getChunkSourceMethod = this.findMethod(serverLevel.getClass(), "getChunkSource");
         if (getChunkSourceMethod == null) {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Could not find getChunkSource method");
            return;
         }

         Object chunkSource = getChunkSourceMethod.invoke(serverLevel);
         if (chunkSource == null) {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: ChunkSource is null");
            return;
         }

         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Got chunk source: " + chunkSource.getClass().getName());
         Field chunkMapField = this.findField(chunkSource.getClass(), "chunkMap", "a", "field_217237_a", "C");
         if (chunkMapField == null) {
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Trying getChunkMap method...");
            Method getChunkMapMethod = this.findMethod(chunkSource.getClass(), "getChunkMap");
            if (getChunkMapMethod != null) {
               Object chunkMap = getChunkMapMethod.invoke(chunkSource);
               if (chunkMap != null) {
                  this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Got chunk map via method: " + chunkMap.getClass().getName());
                  this.invokeAddEntity(chunkMap, entityPlayer);
               } else {
                  this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: ChunkMap from method is null");
               }
            } else {
               this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Could not find chunkMap field or method");
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Available fields in " + chunkSource.getClass().getName() + ":");

               for(Field f : chunkSource.getClass().getDeclaredFields()) {
                  Logger var10000 = this.plugin.getLogger();
                  String var10001 = f.getName();
                  var10000.info("[ServerSideFakePlayer] DEBUG:   - " + var10001 + " : " + f.getType().getName());
               }
            }

            return;
         }

         chunkMapField.setAccessible(true);
         Object chunkMap = chunkMapField.get(chunkSource);
         if (chunkMap == null) {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: ChunkMap is null");
            return;
         }

         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Got chunk map: " + chunkMap.getClass().getName());
         this.invokeAddEntity(chunkMap, entityPlayer);
         this.registerWithMoonriseEntityLookup(serverLevel, entityPlayer);
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Failed to register with chunk tracker: " + e.getMessage());
         e.printStackTrace();
      }

   }

   private void invokeAddEntity(Object chunkMap, Object entityPlayer) {
      this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: invokeAddEntity called");
      String[] addEntityMethodNames = new String[]{"addEntity", "a", "addEntityTracker", "trackEntity"};

      for(String methodName : addEntityMethodNames) {
         try {
            Method addEntityMethod = this.findMethod(chunkMap.getClass(), methodName, entityPlayer.getClass());
            if (addEntityMethod != null) {
               addEntityMethod.invoke(chunkMap, entityPlayer);
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Registered with chunk tracker via " + methodName + "(EntityPlayer)");
               return;
            }

            Class<?> entityClass = null;

            for(Class<?> current = entityPlayer.getClass(); current != null; current = current.getSuperclass()) {
               if (current.getSimpleName().equals("Entity")) {
                  entityClass = current;
                  break;
               }
            }

            if (entityClass != null) {
               addEntityMethod = this.findMethod(chunkMap.getClass(), methodName, entityClass);
               if (addEntityMethod != null) {
                  addEntityMethod.invoke(chunkMap, entityPlayer);
                  this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Registered with chunk tracker via " + methodName + " (Entity param)");
                  return;
               }
            }
         } catch (Exception e) {
            this.plugin.getLogger().fine("[ServerSideFakePlayer] DEBUG: Method " + methodName + " failed: " + e.getMessage());
         }
      }

      this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Could not find any addEntity method on chunk map");
      this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Available methods in " + chunkMap.getClass().getName() + ":");

      for(Method m : chunkMap.getClass().getMethods()) {
         if (m.getName().toLowerCase().contains("add") || m.getName().toLowerCase().contains("track") || m.getName().toLowerCase().contains("entity")) {
            Logger var10000 = this.plugin.getLogger();
            String var10001 = m.getName();
            var10000.info("[ServerSideFakePlayer] DEBUG:   - " + var10001 + "(" + Arrays.toString(m.getParameterTypes()) + ")");
         }
      }

   }

   private void registerWithMoonriseEntityLookup(Object serverLevel, Object entityPlayer) {
      try {
         Class<?> entityLookupClass = Class.forName("ca.spottedleaf.moonrise.patches.chunk_system.level.entity.EntityLookup");
         Field entityLookupField = this.findField(serverLevel.getClass(), "entityLookup", "moonrise$entityLookup");
         if (entityLookupField != null) {
            entityLookupField.setAccessible(true);
            Object entityLookup = entityLookupField.get(serverLevel);
            if (entityLookup != null) {
               Method addEntityMethod = this.findMethod(entityLookupClass, "addEntity", entityPlayer.getClass());
               if (addEntityMethod != null) {
                  addEntityMethod.setAccessible(true);
                  addEntityMethod.invoke(entityLookup, entityPlayer);
                  this.plugin.getLogger().fine("[ServerSideFakePlayer] Registered with Moonrise entity lookup");
               }
            }
         }
      } catch (ClassNotFoundException var7) {
      } catch (Exception e) {
         this.plugin.getLogger().fine("[ServerSideFakePlayer] Moonrise registration skipped: " + e.getMessage());
      }

   }

   private Field findField(Class<?> clazz, String... possibleNames) {
      for(String name : possibleNames) {
         for(Class<?> current = clazz; current != null; current = current.getSuperclass()) {
            try {
               Field field = current.getDeclaredField(name);
               field.setAccessible(true);
               return field;
            }
         }
      }

      return null;
   }

   private Method findMethod(Class<?> clazz, String name, Class<?>... paramTypes) {
      for(Class<?> current = clazz; current != null; current = current.getSuperclass()) {
         try {
            Method method = current.getDeclaredMethod(name, paramTypes);
            method.setAccessible(true);
            return method;
         } catch (NoSuchMethodException var8) {
            try {
               Method method = current.getMethod(name, paramTypes);
               method.setAccessible(true);
               return method;
            }
         }
      }

      return null;
   }

   private Method findMethodByName(Class<?> clazz, String name) {
      for(Class<?> current = clazz; current != null; current = current.getSuperclass()) {
         for(Method method : current.getDeclaredMethods()) {
            if (method.getName().equals(name)) {
               method.setAccessible(true);
               return method;
            }
         }
      }

      return null;
   }

   private void fireJoinEventLegacy(ServerSideFakePlayer fakePlayer) {
      try {
         Player fakeCraftPlayer = fakePlayer.getCraftPlayer();
         if (fakeCraftPlayer == null) {
            return;
         }

         String var10003 = String.valueOf(ChatColor.YELLOW);
         PlayerJoinEvent joinEvent = new PlayerJoinEvent(fakeCraftPlayer, var10003 + fakePlayer.getName() + " joined the game");
         Bukkit.getPluginManager().callEvent(joinEvent);
         String joinMessage = joinEvent.getJoinMessage();
         if (joinMessage != null && !joinMessage.isEmpty()) {
            Bukkit.broadcastMessage(joinMessage);
         }
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Error firing legacy join event: " + e.getMessage());
      }

   }

   private void registerWithHooks(final ServerSideFakePlayer fakePlayer) {
      (new BukkitRunnable() {
         public void run() {
            try {
               Player craftPlayer = fakePlayer.getCraftPlayer();
               UUID uuid = fakePlayer.getUUID();
               String name = fakePlayer.getName();
               if (ServerSideFakePlayerManager.this.voiceChatHook != null && ServerSideFakePlayerManager.this.voiceChatHook.isEnabled()) {
                  ServerSideFakePlayerManager.this.voiceChatHook.registerFakePlayer(craftPlayer, uuid, name);
                  ServerSideFakePlayerManager.this.plugin.getLogger().fine("[ServerSideFakePlayer] Registered " + name + " with VoiceChat");
               }

               if (ServerSideFakePlayerManager.this.forcePackHook != null && ServerSideFakePlayerManager.this.forcePackHook.isEnabled()) {
                  ServerSideFakePlayerManager.this.forcePackHook.registerFakePlayer(craftPlayer, uuid, name);
                  ServerSideFakePlayerManager.this.plugin.getLogger().fine("[ServerSideFakePlayer] Registered " + name + " with ForcePack");
               }

               if (ServerSideFakePlayerManager.this.viaVersionHook != null && ServerSideFakePlayerManager.this.viaVersionHook.isEnabled()) {
                  ServerSideFakePlayerManager.this.viaVersionHook.registerFakePlayer(uuid, name, craftPlayer);
                  ServerSideFakePlayerManager.this.plugin.getLogger().fine("[ServerSideFakePlayer] Registered " + name + " with ViaVersion");
               }
            } catch (Exception e) {
               ServerSideFakePlayerManager.this.plugin.getLogger().warning("[ServerSideFakePlayer] Error registering with hooks: " + e.getMessage());
            }

         }
      }).runTaskLater(this.plugin, 5L);
   }

   private void injectIntoServerList(ServerSideFakePlayer fakePlayer) {
      if (this.serverPlayerList != null && this.serverPlayersByUUID != null) {
         try {
            Object entityPlayer = fakePlayer.getEntityPlayer();
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: injectIntoServerList - entityPlayer: " + (entityPlayer != null ? "OK" : "NULL"));
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Setting Paper-specific fields...");
            this.setPaperSpecificFields(entityPlayer, fakePlayer.getName());
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Setting joining = true...");
            this.setJoiningField(entityPlayer, true);
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Adding to player lists...");
            this.serverPlayerList.add(entityPlayer);
            this.serverPlayersByUUID.put(fakePlayer.getUUID(), entityPlayer);
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Added to serverPlayerList. Size now: " + this.serverPlayerList.size());
            if (this.serverPlayersByName != null) {
               String scoreboardName = this.getScoreboardName(entityPlayer);
               if (scoreboardName != null) {
                  this.serverPlayersByName.put(scoreboardName.toLowerCase(), entityPlayer);
                  this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Added to playersByName map: " + scoreboardName.toLowerCase());
               }
            }

            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Adding to server level...");
            this.addPlayerToServerLevel(entityPlayer);
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Initializing inventory menu...");
            this.initInventoryMenu(entityPlayer);
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Injected " + fakePlayer.getName() + " into server player list");
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Broadcasting player info...");
            this.broadcastPlayerInfo(fakePlayer, true);
         } catch (Exception e) {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] Failed to inject player: " + e.getMessage());
            e.printStackTrace();
         }

      } else {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Cannot inject - reflection not initialized");
         Logger var10000 = this.plugin.getLogger();
         String var10001 = String.valueOf(this.serverPlayerList);
         var10000.warning("[ServerSideFakePlayer] DEBUG: serverPlayerList=" + var10001 + ", serverPlayersByUUID=" + String.valueOf(this.serverPlayersByUUID));
      }
   }

   private void addPlayerToServerLevel(Object entityPlayer) {
      this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: addPlayerToServerLevel called");

      try {
         Method getLevelMethod = entityPlayer.getClass().getMethod("level");
         Object serverLevel = getLevelMethod.invoke(entityPlayer);
         if (serverLevel == null) {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Server level is null in addPlayerToServerLevel!");
            return;
         }

         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Got server level: " + serverLevel.getClass().getName());

         try {
            Method playersMethod = serverLevel.getClass().getMethod("players");
            List<Object> players = (List)playersMethod.invoke(serverLevel);
            Logger var10000 = this.plugin.getLogger();
            Object var10001 = players != null ? players.size() : "null";
            var10000.info("[ServerSideFakePlayer] DEBUG: Got players list, size: " + String.valueOf(var10001));
            if (players != null && !players.contains(entityPlayer)) {
               players.add(entityPlayer);
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Added player to level via players() method. New size: " + players.size());
            } else if (players != null && players.contains(entityPlayer)) {
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Player already in players list");
            }

            return;
         } catch (NoSuchMethodException var11) {
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: players() method not found, trying alternatives...");
            Method addNewPlayerMethod = this.findMethod(serverLevel.getClass(), "addNewPlayer", entityPlayer.getClass());
            if (addNewPlayerMethod != null) {
               addNewPlayerMethod.setAccessible(true);
               addNewPlayerMethod.invoke(serverLevel, entityPlayer);
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Added player to server level via addNewPlayer");
               return;
            }

            Method addPlayerMethod = this.findMethod(serverLevel.getClass(), "addPlayer", entityPlayer.getClass());
            if (addPlayerMethod != null) {
               addPlayerMethod.setAccessible(true);
               addPlayerMethod.invoke(serverLevel, entityPlayer);
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Added player to server level via addPlayer");
               return;
            }

            Field playersField = this.findField(serverLevel.getClass(), "players");
            if (playersField != null) {
               playersField.setAccessible(true);
               List<Object> players = (List)playersField.get(serverLevel);
               if (players != null && !players.contains(entityPlayer)) {
                  players.add(entityPlayer);
                  this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Added player to level players list directly via field");
               }
            } else {
               this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Could not find any way to add player to level");
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Available methods in " + serverLevel.getClass().getName() + ":");

               for(Method m : serverLevel.getClass().getMethods()) {
                  if (m.getName().toLowerCase().contains("add") || m.getName().toLowerCase().contains("player")) {
                     this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG:   - " + m.getName());
                  }
               }
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Failed to add player to server level: " + e.getMessage());
         e.printStackTrace();
      }

   }

   private void initInventoryMenu(Object entityPlayer) {
      try {
         Method initInventoryMenuMethod = entityPlayer.getClass().getMethod("initInventoryMenu");
         initInventoryMenuMethod.invoke(entityPlayer);
         this.plugin.getLogger().fine("[ServerSideFakePlayer] Initialized inventory menu");
      } catch (Exception e) {
         this.plugin.getLogger().fine("[ServerSideFakePlayer] Could not init inventory menu: " + e.getMessage());
      }

   }

   private void setJoiningField(Object entityPlayer, boolean value) {
      try {
         Field joiningField = this.findField(entityPlayer.getClass(), "joining");
         if (joiningField != null) {
            joiningField.setAccessible(true);
            joiningField.setBoolean(entityPlayer, value);
            this.plugin.getLogger().fine("[ServerSideFakePlayer] Set joining = " + value);
         }
      } catch (Exception e) {
         this.plugin.getLogger().fine("[ServerSideFakePlayer] Could not set joining field: " + e.getMessage());
      }

   }

   private void setPaperSpecificFields(Object entityPlayer, String name) {
      try {
         Field isRealPlayerField = this.findField(entityPlayer.getClass(), "isRealPlayer");
         if (isRealPlayerField != null) {
            isRealPlayerField.setAccessible(true);
            isRealPlayerField.setBoolean(entityPlayer, true);
            this.plugin.getLogger().fine("[ServerSideFakePlayer] Set isRealPlayer = true for " + name);
         }

         Field loginTimeField = this.findField(entityPlayer.getClass(), "loginTime");
         if (loginTimeField != null) {
            loginTimeField.setAccessible(true);
            loginTimeField.setLong(entityPlayer, System.currentTimeMillis());
            this.plugin.getLogger().fine("[ServerSideFakePlayer] Set loginTime for " + name);
         }

         Field suppressTrackerField = this.findField(entityPlayer.getClass(), "suppressTrackerForLogin");
         if (suppressTrackerField != null) {
            suppressTrackerField.setAccessible(true);
            suppressTrackerField.setBoolean(entityPlayer, true);
            this.plugin.getLogger().fine("[ServerSideFakePlayer] Set suppressTrackerForLogin = true for " + name);
         }
      } catch (Exception e) {
         this.plugin.getLogger().fine("[ServerSideFakePlayer] Error setting Paper fields: " + e.getMessage());
      }

   }

   private String getScoreboardName(Object entityPlayer) {
      try {
         Method getScoreboardNameMethod = entityPlayer.getClass().getMethod("getScoreboardName");
         return (String)getScoreboardNameMethod.invoke(entityPlayer);
      } catch (Exception var7) {
         try {
            Method getGameProfileMethod = entityPlayer.getClass().getMethod("getGameProfile");
            Object profile = getGameProfileMethod.invoke(entityPlayer);
            Method getNameMethod = profile.getClass().getMethod("getName");
            return (String)getNameMethod.invoke(profile);
         } catch (Exception var6) {
            return null;
         }
      }
   }

   private void broadcastPlayerInfo(ServerSideFakePlayer fakePlayer, boolean add) {
      Logger var10000 = this.plugin.getLogger();
      String var10001 = fakePlayer.getName();
      var10000.info("[ServerSideFakePlayer] DEBUG: broadcastPlayerInfo called for " + var10001 + ", add=" + add);

      try {
         Object entityPlayer = fakePlayer.getEntityPlayer();
         if (entityPlayer == null) {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: entityPlayer is NULL in broadcastPlayerInfo!");
            return;
         }

         int onlinePlayers = Bukkit.getOnlinePlayers().size();
         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Broadcasting to " + onlinePlayers + " online players");

         for(Player player : Bukkit.getOnlinePlayers()) {
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Sending packet to player: " + player.getName());
            Object craftPlayer = craftPlayerClass.cast(player);
            Method getHandleMethod = craftPlayerClass.getMethod("getHandle");
            Object nmsPlayer = getHandleMethod.invoke(craftPlayer);
            Object connection = this.getConnectionFromPlayer(nmsPlayer);
            if (connection == null) {
               this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Connection is null for player " + player.getName());
            } else {
               Method sendMethod = this.findSendMethod(connection.getClass());
               if (sendMethod != null) {
                  if (add) {
                     Object removePacket = playerInfoRemovePacketClass.getConstructor(List.class).newInstance(List.of(fakePlayer.getUUID()));
                     sendMethod.invoke(connection, removePacket);
                     Object addPacket = this.createPlayerInitializingPacket(entityPlayer, nmsPlayer);
                     if (addPacket != null) {
                        sendMethod.invoke(connection, addPacket);
                        this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Sent createPlayerInitializing packet to " + player.getName());
                     } else {
                        this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Failed to create player info packet for " + player.getName());
                     }
                  } else {
                     Object removePacket = playerInfoRemovePacketClass.getConstructor(List.class).newInstance(List.of(fakePlayer.getUUID()));
                     sendMethod.invoke(connection, removePacket);
                     this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Sent REMOVE packet to " + player.getName());
                  }
               }
            }
         }

         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: broadcastPlayerInfo complete for " + fakePlayer.getName());
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Failed to broadcast player info: " + e.getMessage());
         e.printStackTrace();
      }

   }

   private Object getConnectionFromPlayer(Object nmsPlayer) {
      for(Class<?> clazz = nmsPlayer.getClass(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
         for(Field f : clazz.getDeclaredFields()) {
            String typeName = f.getType().getName();
            if (typeName.contains("PacketListener") || typeName.contains("Connection")) {
               try {
                  f.setAccessible(true);
                  Object conn = f.get(nmsPlayer);
                  if (conn != null && !(conn instanceof Number) && !(conn instanceof Boolean)) {
                     return conn;
                  }
               } catch (Exception var10) {
               }
            }
         }
      }

      for(String name : new String[]{"c", "connection", "b"}) {
         try {
            Field connectionField = nmsPlayer.getClass().getDeclaredField(name);
            connectionField.setAccessible(true);
            Object conn = connectionField.get(nmsPlayer);
            if (conn != null && !(conn instanceof Number) && !(conn instanceof Boolean)) {
               return conn;
            }
         } catch (Exception var9) {
         }
      }

      return null;
   }

   private Method findSendMethod(Class<?> connectionClass) {
      for(Method m : connectionClass.getMethods()) {
         Class<?>[] params = m.getParameterTypes();
         if (params.length == 1 && params[0].getName().contains("Packet")) {
            return m;
         }
      }

      return null;
   }

   private Object createPlayerInitializingPacket(Object fakeEntityPlayer, Object targetPlayer) {
      try {
         try {
            Method createMethod = playerInfoUpdatePacketClass.getMethod("createPlayerInitializing", List.class, entityPlayerClass);
            return createMethod.invoke((Object)null, List.of(fakeEntityPlayer), targetPlayer);
         } catch (NoSuchMethodException var11) {
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: createPlayerInitializing(player, target) not found, trying alternative...");

            try {
               Method createMethod = playerInfoUpdatePacketClass.getMethod("createPlayerInitializing", List.class);
               return createMethod.invoke((Object)null, List.of(fakeEntityPlayer));
            } catch (NoSuchMethodException var10) {
               this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: createPlayerInitializing(List) not found, trying constructor...");
               Class<?> actionClass = null;

               for(Class<?> innerClass : playerInfoUpdatePacketClass.getDeclaredClasses()) {
                  if (innerClass.isEnum() && innerClass.getSimpleName().equals("a")) {
                     actionClass = innerClass;
                     break;
                  }
               }

               if (actionClass == null) {
                  actionClass = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket$a");
               }

               Object[] enumConstants = actionClass.getEnumConstants();
               Object addPlayerAction = null;

               for(Object constant : enumConstants) {
                  if (constant.toString().contains("ADD") || constant.toString().equals("a")) {
                     addPlayerAction = constant;
                     break;
                  }
               }

               if (addPlayerAction == null && enumConstants.length > 0) {
                  addPlayerAction = enumConstants[0];
               }

               if (addPlayerAction != null) {
                  Constructor<?> constructor = playerInfoUpdatePacketClass.getConstructor(actionClass, entityPlayerClass);
                  return constructor.newInstance(addPlayerAction, fakeEntityPlayer);
               } else {
                  this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Could not create player info packet - no valid method found");
                  return null;
               }
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Error creating player info packet: " + e.getMessage());
         e.printStackTrace();
         return null;
      }
   }

   public void removeFakePlayer(String name) {
      ServerSideFakePlayer fakePlayer = (ServerSideFakePlayer)this.fakePlayersByName.get(name.toLowerCase());
      if (fakePlayer != null) {
         this.unregisterFromHooks(fakePlayer);
         this.removeFromServerList(fakePlayer);
         this.fakePlayersByName.remove(name.toLowerCase());
         this.fakePlayersByUUID.remove(fakePlayer.getUUID());
         this.fireQuitEvent(fakePlayer);
      }
   }

   private void unregisterFromHooks(ServerSideFakePlayer fakePlayer) {
      try {
         UUID uuid = fakePlayer.getUUID();
         String name = fakePlayer.getName();
         if (this.voiceChatHook != null && this.voiceChatHook.isEnabled()) {
            this.voiceChatHook.unregisterFakePlayer(uuid, name);
         }

         if (this.forcePackHook != null && this.forcePackHook.isEnabled()) {
            this.forcePackHook.unregisterFakePlayer(uuid, name);
         }

         if (this.viaVersionHook != null && this.viaVersionHook.isEnabled()) {
            this.viaVersionHook.unregisterFakePlayer(uuid);
         }
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Error unregistering from hooks: " + e.getMessage());
      }

   }

   private void removeFromServerList(ServerSideFakePlayer fakePlayer) {
      if (this.serverPlayerList != null && this.serverPlayersByUUID != null) {
         try {
            Object entityPlayer = fakePlayer.getEntityPlayer();
            this.serverPlayerList.remove(entityPlayer);
            this.serverPlayersByUUID.remove(fakePlayer.getUUID());
            if (this.serverPlayersByName != null) {
               String scoreboardName = this.getScoreboardName(entityPlayer);
               if (scoreboardName != null) {
                  this.serverPlayersByName.remove(scoreboardName.toLowerCase());
               }
            }

            this.broadcastPlayerInfo(fakePlayer, false);
            this.plugin.getLogger().info("[ServerSideFakePlayer] Removed " + fakePlayer.getName() + " from server player list");
         } catch (Exception e) {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] Failed to remove player: " + e.getMessage());
         }

      }
   }

   private void fireQuitEvent(ServerSideFakePlayer fakePlayer) {
      try {
         Player fakeCraftPlayer = fakePlayer.getCraftPlayer();
         if (fakeCraftPlayer == null) {
            return;
         }

         if (this.loginEventManager != null) {
            this.loginEventManager.firePlayerQuitEvent(fakeCraftPlayer, fakePlayer.getName());
         } else {
            String var10003 = String.valueOf(ChatColor.YELLOW);
            PlayerQuitEvent quitEvent = new PlayerQuitEvent(fakeCraftPlayer, var10003 + fakePlayer.getName() + " left the game");
            Bukkit.getPluginManager().callEvent(quitEvent);
            String quitMessage = quitEvent.getQuitMessage();
            if (quitMessage != null && !quitMessage.isEmpty()) {
               Bukkit.broadcastMessage(quitMessage);
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Error firing quit event: " + e.getMessage());
      }

   }

   public void removeAll() {
      for(String name : new ArrayList(this.fakePlayersByName.keySet())) {
         this.removeFakePlayer(name);
      }

   }

   public ServerSideFakePlayer getFakePlayer(String name) {
      return (ServerSideFakePlayer)this.fakePlayersByName.get(name.toLowerCase());
   }

   public ServerSideFakePlayer getFakePlayer(UUID uuid) {
      return (ServerSideFakePlayer)this.fakePlayersByUUID.get(uuid);
   }

   public Collection<ServerSideFakePlayer> getAllFakePlayers() {
      return this.fakePlayersByName.values();
   }

   public int getFakePlayerCount() {
      return this.fakePlayersByName.size();
   }

   public boolean isFakePlayer(String name) {
      return this.fakePlayersByName.containsKey(name.toLowerCase());
   }

   public boolean isFakePlayer(UUID uuid) {
      return this.fakePlayersByUUID.containsKey(uuid);
   }

   public int getTotalPlayerCount() {
      return Bukkit.getOnlinePlayers().size() + this.getFakePlayerCount();
   }

   public void showAllToPlayer(Player player) {
      try {
         Object craftPlayer = craftPlayerClass.cast(player);
         Method getHandleMethod = craftPlayerClass.getMethod("getHandle");
         Object nmsPlayer = getHandleMethod.invoke(craftPlayer);
         Object connection = this.getConnectionFromPlayer(nmsPlayer);
         if (connection == null) {
            return;
         }

         Method sendMethod = this.findSendMethod(connection.getClass());
         if (sendMethod == null) {
            return;
         }

         for(ServerSideFakePlayer fakePlayer : this.getAllFakePlayers()) {
            Object removePacket = playerInfoRemovePacketClass.getConstructor(List.class).newInstance(List.of(fakePlayer.getUUID()));
            sendMethod.invoke(connection, removePacket);
            Field addModeField = playerInfoUpdatePacketClass.getDeclaredField("a");
            addModeField.setAccessible(true);
            Object addMode = addModeField.get((Object)null);
            Field dField = addMode.getClass().getDeclaredField("d");
            dField.setAccessible(true);
            Object addFlag = dField.get(addMode);
            Object addPacket = playerInfoUpdatePacketClass.getConstructor(addFlag.getClass(), entityPlayerClass).newInstance(addFlag, fakePlayer.getEntityPlayer());
            sendMethod.invoke(connection, addPacket);
         }
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Error showing players: " + e.getMessage());
      }

   }

   public static Object getPlayerTextureProperty(UUID uuid) throws Exception {
      String uuidString = uuid.toString().replace("-", "");
      URI uri = URI.create("https://sessionserver.mojang.com/session/minecraft/profile/" + uuidString + "?unsigned=false");
      BufferedReader in = new BufferedReader(new InputStreamReader(uri.toURL().openStream()));

      String texture;
      label46: {
         String signature;
         label45: {
            Object var12;
            try {
               StringBuilder response = new StringBuilder();

               String line;
               while((line = in.readLine()) != null) {
                  response.append(line);
               }

               String allInput = response.toString();
               String[] valueParts = allInput.split("value\" : \"");
               if (valueParts.length < 2) {
                  texture = null;
                  break label46;
               }

               texture = valueParts[1].split("\",")[0];
               String[] sigParts = allInput.split("signature\" : \"");
               if (sigParts.length < 2) {
                  signature = null;
                  break label45;
               }

               signature = sigParts[1].split("\"")[0];
               Constructor<?> propConstructor = propertyClass.getConstructor(String.class, String.class, String.class);
               var12 = propConstructor.newInstance("textures", texture, signature);
            } catch (Throwable var14) {
               try {
                  in.close();
               } catch (Throwable var13) {
                  var14.addSuppressed(var13);
               }

               throw var14;
            }

            in.close();
            return var12;
         }

         in.close();
         return signature;
      }

      in.close();
      return texture;
   }

   public static UUID getPlayerUUID(String name) throws Exception {
      URI uri = URI.create("https://api.mojang.com/users/profiles/minecraft/" + name);
      BufferedReader in = new BufferedReader(new InputStreamReader(uri.toURL().openStream()));

      String[] idParts;
      label46: {
         String digits;
         label45: {
            UUID var9;
            try {
               StringBuilder response = new StringBuilder();

               String line;
               while((line = in.readLine()) != null) {
                  response.append(line);
               }

               String allInput = response.toString();
               if (allInput.length() < 5) {
                  idParts = null;
                  break label46;
               }

               idParts = allInput.split("id\":\"");
               if (idParts.length < 2) {
                  digits = null;
                  break label45;
               }

               digits = idParts[1].replace("\"}", "");
               String uuid = digits.replaceAll("(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})", "$1-$2-$3-$4-$5");
               var9 = UUID.fromString(uuid);
            } catch (Throwable var11) {
               try {
                  in.close();
               } catch (Throwable var10) {
                  var11.addSuppressed(var10);
               }

               throw var11;
            }

            in.close();
            return var9;
         }

         in.close();
         return digits;
      }

      in.close();
      return idParts;
   }

   public LoginEventManager getLoginEventManager() {
      return this.loginEventManager;
   }

   public VoiceChatHook getVoiceChatHook() {
      return this.voiceChatHook;
   }

   public ForcePackHook getForcePackHook() {
      return this.forcePackHook;
   }

   public ViaVersionHook getViaVersionHook() {
      return this.viaVersionHook;
   }

   public UltraSpoofIntegration getUltraSpoofIntegration() {
      return this.ultraSpoofIntegration;
   }

   public ServerSideFakePlayer addFakePlayerUltraSpoof(String name, Location location, String ipAddress) {
      if (this.ultraSpoofIntegration == null) {
         this.ultraSpoofIntegration = new UltraSpoofIntegration(this.plugin);
      }

      UUID uuid = UUID.randomUUID();
      int portStart = 40000;
      int portEnd = 60000;
      Object entityPlayer = this.ultraSpoofIntegration.spawnUltraSpoofStyle(name, uuid, location, ipAddress, portStart, portEnd);
      if (entityPlayer != null) {
         ServerSideFakePlayer fakePlayer = new ServerSideFakePlayer(this.plugin, name, (UUID)null, (String)null);
         this.fakePlayersByName.put(name.toLowerCase(), fakePlayer);
         this.fakePlayersByUUID.put(fakePlayer.getUUID(), fakePlayer);
         this.plugin.getLogger().info("[ServerSideFakePlayer] Added fake player using UltraSpoof method: " + name);
         return fakePlayer;
      } else {
         return null;
      }
   }

   public void sendSpawnPacketToPlayer(Player target, ServerSideFakePlayer fakePlayer) {
      if (this.ultraSpoofIntegration == null) {
         this.ultraSpoofIntegration = new UltraSpoofIntegration(this.plugin);
      }

      Object entityPlayer = fakePlayer.getEntityPlayer();
      if (entityPlayer != null) {
         this.ultraSpoofIntegration.sendSpawnPacketToPlayer(target, entityPlayer);
      }

   }

   public void addPlayerToServerFull(Object entityPlayer, Object networkManager, String ipAddress) {
      if (this.ultraSpoofIntegration == null) {
         this.ultraSpoofIntegration = new UltraSpoofIntegration(this.plugin);
      }

      try {
         Object minecraftServer = this.getMinecraftServer();
         Object playerList = this.getPlayerList(minecraftServer);
         GameProfile profile = (GameProfile)entityPlayerClass.getMethod("getGameProfile").invoke(entityPlayer);
         Object cookie = this.ultraSpoofIntegration.createCommonListenerCookie(profile, true);
         this.ultraSpoofIntegration.addPlayerToServer(playerList, minecraftServer, networkManager, entityPlayer, cookie);
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Error adding player to server: " + e.getMessage());
      }

   }

   private Object getMinecraftServer() {
      try {
         Object craftServer = craftServerClass.cast(Bukkit.getServer());
         Method getServerMethod = craftServerClass.getMethod("getServer");
         return getServerMethod.invoke(craftServer);
      } catch (Exception var3) {
         return null;
      }
   }

   private Object getPlayerList(Object minecraftServer) {
      try {
         String[] methodNames = new String[]{"bg", "bf", "be", "bd", "bc", "getPlayerList", "ah", "ag", "af"};

         for(String methodName : methodNames) {
            try {
               Method method = minecraftServer.getClass().getMethod(methodName);
               Object result = method.invoke(minecraftServer);
               if (result != null) {
                  return result;
               }
            } catch (NoSuchMethodException var9) {
            }
         }
      } catch (Exception var10) {
      }

      return null;
   }

   static {
      try {
         String[] versions = new String[]{"v1_21_R7", "v1_21_R6", "v1_21_R5", "v1_21_R4", "v1_21_R3", "v1_21_R2", "v1_21_R1", "v1_20_R4", "v1_20_R3", "v1_20_R2", "v1_20_R1"};

         for(String version : versions) {
            try {
               craftServerClass = Class.forName("org.bukkit.craftbukkit." + version + ".CraftServer");
               craftWorldClass = Class.forName("org.bukkit.craftbukkit." + version + ".CraftWorld");
               craftPlayerClass = Class.forName("org.bukkit.craftbukkit." + version + ".entity.CraftPlayer");
               break;
            } catch (ClassNotFoundException var6) {
            }
         }

         minecraftServerClass = Class.forName("net.minecraft.server.MinecraftServer");
         worldServerClass = Class.forName("net.minecraft.server.level.WorldServer");
         dedicatedPlayerListClass = Class.forName("net.minecraft.server.dedicated.DedicatedPlayerList");
         playerListClass = Class.forName("net.minecraft.server.players.PlayerList");
         entityPlayerClass = Class.forName("net.minecraft.server.level.EntityPlayer");
         gameProfileClass = Class.forName("com.mojang.authlib.GameProfile");
         playerInfoRemovePacketClass = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket");
         playerInfoUpdatePacketClass = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket");
         propertyClass = Class.forName("com.mojang.authlib.properties.Property");
         connectionClass = Class.forName("net.minecraft.network.Connection");
      } catch (ClassNotFoundException var7) {
      }

   }
}
