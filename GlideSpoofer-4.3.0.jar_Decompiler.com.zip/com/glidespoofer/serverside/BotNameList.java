package com.glidespoofer.serverside;

import com.glidespoofer.core.GlideSpoofer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import org.bukkit.configuration.file.FileConfiguration;

public class BotNameList {
   private final GlideSpoofer plugin;
   private final List<String> names = new ArrayList();
   private final Set<String> usedNames = new HashSet();
   private final Random random = new Random();
   private boolean usePrefix = false;
   private boolean useSuffix = false;
   private String namePrefix = "";
   private String nameSuffix = "";
   private boolean allowDuplicates = false;
   private static final String[] DEFAULT_NAMES = new String[]{"Aaren", "Aaron", "Abbey", "Abby", "Abel", "Abigail", "Abraham", "Adam", "Adan", "Addison", "Adrian", "Adriana", "Aidan", "Aiden", "Aimee", "Alan", "Alana", "Albert", "Alberto", "Alejandro", "Alex", "Alexander", "Alexandra", "Alexis", "Alice", "Alicia", "Allen", "Allison", "Alondra", "Alvin", "Amanda", "Amber", "Amelia", "Amy", "Andrea", "Andrew", "Angel", "Angela", "Angelica", "Angelina", "Anna", "Anthony", "Antonio", "Aria", "Ariana", "Arianna", "Ashley", "Ashton", "Aubrey", "Austin", "Autumn", "Ava", "Avery", "Bailey", "Barbara", "Becky", "Benjamin", "Bennett", "Bernard", "Bethany", "Bianca", "Blake", "Bradley", "Brandon", "Brayden", "Brenda", "Brian", "Brianna", "Brooke", "Bruce", "Bryan", "Caitlin", "Caleb", "Cameron", "Camila", "Carlos", "Caroline", "Carson", "Carter", "Catherine", "Charles", "Charlotte", "Chelsea", "Cheyenne", "Chris", "Christian", "Christina", "Christine", "Christopher", "Claire", "Cody", "Colin", "Colton", "Connor", "Cooper", "Courtney", "Cristian", "Crystal", "Cynthia", "Daisy", "Dakota", "Dale", "Damian", "Daniel", "Danielle", "Danny", "David", "Dean", "Deborah", "Delilah", "Derek", "Destiny", "Devin", "Diana", "Diego", "Dillon", "Dominic", "Donna", "Dylan", "Easton", "Eddie", "Eduardo", "Edward", "Elena", "Eli", "Elias", "Elijah", "Elizabeth", "Ella", "Ellie", "Emily", "Emma", "Ethan", "Eva", "Evan", "Evelyn", "Faith", "Fernando", "Fiona", "Frank", "Gabriel", "Gabriella", "Gage", "Garrett", "Gary", "Gavin", "George", "Gianna", "Gina", "Grace", "Gracie", "Graham", "Grant", "Gregory", "Hailey", "Hannah", "Harper", "Harrison", "Hayden", "Hazel", "Heather", "Henry", "Holly", "Hope", "Hunter", "Ian", "Isaac", "Isabella", "Isabelle", "Ivan", "Jack", "Jackson", "Jacob", "Jade", "Jake", "James", "Jared", "Jasmine", "Jason", "Javier", "Jayden", "Jean", "Jeffrey", "Jenna", "Jennifer", "Jeremy", "Jesse", "Jessica", "Jesus", "Jillian", "Jimmy", "Joan", "Joanna", "Joel", "John", "Jonathan", "Jordan", "Jordyn", "Jorge", "Joseph", "Joshua", "Josiah", "Juan", "Julia", "Julian", "Julie", "Justin", "Kaden", "Kaitlyn", "Karen", "Kate", "Katherine", "Katie", "Kayla", "Kaylee", "Keith", "Kelly", "Kelsey", "Kenneth", "Kevin", "Kiara", "Kimberly", "Kyle", "Kylee", "Landon", "Laura", "Lauren", "Layla", "Leah", "Leo", "Leon", "Lillian", "Lilly", "Lily", "Linda", "Lindsey", "Logan", "Louis", "Lucas", "Lucy", "Luke", "Lydia", "Mackenzie", "Madeline", "Madison", "Marcus", "Margaret", "Maria", "Marie", "Mark", "Martin", "Mary", "Mason", "Matthew", "Max", "Maya", "Megan", "Melanie", "Melissa", "Mia", "Micah", "Michael", "Michelle", "Miguel", "Mike", "Morgan", "Natalie", "Nathan", "Nicholas", "Nicole", "Noah", "Nolan", "Oliver", "Olivia", "Oscar", "Owen", "Paige", "Parker", "Patrick", "Paul", "Payton", "Peter", "Peyton", "Philip", "Preston", "Rachel", "Ralph", "Randy", "Raymond", "Reagan", "Rebecca", "Riley", "Robert", "Robin", "Rochelle", "Roger", "Roman", "Ronald", "Rowan", "Ryan", "Ryder", "Rylee", "Sabrina", "Sage", "Sally", "Samuel", "Sandra", "Sara", "Sarah", "Savannah", "Scott", "Sean", "Serenity", "Seth", "Shane", "Sharon", "Shawn", "Shelby", "Sierra", "Simon", "Skylar", "Sofia", "Sophia", "Sophie", "Spencer", "Stacy", "Stephanie", "Stephen", "Steven", "Susan", "Sydney", "Tanner", "Taylor", "Teresa", "Terry", "Thomas", "Tiffany", "Timothy", "Travis", "Trenton", "Trevor", "Trinity", "Tyler", "Valerie", "Vanessa", "Veronica", "Victor", "Victoria", "Vincent", "Wesley", "William", "Wyatt", "Xavier", "Yasmin", "Zachary", "Zoe", "Zoey", "Ace", "Alpha", "Arrow", "Atlas", "Axel", "Blaze", "Bolt", "Breeze", "Brick", "Bronco", "Bullet", "Buzz", "Casper", "Chaos", "Cheese", "Chip", "Chuck", "Clash", "Cobra", "Comet", "Crash", "Creek", "Cricket", "Crunch", "Cyber", "Dash", "Denim", "Derby", "Diesel", "Duke", "Echo", "Edge", "Ember", "Fable", "Falcon", "Fang", "Felix", "Finn", "Fizz", "Flash", "Flint", "Fox", "Frost", "Ghost", "Gizmo", "Glitch", "Gohan", "Goku", "Griff", "Groot", "Hawk", "Haze", "Hero", "Hulk", "Hunter", "Iron", "Ivy", "Jet", "Jinx", "Joker", "Justice", "Kash", "King", "Knight", "Koda", "Legend", "Leo", "Lex", "Lightning", "Link", "Loki", "Lucky", "Luigi", "Luna", "Mario", "Mars", "Maverick", "Max", "Mega", "Meteor", "Midnight", "Misty", "Mochi", "Mono", "Moon", "Moss", "Nano", "Nash", "Nebula", "Neo", "Neon", "Nero", "Ness", "Nexus", "Ninja", "Nitro", "Nova", "Onyx", "Orbit", "Orion", "Ox", "Ozone", "Panda", "Peach", "Pepper", "Perry", "Phoenix", "Pixel", "Pluto", "Poke", "Polo", "Pony", "Prism", "Puddles", "Puma", "Punk", "Pyro", "Quark", "Quest", "Racer", "Raid", "Rain", "Ranger", "Raven", "Ray", "Rebel", "Red", "Reef", "Rex", "Rider", "Riptide", "River", "Roach", "Rocket", "Rocky", "Rogue", "Rook", "Rose", "Rover", "Rufus", "Rush", "Rusty", "Ryu", "Sage", "Samus", "Scout", "Shadow", "Shazam", "Sheik", "Shell", "Shrimp", "Siren", "Skull", "Sky", "Slayer", "Smash", "Smoky", "Snake", "Sniper", "Snow", "Sonic", "Spark", "Sparky", "Spider", "Spike", "Spot", "Star", "Storm", "Striker", "Sunny", "Sunset", "Sushi", "Swift", "Tails", "Talon", "Tank", "Taz", "Tech", "Terra", "Tesla", "Thor", "Thunder", "Tiger", "Titan", "Toast", "Tofu", "Tornado", "Toxic", "Tracer", "Trek", "Triton", "Trooper", "Turbo", "Tusk", "Typhoon", "Ultima", "Vader", "Valkyrie", "Vapor", "Vector", "Vega", "Venom", "Venus", "Vertex", "Vibe", "Victor", "Viper", "Virus", "Vortex", "Voyage", "Waffle", "Wasp", "Wave", "Wedge", "Willow", "Winter", "Wish", "Wolf", "Wonder", "Wraith", "Xenon", "Yoshi", "Yoshi", "Zap", "Zen", "Zero", "Zest", "Zilla", "Zinc", "Zodiac", "Zone", "Zoom", "Zues", "Zygote"};

   public BotNameList(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.loadDefaultNames();
   }

   public void load() {
      this.names.clear();
      this.usedNames.clear();
      File namesFile = new File(this.plugin.getDataFolder(), "bot_names.txt");
      if (namesFile.exists()) {
         try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(namesFile), StandardCharsets.UTF_8));

            try {
               String line;
               while((line = reader.readLine()) != null) {
                  line = line.trim();
                  if (!line.isEmpty() && !line.startsWith("#")) {
                     this.names.add(line);
                  }
               }

               this.plugin.getLogger().info("[BotNameList] Loaded " + this.names.size() + " names from file");
            } catch (Throwable var6) {
               try {
                  reader.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }

               throw var6;
            }

            reader.close();
         } catch (IOException e) {
            this.plugin.getLogger().warning("[BotNameList] Error loading names file: " + e.getMessage());
            this.loadDefaultNames();
         }
      } else {
         this.loadDefaultNames();
         this.saveDefaultNamesFile(namesFile);
      }

      FileConfiguration config = this.plugin.getConfig();
      this.usePrefix = config.getBoolean("server-side-bots.names.use-prefix", false);
      this.useSuffix = config.getBoolean("server-side-bots.names.use-suffix", false);
      this.namePrefix = config.getString("server-side-bots.names.prefix", "");
      this.nameSuffix = config.getString("server-side-bots.names.suffix", "");
      this.allowDuplicates = config.getBoolean("server-side-bots.names.allow-duplicates", false);
   }

   private void loadDefaultNames() {
      this.names.clear();
      Collections.addAll(this.names, DEFAULT_NAMES);
   }

   private void saveDefaultNamesFile(File file) {
      try {
         file.getParentFile().mkdirs();
         PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8));

         try {
            writer.println("# Bot Names Configuration");
            writer.println("# One name per line");
            writer.println("# Lines starting with # are comments");
            writer.println("#");

            for(String name : DEFAULT_NAMES) {
               writer.println(name);
            }
         } catch (Throwable var8) {
            try {
               writer.close();
            } catch (Throwable var7) {
               var8.addSuppressed(var7);
            }

            throw var8;
         }

         writer.close();
         this.plugin.getLogger().info("[BotNameList] Saved default names to " + file.getName());
      } catch (IOException e) {
         this.plugin.getLogger().warning("[BotNameList] Could not save default names file: " + e.getMessage());
      }

   }

   public String getRandomName() {
      if (this.names.isEmpty()) {
         return this.generateRandomName();
      } else if (this.allowDuplicates) {
         String baseName = (String)this.names.get(this.random.nextInt(this.names.size()));
         return this.applyModifiers(baseName);
      } else {
         for(int attempts = 0; attempts < 100; ++attempts) {
            String baseName = (String)this.names.get(this.random.nextInt(this.names.size()));
            String finalName = this.applyModifiers(baseName);
            if (!this.usedNames.contains(finalName.toLowerCase())) {
               this.usedNames.add(finalName.toLowerCase());
               return finalName;
            }
         }

         return this.generateRandomName();
      }
   }

   private String applyModifiers(String baseName) {
      StringBuilder sb = new StringBuilder();
      if (this.usePrefix && this.namePrefix != null && !this.namePrefix.isEmpty()) {
         sb.append(this.namePrefix);
      }

      sb.append(baseName);
      if (this.useSuffix && this.nameSuffix != null && !this.nameSuffix.isEmpty()) {
         sb.append(this.nameSuffix);
      }

      String result = sb.toString();
      if (result.length() > 16) {
         result = result.substring(0, 16);
      }

      return result;
   }

   private String generateRandomName() {
      String[] prefixes = new String[]{"X", "The", "Super", "Mega", "Ultra", "Pro", "Epic", "Dark", "Light", "Neo"};
      String[] middles = new String[]{"Player", "Gamer", "Ninja", "Master", "King", "Queen", "Boss", "Chief", "Lord", "Star"};
      String[] suffixes = new String[]{"123", "2024", "YT", "HD", "Pro", "X", "_", "99", "77", "00"};
      StringBuilder name = new StringBuilder();
      if (this.random.nextBoolean()) {
         name.append(prefixes[this.random.nextInt(prefixes.length)]);
      }

      name.append(middles[this.random.nextInt(middles.length)]);
      if (this.random.nextBoolean()) {
         name.append(suffixes[this.random.nextInt(suffixes.length)]);
      }

      String result = name.toString();
      if (result.length() > 16) {
         result = result.substring(0, 16);
      }

      while(this.usedNames.contains(result.toLowerCase())) {
         result = result + this.random.nextInt(10);
         if (result.length() > 16) {
            result = result.substring(0, 16);
         }
      }

      this.usedNames.add(result.toLowerCase());
      return result;
   }

   public void releaseName(String name) {
      this.usedNames.remove(name.toLowerCase());
   }

   public void addName(String name) {
      if (name != null && !name.isEmpty() && name.length() <= 16) {
         this.names.add(name);
      }

   }

   public void removeName(String name) {
      this.names.remove(name);
      this.usedNames.remove(name.toLowerCase());
   }

   public int getNameCount() {
      return this.names.size();
   }

   public int getUsedCount() {
      return this.usedNames.size();
   }

   public void clearUsed() {
      this.usedNames.clear();
   }

   public List<String> getAllNames() {
      return new ArrayList(this.names);
   }
}
