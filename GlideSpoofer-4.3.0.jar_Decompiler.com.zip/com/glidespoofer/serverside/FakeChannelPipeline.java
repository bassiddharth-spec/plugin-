package com.glidespoofer.serverside;

import io.netty.buffer.ByteBufAllocator;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandler;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelOutboundHandler;
import io.netty.channel.ChannelOutboundInvoker;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.ChannelProgressivePromise;
import io.netty.channel.ChannelPromise;
import io.netty.channel.DefaultChannelPromise;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.util.Attribute;
import io.netty.util.AttributeKey;
import io.netty.util.concurrent.EventExecutor;
import io.netty.util.concurrent.EventExecutorGroup;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class FakeChannelPipeline implements ChannelPipeline {
   private final Channel channel;
   private final Map<String, ChannelHandler> handlers = new ConcurrentHashMap();
   private final Map<String, FakeChannelHandlerContext> contexts = new ConcurrentHashMap();
   private final List<String> handlerOrder = new ArrayList();

   public FakeChannelPipeline(Channel channel) {
      this.channel = channel;
   }

   private synchronized void addHandlerInternal(String name, ChannelHandler handler) {
      if (!(handler instanceof ReadTimeoutHandler)) {
         String uniqueName = name != null && !name.isEmpty() ? name : "handler-" + UUID.randomUUID().toString().substring(0, 8);
         this.handlers.put(uniqueName, handler);
         FakeChannelHandlerContext ctx = new FakeChannelHandlerContext(this.channel, uniqueName, handler, this);
         this.contexts.put(uniqueName, ctx);
         if (!this.handlerOrder.contains(uniqueName)) {
            this.handlerOrder.add(uniqueName);
         }

         try {
            if (handler instanceof ChannelInboundHandlerAdapter) {
               ((ChannelInboundHandlerAdapter)handler).handlerAdded(ctx);
            } else if (handler instanceof ChannelInboundHandler) {
               ((ChannelInboundHandler)handler).handlerAdded(ctx);
            } else if (handler instanceof ChannelOutboundHandler) {
               try {
                  handler.getClass().getMethod("handlerAdded", ChannelHandlerContext.class).invoke(handler, ctx);
               } catch (Exception var6) {
               }
            }
         } catch (Exception var7) {
         }

      }
   }

   public ChannelPipeline addFirst(String name, ChannelHandler handler) {
      this.addHandlerInternal(name, handler);
      return this;
   }

   public ChannelPipeline addFirst(EventExecutorGroup group, String name, ChannelHandler handler) {
      this.addHandlerInternal(name, handler);
      return this;
   }

   public ChannelPipeline addLast(String name, ChannelHandler handler) {
      this.addHandlerInternal(name, handler);
      return this;
   }

   public ChannelPipeline addLast(EventExecutorGroup group, String name, ChannelHandler handler) {
      this.addHandlerInternal(name, handler);
      return this;
   }

   public ChannelPipeline addBefore(String baseName, String name, ChannelHandler handler) {
      this.addHandlerInternal(name, handler);
      return this;
   }

   public ChannelPipeline addBefore(EventExecutorGroup group, String baseName, String name, ChannelHandler handler) {
      this.addHandlerInternal(name, handler);
      return this;
   }

   public ChannelPipeline addAfter(String baseName, String name, ChannelHandler handler) {
      this.addHandlerInternal(name, handler);
      return this;
   }

   public ChannelPipeline addAfter(EventExecutorGroup group, String baseName, String name, ChannelHandler handler) {
      this.addHandlerInternal(name, handler);
      return this;
   }

   public ChannelPipeline addFirst(ChannelHandler... handlers) {
      for(int i = 0; i < handlers.length; ++i) {
         this.addHandlerInternal("handler-" + i, handlers[i]);
      }

      return this;
   }

   public ChannelPipeline addFirst(EventExecutorGroup group, ChannelHandler... handlers) {
      for(int i = 0; i < handlers.length; ++i) {
         this.addHandlerInternal("handler-" + i, handlers[i]);
      }

      return this;
   }

   public ChannelPipeline addLast(ChannelHandler... handlers) {
      for(int i = 0; i < handlers.length; ++i) {
         this.addHandlerInternal("handler-" + i, handlers[i]);
      }

      return this;
   }

   public ChannelPipeline addLast(EventExecutorGroup group, ChannelHandler... handlers) {
      for(int i = 0; i < handlers.length; ++i) {
         this.addHandlerInternal("handler-" + i, handlers[i]);
      }

      return this;
   }

   public ChannelPipeline remove(ChannelHandler handler) {
      Iterator<Map.Entry<String, ChannelHandler>> it = this.handlers.entrySet().iterator();

      while(it.hasNext()) {
         Map.Entry<String, ChannelHandler> entry = (Map.Entry)it.next();
         if (entry.getValue() == handler) {
            String name = (String)entry.getKey();
            it.remove();
            this.contexts.remove(name);
            this.handlerOrder.remove(name);
         }
      }

      return this;
   }

   public ChannelHandler remove(String name) {
      ChannelHandler handler = (ChannelHandler)this.handlers.remove(name);
      this.contexts.remove(name);
      this.handlerOrder.remove(name);
      return handler;
   }

   public <T extends ChannelHandler> T remove(Class<T> handlerClass) {
      Iterator<Map.Entry<String, ChannelHandler>> it = this.handlers.entrySet().iterator();

      while(it.hasNext()) {
         Map.Entry<String, ChannelHandler> entry = (Map.Entry)it.next();
         if (handlerClass.isInstance(entry.getValue())) {
            String name = (String)entry.getKey();
            ChannelHandler handler = (ChannelHandler)entry.getValue();
            it.remove();
            this.contexts.remove(name);
            this.handlerOrder.remove(name);
            return (T)handler;
         }
      }

      return null;
   }

   public ChannelHandler removeFirst() {
      if (this.handlerOrder.isEmpty()) {
         return null;
      } else {
         String firstName = (String)this.handlerOrder.get(0);
         return this.remove(firstName);
      }
   }

   public ChannelHandler removeLast() {
      if (this.handlerOrder.isEmpty()) {
         return null;
      } else {
         String lastName = (String)this.handlerOrder.get(this.handlerOrder.size() - 1);
         return this.remove(lastName);
      }
   }

   public ChannelPipeline replace(ChannelHandler oldHandler, String newName, ChannelHandler newHandler) {
      this.remove(oldHandler);
      this.addHandlerInternal(newName, newHandler);
      return this;
   }

   public ChannelHandler replace(String oldName, String newName, ChannelHandler newHandler) {
      ChannelHandler old = this.remove(oldName);
      this.addHandlerInternal(newName, newHandler);
      return old;
   }

   public <T extends ChannelHandler> T replace(Class<T> oldHandlerType, String newName, ChannelHandler newHandler) {
      T old = this.remove(oldHandlerType);
      this.addHandlerInternal(newName, newHandler);
      return old;
   }

   public ChannelHandler first() {
      return this.handlerOrder.isEmpty() ? null : (ChannelHandler)this.handlers.get(this.handlerOrder.get(0));
   }

   public ChannelHandlerContext firstContext() {
      return this.handlerOrder.isEmpty() ? null : (ChannelHandlerContext)this.contexts.get(this.handlerOrder.get(0));
   }

   public ChannelHandler last() {
      return this.handlerOrder.isEmpty() ? null : (ChannelHandler)this.handlers.get(this.handlerOrder.get(this.handlerOrder.size() - 1));
   }

   public ChannelHandlerContext lastContext() {
      return this.handlerOrder.isEmpty() ? null : (ChannelHandlerContext)this.contexts.get(this.handlerOrder.get(this.handlerOrder.size() - 1));
   }

   public ChannelHandler get(String name) {
      return (ChannelHandler)this.handlers.get(name);
   }

   public <T extends ChannelHandler> T get(Class<T> handlerClass) {
      for(ChannelHandler handler : this.handlers.values()) {
         if (handlerClass.isInstance(handler)) {
            return (T)handler;
         }
      }

      return null;
   }

   public ChannelHandlerContext context(ChannelHandler handler) {
      for(Map.Entry<String, ChannelHandler> entry : this.handlers.entrySet()) {
         if (entry.getValue() == handler) {
            return (ChannelHandlerContext)this.contexts.get(entry.getKey());
         }
      }

      return null;
   }

   public ChannelHandlerContext context(String name) {
      return (ChannelHandlerContext)this.contexts.get(name);
   }

   public ChannelHandlerContext context(Class<? extends ChannelHandler> handlerClass) {
      for(Map.Entry<String, ChannelHandler> entry : this.handlers.entrySet()) {
         if (handlerClass.isInstance(entry.getValue())) {
            return (ChannelHandlerContext)this.contexts.get(entry.getKey());
         }
      }

      return null;
   }

   public Channel channel() {
      return this.channel;
   }

   public List<String> names() {
      return new ArrayList(this.handlerOrder);
   }

   public Map<String, ChannelHandler> toMap() {
      return new LinkedHashMap(this.handlers);
   }

   public ChannelPipeline fireChannelRegistered() {
      return this;
   }

   public ChannelPipeline fireChannelUnregistered() {
      return this;
   }

   public ChannelPipeline fireChannelActive() {
      return this;
   }

   public ChannelPipeline fireChannelInactive() {
      return this;
   }

   public ChannelPipeline fireExceptionCaught(Throwable throwable) {
      return this;
   }

   public ChannelPipeline fireUserEventTriggered(Object event) {
      return this;
   }

   public ChannelPipeline fireChannelRead(Object msg) {
      return this;
   }

   public ChannelPipeline fireChannelReadComplete() {
      return this;
   }

   public ChannelPipeline fireChannelWritabilityChanged() {
      return this;
   }

   public ChannelFuture bind(SocketAddress localAddress) {
      return this.newSucceededFuture();
   }

   public ChannelFuture connect(SocketAddress remoteAddress) {
      return this.newSucceededFuture();
   }

   public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress) {
      return this.newSucceededFuture();
   }

   public ChannelFuture disconnect() {
      return this.newSucceededFuture();
   }

   public ChannelFuture close() {
      return this.newSucceededFuture();
   }

   public ChannelFuture deregister() {
      return this.newSucceededFuture();
   }

   public ChannelFuture bind(SocketAddress localAddress, ChannelPromise promise) {
      promise.setSuccess();
      return promise;
   }

   public ChannelFuture connect(SocketAddress remoteAddress, ChannelPromise promise) {
      promise.setSuccess();
      return promise;
   }

   public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) {
      promise.setSuccess();
      return promise;
   }

   public ChannelFuture disconnect(ChannelPromise promise) {
      promise.setSuccess();
      return promise;
   }

   public ChannelFuture close(ChannelPromise promise) {
      promise.setSuccess();
      return promise;
   }

   public ChannelFuture deregister(ChannelPromise promise) {
      promise.setSuccess();
      return promise;
   }

   public ChannelOutboundInvoker read() {
      return this;
   }

   public ChannelFuture write(Object msg) {
      return this.newSucceededFuture();
   }

   public ChannelFuture write(Object msg, ChannelPromise promise) {
      promise.setSuccess();
      return promise;
   }

   public ChannelPipeline flush() {
      return this;
   }

   public ChannelFuture writeAndFlush(Object msg, ChannelPromise promise) {
      promise.setSuccess();
      return promise;
   }

   public ChannelFuture writeAndFlush(Object msg) {
      return this.newSucceededFuture();
   }

   public ChannelPromise newPromise() {
      return new DefaultChannelPromise(this.channel);
   }

   public ChannelProgressivePromise newProgressivePromise() {
      return null;
   }

   public ChannelFuture newSucceededFuture() {
      DefaultChannelPromise promise = new DefaultChannelPromise(this.channel);
      promise.setSuccess();
      return promise;
   }

   public ChannelFuture newFailedFuture(Throwable cause) {
      DefaultChannelPromise promise = new DefaultChannelPromise(this.channel);
      promise.setFailure(cause);
      return promise;
   }

   public ChannelPromise voidPromise() {
      return new DefaultChannelPromise(this.channel);
   }

   public Iterator<Map.Entry<String, ChannelHandler>> iterator() {
      return this.handlers.entrySet().iterator();
   }

   private static class FakeChannelHandlerContext implements ChannelHandlerContext {
      private final Channel channel;
      private final String name;
      private final ChannelHandler handler;
      private final ChannelPipeline pipeline;

      FakeChannelHandlerContext(Channel channel, String name, ChannelHandler handler, ChannelPipeline pipeline) {
         this.channel = channel;
         this.name = name;
         this.handler = handler;
         this.pipeline = pipeline;
      }

      public Channel channel() {
         return this.channel;
      }

      public EventExecutor executor() {
         return this.channel.eventLoop();
      }

      public String name() {
         return this.name;
      }

      public ChannelHandler handler() {
         return this.handler;
      }

      public boolean isRemoved() {
         return false;
      }

      public ChannelHandlerContext fireChannelRegistered() {
         return this;
      }

      public ChannelHandlerContext fireChannelUnregistered() {
         return this;
      }

      public ChannelHandlerContext fireChannelActive() {
         return this;
      }

      public ChannelHandlerContext fireChannelInactive() {
         return this;
      }

      public ChannelHandlerContext fireExceptionCaught(Throwable cause) {
         return this;
      }

      public ChannelHandlerContext fireUserEventTriggered(Object event) {
         return this;
      }

      public ChannelHandlerContext fireChannelRead(Object msg) {
         return this;
      }

      public ChannelHandlerContext fireChannelReadComplete() {
         return this;
      }

      public ChannelHandlerContext fireChannelWritabilityChanged() {
         return this;
      }

      public ChannelFuture bind(SocketAddress localAddress) {
         DefaultChannelPromise promise = new DefaultChannelPromise(this.channel);
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture bind(SocketAddress localAddress, ChannelPromise promise) {
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture connect(SocketAddress remoteAddress) {
         DefaultChannelPromise promise = new DefaultChannelPromise(this.channel);
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress) {
         DefaultChannelPromise promise = new DefaultChannelPromise(this.channel);
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture connect(SocketAddress remoteAddress, ChannelPromise promise) {
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) {
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture disconnect() {
         DefaultChannelPromise promise = new DefaultChannelPromise(this.channel);
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture disconnect(ChannelPromise promise) {
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture close() {
         DefaultChannelPromise promise = new DefaultChannelPromise(this.channel);
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture close(ChannelPromise promise) {
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture deregister() {
         DefaultChannelPromise promise = new DefaultChannelPromise(this.channel);
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture deregister(ChannelPromise promise) {
         promise.setSuccess();
         return promise;
      }

      public ChannelHandlerContext read() {
         return this;
      }

      public ChannelFuture write(Object msg) {
         DefaultChannelPromise promise = new DefaultChannelPromise(this.channel);
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture write(Object msg, ChannelPromise promise) {
         promise.setSuccess();
         return promise;
      }

      public ChannelHandlerContext flush() {
         return this;
      }

      public ChannelFuture writeAndFlush(Object msg) {
         DefaultChannelPromise promise = new DefaultChannelPromise(this.channel);
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture writeAndFlush(Object msg, ChannelPromise promise) {
         promise.setSuccess();
         return promise;
      }

      public ChannelPromise newPromise() {
         return new DefaultChannelPromise(this.channel);
      }

      public ChannelProgressivePromise newProgressivePromise() {
         return null;
      }

      public ChannelFuture newSucceededFuture() {
         DefaultChannelPromise promise = new DefaultChannelPromise(this.channel);
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture newFailedFuture(Throwable cause) {
         DefaultChannelPromise promise = new DefaultChannelPromise(this.channel);
         promise.setFailure(cause);
         return promise;
      }

      public ChannelPromise voidPromise() {
         return new DefaultChannelPromise(this.channel);
      }

      public ChannelPipeline pipeline() {
         return this.pipeline;
      }

      public ByteBufAllocator alloc() {
         return this.channel.alloc();
      }

      public <T> Attribute<T> attr(AttributeKey<T> key) {
         return this.channel.attr(key);
      }

      public <T> boolean hasAttr(AttributeKey<T> key) {
         return this.channel.hasAttr(key);
      }
   }
}
