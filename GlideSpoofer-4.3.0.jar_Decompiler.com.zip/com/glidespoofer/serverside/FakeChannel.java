package com.glidespoofer.serverside;

import io.netty.buffer.ByteBufAllocator;
import io.netty.channel.Channel;
import io.netty.channel.ChannelConfig;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelId;
import io.netty.channel.ChannelMetadata;
import io.netty.channel.ChannelOutboundBuffer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.ChannelProgressivePromise;
import io.netty.channel.ChannelPromise;
import io.netty.channel.DefaultChannelConfig;
import io.netty.channel.DefaultChannelPromise;
import io.netty.channel.DefaultEventLoop;
import io.netty.channel.EventLoop;
import io.netty.channel.RecvByteBufAllocator;
import io.netty.util.Attribute;
import io.netty.util.AttributeKey;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class FakeChannel implements Channel {
   private static volatile EventLoop sharedEventLoop = null;
   private final ChannelId channelId;
   private final SocketAddress localAddress;
   private final SocketAddress remoteAddress;
   private final ChannelPipeline pipeline;
   private final ChannelConfig config;
   private final Map<AttributeKey<?>, Object> attributes;
   private boolean open;
   private boolean registered;
   private boolean active;

   private static synchronized EventLoop getSharedEventLoop() {
      if (sharedEventLoop == null) {
         DefaultEventLoop eventLoop = new DefaultEventLoop();
         eventLoop.execute(() -> {
         });
         sharedEventLoop = eventLoop;
      }

      return sharedEventLoop;
   }

   public FakeChannel() {
      this(new InetSocketAddress("127.0.0.1", 0));
   }

   public FakeChannel(SocketAddress remoteAddress) {
      this.attributes = new ConcurrentHashMap();
      this.open = true;
      this.registered = true;
      this.active = true;
      this.channelId = new FakeChannelId();
      this.localAddress = new InetSocketAddress("127.0.0.1", 25565);
      this.remoteAddress = (SocketAddress)(remoteAddress != null ? remoteAddress : new InetSocketAddress("127.0.0.1", 0));
      this.pipeline = new FakeChannelPipeline(this);
      this.config = new DefaultChannelConfig(this);
   }

   public ChannelId id() {
      return this.channelId;
   }

   public EventLoop eventLoop() {
      return getSharedEventLoop();
   }

   public Channel parent() {
      return null;
   }

   public ChannelConfig config() {
      return this.config;
   }

   public boolean isOpen() {
      return this.open;
   }

   public boolean isRegistered() {
      return this.registered;
   }

   public boolean isActive() {
      return this.active;
   }

   public ChannelMetadata metadata() {
      return new ChannelMetadata(true);
   }

   public SocketAddress localAddress() {
      return this.localAddress;
   }

   public SocketAddress remoteAddress() {
      return this.remoteAddress;
   }

   public ChannelFuture closeFuture() {
      DefaultChannelPromise promise = new DefaultChannelPromise(this);
      promise.setSuccess();
      return promise;
   }

   public boolean isWritable() {
      return true;
   }

   public long bytesBeforeUnwritable() {
      return Long.MAX_VALUE;
   }

   public long bytesBeforeWritable() {
      return 0L;
   }

   public Channel.Unsafe unsafe() {
      return new FakeUnsafe();
   }

   public ChannelPipeline pipeline() {
      return this.pipeline;
   }

   public ByteBufAllocator alloc() {
      return ByteBufAllocator.DEFAULT;
   }

   private ChannelFuture succeededFuture() {
      DefaultChannelPromise promise = new DefaultChannelPromise(this);
      promise.setSuccess();
      return promise;
   }

   public ChannelFuture bind(SocketAddress socketAddress) {
      return this.succeededFuture();
   }

   public ChannelFuture connect(SocketAddress socketAddress) {
      return this.succeededFuture();
   }

   public ChannelFuture connect(SocketAddress socketAddress, SocketAddress socketAddress1) {
      return this.succeededFuture();
   }

   public ChannelFuture disconnect() {
      this.active = false;
      return this.succeededFuture();
   }

   public ChannelFuture close() {
      this.open = false;
      this.active = false;
      return this.succeededFuture();
   }

   public ChannelFuture deregister() {
      this.registered = false;
      return this.succeededFuture();
   }

   public ChannelFuture bind(SocketAddress socketAddress, ChannelPromise channelPromise) {
      channelPromise.setSuccess();
      return channelPromise;
   }

   public ChannelFuture connect(SocketAddress socketAddress, ChannelPromise channelPromise) {
      channelPromise.setSuccess();
      return channelPromise;
   }

   public ChannelFuture connect(SocketAddress socketAddress, SocketAddress socketAddress1, ChannelPromise channelPromise) {
      channelPromise.setSuccess();
      return channelPromise;
   }

   public ChannelFuture disconnect(ChannelPromise channelPromise) {
      this.active = false;
      channelPromise.setSuccess();
      return channelPromise;
   }

   public ChannelFuture close(ChannelPromise channelPromise) {
      this.open = false;
      this.active = false;
      channelPromise.setSuccess();
      return channelPromise;
   }

   public ChannelFuture deregister(ChannelPromise channelPromise) {
      this.registered = false;
      channelPromise.setSuccess();
      return channelPromise;
   }

   public Channel read() {
      return this;
   }

   public ChannelFuture write(Object o) {
      return this.succeededFuture();
   }

   public ChannelFuture write(Object o, ChannelPromise channelPromise) {
      channelPromise.setSuccess();
      return channelPromise;
   }

   public Channel flush() {
      return this;
   }

   public ChannelFuture writeAndFlush(Object o, ChannelPromise channelPromise) {
      channelPromise.setSuccess();
      return channelPromise;
   }

   public ChannelFuture writeAndFlush(Object o) {
      return this.succeededFuture();
   }

   public ChannelPromise newPromise() {
      return new DefaultChannelPromise(this);
   }

   public ChannelProgressivePromise newProgressivePromise() {
      return null;
   }

   public ChannelFuture newSucceededFuture() {
      return this.succeededFuture();
   }

   public ChannelFuture newFailedFuture(Throwable throwable) {
      DefaultChannelPromise promise = new DefaultChannelPromise(this);
      promise.setFailure(throwable);
      return promise;
   }

   public ChannelPromise voidPromise() {
      return new DefaultChannelPromise(this);
   }

   public <T> Attribute<T> attr(AttributeKey<T> attributeKey) {
      Object value = this.attributes.get(attributeKey);
      return value == null ? new FakeAttribute(attributeKey) : new FakeAttribute(attributeKey, value);
   }

   public <T> boolean hasAttr(AttributeKey<T> attributeKey) {
      return this.attributes.containsKey(attributeKey);
   }

   public int compareTo(Channel o) {
      return 0;
   }

   private static class FakeChannelId implements ChannelId {
      private static final long serialVersionUID = 1L;
      private final String id = UUID.randomUUID().toString().substring(0, 8);

      public String asShortText() {
         return this.id;
      }

      public String asLongText() {
         return "fake-" + this.id;
      }

      public int compareTo(ChannelId o) {
         return 0;
      }

      public String toString() {
         return this.asShortText();
      }
   }

   private class FakeAttribute<T> implements Attribute<T> {
      private final AttributeKey<T> key;
      private T value;

      FakeAttribute(AttributeKey<T> key) {
         this.key = key;
      }

      FakeAttribute(AttributeKey<T> key, T value) {
         this.key = key;
         this.value = value;
      }

      public AttributeKey<T> key() {
         return this.key;
      }

      public T get() {
         return this.value;
      }

      public void set(T value) {
         this.value = value;
         FakeChannel.this.attributes.put(this.key, value);
      }

      public T getAndSet(T value) {
         T old = this.value;
         this.set(value);
         return old;
      }

      public T setIfAbsent(T value) {
         if (this.value == null) {
            this.set(value);
            return null;
         } else {
            return this.value;
         }
      }

      public T getAndRemove() {
         T old = this.value;
         this.value = null;
         FakeChannel.this.attributes.remove(this.key);
         return old;
      }

      public boolean compareAndSet(T oldValue, T newValue) {
         if (this.value == oldValue) {
            this.set(newValue);
            return true;
         } else {
            return false;
         }
      }

      public void remove() {
         this.value = null;
         FakeChannel.this.attributes.remove(this.key);
      }
   }

   private class FakeUnsafe implements Channel.Unsafe {
      public SocketAddress localAddress() {
         return FakeChannel.this.localAddress;
      }

      public SocketAddress remoteAddress() {
         return FakeChannel.this.remoteAddress;
      }

      public void register(EventLoop eventLoop, ChannelPromise promise) {
         FakeChannel.this.registered = true;
         promise.setSuccess();
      }

      public void bind(SocketAddress localAddress, ChannelPromise promise) {
         promise.setSuccess();
      }

      public void connect(SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) {
         FakeChannel.this.active = true;
         promise.setSuccess();
      }

      public void disconnect(ChannelPromise promise) {
         FakeChannel.this.active = false;
         promise.setSuccess();
      }

      public void close(ChannelPromise promise) {
         FakeChannel.this.open = false;
         FakeChannel.this.active = false;
         promise.setSuccess();
      }

      public void closeForcibly() {
         FakeChannel.this.open = false;
         FakeChannel.this.active = false;
      }

      public void deregister(ChannelPromise promise) {
         FakeChannel.this.registered = false;
         promise.setSuccess();
      }

      public void beginRead() {
      }

      public void write(Object msg, ChannelPromise promise) {
         promise.setSuccess();
      }

      public void flush() {
      }

      public ChannelPromise voidPromise() {
         return new DefaultChannelPromise(FakeChannel.this);
      }

      public ChannelOutboundBuffer outboundBuffer() {
         return null;
      }

      public RecvByteBufAllocator.Handle recvBufAllocHandle() {
         return null;
      }
   }
}
