package com.glidespoofer.serverside;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FakeConnection {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-FakeConnection");
   private static Class<?> playerConnectionClass;
   private static Class<?> serverCommonPacketListenerClass;
   private static Class<?> minecraftServerClass;
   private static Class<?> networkManagerClass;
   private static Class<?> entityPlayerClass;
   private static Class<?> commonListenerCookieClass;
   private static Class<?> packetClass;
   private static Field pingField;
   private static Field connectionField;
   private Object playerConnection;
   private final Object minecraftServer;
   private final Object networkManager;
   private final Object entityPlayer;
   private final Object cookie;

   private static Field findField(Class<?> clazz, String... names) {
      for(String name : names) {
         try {
            Field field = clazz.getDeclaredField(name);
            field.setAccessible(true);
            return field;
         } catch (NoSuchFieldException var10) {
            Class<?> superClass = clazz.getSuperclass();
            if (superClass != null) {
               try {
                  Field field = superClass.getDeclaredField(name);
                  field.setAccessible(true);
                  return field;
               } catch (NoSuchFieldException var9) {
               }
            }
         }
      }

      return null;
   }

   public FakeConnection(Object minecraftServer, Object networkManager, Object entityPlayer, Object cookie) {
      this.minecraftServer = minecraftServer;
      this.networkManager = networkManager;
      this.entityPlayer = entityPlayer;
      this.cookie = cookie;
      this.createPlayerConnection();
   }

   private void createPlayerConnection() {
      try {
         Constructor<?> constructor = playerConnectionClass.getConstructor(minecraftServerClass, networkManagerClass, entityPlayerClass, commonListenerCookieClass);
         constructor.setAccessible(true);
         this.playerConnection = constructor.newInstance(this.minecraftServer, this.networkManager, this.entityPlayer, this.cookie);
         connectionField = findField(entityPlayerClass, "connection", "c", "b");
         if (connectionField != null) {
            connectionField.setAccessible(true);
            connectionField.set(this.entityPlayer, this.playerConnection);
         }

         LOGGER.fine("[FakeConnection] Created PlayerConnection successfully");
      } catch (Exception e) {
         LOGGER.log(Level.WARNING, "[FakeConnection] Failed to create PlayerConnection", e);
      }

   }

   public void send(Object packet) {
   }

   public void sendPacket(Object packet) {
      try {
         if (this.playerConnection != null) {
            Method sendMethod = playerConnectionClass.getMethod("send", packetClass);
            sendMethod.invoke(this.playerConnection, packet);
         }
      } catch (Exception var3) {
      }

   }

   public void setPing(int ping) {
      try {
         if (pingField != null && this.playerConnection != null) {
            pingField.setInt(this.playerConnection, ping);
         }
      } catch (Exception e) {
         LOGGER.fine("[FakeConnection] Failed to set ping: " + e.getMessage());
      }

   }

   public int getPing() {
      try {
         if (pingField != null && this.playerConnection != null) {
            return pingField.getInt(this.playerConnection);
         }
      } catch (Exception var2) {
      }

      return 0;
   }

   public Object getPlayerConnection() {
      return this.playerConnection;
   }

   public boolean isValid() {
      return this.playerConnection != null;
   }

   public void disconnect(String reason) {
   }

   public void handleResourcePackResponse(Object packet) {
   }

   public static void setPlayerPing(Object entityPlayer, int ping) {
      try {
         Field connectionField = findField(entityPlayer.getClass(), "connection", "c", "b");
         if (connectionField != null) {
            connectionField.setAccessible(true);
            Object connection = connectionField.get(entityPlayer);
            if (connection != null && pingField != null) {
               pingField.setInt(connection, ping);
            }
         }
      } catch (Exception var4) {
      }

   }

   static {
      try {
         playerConnectionClass = Class.forName("net.minecraft.server.network.PlayerConnection");
         serverCommonPacketListenerClass = Class.forName("net.minecraft.server.network.ServerCommonPacketListenerImpl");
         minecraftServerClass = Class.forName("net.minecraft.server.MinecraftServer");
         networkManagerClass = Class.forName("net.minecraft.network.Connection");
         entityPlayerClass = Class.forName("net.minecraft.server.level.EntityPlayer");
         commonListenerCookieClass = Class.forName("net.minecraft.server.network.CommonListenerCookie");
         packetClass = Class.forName("net.minecraft.network.protocol.Packet");
         pingField = findField(serverCommonPacketListenerClass, "o", "ping", "latency");
         if (pingField != null) {
            pingField.setAccessible(true);
         }

         LOGGER.info("[FakeConnection] Initialized reflection successfully");
      } catch (ClassNotFoundException e) {
         LOGGER.warning("[FakeConnection] Failed to load classes: " + e.getMessage());
      }

   }
}
