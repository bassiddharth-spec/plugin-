package com.glidespoofer.serverside;

import com.glidespoofer.core.GlideSpoofer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class AutoBotManager {
   private final GlideSpoofer plugin;
   private final ServerSideFakePlayerManager fakePlayerManager;
   private final BotNameList botNameList;
   private final BotSkinList botSkinList;
   private boolean enabled = false;
   private int minimumBots = 3;
   private int maximumBots = 7;
   private int minimumOnlineMinutes = 10;
   private int maximumOnlineMinutes = 60;
   private boolean autoJoinEnabled = true;
   private boolean autoQuitEnabled = true;
   private boolean welcomeMessagesEnabled = true;
   private int updateIntervalSeconds = 30;
   private int startupDelaySeconds = 10;
   private final List<String> firstJoinMessages = new ArrayList();
   private final List<String> reJoinMessages = new ArrayList();
   private BukkitRunnable autoTask;
   private final Random random = new Random();

   public AutoBotManager(GlideSpoofer plugin, ServerSideFakePlayerManager fakePlayerManager) {
      this.plugin = plugin;
      this.fakePlayerManager = fakePlayerManager;
      this.botNameList = new BotNameList(plugin);
      this.botSkinList = new BotSkinList(plugin);
      this.loadDefaultMessages();
   }

   private void loadDefaultMessages() {
      this.firstJoinMessages.add("Welcome <name>!");
      this.firstJoinMessages.add("Hey <name>, welcome to the server!");
      this.firstJoinMessages.add("Hi <name>! Glad you're here!");
      this.firstJoinMessages.add("Welcome aboard, <name>!");
      this.firstJoinMessages.add("<name> joined the party!");
      this.reJoinMessages.add("Welcome back <name>!");
      this.reJoinMessages.add("Hey <name>, good to see you again!");
      this.reJoinMessages.add("<name> is back!");
      this.reJoinMessages.add("wb <name>");
      this.reJoinMessages.add("<name> returned!");
   }

   public void loadConfiguration() {
      try {
         FileConfiguration config = this.plugin.getConfig();
         this.enabled = config.getBoolean("server-side-bots.enabled", false);
         this.minimumBots = config.getInt("server-side-bots.auto.minimum", 3);
         this.maximumBots = config.getInt("server-side-bots.auto.maximum", 7);
         this.minimumOnlineMinutes = config.getInt("server-side-bots.auto.minimum-online-minutes", 10);
         this.maximumOnlineMinutes = config.getInt("server-side-bots.auto.maximum-online-minutes", 60);
         this.autoJoinEnabled = config.getBoolean("server-side-bots.auto.auto-join", true);
         this.autoQuitEnabled = config.getBoolean("server-side-bots.auto.auto-quit", true);
         this.welcomeMessagesEnabled = config.getBoolean("server-side-bots.welcome-messages.enabled", true);
         this.updateIntervalSeconds = config.getInt("server-side-bots.update-interval-seconds", 30);
         this.startupDelaySeconds = config.getInt("server-side-bots.startup-delay-seconds", 10);
         if (config.contains("server-side-bots.welcome-messages.first-join")) {
            List<String> customFirst = config.getStringList("server-side-bots.welcome-messages.first-join");
            if (!customFirst.isEmpty()) {
               this.firstJoinMessages.clear();
               this.firstJoinMessages.addAll(customFirst);
            }
         }

         if (config.contains("server-side-bots.welcome-messages.rejoin")) {
            List<String> customRejoin = config.getStringList("server-side-bots.welcome-messages.rejoin");
            if (!customRejoin.isEmpty()) {
               this.reJoinMessages.clear();
               this.reJoinMessages.addAll(customRejoin);
            }
         }

         this.botNameList.load();
         this.botSkinList.load();
         this.plugin.getLogger().info("[AutoBotManager] Configuration loaded - Enabled: " + this.enabled + ", Min: " + this.minimumBots + ", Max: " + this.maximumBots);
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.WARNING, "[AutoBotManager] Error loading configuration", e);
      }

   }

   public void start() {
      if (!this.enabled) {
         this.plugin.getLogger().info("[AutoBotManager] Auto bot management is disabled");
      } else {
         int delayTicks = this.startupDelaySeconds * 20;
         (new BukkitRunnable() {
            public void run() {
               AutoBotManager.this.spawnInitialBots();
               AutoBotManager.this.startUpdateTask();
            }
         }).runTaskLater(this.plugin, (long)delayTicks);
         this.plugin.getLogger().info("[AutoBotManager] Started - will spawn bots in " + this.startupDelaySeconds + " seconds");
      }
   }

   public void stop() {
      if (this.autoTask != null) {
         this.autoTask.cancel();
         this.autoTask = null;
      }

      this.plugin.getLogger().info("[AutoBotManager] Stopped");
   }

   private void spawnInitialBots() {
      if (this.enabled) {
         int toSpawn = this.minimumBots;
         this.plugin.getLogger().info("[AutoBotManager] Spawning initial " + toSpawn + " bots...");

         for(int i = 0; i < toSpawn; ++i) {
            this.spawnBot();
         }

      }
   }

   private void startUpdateTask() {
      long intervalTicks = (long)this.updateIntervalSeconds * 20L;
      this.autoTask = new BukkitRunnable() {
         public void run() {
            AutoBotManager.this.update();
         }
      };
      this.autoTask.runTaskTimer(this.plugin, intervalTicks, intervalTicks);
   }

   private void update() {
      if (this.enabled) {
         Collection<ServerSideFakePlayer> bots = new ArrayList(this.fakePlayerManager.getAllFakePlayers());
         long currentTime = System.currentTimeMillis();
         long minTime = (long)(this.minimumOnlineMinutes * 60) * 1000L;
         long maxTime = (long)(this.maximumOnlineMinutes * 60) * 1000L;

         for(ServerSideFakePlayer bot : bots) {
            this.updateBotPing(bot);
            long onlineTime = currentTime - bot.getJoinTime();
            if (onlineTime > maxTime) {
               if (this.autoQuitEnabled) {
                  this.plugin.getLogger().fine("[AutoBotManager] Removing bot " + bot.getName() + " (max time exceeded)");
                  this.fakePlayerManager.removeFakePlayer(bot.getName());
               }
            } else if (onlineTime > minTime && bots.size() > this.minimumBots && this.random.nextInt(1000) > 850 && this.autoQuitEnabled) {
               this.plugin.getLogger().fine("[AutoBotManager] Cycling out bot " + bot.getName());
               this.fakePlayerManager.removeFakePlayer(bot.getName());
            }
         }

         int currentCount = this.fakePlayerManager.getFakePlayerCount();
         if (currentCount >= this.minimumBots) {
            if (currentCount < this.maximumBots && this.random.nextInt(1000) > 850 && this.autoJoinEnabled) {
               this.plugin.getLogger().fine("[AutoBotManager] Adding extra bot");
               this.spawnBot();
            }

         } else {
            if (this.autoJoinEnabled) {
               int toAdd = this.minimumBots - currentCount;
               this.plugin.getLogger().fine("[AutoBotManager] Spawning " + toAdd + " bots to reach minimum");

               for(int i = 0; i < toAdd; ++i) {
                  this.spawnBot();
               }
            }

         }
      }
   }

   private void updateBotPing(ServerSideFakePlayer bot) {
      bot.updatePing();
   }

   public void spawnBot() {
      String name = this.botNameList.getRandomName();
      UUID skinUUID = this.botSkinList.getRandomSkin();
      if (name == null || name.isEmpty()) {
         name = "Player" + this.random.nextInt(10000);
      }

      ServerSideFakePlayer bot = this.fakePlayerManager.addFakePlayer(name, skinUUID, "default");
      if (bot != null) {
         this.plugin.getLogger().fine("[AutoBotManager] Spawned bot: " + name);
      }

   }

   public void sendWelcomeMessages(final Player joiningPlayer) {
      if (this.enabled && this.welcomeMessagesEnabled) {
         if (joiningPlayer != null) {
            final Collection<ServerSideFakePlayer> bots = this.fakePlayerManager.getAllFakePlayers();
            if (!bots.isEmpty()) {
               boolean isFirstJoin = joiningPlayer.getFirstPlayed() + 10000L > System.currentTimeMillis();
               final List<String> messages = isFirstJoin ? this.firstJoinMessages : this.reJoinMessages;
               (new BukkitRunnable() {
                  public void run() {
                     for(ServerSideFakePlayer bot : bots) {
                        if (AutoBotManager.this.random.nextInt(3) < 2 && !joiningPlayer.getName().equals(bot.getName())) {
                           String template = (String)messages.get(AutoBotManager.this.random.nextInt(messages.size()));
                           String message = template.replace("<name>", joiningPlayer.getName());
                           int delay = AutoBotManager.this.random.nextInt(100);
                           (new BukkitRunnable() {
                              // $FF: synthetic field
                              final ServerSideFakePlayer val$bot;
                              // $FF: synthetic field
                              final String val$message;
                              // $FF: synthetic field
                              final <undefinedtype> this$1;

                              {
                                 this.val$bot = val$bot;
                                 this.val$message = val$message;
                                 this.this$1 = this$1;
                              }

                              public void run() {
                                 this.this$1.this$0.sendBotChatMessage(this.val$bot, this.val$message);
                              }
                           }).runTaskLater(AutoBotManager.this.plugin, (long)delay);
                        }
                     }

                  }
               }).runTaskLater(this.plugin, 30L);
            }
         }
      }
   }

   private void sendBotChatMessage(ServerSideFakePlayer bot, String message) {
      try {
         Player fakePlayer = bot.getCraftPlayer();
         if (fakePlayer != null) {
            String var10000 = bot.getName();
            String formattedMessage = "<" + var10000 + "> " + message;
            Bukkit.broadcastMessage(formattedMessage);
         }
      } catch (Exception e) {
         this.plugin.getLogger().fine("[AutoBotManager] Could not send bot message: " + e.getMessage());
      }

   }

   public BotNameList getBotNameList() {
      return this.botNameList;
   }

   public BotSkinList getBotSkinList() {
      return this.botSkinList;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public int getMinimumBots() {
      return this.minimumBots;
   }

   public int getMaximumBots() {
      return this.maximumBots;
   }

   public void setEnabled(boolean enabled) {
      this.enabled = enabled;
   }

   public void addWelcomeMessage(String message, boolean isFirstJoin) {
      if (isFirstJoin) {
         this.firstJoinMessages.add(message);
      } else {
         this.reJoinMessages.add(message);
      }

   }
}
