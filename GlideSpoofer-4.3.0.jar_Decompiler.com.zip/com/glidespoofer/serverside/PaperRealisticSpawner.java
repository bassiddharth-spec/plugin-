package com.glidespoofer.serverside;

import com.glidespoofer.core.GlideSpoofer;
import com.mojang.authlib.GameProfile;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.AbstractChannel;
import io.netty.channel.Channel;
import io.netty.channel.ChannelConfig;
import io.netty.channel.ChannelMetadata;
import io.netty.channel.ChannelOutboundBuffer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.ChannelPromise;
import io.netty.channel.DefaultChannelConfig;
import io.netty.channel.DefaultEventLoop;
import io.netty.channel.EventLoop;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class PaperRealisticSpawner {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-PaperRealisticSpawner");
   private final GlideSpoofer plugin;
   private static Class<?> connectionClass;
   private static Class<?> packetFlowClass;
   private static Class<?> minecraftServerClass;
   private static Class<?> playerListClass;
   private static Class<?> entityPlayerClass;
   private static Class<?> worldServerClass;
   private static Class<?> gameProfileClass;
   private static Class<?> clientInformationClass;
   private static Class<?> cookieClass;
   private static Class<?> craftServerClass;
   private static Class<?> craftWorldClass;
   private static Class<?> craftPlayerClass;
   private static Class<?> packetClass;
   private static Class<?> sendPacketMethodParam;
   private static Object SERVERBOUND;
   private static Constructor<?> connectionConstructor;
   private static Constructor<?> cookieConstructor;
   private static Constructor<?> serverPlayerConstructor;
   private static Method placeNewPlayerMethod;
   private static Method getServerMethod;
   private static Method getPlayerListMethod;
   private static Method getHandleWorldMethod;
   private static Method getBukkitEntityMethod;
   private static Method sendPacketMethod;
   private static Field connectionChannelField;
   private static Field connectionAddressField;
   private static Field connectionProtocolField;
   private static Field connectionListenerField;
   private static Field connectionConnectedField;
   private static Field entityPlayerPingField;
   private static Field entityPlayerIsRealPlayerField;
   private static Field entityPlayerLoginTimeField;
   private static Class<?> protocolStateClass;
   private static Object protocolConfiguration;
   private static Object protocolPlay;
   private static boolean initialized = false;
   private static boolean available = false;
   private static final EventLoop sharedEventLoop = new DefaultEventLoop();

   private static synchronized void initializeReflection() {
      if (!initialized) {
         initialized = true;

         try {
            connectionClass = Class.forName("net.minecraft.network.Connection");
            packetFlowClass = Class.forName("net.minecraft.network.protocol.PacketFlow");
            minecraftServerClass = Class.forName("net.minecraft.server.MinecraftServer");
            playerListClass = Class.forName("net.minecraft.server.players.PlayerList");
            entityPlayerClass = Class.forName("net.minecraft.server.level.ServerPlayer");
            worldServerClass = Class.forName("net.minecraft.server.level.ServerLevel");
            gameProfileClass = Class.forName("com.mojang.authlib.GameProfile");
            clientInformationClass = Class.forName("net.minecraft.server.level.ClientInformation");
            packetClass = Class.forName("net.minecraft.network.protocol.Packet");

            try {
               cookieClass = Class.forName("net.minecraft.server.network.CommonListenerCookie");
            } catch (ClassNotFoundException var18) {
               LOGGER.info("[PaperRealisticSpawner] CommonListenerCookie not found, will use fallback");
            }

            String[] versions = new String[]{"v1_21_R7", "v1_21_R6", "v1_21_R5", "v1_21_R4", "v1_21_R3", "v1_21_R2", "v1_21_R1", "v1_20_R4", "v1_20_R3"};

            for(String version : versions) {
               try {
                  craftServerClass = Class.forName("org.bukkit.craftbukkit." + version + ".CraftServer");
                  craftWorldClass = Class.forName("org.bukkit.craftbukkit." + version + ".CraftWorld");
                  craftPlayerClass = Class.forName("org.bukkit.craftbukkit." + version + ".entity.CraftPlayer");
                  LOGGER.info("[PaperRealisticSpawner] Using CraftBukkit version: " + version);
                  break;
               } catch (ClassNotFoundException var21) {
               }
            }

            if (craftServerClass == null) {
               throw new IllegalStateException("Could not find CraftBukkit classes");
            }

            for(Object constant : packetFlowClass.getEnumConstants()) {
               if (constant.toString().equals("SERVERBOUND")) {
                  SERVERBOUND = constant;
                  break;
               }
            }

            if (SERVERBOUND == null && packetFlowClass.getEnumConstants().length >= 2) {
               SERVERBOUND = packetFlowClass.getEnumConstants()[1];
            }

            try {
               connectionConstructor = connectionClass.getConstructor(packetFlowClass);
            } catch (NoSuchMethodException var17) {
               connectionConstructor = connectionClass.getDeclaredConstructor();
            }

            connectionConstructor.setAccessible(true);
            if (cookieClass != null) {
               for(Constructor<?> c : cookieClass.getConstructors()) {
                  Class<?>[] params = c.getParameterTypes();
                  boolean hasProfile = false;

                  for(Class<?> p : params) {
                     if (p == gameProfileClass || p.isAssignableFrom(gameProfileClass)) {
                        hasProfile = true;
                        break;
                     }
                  }

                  if (hasProfile) {
                     cookieConstructor = c;
                     cookieConstructor.setAccessible(true);
                     LOGGER.info("[PaperRealisticSpawner] Found CommonListenerCookie constructor with " + params.length + " params");
                     break;
                  }
               }
            }

            getServerMethod = craftServerClass.getMethod("getServer");
            getBukkitEntityMethod = entityPlayerClass.getMethod("getBukkitEntity");
            getHandleWorldMethod = craftWorldClass.getMethod("getHandle");
            String[] plMethodNames = new String[]{"getPlayerList", "bg", "bf", "be", "bd", "bc", "ah", "ag", "af"};

            for(String name : plMethodNames) {
               try {
                  Method m = minecraftServerClass.getMethod(name);
                  Object testResult = m.invoke(getServerMethod.invoke(craftServerClass.cast(Bukkit.getServer())));
                  if (testResult != null && playerListClass.isInstance(testResult)) {
                     getPlayerListMethod = m;
                     LOGGER.info("[PaperRealisticSpawner] Found getPlayerList method: " + name);
                     break;
                  }
               } catch (Exception var20) {
               }
            }

            if (cookieClass != null) {
               try {
                  placeNewPlayerMethod = playerListClass.getMethod("placeNewPlayer", connectionClass, entityPlayerClass, cookieClass);
                  LOGGER.info("[PaperRealisticSpawner] Found placeNewPlayer(Connection, ServerPlayer, Cookie)");
               } catch (NoSuchMethodException var16) {
                  try {
                     placeNewPlayerMethod = playerListClass.getMethod("placeNewPlayer", connectionClass, entityPlayerClass);
                     LOGGER.info("[PaperRealisticSpawner] Found placeNewPlayer(Connection, ServerPlayer)");
                  } catch (NoSuchMethodException var15) {
                     LOGGER.warning("[PaperRealisticSpawner] Could not find placeNewPlayer method");
                  }
               }
            } else {
               try {
                  placeNewPlayerMethod = playerListClass.getMethod("placeNewPlayer", connectionClass, entityPlayerClass);
                  LOGGER.info("[PaperRealisticSpawner] Found placeNewPlayer(Connection, ServerPlayer) [no cookie]");
               } catch (NoSuchMethodException var14) {
                  LOGGER.warning("[PaperRealisticSpawner] Could not find placeNewPlayer method");
               }
            }

            for(Method m : connectionClass.getMethods()) {
               if (m.getName().equals("send") || m.getName().equals("a")) {
                  Class<?>[] params = m.getParameterTypes();
                  if (params.length == 1 && params[0].isInterface()) {
                     sendPacketMethod = m;
                     sendPacketMethodParam = params[0];
                     LOGGER.info("[PaperRealisticSpawner] Found send method: " + m.getName());
                     break;
                  }
               }
            }

            if (sendPacketMethod == null) {
               for(Method m : connectionClass.getMethods()) {
                  Class<?>[] params = m.getParameterTypes();
                  if (params.length == 1) {
                     String typeName = params[0].getName();
                     if (typeName.contains("Packet")) {
                        sendPacketMethod = m;
                        sendPacketMethodParam = params[0];
                        LOGGER.info("[PaperRealisticSpawner] Found send method by type: " + m.getName());
                        break;
                     }
                  }
               }
            }

            for(Field f : getAllFields(connectionClass)) {
               if (Channel.class.isAssignableFrom(f.getType())) {
                  f.setAccessible(true);
                  connectionChannelField = f;
                  break;
               }
            }

            for(Field f : getAllFields(connectionClass)) {
               if (SocketAddress.class.isAssignableFrom(f.getType())) {
                  f.setAccessible(true);
                  connectionAddressField = f;
                  break;
               }
            }

            for(Field f : getAllFields(connectionClass)) {
               if (f.getType() == Boolean.TYPE) {
                  String name = f.getName().toLowerCase();
                  if (name.contains("connect") || name.equals("k") || name.equals("l")) {
                     f.setAccessible(true);
                     connectionConnectedField = f;
                     break;
                  }
               }
            }

            for(Field f : getAllFields(connectionClass)) {
               String typeName = f.getType().getName().toLowerCase();
               if (typeName.contains("packetlistener") || typeName.contains("listener")) {
                  f.setAccessible(true);
                  connectionListenerField = f;
                  break;
               }
            }

            String[] pingNames = new String[]{"f", "e", "d", "ping", "latency"};

            for(String name : pingNames) {
               try {
                  Field f = entityPlayerClass.getDeclaredField(name);
                  if (f.getType() == Integer.TYPE) {
                     f.setAccessible(true);
                     entityPlayerPingField = f;
                     break;
                  }
               } catch (NoSuchFieldException var19) {
               }
            }

            try {
               entityPlayerIsRealPlayerField = entityPlayerClass.getDeclaredField("isRealPlayer");
               entityPlayerIsRealPlayerField.setAccessible(true);
            } catch (NoSuchFieldException var13) {
            }

            try {
               entityPlayerLoginTimeField = entityPlayerClass.getDeclaredField("loginTime");
               entityPlayerLoginTimeField.setAccessible(true);
            } catch (NoSuchFieldException var12) {
            }

            try {
               protocolStateClass = Class.forName("net.minecraft.network.protocol.ConnectionProtocol");
            } catch (ClassNotFoundException var11) {
            }

            available = connectionConstructor != null && getServerMethod != null && getPlayerListMethod != null && placeNewPlayerMethod != null && entityPlayerClass != null && craftServerClass != null;
            String var10001 = available ? "SUCCESS" : "PARTIAL";
            LOGGER.info("[PaperRealisticSpawner] Initialization " + var10001);
            boolean var65 = placeNewPlayerMethod != null;
            LOGGER.info("[PaperRealisticSpawner] placeNewPlayer: " + var65);
            var65 = cookieClass != null;
            LOGGER.info("[PaperRealisticSpawner] cookieClass: " + var65);
            LOGGER.info("[PaperRealisticSpawner] sendMethod: " + (sendPacketMethod != null));
         } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "[PaperRealisticSpawner] Initialization failed", e);
            available = false;
         }

      }
   }

   public PaperRealisticSpawner(GlideSpoofer plugin) {
      this.plugin = plugin;
   }

   public boolean isAvailable() {
      return available;
   }

   public PlayerSpawnResult spawnPlayer(String name, UUID skinUUID, String rank) {
      if (!available) {
         LOGGER.warning("[PaperRealisticSpawner] Not available, cannot spawn player");
         return null;
      } else {
         if (name.length() > 16) {
            name = name.substring(0, 16);
         }

         String playerName = name;

         try {
            UUID playerUUID = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
            GameProfile profile = new GameProfile(playerUUID, name);
            LOGGER.info("[PaperRealisticSpawner] Spawning player: " + name + " (" + String.valueOf(playerUUID) + ")");
            String ip = generateIP();
            int port = ThreadLocalRandom.current().nextInt(40000, 60000);
            InetSocketAddress address = new InetSocketAddress(ip, port);
            Object connection = this.createConnection(address);
            if (connection == null) {
               LOGGER.severe("[PaperRealisticSpawner] Failed to create Connection");
               return null;
            } else {
               Object craftServer = craftServerClass.cast(Bukkit.getServer());
               Object minecraftServer = getServerMethod.invoke(craftServer);
               Object playerList = getPlayerListMethod.invoke(minecraftServer);
               World world = (World)Bukkit.getWorlds().get(0);
               Object craftWorld = craftWorldClass.cast(world);
               Object serverLevel = getHandleWorldMethod.invoke(craftWorld);
               Object clientInfo = this.createClientInformation();
               Object serverPlayer = this.createServerPlayer(minecraftServer, serverLevel, profile, clientInfo);
               if (serverPlayer == null) {
                  LOGGER.severe("[PaperRealisticSpawner] Failed to create ServerPlayer");
                  return null;
               } else {
                  Location spawn = world.getSpawnLocation();
                  this.setPlayerPosition(serverPlayer, spawn);
                  int ping = generatePing();
                  if (entityPlayerPingField != null) {
                     entityPlayerPingField.setInt(serverPlayer, ping);
                  }

                  if (entityPlayerIsRealPlayerField != null) {
                     entityPlayerIsRealPlayerField.setBoolean(serverPlayer, true);
                  }

                  if (entityPlayerLoginTimeField != null) {
                     entityPlayerLoginTimeField.setLong(serverPlayer, System.currentTimeMillis());
                  }

                  Object cookie = null;
                  if (cookieClass != null && cookieConstructor != null && placeNewPlayerMethod != null) {
                     Class<?>[] paramTypes = placeNewPlayerMethod.getParameterTypes();
                     if (paramTypes.length == 3 && paramTypes[2] == cookieClass) {
                        cookie = this.createCookie(profile);
                     }
                  }

                  LOGGER.info("[PaperRealisticSpawner] Calling placeNewPlayer for " + name + "...");
                  if (cookie != null) {
                     placeNewPlayerMethod.invoke(playerList, connection, serverPlayer, cookie);
                  } else {
                     placeNewPlayerMethod.invoke(playerList, connection, serverPlayer);
                  }

                  LOGGER.info("[PaperRealisticSpawner] placeNewPlayer completed for " + name);
                  Player craftPlayer = (Player)getBukkitEntityMethod.invoke(serverPlayer);
                  Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                     this.sendClientBrand(connection, "vanilla");
                     LOGGER.info("[PaperRealisticSpawner] Sent client brand for " + playerName);
                  }, 5L);
                  this.fetchAndApplySkin(serverPlayer, profile, skinUUID != null ? skinUUID : playerUUID, name);
                  LOGGER.info("[PaperRealisticSpawner] Successfully spawned: " + name);
                  return new PlayerSpawnResult(craftPlayer, serverPlayer, connection, playerUUID, ip, ping);
               }
            }
         } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "[PaperRealisticSpawner] Failed to spawn " + name, e);
            return null;
         }
      }
   }

   private Object createConnection(InetSocketAddress address) {
      try {
         Object connection;
         if (SERVERBOUND != null && connectionConstructor.getParameterCount() == 1) {
            connection = connectionConstructor.newInstance(SERVERBOUND);
         } else {
            connection = connectionConstructor.newInstance();
         }

         Channel fakeChannel = new RealisticFakeChannel(address);
         if (connectionChannelField != null) {
            connectionChannelField.set(connection, fakeChannel);
         }

         if (connectionAddressField != null) {
            connectionAddressField.set(connection, address);
         }

         if (connectionConnectedField != null) {
            connectionConnectedField.setBoolean(connection, true);
         }

         sharedEventLoop.register(fakeChannel);
         return connection;
      } catch (Exception e) {
         LOGGER.log(Level.WARNING, "[PaperRealisticSpawner] Failed to create Connection", e);
         return null;
      }
   }

   private Object createServerPlayer(Object minecraftServer, Object serverLevel, GameProfile profile, Object clientInfo) {
      try {
         Constructor<?> c = entityPlayerClass.getConstructor(minecraftServerClass, worldServerClass, gameProfileClass, clientInformationClass);
         return c.newInstance(minecraftServer, serverLevel, profile, clientInfo);
      } catch (Exception e) {
         LOGGER.fine("[PaperRealisticSpawner] 4-param constructor failed: " + e.getMessage());

         try {
            Constructor<?> c = entityPlayerClass.getConstructor(minecraftServerClass, worldServerClass, gameProfileClass);
            return c.newInstance(minecraftServer, serverLevel, profile);
         } catch (Exception e) {
            LOGGER.fine("[PaperRealisticSpawner] 3-param constructor failed: " + e.getMessage());

            for(Constructor<?> c : entityPlayerClass.getDeclaredConstructors()) {
               Class<?>[] params = c.getParameterTypes();
               boolean hasMcServer = false;
               boolean hasLevel = false;
               boolean hasProfile = false;

               for(Class<?> p : params) {
                  if (minecraftServerClass.isAssignableFrom(p)) {
                     hasMcServer = true;
                  }

                  if (worldServerClass.isAssignableFrom(p)) {
                     hasLevel = true;
                  }

                  if (gameProfileClass.isAssignableFrom(p)) {
                     hasProfile = true;
                  }
               }

               if (hasMcServer && hasLevel && hasProfile) {
                  c.setAccessible(true);
                  Object[] args = new Object[params.length];

                  for(int i = 0; i < params.length; ++i) {
                     if (minecraftServerClass.isAssignableFrom(params[i])) {
                        args[i] = minecraftServer;
                     } else if (worldServerClass.isAssignableFrom(params[i])) {
                        args[i] = serverLevel;
                     } else if (gameProfileClass.isAssignableFrom(params[i])) {
                        args[i] = profile;
                     } else if (clientInformationClass != null && clientInformationClass.isAssignableFrom(params[i])) {
                        args[i] = clientInfo;
                     } else {
                        args[i] = getDefaultValue(params[i]);
                     }
                  }

                  try {
                     return c.newInstance(args);
                  } catch (Exception e) {
                     LOGGER.fine("[PaperRealisticSpawner] Fallback constructor failed: " + e.getMessage());
                  }
               }
            }

            return null;
         }
      }
   }

   private Object createCookie(GameProfile profile) {
      if (cookieConstructor == null) {
         return null;
      } else {
         try {
            Class<?>[] paramTypes = cookieConstructor.getParameterTypes();
            Object[] args = new Object[paramTypes.length];

            for(int i = 0; i < paramTypes.length; ++i) {
               if (paramTypes[i] != gameProfileClass && !paramTypes[i].isAssignableFrom(gameProfileClass)) {
                  if (paramTypes[i] == Boolean.TYPE) {
                     args[i] = false;
                  } else {
                     args[i] = getDefaultValue(paramTypes[i]);
                  }
               } else {
                  args[i] = profile;
               }
            }

            return cookieConstructor.newInstance(args);
         } catch (Exception e) {
            LOGGER.warning("[PaperRealisticSpawner] Failed to create cookie: " + e.getMessage());
            return null;
         }
      }
   }

   private Object createClientInformation() {
      try {
         Method m = clientInformationClass.getMethod("createDefault");
         return m.invoke((Object)null);
      } catch (Exception var9) {
         try {
            Field f = clientInformationClass.getDeclaredField("DEFAULT");
            return f.get((Object)null);
         } catch (Exception var8) {
            for(Method m : clientInformationClass.getMethods()) {
               if (Modifier.isStatic(m.getModifiers()) && m.getReturnType() == clientInformationClass && m.getParameterCount() == 0) {
                  try {
                     return m.invoke((Object)null);
                  } catch (Exception var7) {
                  }
               }
            }

            try {
               Class<?> chatVisibility = Class.forName("net.minecraft.world.entity.player.EnumChatVisibility");
               Class<?> mainHand = Class.forName("net.minecraft.world.entity.EnumMainHand");
               Class<?> particleStatus = Class.forName("net.minecraft.server.level.ParticleStatus");
               Constructor<?> c = clientInformationClass.getConstructor(String.class, Integer.TYPE, chatVisibility, Boolean.TYPE, Integer.TYPE, mainHand, Boolean.TYPE, Boolean.TYPE, particleStatus);
               return c.newInstance("en_US", 10, chatVisibility.getEnumConstants()[0], true, 127, mainHand.getEnumConstants()[0], false, true, particleStatus.getEnumConstants()[0]);
            } catch (Exception e) {
               LOGGER.warning("[PaperRealisticSpawner] Failed to create ClientInformation: " + e.getMessage());
               return null;
            }
         }
      }
   }

   private void sendClientBrand(Object connection, String brand) {
      try {
         Class<?> resourceLocationClass = Class.forName("net.minecraft.resources.ResourceLocation");
         Constructor<?> rlConstructor = resourceLocationClass.getConstructor(String.class);
         Object brandLocation = rlConstructor.newInstance("minecraft:brand");
         byte[] brandBytes = brand.getBytes(StandardCharsets.UTF_8);
         ByteBuf brandBuf = Unpooled.buffer(brandBytes.length + 1);
         writeVarInt(brandBuf, brandBytes.length);
         brandBuf.writeBytes(brandBytes);

         try {
            Class<?> brandPayloadClass = Class.forName("net.minecraft.network.protocol.common.custom.BrandPayload");
            Constructor<?> bpConstructor = brandPayloadClass.getConstructor(String.class);
            Object brandPayload = bpConstructor.newInstance(brand);
            Class<?> customPacketClass = Class.forName("net.minecraft.network.protocol.common.ClientboundCustomPayloadPacket");
            Constructor<?> cpConstructor = customPacketClass.getConstructor(brandPayloadClass);
            Object packet = cpConstructor.newInstance(brandPayload);
            this.sendPacket(connection, packet);
            return;
         } catch (Exception var15) {
            try {
               Class<?> customPayloadClass = Class.forName("net.minecraft.network.protocol.game.ClientboundCustomPayloadPacket");
               Constructor<?> cpConstructor = customPayloadClass.getConstructor(resourceLocationClass, Class.forName("net.minecraft.network.FriendlyByteBuf"));
               Object friendlyBuf = Class.forName("net.minecraft.network.FriendlyByteBuf").getConstructor(ByteBuf.class).newInstance(brandBuf);
               Object packet = cpConstructor.newInstance(brandLocation, friendlyBuf);
               this.sendPacket(connection, packet);
            } catch (Exception var14) {
            }
         }
      } catch (Exception e) {
         LOGGER.fine("[PaperRealisticSpawner] Could not send client brand: " + e.getMessage());
      }

   }

   private void sendPacket(Object connection, Object packet) {
      if (sendPacketMethod != null) {
         try {
            sendPacketMethod.invoke(connection, packet);
         } catch (Exception e) {
            LOGGER.fine("[PaperRealisticSpawner] Failed to send packet: " + e.getMessage());
         }
      }

   }

   private void setPlayerPosition(Object serverPlayer, Location loc) {
      for(Method m : getAllMethods(serverPlayer.getClass())) {
         if (m.getName().equals("moveTo") && m.getParameterCount() == 5) {
            Class<?>[] params = m.getParameterTypes();
            if (params[0] == Double.TYPE && params[3] == Float.TYPE) {
               try {
                  m.invoke(serverPlayer, loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch());
                  return;
               } catch (Exception var9) {
               }
            }
         }
      }

      for(Method m : getAllMethods(serverPlayer.getClass())) {
         if (m.getName().equals("snapTo") && m.getParameterCount() == 5) {
            try {
               m.invoke(serverPlayer, loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch());
               return;
            } catch (Exception var8) {
            }
         }
      }

      for(Method m : getAllMethods(serverPlayer.getClass())) {
         if (m.getName().equals("setPos") && m.getParameterCount() == 3) {
            try {
               m.invoke(serverPlayer, loc.getX(), loc.getY(), loc.getZ());
            } catch (Exception var7) {
            }

            return;
         }
      }

   }

   private void fetchAndApplySkin(Object serverPlayer, GameProfile profile, UUID skinUUID, String name) {
      Bukkit.getScheduler().runTaskAsynchronously(this.plugin, () -> {
         try {
            MojangAPI.setSkin(this.plugin, profile, skinUUID.toString(), (updatedProfile) -> Bukkit.getScheduler().runTask(this.plugin, () -> {
                  try {
                     for(Field f : getAllFields(entityPlayerClass)) {
                        if (f.getType() == gameProfileClass) {
                           f.setAccessible(true);

                           try {
                              Field mod = Field.class.getDeclaredField("modifiers");
                              mod.setAccessible(true);
                              mod.setInt(f, f.getModifiers() & -17);
                           } catch (NoSuchFieldException var5) {
                           }

                           f.set(serverPlayer, updatedProfile);
                           break;
                        }
                     }
                  } catch (Exception e) {
                     LOGGER.fine("[PaperRealisticSpawner] Failed to update skin: " + e.getMessage());
                  }

               }));
         } catch (Exception e) {
            LOGGER.fine("[PaperRealisticSpawner] Failed to fetch skin: " + e.getMessage());
         }

      });
   }

   private static int generatePing() {
      double r = Math.random();
      if (r < 0.4) {
         return 15 + ThreadLocalRandom.current().nextInt(50);
      } else if (r < (double)0.75F) {
         return 65 + ThreadLocalRandom.current().nextInt(80);
      } else {
         return r < 0.92 ? 145 + ThreadLocalRandom.current().nextInt(100) : 245 + ThreadLocalRandom.current().nextInt(150);
      }
   }

   private static String generateIP() {
      int[] firsts = new int[]{24, 31, 45, 64, 68, 71, 72, 74, 75, 76, 98, 99, 107, 108, 134, 173, 174, 184};
      int f = firsts[ThreadLocalRandom.current().nextInt(firsts.length)];
      return f + "." + ThreadLocalRandom.current().nextInt(256) + "." + ThreadLocalRandom.current().nextInt(256) + "." + (1 + ThreadLocalRandom.current().nextInt(254));
   }

   private static void writeVarInt(ByteBuf buf, int value) {
      while((value & -128) != 0) {
         buf.writeByte(value & 127 | 128);
         value >>>= 7;
      }

      buf.writeByte(value);
   }

   private static Object getDefaultValue(Class<?> type) {
      if (type == Boolean.TYPE) {
         return false;
      } else if (type == Integer.TYPE) {
         return 0;
      } else if (type == Long.TYPE) {
         return 0L;
      } else if (type == Float.TYPE) {
         return 0.0F;
      } else if (type == Double.TYPE) {
         return (double)0.0F;
      } else {
         return type == String.class ? "" : null;
      }
   }

   private static List<Field> getAllFields(Class<?> clazz) {
      List<Field> fields;
      for(fields = new ArrayList(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
         for(Field f : clazz.getDeclaredFields()) {
            fields.add(f);
         }
      }

      return fields;
   }

   private static List<Method> getAllMethods(Class<?> clazz) {
      List<Method> methods;
      for(methods = new ArrayList(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
         for(Method m : clazz.getDeclaredMethods()) {
            methods.add(m);
         }
      }

      return methods;
   }

   static {
      try {
         initializeReflection();
      } catch (Exception e) {
         LOGGER.warning("[PaperRealisticSpawner] Failed to initialize: " + e.getMessage());
      }

   }

   public static class PlayerSpawnResult {
      public final Player craftPlayer;
      public final Object serverPlayer;
      public final Object connection;
      public final UUID uuid;
      public final String ipAddress;
      public final int ping;

      public PlayerSpawnResult(Player craftPlayer, Object serverPlayer, Object connection, UUID uuid, String ipAddress, int ping) {
         this.craftPlayer = craftPlayer;
         this.serverPlayer = serverPlayer;
         this.connection = connection;
         this.uuid = uuid;
         this.ipAddress = ipAddress;
         this.ping = ping;
      }
   }

   private static class RealisticFakeChannel extends AbstractChannel {
      private final ChannelConfig config = new DefaultChannelConfig(this);
      private final ChannelMetadata metadata;
      private final SocketAddress localAddress;
      private final SocketAddress remoteAddress;

      RealisticFakeChannel(SocketAddress remoteAddress) {
         super((Channel)null);
         this.config.setAutoRead(true);
         this.metadata = new ChannelMetadata(true);
         this.localAddress = new InetSocketAddress("127.0.0.1", 25565);
         this.remoteAddress = remoteAddress;
      }

      public ChannelConfig config() {
         return this.config;
      }

      public boolean isOpen() {
         return true;
      }

      public boolean isActive() {
         return true;
      }

      public ChannelMetadata metadata() {
         return this.metadata;
      }

      protected SocketAddress localAddress0() {
         return this.localAddress;
      }

      protected SocketAddress remoteAddress0() {
         return this.remoteAddress;
      }

      protected void doBind(SocketAddress addr) {
      }

      protected void doDisconnect() {
      }

      protected void doClose() {
      }

      protected void doBeginRead() {
      }

      protected void doWrite(ChannelOutboundBuffer in) {
         while(true) {
            Object msg = in.current();
            if (msg == null) {
               return;
            }

            in.remove();
         }
      }

      protected boolean isCompatible(EventLoop loop) {
         return true;
      }

      protected AbstractChannel.AbstractUnsafe newUnsafe() {
         return new AbstractChannel.AbstractUnsafe() {
            {
               super(this$0);
            }

            public void connect(SocketAddress remote, SocketAddress local, ChannelPromise promise) {
               this.safeSetSuccess(promise);
            }
         };
      }

      public EventLoop eventLoop() {
         return PaperRealisticSpawner.sharedEventLoop;
      }

      public ChannelPipeline pipeline() {
         return super.pipeline();
      }
   }
}
