package com.glidespoofer.serverside;

import com.glidespoofer.core.GlideSpoofer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.configuration.file.FileConfiguration;

public class BotSkinList {
   private final GlideSpoofer plugin;
   private final List<UUID> skinUuids = new ArrayList();
   private final Map<UUID, CachedSkin> skinCache = new ConcurrentHashMap();
   private final Random random = new Random();
   private boolean cacheSkins = true;
   private int cacheExpiryMinutes = 60;
   private static final String[] DEFAULT_SKIN_UUIDS = new String[]{"069a79f4-44e9-4726-a5be-fca90e38aaf5", "853c80ef-3f37-4989-80c9-5f8b8f3c9d1a", "b05223a3-0f7a-4e3c-8c7d-5e8f9a0b1c2d", "c1e3f5a7-9b2d-4e8f-a1c3-5d7e9f0a1b2c", "d2f4e6a8-0c3e-4f9a-b2d4-6e8f0a1b2c3d", "e3a5f7b9-1d4f-4a0b-c3e5-7f9a1b2c3d4e", "f4b6a8c0-2e5f-4b1a-d4f6-8a0b1c2d3e4f", "05c7b9d1-3f6a-4c2b-e5a7-9b1c2d3e4f5a", "16d8c0e2-4a7b-4d3c-f6b8-0c2d3e4f5a6b", "27e9d1f3-5b8c-4e4d-a7c9-1d3e4f5a6b7c", "8667ba71-b85a-4004-af54-457a9738eed0", "853c80ef-3f37-4989-80c9-5f8b8f3c9d1a", "696a68ce-6f47-42ee-a9cc-1d76de3887eb", "e6b5c55d-7d4e-4c8a-b8e2-7f8a9b0c1d2e", "f7c6d66e-8e5f-4d9b-c9f3-8a9b0c1d2e3f", "08d7e77f-9f6a-4e0c-d0a4-9b0c1d2e3f4a", "19e8f88a-0a7b-4f1d-e1b5-0c1d2e3f4a5b", "2af9a99b-1b8c-4a2e-f2c6-1d2e3f4a5b6c", "3bf0baac-2c9d-4b3f-a3d7-2e3f4a5b6c7d", "4ca1cbbd-3d0e-4c4a-b4e8-3f4a5b6c7d8e", "5db2dcce-4e1f-4d5b-c5f9-4a5b6c7d8e9f", "6ec3eddf-5f2a-4e6c-d6a0-5b6c7d8e9f0a", "7fd4fee0-6a3b-4f7d-e7b1-6c7d8e9f0a1b", "80e5aff1-7b4c-4a8e-f8c2-7d8e9f0a1b2c", "91f6b002-8c5d-4b9f-a9d3-8e9f0a1b2c3d", "a207c113-9d6e-4c0a-b0e4-9f0a1b2c3d4e", "b318d224-ae7f-4d1b-c1f5-0a1b2c3d4e5f", "c429e335-bf80-4e2c-d206-1b2c3d4e5f6a", "d53af446-c091-4f3d-e317-2c3d4e5f6a7b", "e64b0557-d1a2-4a4e-f428-3d4e5f6a7b8c", "f75c1668-e2b3-4b5f-a539-4e5f6a7b8c9d", "086d2779-f3c4-4c6a-b64a-5f6a7b8c9d0e", "197e3880-a4d5-4d7b-c75b-6a7b8c9d0e1f", "2a8f4991-b5e6-4e8c-d86c-7b8c9d0e1f2a", "3b905aa2-c6f7-4f9d-e97d-8c9d0e1f2a3b", "4ca16bb3-d708-4a0e-f08e-9d0e1f2a3b4c", "5db27cc4-e819-4b1f-a19f-0e1f2a3b4c5d", "6ec38dd5-f92a-4c2a-b2a0-1f2a3b4c5d6e", "7fd49ee6-0a3b-4d3b-c3b1-2a3b4c5d6e7f", "80e5aff7-1b4c-4e4c-d4c2-3b4c5d6e7f8a", "91f6b008-2c5d-4f5d-e5d3-4c5d6e7f8a9b", "a207c119-3d6e-4a6e-f6e4-5d6e7f8a9b0c", "b318d220-4e7f-4b7f-a7f5-6e7f8a9b0c1d", "c429e331-5f80-4c8f-b806-7f8a9b0c1d2e", "d53af442-6091-4d9f-c917-8a9b0c1d2e3f", "e64b0553-71a2-4e0a-d028-9b0c1d2e3f4a", "f75c1664-82b3-4f1b-e139-0c1d2e3f4a5b", "84334a32-6d4d-4599-b2c0-5e7f2b1d3c4a", "94245b43-7e5e-4a0a-c3d1-6f8a3c2e4d5b", "a1356c54-8f6f-4b1b-d4e2-709b4d3f5e6c", "b2467d65-9070-4c2c-e5f3-81ac5e4a6f7d", "c3578e76-a181-4d3d-f604-92bd6f5b708e", "d4689f87-b292-4e4e-a715-a3ce706c819f", "e579a098-c3a3-4f5f-b826-b4df817d92a0", "f68ab109-d4b4-4a0a-c937-c5e0928ea3b1", "079bc210-e5c5-4b1b-d048-d6f1a39fb4c2", "18acd321-f6d6-4c2c-e159-e7a2b40ac5d3", "29bde432-a7e7-4d3d-f26a-f8b3c51bd6e4", "3acef543-b8f8-4e4e-a37b-09c4d62ce7f5", "4bdf0654-c909-4f5f-b48c-1ad5e73df8a6", "5ce01765-da1a-4a0a-c59d-2be6f84ea9b7", "6df12876-eb2b-4b1b-d6ae-3cf7095fba08", "7ee23987-fc3c-4c2c-e7bf-4da81a6gcb19", "8ff34a98-0d4d-4d3d-f8c0-5eb92b7hdc2a", "90a45b09-1e5e-4e4e-a9d1-6fc03c8ied3b", "a1b56c10-2f6f-4f5f-bae2-80d14d9jfe4c", "b2c67d21-3070-4a0a-cbf3-91e25eakgf5d", "c3d78e32-4181-4b1b-dc04-a2f36fblhg6e", "d4e89f43-5292-4c2c-ed15-b3g47gcmih7f", "e5f9a054-63a3-4d3d-fe26-c4h58hdnji8a", "f60ab165-74b4-4e4e-af37-d5i69ieokj9b", "071bc276-85c5-4f5f-b048-e6j7ajfplk0c", "182cd387-96d6-4a0a-c159-f7k8bkgqml1d", "293de498-a7e7-4b1b-d26a-08l9clhrnm2e", "3a4ef509-b8f8-4c2c-a37b-19m0dmisno3f", "4b5f0610-c909-4d3d-b48c-2an1enjtop4a", "5c601721-da1a-4e4e-c59d-3bo2fokupq5b"};

   public BotSkinList(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.loadDefaultSkins();
   }

   public void load() {
      this.skinUuids.clear();
      File skinsFile = new File(this.plugin.getDataFolder(), "bot_skins.txt");
      if (skinsFile.exists()) {
         try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(skinsFile), StandardCharsets.UTF_8));

            try {
               String line;
               while((line = reader.readLine()) != null) {
                  line = line.trim();
                  if (!line.isEmpty() && !line.startsWith("#")) {
                     try {
                        UUID uuid = this.parseUUID(line);
                        if (uuid != null) {
                           this.skinUuids.add(uuid);
                        }
                     } catch (IllegalArgumentException var6) {
                        this.plugin.getLogger().warning("[BotSkinList] Invalid UUID: " + line);
                     }
                  }
               }

               this.plugin.getLogger().info("[BotSkinList] Loaded " + this.skinUuids.size() + " skin UUIDs from file");
            } catch (Throwable var7) {
               try {
                  reader.close();
               } catch (Throwable var5) {
                  var7.addSuppressed(var5);
               }

               throw var7;
            }

            reader.close();
         } catch (IOException e) {
            this.plugin.getLogger().warning("[BotSkinList] Error loading skins file: " + e.getMessage());
            this.loadDefaultSkins();
         }
      } else {
         this.loadDefaultSkins();
         this.saveDefaultSkinsFile(skinsFile);
      }

      FileConfiguration config = this.plugin.getConfig();
      this.cacheSkins = config.getBoolean("server-side-bots.skins.cache-skins", true);
      this.cacheExpiryMinutes = config.getInt("server-side-bots.skins.cache-expiry-minutes", 60);
   }

   private UUID parseUUID(String str) {
      try {
         if (str.contains("-")) {
            return UUID.fromString(str);
         } else {
            String withDashes = str.replaceAll("(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})", "$1-$2-$3-$4-$5");
            return UUID.fromString(withDashes);
         }
      } catch (IllegalArgumentException var3) {
         return null;
      }
   }

   private void loadDefaultSkins() {
      this.skinUuids.clear();

      for(String uuidStr : DEFAULT_SKIN_UUIDS) {
         UUID uuid = this.parseUUID(uuidStr);
         if (uuid != null) {
            this.skinUuids.add(uuid);
         }
      }

   }

   private void saveDefaultSkinsFile(File file) {
      try {
         file.getParentFile().mkdirs();
         PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8));

         try {
            writer.println("# Bot Skins Configuration");
            writer.println("# One UUID per line (with or without dashes)");
            writer.println("# These UUIDs are used to fetch skins from Mojang's API");
            writer.println("# Lines starting with # are comments");
            writer.println("#");

            for(UUID uuid : this.skinUuids) {
               writer.println(uuid.toString());
            }
         } catch (Throwable var6) {
            try {
               writer.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }

            throw var6;
         }

         writer.close();
         this.plugin.getLogger().info("[BotSkinList] Saved default skins to " + file.getName());
      } catch (IOException e) {
         this.plugin.getLogger().warning("[BotSkinList] Could not save default skins file: " + e.getMessage());
      }

   }

   public UUID getRandomSkin() {
      return this.skinUuids.isEmpty() ? null : (UUID)this.skinUuids.get(this.random.nextInt(this.skinUuids.size()));
   }

   public UUID getRandomSkin(Set<UUID> exclude) {
      if (this.skinUuids.isEmpty()) {
         return null;
      } else {
         List<UUID> available = new ArrayList();

         for(UUID uuid : this.skinUuids) {
            if (exclude == null || !exclude.contains(uuid)) {
               available.add(uuid);
            }
         }

         if (available.isEmpty()) {
            return (UUID)this.skinUuids.get(this.random.nextInt(this.skinUuids.size()));
         } else {
            return (UUID)available.get(this.random.nextInt(available.size()));
         }
      }
   }

   public void addSkin(UUID uuid) {
      if (uuid != null && !this.skinUuids.contains(uuid)) {
         this.skinUuids.add(uuid);
      }

   }

   public void addSkin(String uuidStr) {
      UUID uuid = this.parseUUID(uuidStr);
      if (uuid != null) {
         this.addSkin(uuid);
      }

   }

   public void removeSkin(UUID uuid) {
      this.skinUuids.remove(uuid);
      this.skinCache.remove(uuid);
   }

   public int getSkinCount() {
      return this.skinUuids.size();
   }

   public List<UUID> getAllSkins() {
      return new ArrayList(this.skinUuids);
   }

   public void clearCache() {
      this.skinCache.clear();
   }

   public void cleanExpiredCache() {
      this.skinCache.entrySet().removeIf((entry) -> ((CachedSkin)entry.getValue()).isExpired(this.cacheExpiryMinutes));
   }

   private static class CachedSkin {
      final UUID uuid;
      final String texture;
      final String signature;
      final long cachedTime;

      CachedSkin(UUID uuid, String texture, String signature) {
         this.uuid = uuid;
         this.texture = texture;
         this.signature = signature;
         this.cachedTime = System.currentTimeMillis();
      }

      boolean isExpired(int expiryMinutes) {
         return System.currentTimeMillis() > this.cachedTime + (long)(expiryMinutes * 60) * 1000L;
      }
   }
}
