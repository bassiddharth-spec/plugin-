package com.glidespoofer.serverside;

import com.glidespoofer.core.GlideSpoofer;
import com.mojang.authlib.GameProfile;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class ServerSideFakePlayer {
   private static final Random random = new Random();
   private final GlideSpoofer plugin;
   private final String name;
   private final UUID uuid;
   private final String rank;
   private final String ipAddress;
   private final int port;
   private Object entityPlayer;
   private Object craftPlayer;
   private GameProfile gameProfile;
   private Object networkManager;
   private Object playerConnection;
   private long joinTime;
   private int ping;
   private static Class<?> minecraftServerClass;
   private static Class<?> worldServerClass;
   private static Class<?> entityPlayerClass;
   private static Class<?> gameProfileClass;
   private static Class<?> craftWorldClass;
   private static Class<?> craftServerClass;
   private static Class<?> craftPlayerClass;
   private static Class<?> playerConnectionClass;
   private static Class<?> networkManagerClass;
   private static Class<?> enumProtocolDirectionClass;
   private static Class<?> propertyClass;
   private static Class<?> propertyMapClass;
   private static Class<?> clientInformationClass;

   public ServerSideFakePlayer(GlideSpoofer plugin, String name, UUID skinUUID, String rank) {
      this.plugin = plugin;
      this.name = name.length() > 16 ? name.substring(0, 16) : name;
      this.uuid = UUID.randomUUID();
      this.rank = rank != null ? rank : "default";
      this.joinTime = System.currentTimeMillis();
      this.ping = this.generateRandomPing();
      this.port = ThreadLocalRandom.current().nextInt(40000, 60000);
      this.ipAddress = this.generateIP();
      this.setupPlayerWithSkin(skinUUID);
   }

   public ServerSideFakePlayer(GlideSpoofer plugin, String name, String rank, Object serverPlayer, Player bukkitPlayer, Object connection) {
      this.plugin = plugin;
      this.name = name.length() > 16 ? name.substring(0, 16) : name;
      this.rank = rank != null ? rank : "default";
      this.joinTime = System.currentTimeMillis();
      this.ping = this.generateRandomPing();
      this.port = ThreadLocalRandom.current().nextInt(40000, 60000);
      this.ipAddress = this.generateIP();
      this.entityPlayer = serverPlayer;
      this.craftPlayer = bukkitPlayer;
      UUID extractedUUID = null;

      try {
         Method getUUID = serverPlayer.getClass().getMethod("getUUID");
         extractedUUID = (UUID)getUUID.invoke(serverPlayer);
      } catch (Exception var16) {
      }

      this.uuid = extractedUUID != null ? extractedUUID : UUID.randomUUID();

      try {
         Method getProfile = serverPlayer.getClass().getMethod("getGameProfile");
         this.gameProfile = (GameProfile)getProfile.invoke(serverPlayer);
      } catch (Exception var15) {
         this.gameProfile = new GameProfile(this.uuid, this.name);
      }

      this.networkManager = connection;

      try {
         String[] connectionFields = new String[]{"c", "connection", "b"};

         for(String fieldName : connectionFields) {
            try {
               Field f = serverPlayer.getClass().getDeclaredField(fieldName);
               if (f != null) {
                  f.setAccessible(true);
                  Object conn = f.get(serverPlayer);
                  if (conn != null) {
                     this.playerConnection = conn;
                     break;
                  }
               }
            } catch (NoSuchFieldException var17) {
            }
         }
      } catch (Exception var18) {
      }

      this.fetchAndApplySkin((UUID)null, (updatedProfile) -> {
         this.updateGameProfileOnEntity(updatedProfile);
         plugin.getLogger().info("[ServerSideFakePlayer] Skin applied for " + name);
      });
   }

   private int generateRandomPing() {
      double r = Math.random();
      if (r < 0.4) {
         return 15 + random.nextInt(50);
      } else if (r < (double)0.75F) {
         return 65 + random.nextInt(80);
      } else {
         return r < 0.92 ? 145 + random.nextInt(100) : 245 + random.nextInt(150);
      }
   }

   private String generateIP() {
      int[] firstOctets = new int[]{24, 31, 45, 64, 68, 71, 72, 74, 75, 76, 98, 99, 107, 108, 134, 173, 174, 184};
      int first = firstOctets[random.nextInt(firstOctets.length)];
      return first + "." + random.nextInt(256) + "." + random.nextInt(256) + "." + (1 + random.nextInt(254));
   }

   private void setupPlayerWithSkin(UUID skinUUID) {
      try {
         this.gameProfile = new GameProfile(this.uuid, this.name);
         this.createEntityPlayerServerSideBots();
         this.fetchAndApplySkin(skinUUID, (updatedProfile) -> {
            this.updateGameProfileOnEntity(updatedProfile);
            this.plugin.getLogger().info("[ServerSideFakePlayer] Skin applied for " + this.name);
         });
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.WARNING, "[ServerSideFakePlayer] Error setting up player " + this.name, e);
      }

   }

   private void createEntityPlayerServerSideBots() {
      try {
         Object craftServer = craftServerClass.cast(Bukkit.getServer());
         Method getServerMethod = craftServerClass.getMethod("getServer");
         Object minecraftServer = getServerMethod.invoke(craftServer);
         World world = (World)Bukkit.getWorlds().get(0);
         Location spawnLoc = world.getSpawnLocation();
         Object craftWorld = craftWorldClass.cast(world);
         Method getHandleMethod = craftWorldClass.getMethod("getHandle");
         Object worldServer = getHandleMethod.invoke(craftWorld);
         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Creating ServerPlayer for " + this.name);
         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: World: " + world.getName());
         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Spawn: " + String.valueOf(spawnLoc));
         Object clientInfo = this.createClientInformation();
         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: ClientInformation created");
         this.entityPlayer = this.createServerPlayer(minecraftServer, worldServer, clientInfo);
         if (this.entityPlayer == null) {
            this.plugin.getLogger().severe("[ServerSideFakePlayer] DEBUG: Failed to create ServerPlayer instance!");
            return;
         }

         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: ServerPlayer instance created: " + this.entityPlayer.getClass().getName());
         this.setGameProfileOnEntity();
         this.setPlayerPosition(spawnLoc);
         this.setPingField(this.entityPlayer, this.ping);
         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Ping set to " + this.ping);
         this.setupFakeConnection(minecraftServer, this.entityPlayer);
         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Fake connection setup complete");
         this.setPaperSpecificFields();
         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Paper fields set");
         Method getBukkitEntityMethod = entityPlayerClass.getMethod("getBukkitEntity");
         this.craftPlayer = getBukkitEntityMethod.invoke(this.entityPlayer);
         if (this.craftPlayer != null) {
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: CraftPlayer obtained: " + this.craftPlayer.getClass().getName());
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: CraftPlayer name: " + ((Player)this.craftPlayer).getName());
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: CraftPlayer location: " + String.valueOf(((Player)this.craftPlayer).getLocation()));
         } else {
            this.plugin.getLogger().severe("[ServerSideFakePlayer] DEBUG: CraftPlayer is NULL!");
         }

         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: ServerPlayer creation complete for " + this.name);
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.SEVERE, "[ServerSideFakePlayer] Error creating ServerPlayer", e);
      }

   }

   private Object createServerPlayer(Object minecraftServer, Object worldServer, Object clientInfo) {
      this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Trying ServerPlayer constructors...");

      for(Constructor<?> c : entityPlayerClass.getConstructors()) {
         StringBuilder sb = new StringBuilder("[ServerSideFakePlayer] DEBUG: Constructor: ");

         for(Class<?> p : c.getParameterTypes()) {
            sb.append(p.getSimpleName()).append(", ");
         }

         this.plugin.getLogger().info(sb.toString());
      }

      try {
         Constructor<?> constructor = entityPlayerClass.getConstructor(minecraftServerClass, worldServerClass, gameProfileClass, clientInformationClass);
         Object player = constructor.newInstance(minecraftServer, worldServer, this.gameProfile, clientInfo);
         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Created ServerPlayer via 1.21+ constructor");
         return player;
      } catch (Exception e) {
         this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: 1.21+ constructor failed: " + e.getMessage());

         try {
            for(Constructor<?> constructor : entityPlayerClass.getConstructors()) {
               Class<?>[] params = constructor.getParameterTypes();
               if (params.length == 4 && params[0].isAssignableFrom(minecraftServerClass) && params[1].isAssignableFrom(worldServerClass) && gameProfileClass.isAssignableFrom(params[2]) && clientInformationClass.isAssignableFrom(params[3])) {
                  constructor.setAccessible(true);
                  Object player = constructor.newInstance(minecraftServer, worldServer, this.gameProfile, clientInfo);
                  this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Created ServerPlayer via alt constructor");
                  return player;
               }
            }
         } catch (Exception e) {
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Alt constructor failed: " + e.getMessage());
         }

         try {
            Constructor<?> constructor = entityPlayerClass.getConstructor(minecraftServerClass, worldServerClass, gameProfileClass);
            Object player = constructor.newInstance(minecraftServer, worldServer, this.gameProfile);
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Created ServerPlayer via 1.20 constructor");
            return player;
         } catch (Exception e) {
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: 1.20 constructor failed: " + e.getMessage());

            try {
               for(Constructor<?> constructor : entityPlayerClass.getDeclaredConstructors()) {
                  Class<?>[] params = constructor.getParameterTypes();
                  boolean hasMcServer = false;
                  boolean hasWorldServer = false;
                  boolean hasGameProfile = false;

                  for(Class<?> p : params) {
                     if (minecraftServerClass.isAssignableFrom(p)) {
                        hasMcServer = true;
                     }

                     if (worldServerClass.isAssignableFrom(p)) {
                        hasWorldServer = true;
                     }

                     if (gameProfileClass.isAssignableFrom(p)) {
                        hasGameProfile = true;
                     }
                  }

                  if (hasMcServer && hasWorldServer && hasGameProfile) {
                     constructor.setAccessible(true);
                     Object[] args = new Object[params.length];

                     for(int i = 0; i < params.length; ++i) {
                        if (minecraftServerClass.isAssignableFrom(params[i])) {
                           args[i] = minecraftServer;
                        } else if (worldServerClass.isAssignableFrom(params[i])) {
                           args[i] = worldServer;
                        } else if (gameProfileClass.isAssignableFrom(params[i])) {
                           args[i] = this.gameProfile;
                        } else if (clientInformationClass != null && clientInformationClass.isAssignableFrom(params[i])) {
                           args[i] = clientInfo;
                        } else {
                           args[i] = this.getDefaultValue(params[i]);
                        }
                     }

                     Object player = constructor.newInstance(args);
                     this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Created ServerPlayer via reflection constructor");
                     return player;
                  }
               }
            } catch (Exception e) {
               this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Reflection constructor failed: " + e.getMessage());
            }

            this.plugin.getLogger().severe("[ServerSideFakePlayer] DEBUG: All ServerPlayer constructors failed!");
            return null;
         }
      }
   }

   private Object getDefaultValue(Class<?> type) {
      if (type == Boolean.TYPE) {
         return false;
      } else if (type == Integer.TYPE) {
         return 0;
      } else if (type == Long.TYPE) {
         return 0L;
      } else if (type == Float.TYPE) {
         return 0.0F;
      } else if (type == Double.TYPE) {
         return (double)0.0F;
      } else {
         return type == String.class ? "" : null;
      }
   }

   private void setGameProfileOnEntity() {
      try {
         Method getProfileMethod = entityPlayerClass.getMethod("getGameProfile");
         Object currentProfile = getProfileMethod.invoke(this.entityPlayer);
         if (currentProfile != null && currentProfile.equals(this.gameProfile)) {
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: GameProfile already set correctly");
         } else {
            for(Field f : entityPlayerClass.getDeclaredFields()) {
               if (gameProfileClass.isAssignableFrom(f.getType())) {
                  f.setAccessible(true);

                  try {
                     Field modifiersField = Field.class.getDeclaredField("modifiers");
                     modifiersField.setAccessible(true);
                     modifiersField.setInt(f, f.getModifiers() & -17);
                  } catch (NoSuchFieldException var8) {
                  }

                  f.set(this.entityPlayer, this.gameProfile);
                  this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: GameProfile field set via " + f.getName());
                  break;
               }
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] DEBUG: Could not set GameProfile: " + e.getMessage());
      }

   }

   private void setPlayerPosition(Location location) {
      try {
         Method moveToMethod = this.findMethod(this.entityPlayer.getClass(), "moveTo", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
         if (moveToMethod != null) {
            moveToMethod.invoke(this.entityPlayer, location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Set position via moveTo to " + String.valueOf(location));
            return;
         }

         Method snapToMethod = this.findMethod(this.entityPlayer.getClass(), "snapTo", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
         if (snapToMethod != null) {
            snapToMethod.invoke(this.entityPlayer, location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Set position via snapTo to " + String.valueOf(location));
            return;
         }

         Method setPosMethod = this.findMethod(this.entityPlayer.getClass(), "setPos", Double.TYPE, Double.TYPE, Double.TYPE);
         if (setPosMethod != null) {
            setPosMethod.invoke(this.entityPlayer, location.getX(), location.getY(), location.getZ());
            this.plugin.getLogger().info("[ServerSideFakePlayer] DEBUG: Set position via setPos to " + String.valueOf(location));
         }
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Failed to set player position: " + e.getMessage());
      }

   }

   private Method findMethod(Class<?> clazz, String name, Class<?>... paramTypes) {
      for(Class<?> current = clazz; current != null; current = current.getSuperclass()) {
         try {
            Method method = current.getDeclaredMethod(name, paramTypes);
            method.setAccessible(true);
            return method;
         }
      }

      return null;
   }

   private void setPingField(Object entityPlayer, int pingValue) {
      String[] pingFieldNames = new String[]{"f", "e", "d", "ping", "latency"};

      for(String fieldName : pingFieldNames) {
         try {
            Field field = this.findFieldInHierarchy(entityPlayerClass, fieldName);
            if (field != null && (field.getType() == Integer.TYPE || field.getType() == Integer.class)) {
               field.setAccessible(true);
               field.setInt(entityPlayer, pingValue);
               this.plugin.getLogger().fine("[ServerSideFakePlayer] Set ping field '" + fieldName + "' to " + pingValue);
               return;
            }
         } catch (Exception var9) {
         }
      }

      this.plugin.getLogger().fine("[ServerSideFakePlayer] Could not find ping field, using default");
   }

   private Field findFieldInHierarchy(Class<?> clazz, String name) {
      while(clazz != null) {
         try {
            return clazz.getDeclaredField(name);
         } catch (NoSuchFieldException var4) {
            clazz = clazz.getSuperclass();
         }
      }

      return null;
   }

   private void setupFakeConnection(Object minecraftServer, Object entityPlayer) {
      try {
         FakeNetworkManager fakeNetworkManager = new FakeNetworkManager(this.port, this.ipAddress);
         this.networkManager = fakeNetworkManager.getNetworkManager();
         if (this.networkManager == null) {
            Object protocolDirection = enumProtocolDirectionClass.getEnumConstants()[0];
            Constructor<?> nmConstructor = networkManagerClass.getConstructor(enumProtocolDirectionClass);
            this.networkManager = nmConstructor.newInstance(protocolDirection);
            Field channelField = networkManagerClass.getDeclaredField("m");
            channelField.setAccessible(true);
            channelField.set(this.networkManager, new FakeChannel());
            Field addressField = networkManagerClass.getDeclaredField("n");
            addressField.setAccessible(true);
            addressField.set(this.networkManager, new InetSocketAddress(this.ipAddress, this.port));
         }

         Constructor<?> pcConstructor = playerConnectionClass.getConstructor(minecraftServerClass, networkManagerClass, entityPlayerClass);
         this.playerConnection = pcConstructor.newInstance(minecraftServer, this.networkManager, entityPlayer);
         String[] connectionFieldNames = new String[]{"c", "connection", "b"};

         for(String fieldName : connectionFieldNames) {
            try {
               Field connectionField = this.findFieldInHierarchy(entityPlayerClass, fieldName);
               if (connectionField != null && connectionField.getType().isAssignableFrom(playerConnectionClass)) {
                  connectionField.setAccessible(true);
                  connectionField.set(entityPlayer, this.playerConnection);
                  this.plugin.getLogger().fine("[ServerSideFakePlayer] Set player connection field: " + fieldName);
                  break;
               }
            } catch (Exception var11) {
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Error setting up connection: " + e.getMessage());
      }

   }

   private void setPlayerInvisible(Object entityPlayer, boolean invisible) {
      try {
         Method setInvisibleMethod = entityPlayer.getClass().getMethod("setInvisible", Boolean.TYPE);
         setInvisibleMethod.invoke(entityPlayer, invisible);
      } catch (Exception var6) {
         try {
            if (this.craftPlayer instanceof Player) {
               ((Player)this.craftPlayer).setInvisible(invisible);
            }
         } catch (Exception var5) {
         }
      }

   }

   private Object createClientInformation() {
      try {
         Method createDefault = clientInformationClass.getMethod("a");
         return createDefault.invoke((Object)null);
      } catch (Exception var10) {
         try {
            Class<?> chatVisibilityClass = Class.forName("net.minecraft.world.entity.player.EnumChatVisibility");
            Class<?> mainHandClass = Class.forName("net.minecraft.world.entity.EnumMainHand");
            Class<?> particleStatusClass = Class.forName("net.minecraft.server.level.ParticleStatus");
            Object chatVisibility = chatVisibilityClass.getEnumConstants()[0];
            Object mainHand = mainHandClass.getEnumConstants()[0];
            Object particleStatus = particleStatusClass.getEnumConstants()[0];
            Constructor<?> constructor = clientInformationClass.getConstructor(String.class, Integer.TYPE, chatVisibilityClass, Boolean.TYPE, Integer.TYPE, mainHandClass, Boolean.TYPE, Boolean.TYPE, particleStatusClass);
            return constructor.newInstance("en_US", 10, chatVisibility, true, 127, mainHand, false, true, particleStatus);
         } catch (Exception ex) {
            this.plugin.getLogger().warning("[ServerSideFakePlayer] Failed to create ClientInformation: " + ex.getMessage());
            return null;
         }
      }
   }

   private void setPaperSpecificFields() {
      try {
         Field isRealPlayerField = this.findFieldInHierarchy(entityPlayerClass, "isRealPlayer");
         if (isRealPlayerField != null) {
            isRealPlayerField.setAccessible(true);
            isRealPlayerField.setBoolean(this.entityPlayer, true);
         }

         Field loginTimeField = this.findFieldInHierarchy(entityPlayerClass, "loginTime");
         if (loginTimeField != null) {
            loginTimeField.setAccessible(true);
            loginTimeField.setLong(this.entityPlayer, System.currentTimeMillis());
         }

         if (this.craftPlayer instanceof Player) {
            Field hasPlayedBeforeField = this.findFieldInHierarchy(this.craftPlayer.getClass(), "hasPlayedBefore");
            if (hasPlayedBeforeField != null) {
               hasPlayedBeforeField.setAccessible(true);
               hasPlayedBeforeField.setBoolean(this.craftPlayer, true);
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().fine("[ServerSideFakePlayer] Error setting Paper fields: " + e.getMessage());
      }

   }

   private void fetchAndApplySkin(UUID skinUUID, Consumer<GameProfile> callback) {
      if (skinUUID != null) {
         MojangAPI.setSkin(this.plugin, this.gameProfile, skinUUID.toString(), callback);
      } else {
         MojangAPI.setSkin(this.plugin, this.gameProfile, this.name, callback);
      }

   }

   private void updateGameProfileOnEntity(GameProfile newProfile) {
      try {
         Field gameProfileField = null;

         for(Class<?> clazz = entityPlayerClass; clazz != null && gameProfileField == null; clazz = clazz.getSuperclass()) {
            for(Field f : clazz.getDeclaredFields()) {
               if (f.getType() == gameProfileClass) {
                  gameProfileField = f;
                  break;
               }
            }
         }

         if (gameProfileField != null) {
            gameProfileField.setAccessible(true);

            try {
               Field modifiersField = Field.class.getDeclaredField("modifiers");
               modifiersField.setAccessible(true);
               modifiersField.setInt(gameProfileField, gameProfileField.getModifiers() & -17);
            } catch (NoSuchFieldException var8) {
            }

            gameProfileField.set(this.entityPlayer, newProfile);
            this.gameProfile = newProfile;
         }
      } catch (Exception e) {
         this.plugin.getLogger().warning("[ServerSideFakePlayer] Failed to update GameProfile: " + e.getMessage());
      }

   }

   public void setSkin(UUID skinUUID) {
      this.fetchAndApplySkin(skinUUID, this::updateGameProfileOnEntity);
   }

   public void updatePing() {
      int variance = random.nextInt(15) - 7;
      this.ping = Math.max(10, Math.min(400, this.ping + variance));
      this.setPingField(this.entityPlayer, this.ping);
   }

   public String getName() {
      return this.name;
   }

   public UUID getUUID() {
      return this.uuid;
   }

   public String getRank() {
      return this.rank;
   }

   public Object getEntityPlayer() {
      return this.entityPlayer;
   }

   public Player getCraftPlayer() {
      return this.craftPlayer instanceof Player ? (Player)this.craftPlayer : null;
   }

   public GameProfile getGameProfile() {
      return this.gameProfile;
   }

   public long getJoinTime() {
      return this.joinTime;
   }

   public int getPing() {
      return this.ping;
   }

   public String getIpAddress() {
      return this.ipAddress;
   }

   public int getPort() {
      return this.port;
   }

   public Object getNetworkManager() {
      return this.networkManager;
   }

   public Object getPlayerConnection() {
      return this.playerConnection;
   }

   static {
      try {
         minecraftServerClass = Class.forName("net.minecraft.server.MinecraftServer");
         worldServerClass = Class.forName("net.minecraft.server.level.WorldServer");
         entityPlayerClass = Class.forName("net.minecraft.server.level.EntityPlayer");
         gameProfileClass = Class.forName("com.mojang.authlib.GameProfile");
         propertyClass = Class.forName("com.mojang.authlib.properties.Property");
         propertyMapClass = Class.forName("com.mojang.authlib.properties.PropertyMap");
         clientInformationClass = Class.forName("net.minecraft.server.level.ClientInformation");
         playerConnectionClass = Class.forName("net.minecraft.server.network.PlayerConnection");
         networkManagerClass = Class.forName("net.minecraft.network.NetworkManager");
         enumProtocolDirectionClass = Class.forName("net.minecraft.network.protocol.EnumProtocolDirection");
         String[] versions = new String[]{"v1_21_R7", "v1_21_R6", "v1_21_R5", "v1_21_R4", "v1_21_R3", "v1_21_R2", "v1_21_R1", "v1_20_R4", "v1_20_R3", "v1_20_R2", "v1_20_R1"};

         for(String version : versions) {
            try {
               craftWorldClass = Class.forName("org.bukkit.craftbukkit." + version + ".CraftWorld");
               craftServerClass = Class.forName("org.bukkit.craftbukkit." + version + ".CraftServer");
               craftPlayerClass = Class.forName("org.bukkit.craftbukkit." + version + ".entity.CraftPlayer");
               break;
            } catch (ClassNotFoundException var6) {
            }
         }
      } catch (ClassNotFoundException var7) {
      }

   }
}
