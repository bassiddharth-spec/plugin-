package com.glidespoofer.serverside;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.properties.PropertyMap;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Version;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

public class MojangAPI {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-MojangAPI");
   private static final ExecutorService executor = Executors.newCachedThreadPool();
   private static final HttpClient client = HttpClient.newHttpClient();
   private static final Map<String, CacheEntry<Optional<Property>>> caching = new ConcurrentHashMap();
   private static final long CACHE_TTL_MILLIS = 1800000L;
   private static final String MOJANG_PROFILE_URL = "https://api.mojang.com/users/profiles/minecraft/";
   private static final String MOJANG_SESSION_URL = "https://sessionserver.mojang.com/session/minecraft/profile/";
   private static Method propertyMethod;
   private static Method getIdMethod;
   private static Method getNameMethod;
   private static Field propertyMapPropertiesField;

   public static PropertyMap getPropertyMap(GameProfile gameProfile) {
      try {
         return (PropertyMap)propertyMethod.invoke(gameProfile);
      } catch (Exception e) {
         throw new RuntimeException("Could not read GameProfile properties", e);
      }
   }

   public static UUID getProfileId(GameProfile gameProfile) {
      try {
         return (UUID)getIdMethod.invoke(gameProfile);
      } catch (Exception e) {
         throw new RuntimeException("Could not read GameProfile ID", e);
      }
   }

   public static String getProfileName(GameProfile gameProfile) {
      try {
         return (String)getNameMethod.invoke(gameProfile);
      } catch (Exception e) {
         throw new RuntimeException("Could not read GameProfile name", e);
      }
   }

   private static GameProfile createProfileWithProperties(UUID uuid, String name, PropertyMap propertyMap) {
      try {
         try {
            Constructor<?> constructor = GameProfile.class.getConstructor(UUID.class, String.class, PropertyMap.class);
            return (GameProfile)constructor.newInstance(uuid, name, propertyMap);
         } catch (NoSuchMethodException var8) {
            GameProfile gameProfile = new GameProfile(uuid, name);
            Field field = GameProfile.class.getDeclaredField("properties");
            field.setAccessible(true);

            try {
               Field field2 = Field.class.getDeclaredField("modifiers");
               field2.setAccessible(true);
               field2.setInt(field, field.getModifiers() & -17);
            } catch (NoSuchFieldException var7) {
            }

            field.set(gameProfile, propertyMap);
            return gameProfile;
         }
      } catch (Exception e) {
         throw new RuntimeException("Failed to create GameProfile with properties", e);
      }
   }

   private static GameProfile applyTextures(GameProfile gameProfile, Property property) {
      String name = getProfileName(gameProfile);
      UUID uuid = getProfileId(gameProfile);

      try {
         PropertyMap originalProperties = getPropertyMap(gameProfile);
         ImmutableMultimap.Builder<String, Property> builder = ImmutableMultimap.builder();

         for(Map.Entry<String, Property> entry : originalProperties.entries()) {
            if (!"textures".equals(entry.getKey())) {
               builder.put((String)entry.getKey(), (Property)entry.getValue());
            }
         }

         builder.put("textures", property);
         ImmutableMultimap<String, Property> immutableMultimap = builder.build();

         PropertyMap newPropertyMap;
         try {
            Constructor<?> constructor = PropertyMap.class.getConstructor(Multimap.class);
            newPropertyMap = (PropertyMap)constructor.newInstance(immutableMultimap);
         } catch (NoSuchMethodException var9) {
            newPropertyMap = new PropertyMap();
            propertyMapPropertiesField.set(newPropertyMap, immutableMultimap);
         }

         return createProfileWithProperties(uuid, name, newPropertyMap);
      } catch (Exception e) {
         LOGGER.log(Level.WARNING, "[MojangAPI] Failed to apply textures to GameProfile", e);
         throw new RuntimeException("Failed to apply textures to GameProfile", e);
      }
   }

   private static Property clone(Property property) {
      return property.hasSignature() ? new Property(property.name(), property.value(), property.signature()) : new Property(property.name(), property.value());
   }

   public static void setSkin(Plugin plugin, GameProfile gameProfile, String playerName, Consumer<GameProfile> callback) {
      executor.submit(() -> {
         String nameLower = playerName.toLowerCase(Locale.ROOT);
         long currentTime = System.currentTimeMillis();
         CacheEntry<Optional<Property>> cacheEntry = (CacheEntry)caching.get(nameLower);
         if (cacheEntry != null && !cacheEntry.isExpired(currentTime)) {
            Optional<Property> cached = (Optional)cacheEntry.value;
            Bukkit.getScheduler().runTask(plugin, () -> {
               if (cached.isPresent()) {
                  GameProfile updated = applyTextures(gameProfile, clone((Property)cached.get()));
                  callback.accept(updated);
               } else {
                  callback.accept(gameProfile);
               }

            });
         } else {
            try {
               Optional<Property> property = fetchTexturesFromMojang(playerName);
               caching.put(nameLower, new CacheEntry(property, currentTime + 1800000L));
               Bukkit.getScheduler().runTask(plugin, () -> {
                  if (property.isPresent()) {
                     GameProfile updated = applyTextures(gameProfile, clone((Property)property.get()));
                     callback.accept(updated);
                  } else {
                     callback.accept(gameProfile);
                  }

               });
            } catch (Exception e) {
               LOGGER.log(Level.WARNING, "[MojangAPI] Failed to fetch skin for " + playerName, e);
               Bukkit.getScheduler().runTask(plugin, () -> callback.accept(gameProfile));
            }

         }
      });
   }

   private static Optional<Property> fetchTexturesFromMojang(String playerName) throws Exception {
      String encodedName = URLEncoder.encode(playerName, StandardCharsets.UTF_8);
      HttpRequest profileRequest = HttpRequest.newBuilder().uri(new URI("https://api.mojang.com/users/profiles/minecraft/" + encodedName)).version(Version.HTTP_2).timeout(Duration.of(5L, ChronoUnit.SECONDS)).GET().build();
      HttpResponse<String> profileResponse = client.send(profileRequest, BodyHandlers.ofString());
      int profileStatus = profileResponse.statusCode();
      if (profileStatus != 204 && profileStatus != 404) {
         if (profileStatus != 200) {
            throw new IOException("Unexpected status from Mojang profile API: " + profileStatus);
         } else {
            JsonObject profileJson = JsonParser.parseString((String)profileResponse.body()).getAsJsonObject();
            if (!profileJson.has("id")) {
               return Optional.empty();
            } else {
               String uuidString = profileJson.get("id").getAsString();
               HttpRequest sessionRequest = HttpRequest.newBuilder().uri(new URI("https://sessionserver.mojang.com/session/minecraft/profile/" + uuidString + "?unsigned=false")).version(Version.HTTP_2).timeout(Duration.of(5L, ChronoUnit.SECONDS)).GET().build();
               HttpResponse<String> sessionResponse = client.send(sessionRequest, BodyHandlers.ofString());
               int sessionStatus = sessionResponse.statusCode();
               if (sessionStatus != 200) {
                  throw new IOException("Unexpected status from Mojang session server: " + sessionStatus);
               } else {
                  JsonObject sessionJson = JsonParser.parseString((String)sessionResponse.body()).getAsJsonObject();
                  if (!sessionJson.has("properties")) {
                     return Optional.empty();
                  } else {
                     JsonArray propertiesArray = sessionJson.getAsJsonArray("properties");

                     for(int i = 0; i < propertiesArray.size(); ++i) {
                        JsonObject propertyObj = propertiesArray.get(i).getAsJsonObject();
                        String name = propertyObj.get("name").getAsString();
                        if ("textures".equalsIgnoreCase(name)) {
                           String value = propertyObj.get("value").getAsString();
                           String signature = propertyObj.has("signature") ? propertyObj.get("signature").getAsString() : null;
                           Property property = signature != null && !signature.isEmpty() ? new Property("textures", value, signature) : new Property("textures", value);
                           return Optional.of(property);
                        }
                     }

                     return Optional.empty();
                  }
               }
            }
         }
      } else {
         return Optional.empty();
      }
   }

   public static void clearCache() {
      caching.clear();
   }

   public static int getCacheSize() {
      return caching.size();
   }

   static {
      try {
         try {
            propertyMethod = GameProfile.class.getMethod("getProperties");
         } catch (NoSuchMethodException var7) {
            propertyMethod = GameProfile.class.getMethod("properties");
         }

         try {
            getIdMethod = GameProfile.class.getMethod("getId");
         } catch (NoSuchMethodException var6) {
            getIdMethod = GameProfile.class.getMethod("id");
         }

         try {
            getNameMethod = GameProfile.class.getMethod("getName");
         } catch (NoSuchMethodException var5) {
            getNameMethod = GameProfile.class.getMethod("name");
         }

         Class<PropertyMap> clazz = PropertyMap.class;
         Field field = null;

         for(Class<?> clazz2 = clazz; clazz2 != null && field == null; clazz2 = clazz2.getSuperclass()) {
            try {
               field = clazz2.getDeclaredField("properties");
            } catch (NoSuchFieldException var4) {
            }
         }

         if (field == null) {
            throw new NoSuchFieldException("Could not find 'properties' field on PropertyMap hierarchy");
         } else {
            field.setAccessible(true);
            propertyMapPropertiesField = field;
            LOGGER.info("[MojangAPI] Initialized successfully");
         }
      } catch (Exception e) {
         LOGGER.log(Level.SEVERE, "[MojangAPI] Failed to initialize reflection", e);
         throw new RuntimeException("Failed to initialize MojangAPI reflection", e);
      }
   }

   private static final class CacheEntry<T> {
      final T value;
      final long expiresAtMillis;

      CacheEntry(T value, long expiresAtMillis) {
         this.value = value;
         this.expiresAtMillis = expiresAtMillis;
      }

      boolean isExpired(long currentTime) {
         return currentTime >= this.expiresAtMillis;
      }
   }
}
