package com.glidespoofer.fake;

import com.glidespoofer.core.GlideSpoofer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class RandomNameGenerator {
   private final GlideSpoofer plugin;
   private final SkinFetcher skinFetcher;
   private static final String[] PREDEFINED_NAMES = new String[]{"Notch", "jeb_", "Dinnerbone", "Grumm", "MHF_Steve", "MHF_Alex", "MHF_Herobrine", "MHF_Blaze", "MHF_CaveSpider", "MHF_Chicken", "MHF_Cow", "MHF_Creeper", "MHF_Enderman", "MHF_Ghast", "MHF_Giant", "MHF_LavaSlime", "MHF_MushroomCow", "MHF_Ocelot", "MHF_Pig", "MHF_PigZombie", "MHF_Sheep", "MHF_Slime", "MHF_Spider", "MHF_Squid", "MHF_Villager", "MHF_Wolf", "MHF_Zombie", "XboxOreo", "c4rtman", "Makkai", "KrisJelbring", "Neon_Master", "Nohi", "Timolino", "Threezt", "Satharis", "DerpTroller"};
   private static final String[] RELIABLE_SKIN_NAMES = new String[]{"Notch", "jeb_", "Dinnerbone", "Grumm", "MHF_Steve", "MHF_Alex", "MHF_Blaze", "MHF_Chicken", "MHF_Cow", "MHF_Creeper", "MHF_Enderman", "MHF_Ghast", "MHF_Pig", "MHF_Sheep", "MHF_Spider", "MHF_Villager", "MHF_Zombie"};
   private static final String[] HARDCODED_SKINS = new String[]{"ewogICJ0aW1lc3RhbXAiIDogMTYxODU4MDQ1OTAwNiwKICAicHJvZmlsZUlkIiA6ICJlZTliYzg5NzYyMzQ0OGQ5YmYxYjI0MzY2ODFiYzVlIiwKICAicHJvZmlsZU5hbWUiIDogIlN0ZXZlIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzNmNTQ4ZTNjYTU2ODRlZTJiYWYzYmZhMDU1YjExN2U4YzUzMmRlNDJkZTc3YjkzNWYzNjUzNzJiNGJkYjE4ZGUwIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInN0YW5kYXJkIgogICAgICB9CiAgICB9CiAgfQp=", "ewogICJ0aW1lc3RhbXAiIDogMTYxODU4MDUwMjA3MywKICAicHJvZmlsZUlkIiA6ICJjOWRiOWI1MmY0YjI0NjY5YTJiNzRjYWIwYWFkNmMzOSIsCiAgInByb2ZpbGVOYW1lIiA6ICJBbGV4IiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzNmNTQ4ZTNjYTU2ODRlZTJiYWYzYmZhMDU1YjExN2U4YzUzMmRlNDJkZTc3YjkzNWYzNjUzNzJiNGJkYjE4ZGUwIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cg==", "ewogICJ0aW1lc3RhbXAiIDogMTU4OTkyMDI0OTAwMiwKICAicHJvZmlsZUlkIiA6ICJmNDk4MTg1Yjk1Nzc0MmU1OTJjZTBkNjcwOGM1YjMzOCIsCiAgInByb2ZpbGVOYW1lIiA6ICJOb3RjaCIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS82ZTc4MWMyNjg1YmY0MGU1OWIyODBlYjY4MjA0MjIyZTVhOTM2ZmE5YTQ2M2QzYzQ4MjA4OWJjYjNmZjU1ZmMiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic3RhbmRhcmQiCiAgICAgIH0KICAgIH0KICB9Cn0="};
   private static final String EMPTY_SIGNATURE = "";
   private final List<String> cachedNames;
   private final Map<String, SkinData> nameSkinCache;
   private final Set<String> usedNames;
   private final int cacheSize;
   private final boolean reuseNames;
   private final boolean useMojangApi;
   private static final Random RANDOM = new Random();
   private final Object cacheLock = new Object();

   public RandomNameGenerator(GlideSpoofer plugin, SkinFetcher skinFetcher) {
      this.plugin = plugin;
      this.skinFetcher = skinFetcher;
      this.cachedNames = new ArrayList();
      this.nameSkinCache = new ConcurrentHashMap();
      this.usedNames = new HashSet();
      this.cacheSize = plugin.getConfigManager().getConfig().getInt("random-names.cache-size", 100);
      this.reuseNames = plugin.getConfigManager().getConfig().getBoolean("random-names.reuse-names", false);
      this.useMojangApi = plugin.getConfigManager().getConfig().getBoolean("random-names.use-mojang-api", false);
      this.initializeWithRealNames();
      if (plugin.getConfigManager().getConfig().getBoolean("random-names.pre-fill-cache", true)) {
         this.prefetchSkinsAsync();
      }

   }

   private void initializeWithRealNames() {
      synchronized(this.cacheLock) {
         for(String name : PREDEFINED_NAMES) {
            if (this.isValidUsername(name) && !this.cachedNames.contains(name)) {
               this.cachedNames.add(name);
            }
         }

         this.plugin.getLogger().info("Initialized name cache with " + this.cachedNames.size() + " predefined player names");
      }
   }

   private void prefetchSkinsAsync() {
      if (!this.useMojangApi) {
         this.plugin.getLogger().info("Skin prefetch skipped (Mojang API disabled in config)");
      } else {
         this.plugin.getServer().getScheduler().runTaskAsynchronously(this.plugin, () -> {
            int fetched = 0;
            int failed = 0;
            int targetCount = Math.min(50, this.cachedNames.size());
            this.plugin.getLogger().info("Starting skin prefetch for " + targetCount + " names...");

            for(int i = 0; i < targetCount && i < this.cachedNames.size(); ++i) {
               String name = (String)this.cachedNames.get(i);
               if (!this.nameSkinCache.containsKey(name.toLowerCase())) {
                  try {
                     SkinFetcher.SkinData skin = this.skinFetcher.fetchSkinByName(name);
                     if (skin != null) {
                        this.nameSkinCache.put(name.toLowerCase(), new SkinData(skin.value, skin.signature));
                        ++fetched;
                        if (this.plugin.getConfigManager().getConfig().getBoolean("debug.enabled", false)) {
                           this.plugin.getLogger().info("Fetched skin for: " + name);
                        }
                     } else {
                        ++failed;
                     }
                  } catch (Exception e) {
                     ++failed;
                     if (this.plugin.getConfigManager().getConfig().getBoolean("debug.enabled", false)) {
                        this.plugin.getLogger().warning("Failed to fetch skin for " + name + ": " + e.getMessage());
                     }
                  }
               }
            }

            this.plugin.getLogger().info("Prefetched " + fetched + " skins from Mojang API (" + failed + " failed)");
            if (fetched == 0) {
               this.plugin.getLogger().info("No skins fetched from main list, trying reliable premium names...");

               for(String name : RELIABLE_SKIN_NAMES) {
                  if (!this.nameSkinCache.containsKey(name.toLowerCase())) {
                     try {
                        SkinFetcher.SkinData skin = this.skinFetcher.fetchSkinByName(name);
                        if (skin != null) {
                           this.nameSkinCache.put(name.toLowerCase(), new SkinData(skin.value, skin.signature));
                           ++fetched;
                           synchronized(this.cacheLock) {
                              if (!this.cachedNames.contains(name)) {
                                 this.cachedNames.add(name);
                              }
                           }

                           if (this.plugin.getConfigManager().getConfig().getBoolean("debug.enabled", false)) {
                              this.plugin.getLogger().info("Fetched fallback skin for: " + name);
                           }
                        }
                     } catch (Exception e) {
                        if (this.plugin.getConfigManager().getConfig().getBoolean("debug.enabled", false)) {
                           this.plugin.getLogger().warning("Failed to fetch fallback skin for " + name + ": " + e.getMessage());
                        }
                     }
                  }

                  if (fetched >= 20) {
                     break;
                  }
               }

               this.plugin.getLogger().info("Prefetched " + fetched + " fallback skins");
            }

         });
      }
   }

   public RandomPlayerResult getRandomPlayer() {
      return this.getRandomPlayer(true);
   }

   public RandomPlayerResult getRandomPlayer(boolean fetchSkin) {
      String name = this.getRandomNameFromCache();
      if (name == null) {
         return this.generateFallbackName();
      } else {
         SkinData skin = null;
         if (fetchSkin) {
            skin = (SkinData)this.nameSkinCache.get(name.toLowerCase());
            if (skin == null) {
               this.fetchSkinAsync(name);
            }
         }

         return new RandomPlayerResult(name, skin);
      }
   }

   public RandomPlayerResult getRandomPlayerBlocking() {
      String name = this.getRandomNameFromCache();
      if (name != null) {
         SkinData skin = (SkinData)this.nameSkinCache.get(name.toLowerCase());
         if (skin == null && this.useMojangApi) {
            SkinFetcher.SkinData fetched = this.skinFetcher.fetchSkinByName(name);
            if (fetched != null) {
               skin = new SkinData(fetched.value, fetched.signature);
               this.nameSkinCache.put(name.toLowerCase(), skin);
            }
         }

         if (skin == null) {
            skin = this.getRandomSkinFromCache();
            if (skin != null) {
               this.plugin.getLogger().fine("Assigning random skin to " + name + " (original skin unavailable)");
            }
         }

         return new RandomPlayerResult(name, skin);
      } else {
         for(String fallbackName : PREDEFINED_NAMES) {
            SkinData skin = (SkinData)this.nameSkinCache.get(fallbackName.toLowerCase());
            if (skin == null && this.useMojangApi) {
               SkinFetcher.SkinData fetched = this.skinFetcher.fetchSkinByName(fallbackName);
               if (fetched != null) {
                  skin = new SkinData(fetched.value, fetched.signature);
                  this.nameSkinCache.put(fallbackName.toLowerCase(), skin);
               }
            }

            if (skin != null) {
               synchronized(this.cacheLock) {
                  if (!this.cachedNames.contains(fallbackName)) {
                     this.cachedNames.add(fallbackName);
                  }
               }

               return new RandomPlayerResult(fallbackName, skin);
            }
         }

         return this.generateFallbackName();
      }
   }

   private SkinData getRandomSkinFromCache() {
      if (!this.nameSkinCache.isEmpty()) {
         Object[] skins = this.nameSkinCache.values().toArray();
         return (SkinData)skins[RANDOM.nextInt(skins.length)];
      } else {
         if (this.useMojangApi) {
            for(String reliableName : RELIABLE_SKIN_NAMES) {
               SkinFetcher.SkinData fetched = this.skinFetcher.fetchSkinByName(reliableName);
               if (fetched != null) {
                  SkinData skin = new SkinData(fetched.value, fetched.signature);
                  this.nameSkinCache.put(reliableName.toLowerCase(), skin);
                  return skin;
               }
            }
         }

         String randomSkin = HARDCODED_SKINS[RANDOM.nextInt(HARDCODED_SKINS.length)];
         return new SkinData(randomSkin, "");
      }
   }

   private void fetchSkinAsync(String name) {
      this.plugin.getServer().getScheduler().runTaskAsynchronously(this.plugin, () -> {
         SkinFetcher.SkinData skin = this.skinFetcher.fetchSkinByName(name);
         if (skin != null) {
            this.nameSkinCache.put(name.toLowerCase(), new SkinData(skin.value, skin.signature));
         }

      });
   }

   private String getRandomNameFromCache() {
      synchronized(this.cacheLock) {
         if (this.cachedNames.isEmpty()) {
            return null;
         } else {
            for(int i = 0; i < Math.min(20, this.cachedNames.size()); ++i) {
               String name = (String)this.cachedNames.get(RANDOM.nextInt(this.cachedNames.size()));
               if (this.reuseNames || !this.usedNames.contains(name)) {
                  this.usedNames.add(name);
                  return name;
               }
            }

            if (!this.reuseNames) {
               return null;
            } else {
               String name = (String)this.cachedNames.get(RANDOM.nextInt(this.cachedNames.size()));
               this.usedNames.add(name);
               return name;
            }
         }
      }
   }

   private RandomPlayerResult generateFallbackName() {
      String[] prefixes = new String[]{"Mega", "Super", "Pro", "Cool", "Epic", "Dark", "Light", "Shadow", "Pixel", "Cyber"};
      String[] suffixes = new String[]{"Player", "Gamer", "Craft", "Master", "King", "Lord", "Ninja", "Warrior", "Hunter", "Legend"};
      String[] numbers = new String[]{"", "", "", "", "123", "99", "Xx", "xX", "OG"};
      String var10000 = prefixes[RANDOM.nextInt(prefixes.length)];
      String name = var10000 + suffixes[RANDOM.nextInt(suffixes.length)] + numbers[RANDOM.nextInt(numbers.length)];
      if (name.length() > 16) {
         name = name.substring(0, 16);
      }

      return new RandomPlayerResult(name, (SkinData)null);
   }

   private boolean isValidUsername(String name) {
      if (name != null && !name.isEmpty() && name.length() <= 16) {
         return name.startsWith("_") ? false : name.matches("^[a-zA-Z0-9_]+$");
      } else {
         return false;
      }
   }

   public int getCacheSize() {
      synchronized(this.cacheLock) {
         return this.cachedNames.size();
      }
   }

   public int getUsedNamesCount() {
      return this.usedNames.size();
   }

   public int getSkinCacheSize() {
      return this.nameSkinCache.size();
   }

   public void clearCache() {
      synchronized(this.cacheLock) {
         this.cachedNames.clear();
      }

      this.usedNames.clear();
      this.nameSkinCache.clear();
   }

   public boolean isNameUsed(String name) {
      return this.usedNames.contains(name);
   }

   public void markNameUsed(String name) {
      this.usedNames.add(name);
   }

   public static class RandomPlayerResult {
      private final String name;
      private final SkinData skin;

      public RandomPlayerResult(String name, SkinData skin) {
         this.name = name;
         this.skin = skin;
      }

      public String getName() {
         return this.name;
      }

      public SkinData getSkin() {
         return this.skin;
      }

      public boolean hasSkin() {
         return this.skin != null;
      }
   }

   public static class SkinData {
      private final String value;
      private final String signature;

      public SkinData(String value, String signature) {
         this.value = value;
         this.signature = signature;
      }

      public String getValue() {
         return this.value;
      }

      public String getSignature() {
         return this.signature;
      }
   }
}
