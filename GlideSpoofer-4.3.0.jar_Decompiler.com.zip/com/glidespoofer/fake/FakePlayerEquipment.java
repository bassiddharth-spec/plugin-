package com.glidespoofer.fake;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class FakePlayerEquipment {
   private ItemStack helmet = null;
   private ItemStack chestplate = null;
   private ItemStack leggings = null;
   private ItemStack boots = null;
   private ItemStack mainHand = null;
   private ItemStack offHand = null;

   public ItemStack getHelmet() {
      return this.helmet;
   }

   public void setHelmet(ItemStack helmet) {
      this.helmet = helmet;
   }

   public ItemStack getChestplate() {
      return this.chestplate;
   }

   public void setChestplate(ItemStack chestplate) {
      this.chestplate = chestplate;
   }

   public ItemStack getLeggings() {
      return this.leggings;
   }

   public void setLeggings(ItemStack leggings) {
      this.leggings = leggings;
   }

   public ItemStack getBoots() {
      return this.boots;
   }

   public void setBoots(ItemStack boots) {
      this.boots = boots;
   }

   public ItemStack getMainHand() {
      return this.mainHand;
   }

   public void setMainHand(ItemStack mainHand) {
      this.mainHand = mainHand;
   }

   public ItemStack getOffHand() {
      return this.offHand;
   }

   public void setOffHand(ItemStack offHand) {
      this.offHand = offHand;
   }

   public void setArmorMaterial(String helmetType, String chestplateType, String leggingsType, String bootsType) {
      if (helmetType != null && !helmetType.isEmpty()) {
         this.helmet = new ItemStack(Material.matchMaterial(helmetType), 1);
      }

      if (chestplateType != null && !chestplateType.isEmpty()) {
         this.chestplate = new ItemStack(Material.matchMaterial(chestplateType), 1);
      }

      if (leggingsType != null && !leggingsType.isEmpty()) {
         this.leggings = new ItemStack(Material.matchMaterial(leggingsType), 1);
      }

      if (bootsType != null && !bootsType.isEmpty()) {
         this.boots = new ItemStack(Material.matchMaterial(bootsType), 1);
      }

   }

   public void setHeldItems(String mainHandType, String offHandType) {
      if (mainHandType != null && !mainHandType.isEmpty()) {
         this.mainHand = new ItemStack(Material.matchMaterial(mainHandType), 1);
      }

      if (offHandType != null && !offHandType.isEmpty()) {
         this.offHand = new ItemStack(Material.matchMaterial(offHandType), 1);
      }

   }

   public boolean hasEquipment() {
      return this.helmet != null || this.chestplate != null || this.leggings != null || this.boots != null || this.mainHand != null || this.offHand != null;
   }

   public ItemStack getItemInMainHand() {
      return this.mainHand != null ? this.mainHand : new ItemStack(Material.AIR);
   }

   public ItemStack getItemInOffHand() {
      return this.offHand != null ? this.offHand : new ItemStack(Material.AIR);
   }
}
