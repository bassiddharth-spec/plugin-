package com.glidespoofer.fake;

import com.glidespoofer.ai.MovementAIService;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.util.Vector;

public class FakePlayerAI {
   private final FakePlayer fakePlayer;
   private MovementAIService movementAI;
   private boolean enabled = true;
   private MovementAction currentAction;
   private int actionTimer;
   private double posX;
   private double posY;
   private double posZ;
   private float yaw;
   private float pitch;
   private float targetYaw;
   private float targetPitch;
   private float bodyYaw;
   private double velocityX;
   private double velocityZ;
   private static final double MAX_WALK_SPEED = 0.1;
   private static final double MAX_SPRINT_SPEED = 0.13;
   private static final double ACCELERATION = 0.025;
   private static final double DECELERATION = 0.08;
   private static final double TURN_SPEED = (double)8.0F;
   private boolean onGround;
   private boolean isJumping;
   private int ticksSinceGrounded;
   private boolean sprinting;
   private double microSwayPhase;
   private long lastIdleMovement;
   private double velocityY;

   public FakePlayerAI(FakePlayer fakePlayer) {
      this.currentAction = FakePlayerAI.MovementAction.IDLE;
      this.actionTimer = 0;
      this.velocityX = (double)0.0F;
      this.velocityZ = (double)0.0F;
      this.onGround = true;
      this.isJumping = false;
      this.ticksSinceGrounded = 0;
      this.sprinting = false;
      this.microSwayPhase = Math.random() * Math.PI * (double)2.0F;
      this.lastIdleMovement = 0L;
      this.velocityY = (double)0.0F;
      this.fakePlayer = fakePlayer;
      Location loc = fakePlayer.getLocation();
      if (loc != null) {
         this.posX = loc.getX();
         this.posY = loc.getY();
         this.posZ = loc.getZ();
         this.yaw = loc.getYaw();
         this.pitch = loc.getPitch();
         this.targetYaw = this.yaw;
         this.targetPitch = this.pitch;
         this.bodyYaw = this.yaw;
         this.snapToGround();
      }

   }

   public void setMovementAI(MovementAIService movementAI) {
      this.movementAI = movementAI;
   }

   public void update() {
      if (this.enabled && this.fakePlayer.isSpawned() && !this.fakePlayer.isDead()) {
         Location loc = this.fakePlayer.getLocation();
         if (loc != null) {
            this.posX = loc.getX();
            this.posY = loc.getY();
            this.posZ = loc.getZ();
            this.yaw = loc.getYaw();
            this.pitch = loc.getPitch();
            boolean wasOnGround = this.onGround;
            this.updateGroundState();
            if (!wasOnGround && this.onGround) {
               this.isJumping = false;
               if (this.currentAction == FakePlayerAI.MovementAction.JUMPING) {
                  this.currentAction = FakePlayerAI.MovementAction.IDLE;
                  this.actionTimer = 5;
               }
            }

            if (--this.actionTimer <= 0) {
               this.pickNewAction();
            }

            this.executeAction();
            this.applyMicroMovements();
            this.updateRotations();
            this.applyMovement();
            if (!this.onGround && this.currentAction != FakePlayerAI.MovementAction.JUMPING) {
               this.applyGravity();
            }

            loc.setX(this.posX);
            loc.setY(this.posY);
            loc.setZ(this.posZ);
            loc.setYaw(this.yaw);
            loc.setPitch(Math.max(-90.0F, Math.min(90.0F, this.pitch)));
            this.fakePlayer.setLocation(loc);
            if (this.onGround) {
               this.ticksSinceGrounded = 0;
            } else {
               ++this.ticksSinceGrounded;
            }
         }
      }

   }

   private void updateGroundState() {
      World world = this.fakePlayer.getLocation().getWorld();
      if (world != null) {
         boolean found = false;
         double[][] pts = new double[][]{{this.posX, this.posZ}, {this.posX - 0.29, this.posZ - 0.29}, {this.posX + 0.29, this.posZ + 0.29}};

         for(double[] p : pts) {
            Block b = world.getBlockAt((int)Math.floor(p[0]), (int)Math.floor(this.posY - 0.02), (int)Math.floor(p[1]));
            if (b.getType().isSolid()) {
               found = true;
               break;
            }
         }

         this.onGround = found;
      }

   }

   private void snapToGround() {
      World world = this.fakePlayer.getLocation().getWorld();
      if (world != null) {
         for(int dy = 0; dy >= -5; --dy) {
            Block b = world.getBlockAt((int)Math.floor(this.posX), (int)Math.floor(this.posY) + dy - 1, (int)Math.floor(this.posZ));
            if (b.getType().isSolid()) {
               Block feet = world.getBlockAt((int)Math.floor(this.posX), b.getY() + 1, (int)Math.floor(this.posZ));
               Block head = world.getBlockAt((int)Math.floor(this.posX), b.getY() + 2, (int)Math.floor(this.posZ));
               if (!feet.getType().isSolid() && !head.getType().isSolid()) {
                  this.posY = (double)(b.getY() + 1);
                  this.onGround = true;
                  this.velocityX = this.velocityZ = (double)0.0F;
                  return;
               }
            }
         }
      }

   }

   private void pickNewAction() {
      boolean useAI = this.movementAI != null && this.movementAI.isEnabled();
      if (useAI) {
         String ctx = this.buildContext();
         this.movementAI.getMovementDecision(this.fakePlayer.getName(), ctx).thenAccept((d) -> {
            if (d != null) {
               this.applyAIDecision(d);
            } else {
               this.pickRandomAction();
            }

         });
         this.currentAction = FakePlayerAI.MovementAction.THINKING;
         this.actionTimer = 5;
      } else {
         this.pickRandomAction();
      }

   }

   private void applyAIDecision(MovementAIService.MovementDecision d) {
      String action = d.getAction().toLowerCase();
      int dur = d.getDuration();
      switch (action) {
         case "idle":
            this.currentAction = FakePlayerAI.MovementAction.IDLE;
            this.actionTimer = Math.max(20, Math.min(200, dur));
            break;
         case "look":
            this.currentAction = FakePlayerAI.MovementAction.LOOKING;
            this.actionTimer = Math.max(15, Math.min(100, dur));
            this.pickRandomLookTarget();
            break;
         case "walk":
         case "wander":
            if (this.canMoveForward()) {
               this.currentAction = FakePlayerAI.MovementAction.WALKING;
               this.actionTimer = Math.max(30, Math.min(150, dur));
               this.pickWalkDirection();
            } else {
               this.currentAction = FakePlayerAI.MovementAction.LOOKING;
               this.actionTimer = 20;
               this.targetYaw = this.yaw + (float)(Math.random() > (double)0.5F ? 90 : -90);
            }
            break;
         case "sprint":
            if (this.onGround && this.canMoveForward()) {
               this.currentAction = FakePlayerAI.MovementAction.SPRINTING;
               this.actionTimer = Math.max(20, Math.min(100, dur));
               this.pickWalkDirection();
            } else {
               this.currentAction = FakePlayerAI.MovementAction.WALKING;
               this.actionTimer = 40;
            }
            break;
         case "jump":
            if (this.onGround) {
               this.currentAction = FakePlayerAI.MovementAction.JUMPING;
               this.actionTimer = 15;
               this.isJumping = true;
               this.velocityY = 0.3;
            } else {
               this.currentAction = FakePlayerAI.MovementAction.IDLE;
               this.actionTimer = 20;
            }
            break;
         default:
            this.pickRandomAction();
      }

   }

   private void pickRandomAction() {
      double roll = Math.random();
      boolean blocked = !this.canMoveForward() || this.checkDropAhead();
      if (blocked) {
         if (roll < (double)0.5F) {
            this.currentAction = FakePlayerAI.MovementAction.LOOKING;
            this.actionTimer = 20 + (int)(Math.random() * (double)30.0F);
            this.targetYaw = this.yaw + (float)((Math.random() - (double)0.5F) * (double)180.0F);
         } else {
            this.currentAction = FakePlayerAI.MovementAction.IDLE;
            this.actionTimer = 30 + (int)(Math.random() * (double)50.0F);
         }
      } else if (roll < 0.35) {
         this.currentAction = FakePlayerAI.MovementAction.IDLE;
         this.actionTimer = 40 + (int)(Math.random() * (double)80.0F);
      } else if (roll < 0.55) {
         this.currentAction = FakePlayerAI.MovementAction.LOOKING;
         this.actionTimer = 25 + (int)(Math.random() * (double)45.0F);
         this.pickRandomLookTarget();
      } else if (roll < 0.9) {
         this.currentAction = FakePlayerAI.MovementAction.WALKING;
         this.actionTimer = 50 + (int)(Math.random() * (double)100.0F);
         this.pickWalkDirection();
      } else {
         this.currentAction = FakePlayerAI.MovementAction.SPRINTING;
         this.actionTimer = 20 + (int)(Math.random() * (double)40.0F);
         this.pickWalkDirection();
      }

   }

   private void executeAction() {
      double speed = Math.sqrt(this.velocityX * this.velocityX + this.velocityZ * this.velocityZ);
      switch (this.currentAction.ordinal()) {
         case 0:
         case 3:
         case 5:
            this.velocityX *= 0.92;
            this.velocityZ *= 0.92;
            if (speed < 0.001) {
               this.velocityX = this.velocityZ = (double)0.0F;
            }
            break;
         case 1:
            this.updateVelocity(0.1);
            break;
         case 2:
            this.updateVelocity(0.13);
            break;
         case 4:
            if (!this.isJumping && this.onGround) {
               this.isJumping = true;
               this.velocityY = 0.3;
            }

            if (!this.onGround) {
               this.updateVelocity(0.08000000000000002);
            }
      }

   }

   private void updateVelocity(double maxSpeed) {
      double yawRad = Math.toRadians((double)(-this.yaw));
      double targetX = -Math.sin(yawRad) * maxSpeed;
      double targetZ = Math.cos(yawRad) * maxSpeed;
      double accel = this.onGround ? 0.025 : 0.005000000000000001;
      this.velocityX += (targetX - this.velocityX) * accel;
      this.velocityZ += (targetZ - this.velocityZ) * accel;
   }

   private void applyMicroMovements() {
      if (this.currentAction == FakePlayerAI.MovementAction.IDLE) {
         this.microSwayPhase += 0.02;
         if (this.microSwayPhase > (Math.PI * 2D)) {
            this.microSwayPhase -= (Math.PI * 2D);
         }

         long now = System.currentTimeMillis();
         if (now - this.lastIdleMovement > (long)(100 + (int)(Math.random() * (double)200.0F))) {
            this.lastIdleMovement = now;
            this.targetYaw += (float)((Math.random() - (double)0.5F) * (double)8.0F);
            this.targetPitch += (float)((Math.random() - (double)0.5F) * (double)4.0F);
            this.targetPitch = Math.max(-30.0F, Math.min(30.0F, this.targetPitch));
         }
      }

   }

   private void applyMovement() {
      if (this.velocityX != (double)0.0F || this.velocityZ != (double)0.0F || !this.onGround) {
         World world = this.fakePlayer.getLocation().getWorld();
         if (world != null) {
            double newX = this.posX + this.velocityX;
            double newZ = this.posZ + this.velocityZ;
            if (this.velocityX != (double)0.0F && this.checkCollision(newX, this.posY, this.posZ, world)) {
               if (this.onGround && !this.checkCollision(newX, this.posY + 0.6, this.posZ, world)) {
                  this.posY += this.findStep(newX, this.posY, this.posZ, world);
               } else {
                  newX = this.posX;
                  this.velocityX = (double)0.0F;
                  if (this.currentAction == FakePlayerAI.MovementAction.WALKING || this.currentAction == FakePlayerAI.MovementAction.SPRINTING) {
                     this.targetYaw = this.targetYaw + 45.0F + (float)(Math.random() * (double)90.0F);
                  }
               }
            }

            this.posX = newX;
            if (this.velocityZ != (double)0.0F && this.checkCollision(this.posX, this.posY, newZ, world)) {
               if (this.onGround && !this.checkCollision(this.posX, this.posY + 0.6, newZ, world)) {
                  this.posY += this.findStep(this.posX, this.posY, newZ, world);
               } else {
                  newZ = this.posZ;
                  this.velocityZ = (double)0.0F;
                  if (this.currentAction == FakePlayerAI.MovementAction.WALKING || this.currentAction == FakePlayerAI.MovementAction.SPRINTING) {
                     this.targetYaw = this.targetYaw + 45.0F + (float)(Math.random() * (double)90.0F);
                  }
               }
            }

            this.posZ = newZ;
            if (this.onGround && this.currentAction != FakePlayerAI.MovementAction.JUMPING) {
               this.snapToGroundAt(newX, this.posZ, world);
            }

            if ((this.currentAction == FakePlayerAI.MovementAction.WALKING || this.currentAction == FakePlayerAI.MovementAction.SPRINTING) && this.onGround && this.checkDropAhead()) {
               this.velocityX *= 0.3;
               this.velocityZ *= 0.3;
               this.targetYaw = this.targetYaw + 90.0F + (float)(Math.random() * (double)90.0F);
            }
         }
      }

   }

   private boolean checkCollision(double x, double y, double z, World world) {
      for(double dy = (double)0.0F; dy < 1.8; dy += (double)0.5F) {
         for(double dx = -0.3; dx <= 0.3; dx += 0.3) {
            for(double dz = -0.3; dz <= 0.3; dz += 0.3) {
               Block b = world.getBlockAt((int)Math.floor(x + dx), (int)Math.floor(y + dy), (int)Math.floor(z + dz));
               if (this.isSolid(b)) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private double findStep(double x, double y, double z, World world) {
      for(double s = 0.1; s <= 0.6; s += 0.1) {
         if (!this.checkCollision(x, y + s, z, world)) {
            Block g = world.getBlockAt((int)Math.floor(x), (int)Math.floor(y + s - 0.1), (int)Math.floor(z));
            if (g.getType().isSolid()) {
               return s;
            }
         }
      }

      return (double)0.0F;
   }

   private boolean isSolid(Block b) {
      if (b == null) {
         return false;
      } else {
         Material t = b.getType();
         if (t.isAir()) {
            return false;
         } else {
            String n = t.name();
            if (!n.contains("SIGN") && !n.contains("TORCH") && !n.contains("BUTTON") && !n.contains("PRESSURE_PLATE") && !n.contains("LEVER") && !n.contains("RAIL") && !n.contains("FLOWER") && !n.contains("SAPLING") && !n.contains("FERN") && !n.contains("DEAD_BUSH") && !n.contains("CARPET") && (!n.contains("GRASS") || n.contains("BLOCK"))) {
               return t != Material.WATER && t != Material.LAVA ? t.isSolid() : false;
            } else {
               return false;
            }
         }
      }
   }

   private void updateRotations() {
      float yawDiff = this.normalizeAngle(this.targetYaw - this.yaw);
      float pitchDiff = this.targetPitch - this.pitch;
      float yawSpd = (float)((double)8.0F * ((double)1.0F + (double)Math.abs(yawDiff) / (double)180.0F * (double)0.5F)) / 20.0F;
      if ((double)Math.abs(yawDiff) > (double)0.5F) {
         this.yaw += yawDiff * yawSpd;
      } else {
         this.yaw = this.targetYaw;
      }

      if ((double)Math.abs(pitchDiff) > (double)0.5F) {
         this.pitch += pitchDiff * 0.4F / 20.0F;
      } else {
         this.pitch = this.targetPitch;
      }

      this.yaw = this.normalizeAngle(this.yaw);
      float bodyDiff = this.normalizeAngle(this.yaw - this.bodyYaw);
      if (Math.abs(bodyDiff) > 30.0F) {
         this.bodyYaw += bodyDiff * 0.2F;
         this.bodyYaw = this.normalizeAngle(this.bodyYaw);
      }

   }

   private void pickRandomLookTarget() {
      this.targetYaw = this.yaw + (float)((Math.random() - (double)0.5F) * (double)120.0F);
      this.targetPitch = (float)((Math.random() - (double)0.5F) * (double)40.0F);
      this.targetPitch = Math.max(-60.0F, Math.min(60.0F, this.targetPitch));
   }

   private void pickWalkDirection() {
      if (this.canMoveInDirection(this.yaw)) {
         this.targetYaw = this.yaw + (float)((Math.random() - (double)0.5F) * (double)45.0F);
      } else {
         float[] angles = new float[]{45.0F, -45.0F, 90.0F, -90.0F, 135.0F, -135.0F, 180.0F};

         for(float a : angles) {
            if (this.canMoveInDirection(this.yaw + a)) {
               this.targetYaw = this.yaw + a + (float)((Math.random() - (double)0.5F) * (double)20.0F);
               break;
            }
         }
      }

      this.targetPitch = (float)((Math.random() - (double)0.5F) * (double)10.0F);
   }

   private boolean canMoveForward() {
      return this.canMoveInDirection(this.yaw);
   }

   private boolean canMoveInDirection(float checkYaw) {
      World world = this.fakePlayer.getLocation().getWorld();
      if (world == null) {
         return false;
      } else {
         double yawRad = Math.toRadians((double)(-checkYaw));
         double dx = -Math.sin(yawRad);
         double dz = Math.cos(yawRad);

         for(double dist = (double)0.5F; dist <= (double)1.5F; dist += (double)0.5F) {
            double cx = this.posX + dx * dist;
            double cz = this.posZ + dz * dist;
            Block feet = world.getBlockAt((int)Math.floor(cx), (int)Math.floor(this.posY), (int)Math.floor(cz));
            Block head = world.getBlockAt((int)Math.floor(cx), (int)Math.floor(this.posY + (double)1.0F), (int)Math.floor(cz));
            Block ground = world.getBlockAt((int)Math.floor(cx), (int)Math.floor(this.posY - (double)1.0F), (int)Math.floor(cz));
            if (this.isSolid(feet) || this.isSolid(head)) {
               return false;
            }

            if (!ground.getType().isSolid() && dist > (double)0.5F) {
               boolean hasGround = false;

               for(int dy = -1; dy >= -3; --dy) {
                  Block below = world.getBlockAt((int)Math.floor(cx), (int)Math.floor(this.posY) + dy, (int)Math.floor(cz));
                  if (below.getType().isSolid()) {
                     hasGround = true;
                     break;
                  }
               }

               if (!hasGround) {
                  return false;
               }
            }
         }

         return true;
      }
   }

   private boolean checkDropAhead() {
      World world = this.fakePlayer.getLocation().getWorld();
      if (world == null) {
         return false;
      } else {
         double yawRad = Math.toRadians((double)(-this.yaw));
         double cx = this.posX - Math.sin(yawRad) * 0.8;
         double cz = this.posZ + Math.cos(yawRad) * 0.8;
         Block ground = world.getBlockAt((int)Math.floor(cx), (int)Math.floor(this.posY - (double)1.0F), (int)Math.floor(cz));
         if (ground.getType().isSolid()) {
            return false;
         } else {
            for(int dy = -1; dy >= -4; --dy) {
               Block below = world.getBlockAt((int)Math.floor(cx), (int)Math.floor(this.posY) + dy, (int)Math.floor(cz));
               if (below.getType().isSolid()) {
                  return Math.abs(dy) > 3;
               }
            }

            return true;
         }
      }
   }

   private void applyGravity() {
      World world = this.fakePlayer.getLocation().getWorld();
      if (world != null) {
         if (this.isJumping && this.velocityY > (double)0.0F) {
            this.posY += this.velocityY;
            this.velocityY -= 0.02;
            if (this.velocityY <= (double)0.0F) {
               this.velocityY = (double)0.0F;
               this.isJumping = false;
            }

            Block head = world.getBlockAt((int)Math.floor(this.posX), (int)Math.floor(this.posY + 1.8), (int)Math.floor(this.posZ));
            if (this.isSolid(head)) {
               this.velocityY = (double)0.0F;
               this.isJumping = false;
            }

            this.onGround = false;
         } else {
            double newY = this.posY - 0.15;
            if (newY < this.posY - (double)3.0F) {
               newY = this.posY - (double)3.0F;
            }

            Block below = world.getBlockAt((int)Math.floor(this.posX), (int)Math.floor(newY - 0.1), (int)Math.floor(this.posZ));
            if (below.getType().isSolid()) {
               this.posY = (double)below.getY() + (double)1.0F;
               this.onGround = true;
               this.velocityX *= (double)0.5F;
               this.velocityZ *= (double)0.5F;
            } else {
               this.posY = newY;
               this.onGround = false;

               for(int dy = -2; dy >= -10; --dy) {
                  Block groundCheck = world.getBlockAt((int)Math.floor(this.posX), (int)Math.floor(this.posY + (double)dy), (int)Math.floor(this.posZ));
                  if (groundCheck.getType().isSolid()) {
                     Block spaceCheck = world.getBlockAt((int)Math.floor(this.posX), groundCheck.getY() + 1, (int)Math.floor(this.posZ));
                     Block headCheck = world.getBlockAt((int)Math.floor(this.posX), groundCheck.getY() + 2, (int)Math.floor(this.posZ));
                     if (!spaceCheck.getType().isSolid() && !headCheck.getType().isSolid()) {
                        this.posY = (double)groundCheck.getY() + (double)1.0F;
                        this.onGround = true;
                        break;
                     }
                  }
               }
            }
         }
      }

   }

   private void snapToGroundAt(double x, double z, World world) {
      Block below = world.getBlockAt((int)Math.floor(x), (int)Math.floor(this.posY - 0.1), (int)Math.floor(z));
      if (below.getType().isSolid()) {
         int groundY = below.getY();
         double targetY = (double)groundY + (double)1.0F;
         if (Math.abs(this.posY - targetY) < (double)0.5F) {
            this.posY = targetY;
         }
      } else {
         for(int dy = -1; dy >= -3; --dy) {
            Block checkGround = world.getBlockAt((int)Math.floor(x), (int)Math.floor(this.posY + (double)dy - (double)1.0F), (int)Math.floor(z));
            if (checkGround.getType().isSolid()) {
               Block feetCheck = world.getBlockAt((int)Math.floor(x), checkGround.getY() + 1, (int)Math.floor(z));
               Block headCheck = world.getBlockAt((int)Math.floor(x), checkGround.getY() + 2, (int)Math.floor(z));
               if (!feetCheck.getType().isSolid() && !headCheck.getType().isSolid()) {
                  if (Math.abs(dy) <= 2) {
                     this.posY = (double)checkGround.getY() + (double)1.0F;
                  }
                  break;
               }
            }
         }
      }

   }

   private String buildContext() {
      StringBuilder ctx = new StringBuilder();
      ctx.append("Pos:").append((int)this.posX).append(",").append((int)this.posY).append(",").append((int)this.posZ);
      ctx.append(" Ground:").append(this.onGround ? "Y" : "N");
      ctx.append(" Action:").append(this.currentAction);
      if (!this.canMoveForward()) {
         ctx.append(" Ahead:BLOCKED");
      } else if (this.checkDropAhead()) {
         ctx.append(" Ahead:DROP");
      } else {
         ctx.append(" Ahead:CLEAR");
      }

      return ctx.toString();
   }

   private float normalizeAngle(float a) {
      while(a <= -180.0F) {
         a += 360.0F;
      }

      while(a > 180.0F) {
         a -= 360.0F;
      }

      return a;
   }

   public void applyKnockback(Location source, double strength) {
      Vector dir = this.fakePlayer.getLocation().toVector().subtract(source.toVector());
      dir.setY(0);
      if (dir.lengthSquared() > (double)0.0F) {
         dir.normalize();
      }

      this.velocityX = dir.getX() * strength * 0.4;
      this.velocityZ = dir.getZ() * strength * 0.4;
      this.currentAction = FakePlayerAI.MovementAction.IDLE;
      this.actionTimer = 10;
   }

   public void lookAt(Location target) {
      if (target != null) {
         double dx = target.getX() - this.posX;
         double dy = target.getY() - this.posY;
         double dz = target.getZ() - this.posZ;
         this.targetYaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
         this.targetPitch = (float)Math.toDegrees(Math.atan2(-dy, Math.sqrt(dx * dx + dz * dz)));
         this.targetPitch = Math.max(-90.0F, Math.min(90.0F, this.targetPitch));
      }

   }

   public void stop() {
      this.currentAction = FakePlayerAI.MovementAction.IDLE;
      this.actionTimer = 20;
      this.velocityX = this.velocityZ = (double)0.0F;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void setEnabled(boolean e) {
      this.enabled = e;
   }

   public boolean isOnGround() {
      return this.onGround;
   }

   public boolean isJumping() {
      return this.isJumping;
   }

   public boolean isUsingAIMovement() {
      return this.movementAI != null && this.movementAI.isEnabled();
   }

   public MovementAction getCurrentAction() {
      return this.currentAction;
   }

   public void setSprinting(boolean sprinting) {
      this.sprinting = sprinting;
   }

   public boolean isSprinting() {
      return this.sprinting;
   }

   public void setJumping(boolean jumping) {
      this.isJumping = jumping;
      if (jumping && this.onGround) {
         this.velocityY = 0.3;
      }

   }

   public static enum MovementAction {
      IDLE,
      WALKING,
      SPRINTING,
      LOOKING,
      JUMPING,
      THINKING;

      // $FF: synthetic method
      private static MovementAction[] $values() {
         return new MovementAction[]{IDLE, WALKING, SPRINTING, LOOKING, JUMPING, THINKING};
      }
   }
}
