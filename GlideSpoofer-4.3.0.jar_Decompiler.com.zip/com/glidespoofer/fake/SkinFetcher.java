package com.glidespoofer.fake;

import com.glidespoofer.core.GlideSpoofer;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;

public class SkinFetcher {
   private final GlideSpoofer plugin;
   private final Map<String, SkinData> skinCache;
   private boolean enabled;

   public SkinFetcher(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.skinCache = new ConcurrentHashMap();
      this.enabled = plugin.getConfigManager().getConfig().getBoolean("skins.enabled", true);
   }

   public void fetchSkinAsync(FakePlayer fake, Runnable callback) {
      if (!this.enabled) {
         if (callback != null) {
            Bukkit.getScheduler().runTask(this.plugin, callback);
         }
      } else {
         Runnable skinTask = () -> {
            SkinData skin = null;
            if (fake.getSkinProfileUuid() != null) {
               skin = this.fetchSkinByUUID(fake.getSkinProfileUuid());
            }

            if (skin == null && this.plugin.getConfigManager().getConfig().getBoolean("skins.fetch-from-mojang", true)) {
               skin = this.fetchSkinByName(fake.getName());
            }

            if (skin != null) {
               fake.setSkinValue(skin.value);
               fake.setSkinSignature(skin.signature);
               this.skinCache.put(fake.getName().toLowerCase(), skin);
            }

            if (callback != null) {
               Bukkit.getScheduler().runTask(this.plugin, callback);
            }

         };
         if (GlideSpoofer.isFolia()) {
            skinTask.run();
         } else {
            Bukkit.getScheduler().runTaskAsynchronously(this.plugin, skinTask);
         }
      }

   }

   public SkinData fetchSkinByName(String name) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("skins.cache-enabled", true)) {
         SkinData cached = (SkinData)this.skinCache.get(name.toLowerCase());
         if (cached != null) {
            return cached;
         }
      }

      try {
         String uuidUrl = "https://api.mojang.com/users/profiles/minecraft/" + name;
         String uuidResponse = this.httpGet(uuidUrl);
         if (uuidResponse != null && !uuidResponse.isEmpty()) {
            String uuidStr = this.parseJsonString(uuidResponse, "id");
            if (uuidStr == null) {
               return null;
            } else {
               UUID uuid = this.formatUUID(uuidStr);
               return this.fetchSkinByUUID(uuid);
            }
         } else {
            return null;
         }
      } catch (Exception var6) {
         this.plugin.getLogger().fine("Failed to fetch skin for " + name + ": " + var6.getMessage());
         return null;
      }
   }

   public SkinData fetchSkinByUUID(UUID uuid) {
      try {
         String var15 = uuid.toString();
         String profileUrl = "https://sessionserver.mojang.com/session/minecraft/profile/" + var15.replace("-", "") + "?unsigned=false";
         String response = this.httpGet(profileUrl);
         if (response != null && !response.isEmpty()) {
            int propsStart = response.indexOf("\"properties\"");
            if (propsStart == -1) {
               return null;
            } else {
               int texturesStart = response.indexOf("\"name\":\"textures\"", propsStart);
               if (texturesStart == -1) {
                  return null;
               } else {
                  int valueStart = response.indexOf("\"value\":\"", texturesStart);
                  if (valueStart == -1) {
                     return null;
                  } else {
                     valueStart += 9;
                     int valueEnd = response.indexOf("\"", valueStart);
                     String value = response.substring(valueStart, valueEnd);
                     String signature = null;
                     int sigStart = response.indexOf("\"signature\":\"", texturesStart);
                     if (sigStart != -1) {
                        sigStart += 13;
                        int sigEnd = response.indexOf("\"", sigStart);
                        signature = response.substring(sigStart, sigEnd);
                     }

                     return new SkinData(value, signature);
                  }
               }
            }
         } else {
            return null;
         }
      } catch (Exception var12) {
         Logger var10000 = this.plugin.getLogger();
         String var10001 = String.valueOf(uuid);
         var10000.fine("Failed to fetch skin for UUID " + var10001 + ": " + var12.getMessage());
         return null;
      }
   }

   private String httpGet(String urlStr) {
      try {
         HttpURLConnection conn = (HttpURLConnection)(new URL(urlStr)).openConnection();
         conn.setRequestMethod("GET");
         conn.setRequestProperty("User-Agent", "GlideSpoofer/3.0");
         conn.setConnectTimeout(5000);
         conn.setReadTimeout(5000);
         if (conn.getResponseCode() != 200) {
            return null;
         } else {
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();

            String line;
            while((line = reader.readLine()) != null) {
               response.append(line);
            }

            reader.close();
            return response.toString();
         }
      } catch (Exception var6) {
         return null;
      }
   }

   private String parseJsonString(String json, String key) {
      Pattern pattern = Pattern.compile("\"" + key + "\"\\s*:\\s*\"([^\"]+)\"");
      Matcher matcher = pattern.matcher(json);
      return matcher.find() ? matcher.group(1) : null;
   }

   private UUID formatUUID(String uuidStr) {
      UUID var10000;
      if (uuidStr.contains("-")) {
         var10000 = UUID.fromString(uuidStr);
      } else {
         String var2 = uuidStr.substring(0, 8);
         var10000 = UUID.fromString(var2 + "-" + uuidStr.substring(8, 12) + "-" + uuidStr.substring(12, 16) + "-" + uuidStr.substring(16, 20) + "-" + uuidStr.substring(20));
      }

      return var10000;
   }

   public int getCacheSize() {
      return this.skinCache.size();
   }

   public void clearCache() {
      this.skinCache.clear();
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void setEnabled(boolean enabled) {
      this.enabled = enabled;
   }

   public static class SkinData {
      public final String value;
      public final String signature;

      public SkinData(String value, String signature) {
         this.value = value;
         this.signature = signature;
      }
   }
}
