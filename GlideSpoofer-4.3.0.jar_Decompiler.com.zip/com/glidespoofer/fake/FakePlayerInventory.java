package com.glidespoofer.fake;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public class FakePlayerInventory {
   private final UUID fakePlayerUuid;
   private static final int MAIN_SIZE = 36;
   private static final int HOTBAR_SIZE = 9;
   public static final int HELMET_SLOT = 36;
   public static final int CHESTPLATE_SLOT = 37;
   public static final int LEGGINGS_SLOT = 38;
   public static final int BOOTS_SLOT = 39;
   public static final int OFFHAND_SLOT = 40;
   private static final int TOTAL_SIZE = 41;
   private int heldItemSlot = 0;

   public FakePlayerInventory(UUID fakePlayerUuid) {
      this.fakePlayerUuid = fakePlayerUuid;
   }

   private Player getRealPlayer() {
      return Bukkit.getPlayer(this.fakePlayerUuid);
   }

   public boolean addItem(ItemStack item) {
      if (item != null && !item.getType().isAir()) {
         Player real = this.getRealPlayer();
         if (real == null) {
            return false;
         } else if (this.tryAutoEquipArmor(real, item)) {
            return true;
         } else {
            HashMap<Integer, ItemStack> leftover = real.getInventory().addItem(new ItemStack[]{item.clone()});
            return leftover.isEmpty();
         }
      } else {
         return false;
      }
   }

   private boolean tryAutoEquipArmor(Player real, ItemStack item) {
      String name = item.getType().name().toUpperCase();
      PlayerInventory inv = real.getInventory();
      if (!name.contains("HELMET") && !name.contains("_CAP") && !name.equals("CARVED_PUMPKIN") && !name.equals("TURTLE_HELMET") && !name.contains("SKULL") && !name.contains("HEAD") || inv.getHelmet() != null && !inv.getHelmet().getType().isAir()) {
         if (!name.contains("CHESTPLATE") && !name.contains("_TUNIC") && !name.equals("ELYTRA") || inv.getChestplate() != null && !inv.getChestplate().getType().isAir()) {
            if (!name.contains("LEGGINGS") && !name.contains("_PANTS") || inv.getLeggings() != null && !inv.getLeggings().getType().isAir()) {
               if (name.contains("BOOTS") && (inv.getBoots() == null || inv.getBoots().getType().isAir())) {
                  inv.setBoots(item.clone());
                  return true;
               } else {
                  return false;
               }
            } else {
               inv.setLeggings(item.clone());
               return true;
            }
         } else {
            inv.setChestplate(item.clone());
            return true;
         }
      } else {
         inv.setHelmet(item.clone());
         return true;
      }
   }

   public boolean removeItem(Material material, int amount) {
      Player real = this.getRealPlayer();
      if (real == null) {
         return false;
      } else {
         int remaining = amount;
         PlayerInventory inv = real.getInventory();

         for(int i = 0; i < inv.getSize() && remaining > 0; ++i) {
            ItemStack slot = inv.getItem(i);
            if (slot != null && slot.getType() == material) {
               int cur = slot.getAmount();
               if (cur <= remaining) {
                  remaining -= cur;
                  inv.setItem(i, (ItemStack)null);
               } else {
                  slot.setAmount(cur - remaining);
                  remaining = 0;
               }
            }
         }

         return remaining <= 0;
      }
   }

   public boolean removeItem(ItemStack item) {
      Player real = this.getRealPlayer();
      if (real == null) {
         return false;
      } else {
         real.getInventory().removeItem(new ItemStack[]{item});
         return true;
      }
   }

   public ItemStack removeItem(int index) {
      Player real = this.getRealPlayer();
      if (real == null) {
         return null;
      } else if (index >= 0 && index < real.getInventory().getSize()) {
         ItemStack removed = real.getInventory().getItem(index);
         real.getInventory().setItem(index, (ItemStack)null);
         return removed;
      } else {
         return null;
      }
   }

   public List<ItemStack> getItems() {
      List<ItemStack> items = new ArrayList();
      Player real = this.getRealPlayer();
      if (real == null) {
         return items;
      } else {
         for(ItemStack slot : real.getInventory().getContents()) {
            if (slot != null && !slot.getType().isAir()) {
               items.add(slot.clone());
            }
         }

         for(ItemStack armor : real.getInventory().getArmorContents()) {
            if (armor != null && !armor.getType().isAir()) {
               items.add(armor.clone());
            }
         }

         ItemStack offhand = real.getInventory().getItemInOffHand();
         if (offhand != null && !offhand.getType().isAir()) {
            items.add(offhand.clone());
         }

         return items;
      }
   }

   public ItemStack getItem(int index) {
      Player real = this.getRealPlayer();
      if (real == null) {
         return null;
      } else {
         return index >= 0 && index < real.getInventory().getSize() ? real.getInventory().getItem(index) : null;
      }
   }

   public void setItem(int index, ItemStack item) {
      Player real = this.getRealPlayer();
      if (real != null && index >= 0 && index < real.getInventory().getSize()) {
         real.getInventory().setItem(index, item != null ? item.clone() : null);
      }

   }

   public ItemStack getItemInMainHand() {
      Player real = this.getRealPlayer();
      return real != null ? real.getInventory().getItemInMainHand() : null;
   }

   public void setItemInMainHand(ItemStack item) {
      Player real = this.getRealPlayer();
      if (real != null) {
         real.getInventory().setItemInMainHand(item != null ? item.clone() : null);
      }

   }

   public ItemStack getItemInOffHand() {
      Player real = this.getRealPlayer();
      return real != null ? real.getInventory().getItemInOffHand() : null;
   }

   public void setItemInOffHand(ItemStack item) {
      Player real = this.getRealPlayer();
      if (real != null) {
         real.getInventory().setItemInOffHand(item != null ? item.clone() : null);
      }

   }

   public ItemStack getHelmet() {
      Player real = this.getRealPlayer();
      return real != null ? real.getInventory().getHelmet() : null;
   }

   public void setHelmet(ItemStack item) {
      Player real = this.getRealPlayer();
      if (real != null) {
         real.getInventory().setHelmet(item != null ? item.clone() : null);
      }

   }

   public ItemStack getChestplate() {
      Player real = this.getRealPlayer();
      return real != null ? real.getInventory().getChestplate() : null;
   }

   public void setChestplate(ItemStack item) {
      Player real = this.getRealPlayer();
      if (real != null) {
         real.getInventory().setChestplate(item != null ? item.clone() : null);
      }

   }

   public ItemStack getLeggings() {
      Player real = this.getRealPlayer();
      return real != null ? real.getInventory().getLeggings() : null;
   }

   public void setLeggings(ItemStack item) {
      Player real = this.getRealPlayer();
      if (real != null) {
         real.getInventory().setLeggings(item != null ? item.clone() : null);
      }

   }

   public ItemStack getBoots() {
      Player real = this.getRealPlayer();
      return real != null ? real.getInventory().getBoots() : null;
   }

   public void setBoots(ItemStack item) {
      Player real = this.getRealPlayer();
      if (real != null) {
         real.getInventory().setBoots(item != null ? item.clone() : null);
      }

   }

   public void syncToEquipment(FakePlayerEquipment equipment) {
      if (equipment != null) {
         Player real = this.getRealPlayer();
         if (real != null) {
            PlayerInventory inv = real.getInventory();
            equipment.setHelmet(inv.getHelmet());
            equipment.setChestplate(inv.getChestplate());
            equipment.setLeggings(inv.getLeggings());
            equipment.setBoots(inv.getBoots());
            equipment.setMainHand(inv.getItemInMainHand());
            equipment.setOffHand(inv.getItemInOffHand());
         }
      }

   }

   public void clear() {
      Player real = this.getRealPlayer();
      if (real != null) {
         real.getInventory().clear();
      }

   }

   public int getSize() {
      Player real = this.getRealPlayer();
      if (real == null) {
         return 0;
      } else {
         int count = 0;

         for(ItemStack s : real.getInventory().getContents()) {
            if (s != null && !s.getType().isAir()) {
               ++count;
            }
         }

         return count;
      }
   }

   public boolean isFull() {
      Player real = this.getRealPlayer();
      return real == null ? true : real.getInventory().firstEmpty() == -1;
   }

   public boolean isEmpty() {
      return this.getSize() == 0;
   }

   public boolean contains(Material material) {
      Player real = this.getRealPlayer();
      return real != null && real.getInventory().contains(material);
   }

   public int countMaterial(Material material) {
      Player real = this.getRealPlayer();
      if (real == null) {
         return 0;
      } else {
         int count = 0;

         for(ItemStack s : real.getInventory().getContents()) {
            if (s != null && s.getType() == material) {
               count += s.getAmount();
            }
         }

         return count;
      }
   }

   public int getHeldItemSlot() {
      return this.heldItemSlot;
   }

   public void setHeldItemSlot(int slot) {
      if (slot >= 0 && slot < 9) {
         this.heldItemSlot = slot;
      }

   }

   public ItemStack[] getContents() {
      Player real = this.getRealPlayer();
      return real != null ? real.getInventory().getContents() : new ItemStack[0];
   }

   public ItemStack[] getArmorContents() {
      Player real = this.getRealPlayer();
      return real != null ? real.getInventory().getArmorContents() : new ItemStack[0];
   }

   public UUID getFakePlayerUuid() {
      return this.fakePlayerUuid;
   }
}
