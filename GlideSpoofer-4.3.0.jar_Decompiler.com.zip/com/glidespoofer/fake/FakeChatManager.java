package com.glidespoofer.fake;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.hooks.AuthMeHook;
import com.glidespoofer.hooks.InteractiveChatHook;
import com.glidespoofer.hooks.LPCHook;
import com.glidespoofer.hooks.ZelChatHook;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class FakeChatManager implements Listener {
   private final GlideSpoofer plugin;
   private final Random random;
   private final Map<UUID, Long> lastChatTime;
   private final Map<UUID, Boolean> isMuted;
   private Object chatTask;
   private boolean enabled;
   private InteractiveChatHook interactiveChatHook;
   private LPCHook lpcHook;
   private ZelChatHook zelChatHook;

   public FakeChatManager(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.random = new Random();
      this.lastChatTime = new ConcurrentHashMap();
      this.isMuted = new ConcurrentHashMap();
      this.enabled = plugin.getConfigManager().getConfig().getBoolean("chat.enabled", true);
      this.interactiveChatHook = null;
      this.lpcHook = null;
      this.zelChatHook = null;
   }

   public void setInteractiveChatHook(InteractiveChatHook hook) {
      this.interactiveChatHook = hook;
   }

   public InteractiveChatHook getInteractiveChatHook() {
      return this.interactiveChatHook;
   }

   public void setLPCHook(LPCHook hook) {
      this.lpcHook = hook;
   }

   public LPCHook getLPCHook() {
      return this.lpcHook;
   }

   public void setZelChatHook(ZelChatHook hook) {
      this.zelChatHook = hook;
   }

   public ZelChatHook getZelChatHook() {
      return this.zelChatHook;
   }

   private List<String> getSpawnedFakePlayerNames() {
      List<String> names = new ArrayList();
      if (this.plugin.isUsingNMS() && this.plugin.getSimpleFakePlayerManager() != null) {
         for(SimpleFakePlayerManager.FakePlayerData data : this.plugin.getSimpleFakePlayerManager().getAllFakePlayers()) {
            names.add(data.getName());
         }
      }

      return names;
   }

   private SimpleFakePlayerManager.FakePlayerData getFakePlayerData(String name) {
      return this.plugin.isUsingNMS() && this.plugin.getSimpleFakePlayerManager() != null ? this.plugin.getSimpleFakePlayerManager().getFakePlayer(name) : null;
   }

   public void start() {
      if (this.enabled) {
         int interval = this.plugin.getConfigManager().getConfig().getInt("chat.interval", 90) * 20;
         if (GlideSpoofer.isFolia()) {
            this.chatTask = this.runFoliaGlobalTask(() -> this.tryRandomChat(), (long)interval, (long)interval);
         } else {
            this.chatTask = Bukkit.getScheduler().runTaskTimer(this.plugin, this::tryRandomChat, (long)interval, (long)interval);
         }

         if (this.plugin.getConfigManager().getConfig().getBoolean("chat.reply-to-players", true)) {
            Bukkit.getPluginManager().registerEvents(this, this.plugin);
         }

         this.plugin.getLogger().info("Fake chat system started (using real chat events)!");
      }

   }

   public void stop() {
      this.cancelTask(this.chatTask);
      this.chatTask = null;
   }

   private void cancelTask(Object task) {
      if (task != null) {
         try {
            if (task instanceof BukkitTask) {
               ((BukkitTask)task).cancel();
            } else if (task.getClass().getName().contains("ScheduledTask")) {
               task.getClass().getMethod("cancel").invoke(task);
            }
         } catch (Exception var3) {
         }
      }

   }

   private void tryRandomChat() {
      if (this.enabled && !Bukkit.getOnlinePlayers().isEmpty()) {
         int chance = this.plugin.getConfigManager().getConfig().getInt("chat.chance", 15);
         if (this.random.nextInt(100) < chance) {
            List<String> fakeNames = this.getSpawnedFakePlayerNames();
            if (!fakeNames.isEmpty()) {
               int cooldownSeconds = this.plugin.getConfigManager().getConfig().getInt("chat.cooldown", 60);
               long now = System.currentTimeMillis();
               List<String> available = new ArrayList();

               for(String name : fakeNames) {
                  SimpleFakePlayerManager.FakePlayerData data = this.getFakePlayerData(name);
                  if (data != null && !(Boolean)this.isMuted.getOrDefault(data.getUuid(), false)) {
                     Long lastChat = (Long)this.lastChatTime.get(data.getUuid());
                     if (lastChat == null || now - lastChat > (long)cooldownSeconds * 1000L) {
                        available.add(name);
                     }
                  }
               }

               if (!available.isEmpty()) {
                  String chosenName = (String)available.get(this.random.nextInt(available.size()));
                  SimpleFakePlayerManager.FakePlayerData chosenData = this.getFakePlayerData(chosenName);
                  if (chosenData != null) {
                     List<String> messages = this.plugin.getConfigManager().getConfig().getStringList("chat.messages");
                     if (!messages.isEmpty()) {
                        String message = (String)messages.get(this.random.nextInt(messages.size()));
                        this.sendFakeChat(chosenData, message);
                        this.lastChatTime.put(chosenData.getUuid(), now);
                     }
                  }
               }
            }
         }
      }

   }

   private void sendFakeChat(SimpleFakePlayerManager.FakePlayerData fakeData, String message) {
      Player fakePlayer = fakeData.getPlayer();
      if (fakePlayer != null) {
         if (this.zelChatHook != null && this.zelChatHook.isEnabled() && this.zelChatHook.isChatMuted()) {
            this.plugin.getLogger().fine("[FakeChat] Chat is muted in ZelChat, skipping message from " + fakeData.getName());
         } else {
            AuthMeHook authMeHook = this.plugin.getAuthMeHook();
            if (authMeHook != null && authMeHook.isEnabled()) {
               authMeHook.ensureAuthenticated(fakePlayer);
            }

            if (this.plugin.getLuckPermsHook() != null && this.plugin.getLuckPermsHook().isEnabled()) {
               try {
                  Object user = this.plugin.getLuckPermsHook().getUserByUuid(fakeData.getUuid());
                  if (user == null) {
                     this.plugin.getLuckPermsHook().loadUser(fakeData.getUuid(), fakeData.getName()).join();
                  }
               } catch (Exception var10) {
                  this.plugin.getLogger().fine("[FakeChat] LuckPerms user load warning: " + var10.getMessage());
               }
            }

            Set<Player> realRecipients = new HashSet();

            for(Player player : Bukkit.getOnlinePlayers()) {
               if (this.plugin.getSimpleFakePlayerManager() != null && !this.plugin.getSimpleFakePlayerManager().isFakePlayer(player)) {
                  realRecipients.add(player);
               }
            }

            if (!realRecipients.isEmpty()) {
               boolean lpcActive = this.lpcHook != null && this.lpcHook.shouldFormatWithLPC();

               try {
                  String finalMessage = message;
                  if (this.interactiveChatHook != null && this.interactiveChatHook.isEnabled()) {
                     finalMessage = this.interactiveChatHook.markSender(message, fakeData.getUuid());
                  }

                  fakePlayer.chat(finalMessage);
                  if (this.plugin.getConfigManager().getConfig().getBoolean("debug.enabled", false)) {
                     StringBuilder tag = new StringBuilder("[FakeChat");
                     if (lpcActive) {
                        tag.append("-LPC");
                     }

                     if (this.interactiveChatHook != null && this.interactiveChatHook.isEnabled()) {
                        tag.append("-IC");
                     }

                     if (this.zelChatHook != null && this.zelChatHook.isEnabled()) {
                        tag.append("-ZC");
                     }

                     tag.append("] ");
                     Logger var10000 = this.plugin.getLogger();
                     String var10001 = String.valueOf(tag);
                     var10000.info(var10001 + fakeData.getName() + ": " + message);
                  }
               } catch (Exception var9) {
                  this.plugin.getLogger().log(Level.WARNING, "Error sending fake chat: " + var9.getMessage(), var9);
               }
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onPlayerChat(AsyncPlayerChatEvent event) {
      if (this.enabled && this.plugin.getConfigManager().getConfig().getBoolean("chat.reply-to-players", true)) {
         int replyChance = this.plugin.getConfigManager().getConfig().getInt("chat.reply-chance", 10);
         if (this.random.nextInt(100) < replyChance) {
            List<String> fakeNames = this.getSpawnedFakePlayerNames();
            if (!fakeNames.isEmpty()) {
               String replierName = (String)fakeNames.get(this.random.nextInt(fakeNames.size()));
               SimpleFakePlayerManager.FakePlayerData replierData = this.getFakePlayerInfo(replierName);
               if (replierData != null) {
                  UUID replierUuid = replierData.getUuid();
                  int cooldownSeconds = this.plugin.getConfigManager().getConfig().getInt("chat.cooldown", 60);
                  Long lastChat = (Long)this.lastChatTime.get(replierUuid);
                  if ((lastChat == null || System.currentTimeMillis() - lastChat >= (long)cooldownSeconds * 1000L) && !(Boolean)this.isMuted.getOrDefault(replierUuid, false)) {
                     List<String> replies = this.plugin.getConfigManager().getConfig().getStringList("chat.replies");
                     if (replies.isEmpty()) {
                        replies = this.plugin.getConfigManager().getConfig().getStringList("chat.messages");
                     }

                     if (!replies.isEmpty()) {
                        String reply = (String)replies.get(this.random.nextInt(replies.size()));
                        int minDelay = this.plugin.getConfigManager().getConfig().getInt("chat.reply-delay-min", 2);
                        int maxDelay = this.plugin.getConfigManager().getConfig().getInt("chat.reply-delay-max", 8);
                        int delay = minDelay + this.random.nextInt(Math.max(1, maxDelay - minDelay));
                        if (GlideSpoofer.isFolia()) {
                           this.runFoliaGlobalDelayedTask(() -> {
                              this.sendFakeChat(replierData, reply);
                              this.lastChatTime.put(replierUuid, System.currentTimeMillis());
                           }, (long)delay * 20L);
                        } else {
                           Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                              this.sendFakeChat(replierData, reply);
                              this.lastChatTime.put(replierUuid, System.currentTimeMillis());
                           }, (long)delay * 20L);
                        }
                     }
                  }
               }
            }
         }
      }

   }

   private SimpleFakePlayerManager.FakePlayerData getFakePlayerInfo(String name) {
      return this.plugin.isUsingNMS() && this.plugin.getSimpleFakePlayerManager() != null ? this.plugin.getSimpleFakePlayerManager().getFakePlayer(name) : null;
   }

   public void say(String fakeName, String message) {
      SimpleFakePlayerManager.FakePlayerData data = this.getFakePlayerData(fakeName);
      if (data != null && !(Boolean)this.isMuted.getOrDefault(data.getUuid(), false)) {
         this.sendFakeChat(data, message);
         this.lastChatTime.put(data.getUuid(), System.currentTimeMillis());
      }

   }

   public void sayRandom(String message) {
      List<String> fakeNames = this.getSpawnedFakePlayerNames();
      if (!fakeNames.isEmpty()) {
         String name = (String)fakeNames.get(this.random.nextInt(fakeNames.size()));
         SimpleFakePlayerManager.FakePlayerData data = this.getFakePlayerData(name);
         if (data != null && !(Boolean)this.isMuted.getOrDefault(data.getUuid(), false)) {
            this.sendFakeChat(data, message);
            this.lastChatTime.put(data.getUuid(), System.currentTimeMillis());
         }
      }

   }

   public void setMuted(UUID uuid, boolean muted) {
      this.isMuted.put(uuid, muted);
   }

   public boolean isMuted(UUID uuid) {
      return (Boolean)this.isMuted.getOrDefault(uuid, false);
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void setEnabled(boolean enabled) {
      this.enabled = enabled;
   }

   private Object runFoliaGlobalTask(Runnable task, long initialDelay, long period) {
      try {
         Method getGlobalRegionScheduler = Bukkit.class.getMethod("getGlobalRegionScheduler");
         Object regionScheduler = getGlobalRegionScheduler.invoke((Object)null);
         Method runAtFixedRate = regionScheduler.getClass().getMethod("runAtFixedRate", Plugin.class, Consumer.class, Long.TYPE, Long.TYPE);
         Consumer<Object> taskWrapper = (ignored) -> task.run();
         return runAtFixedRate.invoke(regionScheduler, this.plugin, taskWrapper, initialDelay, period);
      } catch (Exception var10) {
         this.plugin.getLogger().severe("Failed to schedule Folia task: " + var10.getMessage());
         throw new UnsupportedOperationException("Folia scheduling failed", var10);
      }
   }

   private void runFoliaGlobalDelayedTask(Runnable task, long delay) {
      try {
         Method getGlobalRegionScheduler = Bukkit.class.getMethod("getGlobalRegionScheduler");
         Object regionScheduler = getGlobalRegionScheduler.invoke((Object)null);
         Method runDelayed = regionScheduler.getClass().getMethod("runDelayed", Plugin.class, Consumer.class, Long.TYPE);
         runDelayed.invoke(regionScheduler, this.plugin, (Consumer)(t) -> task.run(), delay);
      } catch (Exception var7) {
         this.plugin.getLogger().warning("Failed to schedule delayed Folia task, falling back to Bukkit scheduler: " + var7.getMessage());
         Bukkit.getScheduler().runTaskLater(this.plugin, task, delay);
      }

   }
}
