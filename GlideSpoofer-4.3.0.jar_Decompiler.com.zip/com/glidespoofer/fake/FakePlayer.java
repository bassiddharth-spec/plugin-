package com.glidespoofer.fake;

import com.glidespoofer.ai.MovementAIService;
import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.pathfinding.SmartMovementController;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class FakePlayer {
   private final UUID uuid;
   private final String name;
   private Location location;
   private UUID skinProfileUuid;
   private String skinValue;
   private String skinSignature;
   private final Map<UUID, Integer> viewerEntityIds;
   private boolean visibleInTab;
   private boolean visibleInPing;
   private boolean visibleInWorld;
   private String displayName;
   private String prefix;
   private String suffix;
   private String tabColor;
   private String rank;
   private int ping;
   private String ipAddress;
   private int fakeVotes;
   private long spawnTime;
   private boolean spawned;
   private boolean dead;
   private int health;
   private int maxHealth;
   private long deathTime;
   private AnimationState activeAnimation;
   private FakePlayerEquipment equipment;
   private FakePlayerAI ai;
   private SmartMovementController smartMovement;
   private FakePlayerInventory inventory;
   private int hurtAnimationTicks;
   private static final int HURT_ANIMATION_DURATION = 10;

   public FakePlayer(String name) {
      this.uuid = generateOfflineUUID(name);
      this.name = name;
      this.viewerEntityIds = new ConcurrentHashMap();
      this.visibleInTab = true;
      this.visibleInPing = true;
      this.visibleInWorld = true;
      this.displayName = name;
      this.prefix = "";
      this.suffix = "";
      this.tabColor = "§7";
      this.rank = "default";
      this.ping = this.generatePing();
      this.ipAddress = this.generateIP();
      this.fakeVotes = 0;
      this.spawnTime = System.currentTimeMillis();
      this.spawned = false;
      this.health = 20;
      this.maxHealth = 20;
   }

   public FakePlayer(UUID uuid, String name) {
      this.uuid = uuid;
      this.name = name;
      this.viewerEntityIds = new ConcurrentHashMap();
      this.visibleInTab = true;
      this.visibleInPing = true;
      this.visibleInWorld = true;
      this.displayName = name;
      this.prefix = "";
      this.suffix = "";
      this.tabColor = "§7";
      this.rank = "default";
      this.ping = this.generatePing();
      this.ipAddress = this.generateIP();
      this.fakeVotes = 0;
      this.spawnTime = System.currentTimeMillis();
      this.spawned = false;
      this.health = 20;
      this.maxHealth = 20;
   }

   public static UUID generateOfflineUUID(String name) {
      return UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
   }

   public void setViewerEntityId(Player viewer, int entityId) {
      this.viewerEntityIds.put(viewer.getUniqueId(), entityId);
   }

   public void setViewerEntityId(UUID viewerUuid, int entityId) {
      this.viewerEntityIds.put(viewerUuid, entityId);
   }

   public Integer getViewerEntityId(Player viewer) {
      return (Integer)this.viewerEntityIds.get(viewer.getUniqueId());
   }

   public Integer getViewerEntityId(UUID viewerUuid) {
      return (Integer)this.viewerEntityIds.get(viewerUuid);
   }

   public void removeViewerEntityId(Player viewer) {
      this.viewerEntityIds.remove(viewer.getUniqueId());
   }

   public void removeViewerEntityId(UUID viewerUuid) {
      this.viewerEntityIds.remove(viewerUuid);
   }

   public boolean hasViewerEntityId(Player viewer) {
      return this.viewerEntityIds.containsKey(viewer.getUniqueId());
   }

   public Map<UUID, Integer> getAllViewerEntityIds() {
      return new ConcurrentHashMap(this.viewerEntityIds);
   }

   public void clearViewerEntityIds() {
      this.viewerEntityIds.clear();
   }

   private int generatePing() {
      double r = Math.random();
      if (r < 0.4) {
         return 15 + (int)(Math.random() * (double)50.0F);
      } else if (r < (double)0.75F) {
         return 65 + (int)(Math.random() * (double)80.0F);
      } else {
         return r < 0.92 ? 145 + (int)(Math.random() * (double)100.0F) : 245 + (int)(Math.random() * (double)150.0F);
      }
   }

   private String generateIP() {
      int[] firstOctets = new int[]{24, 31, 45, 64, 68, 71, 72, 74, 75, 76, 98, 99, 107, 108, 134, 173, 174, 184};
      int first = firstOctets[(int)(Math.random() * (double)firstOctets.length)];
      return first + "." + (int)(Math.random() * (double)256.0F) + "." + (int)(Math.random() * (double)256.0F) + "." + (1 + (int)(Math.random() * (double)254.0F));
   }

   public long getOnlineTime() {
      return System.currentTimeMillis() - this.spawnTime;
   }

   public String getFormattedDisplayName() {
      StringBuilder sb = new StringBuilder();
      if (this.prefix != null && !this.prefix.isEmpty()) {
         sb.append(this.prefix);
      }

      sb.append(this.tabColor != null ? this.tabColor : "§7").append(this.name);
      if (this.suffix != null && !this.suffix.isEmpty()) {
         sb.append(this.suffix);
      }

      return sb.toString();
   }

   public void updatePing() {
      int variance = (int)(Math.random() * (double)15.0F) - 7;
      this.ping = Math.max(10, Math.min(400, this.ping + variance));
   }

   public void damage(int amount) {
      if (!this.dead) {
         this.health = Math.max(0, this.health - amount);
         this.triggerHurtAnimation();
         if (this.health <= 0) {
            this.die();
         }
      }

   }

   public boolean isDead() {
      return this.dead || this.health <= 0;
   }

   public void die() {
      this.dead = true;
      this.deathTime = System.currentTimeMillis();
      this.activeAnimation = null;
      this.resetHurtAnimation();
   }

   public void heal() {
      this.health = this.maxHealth;
      this.dead = false;
      this.deathTime = 0L;
   }

   public void respawn() {
      this.heal();
      this.activeAnimation = null;
   }

   public void setActiveAnimation(AnimationState animation) {
      this.activeAnimation = animation;
   }

   public AnimationState getActiveAnimation() {
      return this.activeAnimation;
   }

   public void stopAnimation() {
      this.activeAnimation = null;
   }

   public boolean hasActiveAnimation() {
      return this.activeAnimation != null;
   }

   public UUID getUuid() {
      return this.uuid;
   }

   public String getName() {
      return this.name;
   }

   public Location getLocation() {
      return this.location;
   }

   public void setLocation(Location location) {
      this.location = location;
   }

   public UUID getSkinProfileUuid() {
      return this.skinProfileUuid;
   }

   public void setSkinProfileUuid(UUID skinProfileUuid) {
      this.skinProfileUuid = skinProfileUuid;
   }

   public String getSkinValue() {
      return this.skinValue;
   }

   public void setSkinValue(String skinValue) {
      this.skinValue = skinValue;
   }

   public String getSkinSignature() {
      return this.skinSignature;
   }

   public void setSkinSignature(String skinSignature) {
      this.skinSignature = skinSignature;
   }

   public boolean hasSkin() {
      return this.skinValue != null && !this.skinValue.isEmpty();
   }

   public boolean isVisibleInTab() {
      return this.visibleInTab;
   }

   public void setVisibleInTab(boolean visibleInTab) {
      this.visibleInTab = visibleInTab;
   }

   public boolean isVisibleInPing() {
      return this.visibleInPing;
   }

   public void setVisibleInPing(boolean visibleInPing) {
      this.visibleInPing = visibleInPing;
   }

   public boolean isVisibleInWorld() {
      return this.visibleInWorld;
   }

   public void setVisibleInWorld(boolean visibleInWorld) {
      this.visibleInWorld = visibleInWorld;
   }

   public String getDisplayName() {
      return this.displayName;
   }

   public void setDisplayName(String displayName) {
      this.displayName = displayName;
   }

   public String getPrefix() {
      return this.prefix;
   }

   public void setPrefix(String prefix) {
      this.prefix = prefix;
   }

   public String getSuffix() {
      return this.suffix;
   }

   public void setSuffix(String suffix) {
      this.suffix = suffix;
   }

   public String getTabColor() {
      return this.tabColor;
   }

   public void setTabColor(String tabColor) {
      this.tabColor = tabColor;
   }

   public String getRank() {
      return this.rank;
   }

   public void setRank(String rank) {
      this.rank = rank;
   }

   public int getPing() {
      return this.ping;
   }

   public void setPing(int ping) {
      this.ping = ping;
   }

   public String getIpAddress() {
      return this.ipAddress;
   }

   public void setIpAddress(String ipAddress) {
      this.ipAddress = ipAddress;
   }

   public int getFakeVotes() {
      return this.fakeVotes;
   }

   public void setFakeVotes(int fakeVotes) {
      this.fakeVotes = fakeVotes;
   }

   public void addFakeVotes(int amount) {
      this.fakeVotes += amount;
   }

   public long getSpawnTime() {
      return this.spawnTime;
   }

   public void setSpawnTime(long spawnTime) {
      this.spawnTime = spawnTime;
   }

   public long getDeathTime() {
      return this.deathTime;
   }

   public void setDeathTime(long deathTime) {
      this.deathTime = deathTime;
   }

   public boolean isSpawned() {
      return this.spawned;
   }

   public void setSpawned(boolean spawned) {
      this.spawned = spawned;
   }

   public int getHealth() {
      return this.health;
   }

   public void setHealth(int health) {
      this.health = health;
   }

   public int getMaxHealth() {
      return this.maxHealth;
   }

   public void setMaxHealth(int maxHealth) {
      this.maxHealth = maxHealth;
   }

   public FakePlayerEquipment getEquipment() {
      if (this.equipment == null) {
         this.equipment = new FakePlayerEquipment();
      }

      return this.equipment;
   }

   public void setEquipment(FakePlayerEquipment equipment) {
      this.equipment = equipment;
   }

   public FakePlayerAI getAI() {
      if (this.ai == null) {
         this.ai = new FakePlayerAI(this);

         try {
            GlideSpoofer plugin = GlideSpoofer.getInstance();
            if (plugin != null) {
               MovementAIService movementAI = plugin.getMovementAI();
               if (movementAI != null && movementAI.isEnabled()) {
                  this.ai.setMovementAI(movementAI);
               }
            }
         } catch (Exception var3) {
         }
      }

      return this.ai;
   }

   public void setAI(FakePlayerAI ai) {
      this.ai = ai;
   }

   public boolean hasAI() {
      return this.ai != null;
   }

   public boolean hasEquipment() {
      return this.equipment != null;
   }

   public SmartMovementController getSmartMovement() {
      if (this.smartMovement == null) {
         this.smartMovement = new SmartMovementController(this.uuid);
      }

      return this.smartMovement;
   }

   public FakePlayerInventory getInventory() {
      if (this.inventory == null) {
         this.inventory = new FakePlayerInventory(this.uuid);
      }

      return this.inventory;
   }

   public void setInventory(FakePlayerInventory inventory) {
      this.inventory = inventory;
   }

   public boolean hasInventory() {
      return this.inventory != null;
   }

   public void triggerHurtAnimation() {
      this.hurtAnimationTicks = 10;
   }

   public boolean isHurtAnimationActive() {
      return this.hurtAnimationTicks > 0;
   }

   public int getHurtAnimationTicks() {
      return this.hurtAnimationTicks;
   }

   public boolean tickHurtAnimation() {
      if (this.hurtAnimationTicks > 0) {
         --this.hurtAnimationTicks;
         return this.hurtAnimationTicks > 0;
      } else {
         return false;
      }
   }

   public void resetHurtAnimation() {
      this.hurtAnimationTicks = 0;
   }

   public boolean equals(Object o) {
      if (this == o) {
         return true;
      } else if (o != null && this.getClass() == o.getClass()) {
         FakePlayer that = (FakePlayer)o;
         return this.uuid.equals(that.uuid);
      } else {
         return false;
      }
   }

   public int hashCode() {
      return this.uuid.hashCode();
   }

   public String toString() {
      String var10000 = this.name;
      return "FakePlayer{name='" + var10000 + "', uuid=" + String.valueOf(this.uuid) + ", spawned=" + this.spawned + "}";
   }

   public static enum AnimationState {
      SWING_ARM,
      MINING,
      PATHFINDING_WALK,
      COMBAT,
      GUARD,
      NONE;

      // $FF: synthetic method
      private static AnimationState[] $values() {
         return new AnimationState[]{SWING_ARM, MINING, PATHFINDING_WALK, COMBAT, GUARD, NONE};
      }
   }
}
