package com.glidespoofer.fake;

public enum FakePlayerAnimation {
   WALK,
   SPRINT,
   SWIM,
   SWING_MAIN_HAND,
   SWING_OFF_HAND,
   HIT,
   CRIT,
   MAGIC_CRIT,
   SLEEP,
   WAKE_UP,
   HURT,
   DEATH,
   BLOCK,
   BOW_CHARGE,
   ITEM_BREAK,
   START_DIGGING,
   STOP_DIGGING,
   DROP_ITEM,
   LOOK_LEFT,
   LOOK_RIGHT,
   LOOK_UP,
   LOOK_DOWN,
   IDLE,
   HEAD_ROTATION;

   public int getDuration() {
      switch (this.ordinal()) {
         case 3:
         case 4:
            return 6;
         case 5:
            return 10;
         case 6:
         case 7:
            return 15;
         case 8:
         case 9:
            return 20;
         case 10:
            return 5;
         case 11:
            return 20;
         case 12:
            return -1;
         case 13:
            return -1;
         case 14:
         default:
            return 0;
         case 15:
            return -1;
      }
   }

   // $FF: synthetic method
   private static FakePlayerAnimation[] $values() {
      return new FakePlayerAnimation[]{WALK, SPRINT, SWIM, SWING_MAIN_HAND, SWING_OFF_HAND, HIT, CRIT, MAGIC_CRIT, SLEEP, WAKE_UP, HURT, DEATH, BLOCK, BOW_CHARGE, ITEM_BREAK, START_DIGGING, STOP_DIGGING, DROP_ITEM, LOOK_LEFT, LOOK_RIGHT, LOOK_UP, LOOK_DOWN, IDLE, HEAD_ROTATION};
   }
}
