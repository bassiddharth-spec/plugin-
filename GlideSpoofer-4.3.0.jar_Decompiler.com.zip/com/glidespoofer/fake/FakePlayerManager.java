package com.glidespoofer.fake;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.hooks.LuckPermsHook;
import com.glidespoofer.packet.PacketManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class FakePlayerManager {
   private final GlideSpoofer plugin;
   private final PacketManager packetManager;
   private final Map<UUID, FakePlayer> fakePlayersByUuid;
   private final Map<String, FakePlayer> fakePlayersByName;
   private final AtomicInteger entityIdCounter;
   private final SkinFetcher skinFetcher;

   public FakePlayerManager(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.packetManager = new PacketManager(plugin);
      this.fakePlayersByUuid = new ConcurrentHashMap();
      this.fakePlayersByName = new ConcurrentHashMap();
      this.entityIdCounter = new AtomicInteger(50000);
      this.skinFetcher = new SkinFetcher(plugin);
   }

   public void register(FakePlayer fakePlayer) {
      this.fakePlayersByUuid.put(fakePlayer.getUuid(), fakePlayer);
      this.fakePlayersByName.put(fakePlayer.getName().toLowerCase(), fakePlayer);
      if (this.plugin.getLuckPermsHook() != null && this.plugin.getLuckPermsHook().isEnabled()) {
         this.plugin.getLuckPermsHook().setupFakePlayer(fakePlayer);
      }

      this.plugin.getLogger().fine("Registered fake player: " + fakePlayer.getName());
   }

   public void unregister(FakePlayer fakePlayer) {
      if (fakePlayer.isSpawned()) {
         this.despawnFromAll(fakePlayer);
      }

      this.fakePlayersByUuid.remove(fakePlayer.getUuid());
      this.fakePlayersByName.remove(fakePlayer.getName().toLowerCase());
      this.plugin.getLogger().fine("Unregistered fake player: " + fakePlayer.getName());
   }

   public void unregisterAll() {
      for(FakePlayer fake : new ArrayList(this.fakePlayersByUuid.values())) {
         this.unregister(fake);
      }

   }

   public void spawnFor(FakePlayer fakePlayer, Player viewer) {
      if (!fakePlayer.hasViewerEntityId(viewer)) {
         int entityId = this.entityIdCounter.getAndIncrement();
         fakePlayer.setViewerEntityId(viewer, entityId);
         this.updateLuckPermsData(fakePlayer);
         this.packetManager.sendTeamCreate(viewer, fakePlayer);
         this.packetManager.sendPlayerInfoAdd(viewer, fakePlayer);
         if (fakePlayer.isVisibleInWorld() && fakePlayer.getLocation() != null) {
            this.packetManager.sendSpawnPlayer(viewer, fakePlayer, entityId);
            this.packetManager.sendHeadRotation(viewer, entityId, fakePlayer.getLocation().getYaw());
            this.packetManager.sendEntityMetadata(viewer, fakePlayer, entityId);
            this.packetManager.sendEquipment(viewer, fakePlayer, entityId);
         }
      }

   }

   public void spawnForAllOnline(FakePlayer fakePlayer) {
      if (fakePlayer.getLocation() == null) {
         fakePlayer.setLocation(this.getDefaultSpawnLocation());
      }

      fakePlayer.setSpawned(true);
      fakePlayer.setSpawnTime(System.currentTimeMillis());

      for(Player player : Bukkit.getOnlinePlayers()) {
         this.spawnFor(fakePlayer, player);
      }

      this.plugin.getLogger().fine("Spawned fake player for all: " + fakePlayer.getName());
   }

   public void despawnFor(FakePlayer fakePlayer, Player viewer) {
      Integer entityId = fakePlayer.getViewerEntityId(viewer);
      if (entityId != null) {
         this.packetManager.sendDestroyEntity(viewer, entityId);
         if (fakePlayer.isVisibleInTab()) {
            this.packetManager.sendPlayerInfoRemove(viewer, fakePlayer);
         }

         this.packetManager.sendTeamRemove(viewer, fakePlayer);
         fakePlayer.removeViewerEntityId(viewer);
      }

   }

   public void despawnFromAll(FakePlayer fakePlayer) {
      for(UUID viewerUuid : fakePlayer.getAllViewerEntityIds().keySet()) {
         Player viewer = Bukkit.getPlayer(viewerUuid);
         if (viewer != null && viewer.isOnline()) {
            this.despawnFor(fakePlayer, viewer);
         }
      }

      fakePlayer.clearViewerEntityIds();
      fakePlayer.setSpawned(false);
      this.plugin.getLogger().fine("Despawned fake player from all: " + fakePlayer.getName());
   }

   public void spawnAllFor(Player viewer) {
      for(FakePlayer fake : this.fakePlayersByUuid.values()) {
         if (fake.isSpawned()) {
            this.spawnFor(fake, viewer);
         }
      }

   }

   public void despawnAllFrom(Player viewer) {
      for(FakePlayer fake : this.fakePlayersByUuid.values()) {
         fake.removeViewerEntityId(viewer);
      }

   }

   public FakePlayer createFakePlayer(String name) {
      return this.createFakePlayer(name, (Location)null);
   }

   public FakePlayer createFakePlayer(String name, Location location) {
      FakePlayer fake = new FakePlayer(name);
      if (location != null) {
         fake.setLocation(location);
      } else {
         fake.setLocation(this.getDefaultSpawnLocation());
      }

      this.skinFetcher.fetchSkinAsync(fake, () -> {
         if (fake.isSpawned()) {
            for(Player viewer : Bukkit.getOnlinePlayers()) {
               this.despawnFor(fake, viewer);
               this.spawnFor(fake, viewer);
            }
         }

      });
      this.register(fake);
      return fake;
   }

   public FakePlayer spawnFakePlayer(String name, Location location) {
      FakePlayer fake = this.createFakePlayer(name, location);
      this.spawnForAllOnline(fake);
      if (this.plugin.getConfigManager().isBroadcastJoinEnabled()) {
         String msg = this.plugin.getConfigManager().getConfig().getString("messages.join", "§e%player% joined the game").replace("%player%", name);
         Bukkit.broadcastMessage(msg);
      }

      return fake;
   }

   public void removeFakePlayer(FakePlayer fake) {
      if (fake.isSpawned() && this.plugin.getConfigManager().isBroadcastQuitEnabled()) {
         String msg = this.plugin.getConfigManager().getConfig().getString("messages.quit", "§e%player% left the game").replace("%player%", fake.getName());
         Bukkit.broadcastMessage(msg);
      }

      this.unregister(fake);
   }

   public FakePlayer getFakePlayer(UUID uuid) {
      return (FakePlayer)this.fakePlayersByUuid.get(uuid);
   }

   public FakePlayer getFakePlayer(String name) {
      return (FakePlayer)this.fakePlayersByName.get(name.toLowerCase());
   }

   public FakePlayer getFakePlayerByEntityId(Player viewer, int entityId) {
      for(FakePlayer fake : this.fakePlayersByUuid.values()) {
         Integer fakeEntityId = fake.getViewerEntityId(viewer);
         if (fakeEntityId != null && fakeEntityId == entityId) {
            return fake;
         }
      }

      return null;
   }

   public List<FakePlayer> getFakePlayers() {
      return new ArrayList(this.fakePlayersByUuid.values());
   }

   public List<FakePlayer> getSpawnedFakePlayers() {
      return (List)this.fakePlayersByUuid.values().stream().filter(FakePlayer::isSpawned).collect(Collectors.toList());
   }

   public List<FakePlayer> getFakePlayersVisibleInTab() {
      return (List)this.fakePlayersByUuid.values().stream().filter(FakePlayer::isVisibleInTab).filter(FakePlayer::isSpawned).collect(Collectors.toList());
   }

   public List<FakePlayer> getFakePlayersVisibleInPing() {
      return (List)this.fakePlayersByUuid.values().stream().filter(FakePlayer::isVisibleInPing).filter(FakePlayer::isSpawned).collect(Collectors.toList());
   }

   public int getFakePlayerCount() {
      return this.fakePlayersByUuid.size();
   }

   public int getSpawnedCount() {
      return (int)this.fakePlayersByUuid.values().stream().filter(FakePlayer::isSpawned).count();
   }

   public int getTotalPlayerCount() {
      return Bukkit.getOnlinePlayers().size() + this.getSpawnedCount();
   }

   public boolean isFakePlayer(String name) {
      return this.fakePlayersByName.containsKey(name.toLowerCase());
   }

   public boolean isFakePlayer(UUID uuid) {
      return this.fakePlayersByUuid.containsKey(uuid);
   }

   private Location getDefaultSpawnLocation() {
      if (Bukkit.getWorlds().isEmpty()) {
         return null;
      } else {
         Location spawn = ((World)Bukkit.getWorlds().get(0)).getSpawnLocation();
         double offsetX = (Math.random() - (double)0.5F) * (double)30.0F;
         double offsetZ = (Math.random() - (double)0.5F) * (double)30.0F;
         Location loc = spawn.clone().add(offsetX, (double)0.0F, offsetZ);
         loc.setY((double)(spawn.getWorld().getHighestBlockYAt(loc) + 1));
         return loc;
      }
   }

   private void updateLuckPermsData(FakePlayer fake) {
      LuckPermsHook lp = this.plugin.getLuckPermsHook();
      if (lp != null && lp.isEnabled()) {
         if (fake.getRank() != null && !fake.getRank().isEmpty()) {
            lp.setupFakePlayer(fake);
         }

         String prefix = lp.getPrefix(fake);
         String suffix = lp.getSuffix(fake);
         if (prefix != null) {
            fake.setPrefix(prefix);
         }

         if (suffix != null) {
            fake.setSuffix(suffix);
         }
      }

   }

   public void updateAllPings() {
      for(FakePlayer fake : this.fakePlayersByUuid.values()) {
         if (fake.isSpawned()) {
            fake.updatePing();

            for(UUID viewerUuid : fake.getAllViewerEntityIds().keySet()) {
               Player viewer = Bukkit.getPlayer(viewerUuid);
               if (viewer != null && viewer.isOnline()) {
                  this.packetManager.sendPlayerInfoUpdatePing(viewer, fake);
               }
            }
         }
      }

   }

   public PacketManager getPacketManager() {
      return this.packetManager;
   }

   public SkinFetcher getSkinFetcher() {
      return this.skinFetcher;
   }

   public List<String> getAllPlayerNames() {
      List<String> names = new ArrayList();

      for(Player p : Bukkit.getOnlinePlayers()) {
         names.add(p.getName());
      }

      for(FakePlayer fake : this.fakePlayersByUuid.values()) {
         names.add(fake.getName());
      }

      return names;
   }

   public void despawnAll() {
      this.unregisterAll();
   }

   public void addFakePlayer(FakePlayer fakePlayer) {
      this.register(fakePlayer);
   }
}
