package com.glidespoofer.fake;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.hooks.InteractiveChatHook;
import com.glidespoofer.nms.NMSHandler;
import com.glidespoofer.nms.SimpleNMSHandler;
import com.glidespoofer.nms.UltraSpoofStyleSpawner;
import com.glidespoofer.packet.TeamPacketManager;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

public class SimpleFakePlayerManager {
   private final GlideSpoofer plugin;
   private final Map<String, FakePlayerData> fakePlayers;
   private final SimpleNMSHandler nmsHandler;
   private boolean nmsAvailable = false;
   private static final int MAX_USERNAME_LENGTH = 16;
   private static final String[] NAME_PREFIXES = new String[]{"Dark", "Shadow", "Night", "Storm", "Fire", "Ice", "Thunder", "Silver", "Golden", "Crimson", "Mystic", "Cosmic", "Lunar", "Solar", "Atomic", "Cyber", "Neon", "Pixel", "Crystal", "Dragon", "Phoenix", "Wolf", "Tiger", "Bear", "Eagle", "Hawk", "Cobra", "Viper", "Ghost", "Savage"};
   private static final String[] NAME_SUFFIXES = new String[]{"Slayer", "Master", "King", "Lord", "Warrior", "Hunter", "Ninja", "Samurai", "Knight", "Dragon", "Beast", "Titan", "Legend", "Hero", "Champion", "Assassin", "Ranger", "Mage", "Wizard", "Sorcerer", "Gamer", "Player", "Pro", "Elite", "Boss", "Chief", "Captain"};
   private static final String[] NAME_NUMBERS = new String[]{"69", "99", "420", "777", "123", "2000", "2024", "X", "XX", "Xx", "xX", "OG", "TV"};
   private final Random random = new Random();
   private final Set<String> usedGeneratedNames = ConcurrentHashMap.newKeySet();
   private int nameCounter = 1;

   public SimpleFakePlayerManager(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.fakePlayers = new ConcurrentHashMap();
      boolean debugEnabled = plugin.getConfigManager() != null && plugin.getConfigManager().isDebugEnabled();
      SimpleNMSHandler.setDebugMode(debugEnabled);
      this.nmsHandler = new SimpleNMSHandler(plugin);
      this.nmsAvailable = this.nmsHandler.isCompatible();
      if (this.nmsAvailable) {
         this.nmsHandler.registerWithPlugin(plugin);
         plugin.getLogger().info("§a[FakePlayerManager] NMS initialized for " + this.nmsHandler.getVersion());
         plugin.getLogger().info("§a[FakePlayerManager] Full fake player support enabled!");
      } else {
         plugin.getLogger().warning("[FakePlayerManager] NMS not available!");
      }

   }

   private String getMinecraftVersion() {
      try {
         return Bukkit.getMinecraftVersion();
      } catch (NoSuchMethodError var5) {
         String serverVersion = Bukkit.getServer().getVersion();
         if (serverVersion.contains("(MC: ")) {
            int start = serverVersion.indexOf("(MC: ") + 5;
            int end = serverVersion.indexOf(")", start);
            return serverVersion.substring(start, end);
         } else {
            return "1.8.8";
         }
      }
   }

   private boolean isVersion1218OrNewer(String version) {
      String[] parts = version.split("\\.");
      if (parts.length < 2) {
         return false;
      } else {
         try {
            int major = Integer.parseInt(parts[0]);
            int minor = Integer.parseInt(parts[1].replaceAll("[^0-9]", ""));
            int patch = parts.length > 2 ? Integer.parseInt(parts[2].replaceAll("[^0-9]", "")) : 0;
            if (major > 1) {
               return true;
            } else {
               return major == 1 && minor > 21 ? true : major == 1 && minor == 21 && patch >= 8;
            }
         } catch (NumberFormatException var6) {
            return false;
         }
      }
   }

   public FakePlayerData spawnFakePlayer(String name, Location location) {
      return this.spawnFakePlayer(name, location, (String)null, (String)null, true, false, (Map)null);
   }

   public FakePlayerData spawnFakePlayer(String name, Location location, String skinName) {
      return this.spawnFakePlayer(name, location, skinName, (String)null, true, false, (Map)null);
   }

   public FakePlayerData spawnFakePlayer(String name, Location location, String skinName, String rank, boolean movement) {
      return this.spawnFakePlayer(name, location, skinName, rank, movement, false, (Map)null);
   }

   public FakePlayerData spawnFakePlayer(String name, Location location, String skinName, String rank, boolean movement, boolean silent) {
      return this.spawnFakePlayer(name, location, skinName, rank, movement, silent, (Map)null, false);
   }

   public FakePlayerData spawnFakePlayerUltraSpoofStyle(String name, Location location, String skinName) {
      return this.spawnFakePlayerUltraSpoofStyle(name, location, skinName, (String)null, true, false, (Map)null);
   }

   public FakePlayerData spawnFakePlayerUltraSpoofStyle(String name, Location location, String skinName, String rank, boolean movement, boolean silent, Map<String, String> tracks) {
      if (!this.nmsAvailable) {
         this.plugin.getLogger().warning("[FakePlayerManager] Cannot spawn - NMS not available");
         return null;
      } else if (name != null && name.length() > 16) {
         this.plugin.getLogger().warning("[FakePlayerManager] Username too long: " + name);
         return null;
      } else {
         UltraSpoofStyleSpawner spawner = this.plugin.getUltraSpoofStyleSpawner();
         if (spawner == null) {
            this.plugin.getLogger().warning("[FakePlayerManager] UltraSpoofStyleSpawner not initialized, falling back to regular spawning");
            return this.spawnFakePlayer(name, location, skinName, rank, movement, silent, tracks);
         } else {
            UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
            String actualSkin = skinName != null && !skinName.isEmpty() && !skinName.equalsIgnoreCase("random") ? skinName : this.nmsHandler.getRandomSkinName();
            this.debug("[FakePlayerManager] Spawning " + name + " using UltraSpoofStyleSpawner method...");
            Player player = spawner.spawnFakePlayer(name, uuid, location);
            if (player == null) {
               this.plugin.getLogger().warning("[FakePlayerManager] UltraSpoofStyleSpawner failed for " + name + ", falling back to regular method");
               return this.spawnFakePlayer(name, location, skinName, rank, movement, silent, tracks);
            } else {
               FakePlayerData data = new FakePlayerData(name, uuid, location, player, actualSkin, rank, movement);
               data.setTracks(tracks);
               this.fakePlayers.put(name.toLowerCase(), data);
               if (this.plugin.getLuckPermsHook() != null && this.plugin.getLuckPermsHook().isEnabled()) {
                  try {
                     String cachedPrefix = "";
                     if (tracks != null && !tracks.isEmpty()) {
                        cachedPrefix = this.plugin.getLuckPermsHook().setupFakePlayerSync(uuid, name, tracks);
                     } else if (rank != null && !rank.isEmpty()) {
                        cachedPrefix = (String)this.plugin.getLuckPermsHook().setupFakePlayer(uuid, name, rank).join();
                        if (cachedPrefix == null) {
                           cachedPrefix = "";
                        }
                     } else {
                        cachedPrefix = this.plugin.getLuckPermsHook().setupFakePlayerWithDefaultGroup(uuid, name);
                     }

                     if (cachedPrefix != null && !cachedPrefix.isEmpty()) {
                        TeamPacketManager.sendTeamToAllPlayers(uuid, name, cachedPrefix, "");
                     }
                  } catch (Exception e) {
                     this.plugin.getLogger().warning("[FakePlayerManager] LuckPerms setup failed: " + e.getMessage());
                  }
               }

               if (this.plugin.getGuiListener() != null && this.plugin.getGuiListener().getGUI() != null) {
                  this.plugin.getGuiListener().getGUI().applyGlobalSettingsToFakePlayer(name, uuid, data);
               } else {
                  this.nmsHandler.setSwingArmEnabled(uuid, true);
                  this.nmsHandler.setHeadMovementEnabled(uuid, true);
                  this.setLookAtPlayers(uuid, true);
               }

               if (movement) {
                  this.nmsHandler.setLookAtPlayers(uuid, true);
               }

               if (!silent && this.plugin.getConfigManager().isBroadcastJoinEnabled()) {
                  this.broadcastJoinMessage(name, actualSkin);
               }

               this.debug("[FakePlayerManager] Successfully spawned " + name + " using UltraSpoofStyleSpawner");
               return data;
            }
         }
      }
   }

   public FakePlayerData spawnFakePlayer(String name, Location location, String skinName, String rank, boolean movement, boolean silent, Map<String, String> tracks) {
      return this.spawnFakePlayer(name, location, skinName, rank, movement, silent, tracks, false);
   }

   public FakePlayerData spawnFakePlayer(String name, Location location, String skinName, String rank, boolean movement, boolean silent, Map<String, String> tracks, boolean skipLuckPerms) {
      return this.spawnFakePlayer(name, location, skinName, rank, movement, silent, tracks, skipLuckPerms, (UUID)null);
   }

   public FakePlayerData spawnFakePlayer(String name, Location location, String skinName, String rank, boolean movement, boolean silent, Map<String, String> tracks, boolean skipLuckPerms, UUID specificUuid) {
      if (!this.nmsAvailable) {
         this.plugin.getLogger().warning("[FakePlayerManager] Cannot spawn - NMS not available");
         return null;
      } else if (this.plugin.getRustHook() != null && this.plugin.getRustHook().isEnabled() && specificUuid == null) {
         this.plugin.getLogger().warning("[FakePlayerManager] Cannot spawn - RustHook is enabled (only takeover fakes allowed)");
         return null;
      } else if (name != null && name.length() > 16) {
         this.plugin.getLogger().warning("[FakePlayerManager] Username too long (max 16 chars): " + name + " (" + name.length() + " chars) - Skipping spawn to prevent packet errors");
         return null;
      } else {
         UUID uuid = specificUuid != null ? specificUuid : UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
         if (this.fakePlayers.containsKey(name.toLowerCase())) {
            FakePlayerData existing = (FakePlayerData)this.fakePlayers.get(name.toLowerCase());
            if (existing != null && existing.getUuid().equals(uuid)) {
               this.debug("[FakePlayerManager] Fake player " + name + " with same UUID already exists, returning existing");
               return existing;
            }

            this.plugin.getLogger().warning("[FakePlayerManager] Fake player " + name + " exists with WRONG UUID " + String.valueOf(existing != null ? existing.getUuid() : "null") + " (expected " + String.valueOf(uuid) + "), removing and respawning");
            this.fakePlayers.remove(name.toLowerCase());
            if (existing != null && existing.getUuid() != null) {
               try {
                  this.nmsHandler.removeFakePlayer(existing.getUuid());
                  this.debug("[FakePlayerManager] Removed old fake with wrong UUID from NMS handler");
               } catch (Exception var21) {
                  this.plugin.getLogger().warning("[FakePlayerManager] Error removing old fake: " + var21.getMessage());
               }
            }
         }

         try {
            String actualSkin;
            if (skinName != null && !skinName.isEmpty() && !skinName.equalsIgnoreCase("random")) {
               actualSkin = skinName;
            } else {
               actualSkin = this.nmsHandler.getRandomSkinName();
            }

            String cachedPrefix = "";
            if (!skipLuckPerms && this.plugin.getLuckPermsHook() != null && this.plugin.getLuckPermsHook().isEnabled()) {
               try {
                  if (tracks != null && !tracks.isEmpty()) {
                     cachedPrefix = this.plugin.getLuckPermsHook().setupFakePlayerSync(uuid, name, tracks);
                  } else if (rank != null && !rank.isEmpty()) {
                     cachedPrefix = (String)this.plugin.getLuckPermsHook().setupFakePlayer(uuid, name, rank).join();
                     if (cachedPrefix == null) {
                        cachedPrefix = "";
                     }
                  } else {
                     cachedPrefix = this.plugin.getLuckPermsHook().setupFakePlayerWithDefaultGroup(uuid, name);
                  }

                  this.debug("[FakePlayerManager] Pre-cached LuckPerms for " + name + " with prefix: " + cachedPrefix);
               } catch (Exception lpEx) {
                  this.plugin.getLogger().warning("[FakePlayerManager] LuckPerms pre-cache failed for " + name + ": " + lpEx.getMessage());
               }
            } else if (skipLuckPerms) {
               this.debug("[FakePlayerManager] Skipping LuckPerms for takeover fake: " + name);
            }

            Player player = this.nmsHandler.spawnFakePlayer(name, uuid, location, actualSkin);
            if (player == null) {
               this.plugin.getLogger().warning("[FakePlayerManager] Failed to spawn: " + name);
               return null;
            } else {
               FakePlayerData data = new FakePlayerData(name, uuid, location, player, actualSkin, rank, movement);
               data.setTracks(tracks);
               this.fakePlayers.put(name.toLowerCase(), data);
               this.ensureEconomyAccount(name);
               if (this.plugin.getGuiListener() != null && this.plugin.getGuiListener().getGUI() != null) {
                  this.plugin.getGuiListener().getGUI().applyGlobalSettingsToFakePlayer(name, uuid, data);
               } else {
                  this.nmsHandler.setSwingArmEnabled(uuid, true);
                  this.nmsHandler.setHeadMovementEnabled(uuid, true);
                  this.setLookAtPlayers(uuid, true);
               }

               String finalPrefix = cachedPrefix;
               Player finalPlayer = player;
               boolean tabEnabled = this.plugin.getTabHook() != null && this.plugin.getTabHook().isEnabled();
               if (cachedPrefix != null && !cachedPrefix.isEmpty()) {
                  TeamPacketManager.sendTeamToAllPlayers(uuid, name, cachedPrefix, "");
                  if (!tabEnabled && player != null && player.isOnline()) {
                     try {
                        String tabName = finalPrefix + String.valueOf(ChatColor.RESET) + name;
                        finalPlayer.setPlayerListName(tabName);
                        this.debug("[FakePlayerManager] Applied tab list name for " + name + ": " + tabName);
                     } catch (Exception e) {
                        this.plugin.getLogger().warning("[FakePlayerManager] Failed to set tab list name: " + e.getMessage());
                     }
                  } else if (tabEnabled) {
                     this.debug("[FakePlayerManager] TAB is enabled - letting TAB handle tab list for " + name);
                  }
               }

               if (this.plugin.getFakeChatManager() != null) {
                  InteractiveChatHook icHook = this.plugin.getFakeChatManager().getInteractiveChatHook();
                  if (icHook != null && icHook.isEnabled()) {
                     boolean registered = icHook.registerFakePlayer(name, uuid);
                     if (registered) {
                        this.debug("[FakePlayerManager] Registered " + name + " with InteractiveChat");
                     }
                  }
               }

               if (this.plugin.getConfigManager().isDebugEnabled()) {
                  this.plugin.getLogger().info("§a[FakePlayerManager] Spawned: " + name + " (skin: " + actualSkin + ", ping: " + this.nmsHandler.getPing(uuid) + "ms" + (tracks != null ? ", tracks: " + String.valueOf(tracks) : "") + ")");
               }

               if (!silent && !GlideSpoofer.isFolia()) {
                  if (this.plugin.getViaVersionHook() != null && this.plugin.getViaVersionHook().isEnabled()) {
                     try {
                        this.plugin.getViaVersionHook().registerFakePlayer(uuid, name, player);
                        this.debug("[FakePlayerManager] Registered " + name + " with ViaVersion");
                     } catch (Exception viaEx) {
                        this.plugin.getLogger().warning("[FakePlayerManager] ViaVersion registration failed: " + viaEx.getMessage());
                     }
                  }

                  if (this.plugin.getTabHook() != null && this.plugin.getTabHook().isEnabled()) {
                     try {
                        this.plugin.getTabHook().injectFakePlayerTAB(player, uuid, name);
                        this.debug("[FakePlayerManager] Injected " + name + " into TAB");
                     } catch (Exception tabEx) {
                        this.plugin.getLogger().warning("[FakePlayerManager] TAB injection failed: " + tabEx.getMessage());
                     }
                  }
               } else if (!silent) {
                  if (this.plugin.getViaVersionHook() != null && this.plugin.getViaVersionHook().isEnabled()) {
                     try {
                        this.plugin.getViaVersionHook().registerFakePlayer(uuid, name, player);
                     } catch (Exception viaEx) {
                        this.plugin.getLogger().warning("[FakePlayerManager] ViaVersion registration failed: " + viaEx.getMessage());
                     }
                  }

                  if (this.plugin.getTabHook() != null && this.plugin.getTabHook().isEnabled()) {
                     try {
                        this.plugin.getTabHook().injectFakePlayerTAB(player, uuid, name);
                     } catch (Exception tabEx) {
                        this.plugin.getLogger().warning("[FakePlayerManager] TAB injection failed: " + tabEx.getMessage());
                     }
                  }
               }

               if (!silent && this.plugin.getConfigManager().isBroadcastJoinEnabled()) {
                  this.broadcastJoinMessage(name, actualSkin);
               }

               if (!silent) {
                  this.executeJoinCommands(name, player);
               }

               if (this.plugin.getSuperiorSkyblockHook() != null && this.plugin.getSuperiorSkyblockHook().isEnabled()) {
                  this.plugin.getSuperiorSkyblockHook().onFakePlayerJoin(name, uuid);
               }

               if (this.plugin.getAuthMeHook() != null && this.plugin.getAuthMeHook().isEnabled()) {
                  this.plugin.getAuthMeHook().setupFakePlayer(player);
               }

               if (this.plugin.getTabHook() != null && this.plugin.getTabHook().isEnabled()) {
                  this.plugin.getTabHook().registerFakePlayer(uuid, name, location.getWorld() != null ? location.getWorld().getName() : null);
                  this.debug("[FakePlayerManager] Registered " + name + " with TAB TabListFormatManager");
               }

               if (movement) {
                  this.nmsHandler.setLookAtPlayers(uuid, true);
               }

               if (this.plugin.getProxyMessenger() != null) {
                  this.plugin.getProxyMessenger().forceSync();
               }

               return data;
            }
         } catch (Exception var22) {
            this.plugin.getLogger().log(Level.SEVERE, "[FakePlayerManager] Error spawning: " + name, var22);
            return null;
         }
      }
   }

   private void broadcastJoinMessage(String name, String skin) {
      try {
         if (this.plugin.getEssentialsHook() != null && this.plugin.getEssentialsHook().isEnabled()) {
            UUID fakeUuid = this.fakePlayers.get(name.toLowerCase()) != null ? ((FakePlayerData)this.fakePlayers.get(name.toLowerCase())).getUuid() : UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
            this.plugin.getEssentialsHook().broadcastFakePlayerJoin(name, fakeUuid);
            return;
         }

         String joinMessage = this.plugin.getConfigManager().getConfig().getString("messages.join", "%player% joined the game").replace("%player%", name);
         joinMessage = ChatColor.translateAlternateColorCodes('&', joinMessage);
         TextComponent component = new TextComponent(joinMessage);

         for(Player online : Bukkit.getOnlinePlayers()) {
            if (!this.plugin.isUsingNMS() || this.plugin.getSimpleFakePlayerManager() == null || !this.plugin.getSimpleFakePlayerManager().isFakePlayer(online)) {
               online.spigot().sendMessage(ChatMessageType.SYSTEM, component);
            }
         }
      } catch (Exception var7) {
         this.plugin.getLogger().warning("[FakePlayerManager] Error broadcasting join message: " + var7.getMessage());
      }

   }

   public void despawnFakePlayer(String name) {
      this.despawnFakePlayer(name, false);
   }

   public void despawnFakePlayer(String name, boolean silent) {
      FakePlayerData data = (FakePlayerData)this.fakePlayers.remove(name.toLowerCase());
      if (data != null) {
         if (!silent && this.plugin.getConfigManager().isBroadcastQuitEnabled()) {
            if (this.plugin.getEssentialsHook() != null && this.plugin.getEssentialsHook().isEnabled()) {
               this.plugin.getEssentialsHook().broadcastFakePlayerLeave(name, data.uuid);
            } else {
               String quitMessage = this.plugin.getConfigManager().getConfig().getString("messages.quit", "%player% left the game").replace("%player%", name);
               quitMessage = ChatColor.translateAlternateColorCodes('&', quitMessage);
               TextComponent component = new TextComponent(quitMessage);

               for(Player online : Bukkit.getOnlinePlayers()) {
                  if (!this.plugin.isUsingNMS() || this.plugin.getSimpleFakePlayerManager() == null || !this.plugin.getSimpleFakePlayerManager().isFakePlayer(online)) {
                     online.spigot().sendMessage(ChatMessageType.SYSTEM, component);
                  }
               }
            }
         }

         if (!silent) {
            this.executeLeaveCommands(name, data.player);
         }

         try {
            this.nmsHandler.removeFakePlayer(data.uuid);
            if (this.plugin.getConfigManager().isDebugEnabled()) {
               this.plugin.getLogger().info("§c[FakePlayerManager] Despawned: " + name);
            }
         } catch (Exception var8) {
            this.plugin.getLogger().log(Level.WARNING, "[FakePlayerManager] Error despawning: " + name, var8);
         }

         if (this.plugin.getFakeChatManager() != null) {
            InteractiveChatHook icHook = this.plugin.getFakeChatManager().getInteractiveChatHook();
            if (icHook != null && icHook.isEnabled()) {
               icHook.unregisterFakePlayer(data.uuid);
            }
         }

         if (this.plugin.getTabHook() != null && this.plugin.getTabHook().isEnabled()) {
            this.plugin.getTabHook().unregisterFakePlayer(data.uuid);
            this.debug("[FakePlayerManager] Unregistered " + name + " from TAB");
         }

         TeamPacketManager.removeTeamForAllPlayers(data.uuid);
      }

   }

   public void despawnAll() {
      for(String name : new ArrayList(this.fakePlayers.keySet())) {
         this.despawnFakePlayer(name);
      }

   }

   private void ensureEconomyAccount(String playerName) {
      try {
         if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
            return;
         }

         Class<?> economyClass = Class.forName("net.milkbowl.vault.economy.Economy");
         RegisteredServiceProvider<?> rsp = Bukkit.getServicesManager().getRegistration(economyClass);
         if (rsp == null) {
            return;
         }

         Object economy = rsp.getProvider();
         OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(playerName);
         Method hasAccount = economy.getClass().getMethod("hasAccount", OfflinePlayer.class);
         if (!(Boolean)hasAccount.invoke(economy, offlinePlayer)) {
            Method createAccount = economy.getClass().getMethod("createPlayerAccount", OfflinePlayer.class);
            createAccount.invoke(economy, offlinePlayer);
            this.plugin.getLogger().info("[FakePlayerManager] Created economy account for " + playerName);
         }
      } catch (Exception var8) {
      }

   }

   public Collection<FakePlayerData> getAllFakePlayers() {
      return Collections.unmodifiableCollection(this.fakePlayers.values());
   }

   public FakePlayerData getFakePlayer(String name) {
      return (FakePlayerData)this.fakePlayers.get(name.toLowerCase());
   }

   public int getFakePlayerCount() {
      return this.fakePlayers.size();
   }

   public boolean hasFakePlayer(String name) {
      return this.fakePlayers.containsKey(name.toLowerCase());
   }

   public boolean isFakePlayer(Player player) {
      return player != null && this.nmsHandler.isFakePlayer(player);
   }

   public boolean isFakePlayer(UUID uuid) {
      return this.nmsHandler.isFakePlayer(uuid);
   }

   public boolean isNMSAvailable() {
      return this.nmsAvailable;
   }

   public SimpleNMSHandler getNMSHandler() {
      return this.nmsHandler;
   }

   public int getPing(String name) {
      FakePlayerData data = this.getFakePlayer(name);
      return data != null ? this.nmsHandler.getPing(data.uuid) : 50;
   }

   public int getPing(UUID uuid) {
      return this.nmsHandler.getPing(uuid);
   }

   public void performAction(String name, NMSHandler.FakePlayerAction action) {
      FakePlayerData data = this.getFakePlayer(name);
      if (data != null && data.player != null) {
         this.nmsHandler.performAction(data.player, action);
      }

   }

   public void teleportFakePlayer(String name, Location location) {
      FakePlayerData data = this.getFakePlayer(name);
      if (data != null && data.player != null) {
         this.nmsHandler.updatePosition(data.player, location, false);
      }

   }

   public void damageFakePlayer(String name, double damage) {
      FakePlayerData data = this.getFakePlayer(name);
      if (data != null) {
         this.nmsHandler.damageFakePlayer(data.uuid, damage, (Object)null);
      }

   }

   public void killFakePlayer(String name) {
      FakePlayerData data = this.getFakePlayer(name);
      if (data != null) {
         this.nmsHandler.killFakePlayer(data.uuid, (Object)null);
      }

   }

   public void kickFakePlayer(String name, String reason) {
      FakePlayerData data = this.getFakePlayer(name);
      if (data != null) {
         String kickReason = reason != null && !reason.isEmpty() ? reason : "Kicked by admin";
         String kickMessage = "§e" + data.name + " was kicked: " + kickReason;

         for(Player player : Bukkit.getOnlinePlayers()) {
            player.sendMessage(kickMessage);
         }

         this.despawnFakePlayer(name, true);
         this.debug("[FakePlayerManager] Kicked: " + name + " - " + kickReason);
      }

   }

   public void banFakePlayer(String name, String reason) {
      FakePlayerData data = this.getFakePlayer(name);
      if (data != null) {
         String banReason = reason != null && !reason.isEmpty() ? reason : "Banned by admin";
         String banMessage = "§c" + data.name + " was banned: " + banReason;

         for(Player player : Bukkit.getOnlinePlayers()) {
            player.sendMessage(banMessage);
         }

         this.despawnFakePlayer(name, true);
         this.nmsHandler.setBanned(data.uuid, true);
         this.debug("[FakePlayerManager] Banned: " + name + " - " + banReason);
      }

   }

   public void unbanFakePlayer(String name) {
      FakePlayerData data = this.getFakePlayer(name);
      if (data != null) {
         this.nmsHandler.setBanned(data.uuid, false);
      } else {
         for(FakePlayerData fd : this.fakePlayers.values()) {
            if (fd.name.equalsIgnoreCase(name)) {
               this.nmsHandler.setBanned(fd.uuid, false);
               this.debug("[FakePlayerManager] Unbanned: " + name);
               return;
            }
         }
      }

   }

   public void muteFakePlayer(String name) {
      FakePlayerData data = this.getFakePlayer(name);
      if (data != null) {
         this.nmsHandler.setMuted(data.uuid, true);
         if (this.plugin.getFakeChatManager() != null) {
            this.plugin.getFakeChatManager().setMuted(data.uuid, true);
         }
      }

   }

   public void unmuteFakePlayer(String name) {
      FakePlayerData data = this.getFakePlayer(name);
      if (data != null) {
         this.nmsHandler.setMuted(data.uuid, false);
         if (this.plugin.getFakeChatManager() != null) {
            this.plugin.getFakeChatManager().setMuted(data.uuid, false);
         }
      }

   }

   public boolean executeCommand(String name, String command) {
      FakePlayerData data = this.getFakePlayer(name);
      if (data != null && data.player != null) {
         if (this.nmsHandler.isMuted(data.uuid) && command.startsWith("/")) {
            data.player.sendMessage("§cYou are muted and cannot use commands.");
            return false;
         } else {
            try {
               return Bukkit.dispatchCommand(data.player, command.startsWith("/") ? command.substring(1) : command);
            } catch (Exception var5) {
               this.plugin.getLogger().log(Level.WARNING, "[FakePlayerManager] Error executing command for " + name, var5);
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private void executeJoinCommands(String playerName, Player fakePlayer) {
      if (this.plugin.getConfigManager().isJoinLeaveCommandsEnabled()) {
         List<String> commands = this.plugin.getConfigManager().getJoinCommands();
         if (!commands.isEmpty()) {
            int delay = this.plugin.getConfigManager().getJoinLeaveCommandsDelay();
            boolean randomMode = this.plugin.getConfigManager().isJoinLeaveCommandsRandomMode();
            int randomCount = this.plugin.getConfigManager().getJoinLeaveCommandsRandomCount();
            Runnable executeCommandsTask = () -> {
               List<String> commandsToExecute;
               if (randomMode) {
                  int count = randomCount == 0 ? commands.size() : Math.min(randomCount, commands.size());
                  List<String> shuffled = new ArrayList(commands);
                  Collections.shuffle(shuffled);
                  commandsToExecute = new ArrayList(shuffled.subList(0, count));
               } else {
                  commandsToExecute = commands;
               }

               for(String command : commandsToExecute) {
                  try {
                     String processedCommand = command.replace("%player%", playerName);
                     Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processedCommand);
                  } catch (Exception var9) {
                     this.plugin.getLogger().log(Level.WARNING, "[FakePlayerManager] Error executing join command for " + playerName, var9);
                  }
               }

            };
            if (GlideSpoofer.isFolia()) {
               Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> executeCommandsTask.run(), (long)delay);
            } else {
               Bukkit.getScheduler().runTaskLater(this.plugin, executeCommandsTask, (long)delay);
            }
         }
      }

   }

   private void executeLeaveCommands(String playerName, Player fakePlayer) {
      if (this.plugin.getConfigManager().isJoinLeaveCommandsEnabled()) {
         List<String> commands = this.plugin.getConfigManager().getLeaveCommands();
         if (!commands.isEmpty()) {
            int delay = this.plugin.getConfigManager().getJoinLeaveCommandsDelay();
            boolean randomMode = this.plugin.getConfigManager().isJoinLeaveCommandsRandomMode();
            int randomCount = this.plugin.getConfigManager().getJoinLeaveCommandsRandomCount();
            Runnable executeCommandsTask = () -> {
               List<String> commandsToExecute;
               if (randomMode) {
                  int count = randomCount == 0 ? commands.size() : Math.min(randomCount, commands.size());
                  List<String> shuffled = new ArrayList(commands);
                  Collections.shuffle(shuffled);
                  commandsToExecute = new ArrayList(shuffled.subList(0, count));
               } else {
                  commandsToExecute = commands;
               }

               for(String command : commandsToExecute) {
                  try {
                     String processedCommand = command.replace("%player%", playerName);
                     Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processedCommand);
                  } catch (Exception var9) {
                     this.plugin.getLogger().log(Level.WARNING, "[FakePlayerManager] Error executing leave command for " + playerName, var9);
                  }
               }

            };
            if (GlideSpoofer.isFolia()) {
               Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> executeCommandsTask.run(), (long)delay);
            } else {
               Bukkit.getScheduler().runTaskLater(this.plugin, executeCommandsTask, (long)delay);
            }
         }
      }

   }

   public boolean randomTeleport(String name) {
      FakePlayerData data = this.getFakePlayer(name);
      if (data != null && data.player != null) {
         Location currentLoc = data.player.getLocation();
         World world = currentLoc.getWorld();
         int range = this.plugin.getConfigManager().getConfig().getInt("rtp.range", 5000);
         int centerY = this.plugin.getConfigManager().getConfig().getInt("rtp.center-y", world.getHighestBlockYAt(0, 0));
         Random random = new Random();
         int x = random.nextInt(range * 2) - range;
         int z = random.nextInt(range * 2) - range;
         int y = world.getHighestBlockYAt(x, z);
         Location rtpLoc = new Location(world, (double)x + (double)0.5F, (double)y, (double)z + (double)0.5F, currentLoc.getYaw(), currentLoc.getPitch());
         this.teleportFakePlayer(name, rtpLoc);
         if (this.plugin.getConfigManager().getConfig().getBoolean("debug.enabled", false)) {
            this.plugin.getLogger().info("[RTP] " + name + " teleported to " + x + ", " + y + ", " + z);
         }

         return true;
      } else {
         return false;
      }
   }

   public void shutdown() {
      this.nmsHandler.shutdown();
      this.fakePlayers.clear();
   }

   public void setLookAtPlayers(UUID uuid, boolean enabled) {
      this.nmsHandler.setLookAtPlayers(uuid, enabled);
   }

   public boolean isLookingAtPlayers(UUID uuid) {
      return this.nmsHandler.isLookingAtPlayers(uuid);
   }

   public void listFakePlayers(Player sender) {
      if (this.fakePlayers.isEmpty()) {
         sender.sendMessage("§cNo fake players spawned.");
      } else {
         sender.sendMessage("§6§lFake Players §7(" + this.fakePlayers.size() + "):");

         for(FakePlayerData data : this.fakePlayers.values()) {
            int ping = this.nmsHandler.getPing(data.uuid);
            String status = data.player != null && data.player.isOnline() ? "§a✔" : "§c✘";
            String pingColor = ping < 100 ? "§a" : (ping < 200 ? "§e" : "§c");
            sender.sendMessage("  " + status + " §f" + data.name + " §7(Ping: " + pingColor + ping + "ms§7, Skin: §b" + data.skinName + "§7)");
         }
      }

   }

   public String generateRandomName() {
      int attempts = 0;

      String name;
      do {
         String prefix = NAME_PREFIXES[this.random.nextInt(NAME_PREFIXES.length)];
         String suffix = NAME_SUFFIXES[this.random.nextInt(NAME_SUFFIXES.length)];
         int pattern = this.random.nextInt(6);
         String var10000;
         switch (pattern) {
            case 0 -> var10000 = prefix + suffix;
            case 1 -> var10000 = prefix + "_" + suffix;
            case 2 -> var10000 = prefix + NAME_NUMBERS[this.random.nextInt(NAME_NUMBERS.length)];
            case 3 -> var10000 = prefix + suffix + NAME_NUMBERS[this.random.nextInt(NAME_NUMBERS.length)];
            case 4 -> var10000 = prefix + this.nameCounter++;
            case 5 -> var10000 = prefix + (this.random.nextInt(99) + 1);
            default -> var10000 = prefix + suffix;
         }

         name = var10000;
         if (!name.matches(".*\\d+.*") && !name.contains("_")) {
            var10000 = name.substring(0, 1);
            name = var10000 + name.substring(1).toLowerCase();
         }

         if (name.length() > 16) {
            name = name.substring(0, 16);
         }

         ++attempts;
         if (attempts > 100) {
            int var10002 = this.nameCounter++;
            name = "Fake" + var10002;
            if (name.length() > 16) {
               name = name.substring(0, 16);
            }
            break;
         }
      } while(this.fakePlayers.containsKey(name.toLowerCase()) || this.usedGeneratedNames.contains(name.toLowerCase()));

      this.usedGeneratedNames.add(name.toLowerCase());
      return name;
   }

   public int gradualSpawn(int count) {
      if (!this.nmsAvailable) {
         this.plugin.getLogger().warning("[FakePlayerManager] Cannot spawn - NMS not available");
         return 0;
      } else if (count <= 0) {
         return 0;
      } else {
         long interval = 1200L / (long)count;
         interval = Math.max(interval, 20L);
         AtomicInteger spawned = new AtomicInteger(0);
         boolean isFolia = GlideSpoofer.isFolia();

         for(int i = 0; i < count; ++i) {
            long delay = interval * (long)i;
            Runnable spawnTask = () -> {
               String name = this.generateRandomName();
               Location spawnLoc = null;
               if (this.plugin.getGuiListener() != null && this.plugin.getGuiListener().getGUI() != null) {
                  spawnLoc = this.plugin.getGuiListener().getGUI().getRandomFluctuationPoint();
                  if (spawnLoc == null) {
                     spawnLoc = this.plugin.getGuiListener().getGUI().getConfiguredSpawnLocation();
                  }
               }

               if (spawnLoc == null || spawnLoc.getWorld() == null) {
                  spawnLoc = ((World)this.plugin.getServer().getWorlds().get(0)).getSpawnLocation();
               }

               FakePlayerData data = this.spawnFakePlayer(name, spawnLoc, "random", (String)null, true, false);
               if (data != null) {
                  if (this.plugin.getFluctuationManager() != null && this.plugin.getFluctuationManager().isEnabled()) {
                     this.plugin.getFluctuationManager().addFluctuationPlayer(name, spawnLoc, true, true);
                  }

                  spawned.incrementAndGet();
                  this.plugin.getLogger().fine("[GradualSpawn] Spawned " + name + " (" + (i + 1) + "/" + count + ")");
               }

            };
            if (isFolia) {
               Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> spawnTask.run(), delay);
            } else {
               Bukkit.getScheduler().runTaskLater(this.plugin, spawnTask, delay);
            }
         }

         this.plugin.getLogger().info("[GradualSpawn] Scheduling " + count + " fake players to spawn over 1 minute");
         return count;
      }
   }

   public int gradualDespawn(int count) {
      List<FakePlayerData> allFakes = new ArrayList(this.fakePlayers.values());
      int toRemove = Math.min(count, allFakes.size());
      if (toRemove <= 0) {
         return 0;
      } else {
         Collections.shuffle(allFakes);
         long interval = 1200L / (long)toRemove;
         interval = Math.max(interval, 20L);
         boolean isFolia = GlideSpoofer.isFolia();

         for(int i = 0; i < toRemove; ++i) {
            FakePlayerData data = (FakePlayerData)allFakes.get(i);
            long delay = interval * (long)i;
            Runnable despawnTask = () -> {
               this.despawnFakePlayer(data.getName());
               Logger var10000 = this.plugin.getLogger();
               String var10001 = data.getName();
               var10000.fine("[GradualDespawn] Removed " + var10001 + " (" + (i + 1) + "/" + toRemove + ")");
            };
            if (isFolia) {
               Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> despawnTask.run(), delay);
            } else {
               Bukkit.getScheduler().runTaskLater(this.plugin, despawnTask, delay);
            }
         }

         this.plugin.getLogger().info("[GradualDespawn] Scheduling " + toRemove + " fake players to despawn over 1 minute");
         return toRemove;
      }
   }

   private void debug(String message) {
      if (this.plugin.getConfigManager() != null && this.plugin.getConfigManager().isDebugEnabled()) {
         this.plugin.getLogger().info(message);
      }

   }

   public static class FakePlayerData {
      public final String name;
      public final UUID uuid;
      public final Location spawnLocation;
      public final Player player;
      public final String skinName;
      private String rank;
      private boolean movementEnabled;
      private Map<String, String> tracks;
      private boolean lookAtPlayers;

      public FakePlayerData(String name, UUID uuid, Location spawnLocation, Player player, String skinName, String rank, boolean movementEnabled) {
         this.name = name;
         this.uuid = uuid;
         this.spawnLocation = spawnLocation;
         this.player = player;
         this.skinName = skinName;
         this.rank = rank;
         this.movementEnabled = movementEnabled;
         this.tracks = new HashMap();
         this.lookAtPlayers = false;
      }

      public Player getPlayer() {
         return this.player;
      }

      public UUID getUuid() {
         return this.uuid;
      }

      public String getName() {
         return this.name;
      }

      public Location getSpawnLocation() {
         return this.spawnLocation;
      }

      public String getSkinName() {
         return this.skinName;
      }

      public String getRank() {
         return this.rank;
      }

      public void setRank(String rank) {
         this.rank = rank;
      }

      public boolean isMovementEnabled() {
         return this.movementEnabled;
      }

      public void setMovementEnabled(boolean enabled) {
         this.movementEnabled = enabled;
      }

      public boolean isOnline() {
         return this.player != null && this.player.isOnline();
      }

      public Map<String, String> getTracks() {
         return this.tracks;
      }

      public void setTracks(Map<String, String> tracks) {
         this.tracks = (Map<String, String>)(tracks != null ? tracks : new HashMap());
      }

      public String getTrack(String trackName) {
         return (String)this.tracks.get(trackName);
      }

      public void setTrack(String trackName, String value) {
         this.tracks.put(trackName, value);
      }

      public boolean isLookAtPlayers() {
         return this.lookAtPlayers;
      }

      public void setLookAtPlayers(boolean enabled) {
         this.lookAtPlayers = enabled;
      }
   }
}
