package com.glidespoofer.fake;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.nms.SimpleNMSHandler;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

public class FakePlayerFluctuationManager {
   private final GlideSpoofer plugin;
   private final SimpleFakePlayerManager fakePlayerManager;
   private final Random random;
   private final Map<String, FluctuationState> fluctuationStates;
   private Object fluctuationTask;
   private boolean enabled;
   private int checkInterval;
   private int minPlayersOnline;
   private int minOnlineTarget;
   private int maxOnlineTarget;
   private double multiplier;
   private int maxPlayersPerCheck;
   private boolean allowLeaving;
   private boolean timeBasedRestrictionsEnabled;
   private int quietHoursStart;
   private int quietHoursEnd;
   private double quietHoursMultiplier;
   private boolean startupEnabled;
   private int startupBatchSize;
   private int startupBatchDelay;
   private int startupBatchDelayVariation;
   private String defaultRank;

   public FakePlayerFluctuationManager(GlideSpoofer plugin, SimpleFakePlayerManager fakePlayerManager) {
      this.plugin = plugin;
      this.fakePlayerManager = fakePlayerManager;
      this.random = new Random();
      this.fluctuationStates = new ConcurrentHashMap();
      this.loadFluctuationSettings();
      this.loadFluctuationConfig();
      this.enabled = plugin.getConfigManager().getFakesConfig().getBoolean("fluctuation.enabled", true);
   }

   private void loadFluctuationSettings() {
      ConfigurationSection fluctuationConfig = this.plugin.getConfigManager().getFakesConfig().getConfigurationSection("fluctuation");
      if (fluctuationConfig == null) {
         this.plugin.getLogger().warning("No 'fluctuation' section found in fakes.yml! Using defaults.");
         this.checkInterval = 600;
         this.minPlayersOnline = 3;
         this.minOnlineTarget = 3;
         this.maxOnlineTarget = Integer.MAX_VALUE;
         this.multiplier = (double)0.5F;
         this.maxPlayersPerCheck = 1;
         this.allowLeaving = true;
         this.timeBasedRestrictionsEnabled = false;
         this.startupEnabled = false;
      } else {
         this.checkInterval = fluctuationConfig.getInt("check-interval", 600);
         this.minPlayersOnline = fluctuationConfig.getInt("min-players-online", 3);
         this.minOnlineTarget = fluctuationConfig.getInt("min-online", 3);
         int maxFromConfig = fluctuationConfig.getInt("max-online", -1);
         this.maxOnlineTarget = maxFromConfig <= 0 ? Integer.MAX_VALUE : maxFromConfig;
         this.maxPlayersPerCheck = fluctuationConfig.getInt("max-players-per-check", 1);
         this.allowLeaving = fluctuationConfig.getBoolean("allow-leaving", true);
         double configMultiplier = this.plugin.getConfigManager().getMultiplier();
         if (configMultiplier > (double)0.0F) {
            this.multiplier = configMultiplier;
         } else {
            this.multiplier = fluctuationConfig.getDouble("multiplier", (double)0.5F);
         }

         ConfigurationSection timeRestrictions = fluctuationConfig.getConfigurationSection("time-based-restrictions");
         if (timeRestrictions != null) {
            this.timeBasedRestrictionsEnabled = timeRestrictions.getBoolean("enabled", false);
            ConfigurationSection quietHours = timeRestrictions.getConfigurationSection("quiet-hours");
            if (quietHours != null) {
               this.quietHoursStart = quietHours.getInt("start", 0);
               this.quietHoursEnd = quietHours.getInt("end", 6);
            } else {
               this.quietHoursStart = 0;
               this.quietHoursEnd = 6;
            }

            this.quietHoursMultiplier = timeRestrictions.getDouble("quiet-hours-multiplier", 0.2);
         } else {
            this.timeBasedRestrictionsEnabled = false;
            this.quietHoursStart = 0;
            this.quietHoursEnd = 6;
            this.quietHoursMultiplier = 0.2;
         }

         ConfigurationSection startupConfig = fluctuationConfig.getConfigurationSection("startup");
         if (startupConfig != null) {
            this.startupEnabled = startupConfig.getBoolean("enabled", true);
            this.startupBatchSize = startupConfig.getInt("batch-size", 2);
            this.startupBatchDelay = startupConfig.getInt("batch-delay", 100);
            this.startupBatchDelayVariation = startupConfig.getInt("batch-delay-variation", 40);
         } else {
            this.startupEnabled = true;
            this.startupBatchSize = 2;
            this.startupBatchDelay = 100;
            this.startupBatchDelayVariation = 40;
         }

         this.plugin.getLogger().info("Fluctuation settings loaded from fakes.yml:");
         this.plugin.getLogger().info("  - Check interval: " + this.checkInterval / 20 + " seconds");
         this.plugin.getLogger().info("  - Target formula: " + this.minOnlineTarget + " + (real_players * " + this.multiplier + ")");
         this.plugin.getLogger().info("  - Min online: " + this.minPlayersOnline);
         Logger var10000 = this.plugin.getLogger();
         Object var10001 = this.maxOnlineTarget == Integer.MAX_VALUE ? "unlimited" : this.maxOnlineTarget;
         var10000.info("  - Max online: " + String.valueOf(var10001));
         var10000 = this.plugin.getLogger();
         String var9 = this.startupEnabled ? "enabled (" + this.startupBatchSize + " per batch)" : "disabled";
         var10000.info("  - Startup gradual spawn: " + var9);
      }

   }

   public void start() {
      if (!this.enabled) {
         this.plugin.getLogger().info("Fluctuation system is disabled in fakes.yml");
      } else {
         this.loadFluctuationConfig();
         if (GlideSpoofer.isFolia()) {
            this.fluctuationTask = Bukkit.getGlobalRegionScheduler().runAtFixedRate(this.plugin, (task) -> this.processFluctuation(), (long)this.checkInterval, (long)this.checkInterval);
         } else {
            this.fluctuationTask = Bukkit.getScheduler().runTaskTimer(this.plugin, this::processFluctuation, (long)this.checkInterval, (long)this.checkInterval);
         }

         this.plugin.getLogger().info("Fake player fluctuation system started! Check interval: " + this.checkInterval / 20 + " seconds");
      }

   }

   public void startGradualSpawning() {
      if (this.enabled && this.startupEnabled) {
         List<String> offlinePlayers = new ArrayList();

         for(Map.Entry<String, FluctuationState> entry : this.fluctuationStates.entrySet()) {
            FluctuationState state = (FluctuationState)entry.getValue();
            boolean isOnline = this.fakePlayerManager.hasFakePlayer((String)entry.getKey());
            if (!isOnline) {
               offlinePlayers.add(state.name);
            }
         }

         if (!offlinePlayers.isEmpty()) {
            Collections.shuffle(offlinePlayers);
            int totalToSpawn = Math.min(this.startupBatchSize, offlinePlayers.size());
            this.plugin.getLogger().info("Starting gradual spawn of " + totalToSpawn + " fake players with randomized delays");

            for(int i = 0; i < totalToSpawn; ++i) {
               String playerName = (String)offlinePlayers.get(i);
               int minDelayBetweenSpawns = 60;
               int baseDelay = Math.max(minDelayBetweenSpawns * i, this.startupBatchDelay / Math.max(1, this.startupBatchSize) * i);
               int delay = baseDelay;
               if (this.startupBatchDelayVariation > 0) {
                  delay = baseDelay + (this.random.nextInt(this.startupBatchDelayVariation * 2 + 1) - this.startupBatchDelayVariation);
               }

               if (delay < 1) {
                  delay = 1;
               }

               Location spawnLoc = this.getDefaultSpawnLocation();
               if (GlideSpoofer.isFolia() && spawnLoc != null && spawnLoc.getWorld() != null) {
                  Bukkit.getRegionScheduler().runDelayed(this.plugin, spawnLoc, (task) -> {
                     this.spawnFakePlayer(playerName);
                     this.plugin.getLogger().fine("Gradual spawn: spawned " + playerName);
                  }, (long)delay);
               } else if (GlideSpoofer.isFolia()) {
                  Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> {
                     this.spawnFakePlayer(playerName);
                     this.plugin.getLogger().fine("Gradual spawn: spawned " + playerName);
                  }, (long)delay);
               } else {
                  Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                     this.spawnFakePlayer(playerName);
                     this.plugin.getLogger().fine("Gradual spawn: spawned " + playerName);
                  }, (long)delay);
               }
            }

            this.plugin.getLogger().info("Scheduled " + totalToSpawn + " fake players to spawn gradually");
         }
      }

   }

   private Location getDefaultSpawnLocation() {
      if (this.plugin.getGuiListener() != null && this.plugin.getGuiListener().getGUI() != null) {
         Location fluctuationPoint = this.plugin.getGuiListener().getGUI().getRandomFluctuationPoint();
         if (fluctuationPoint != null) {
            return fluctuationPoint;
         }

         Location configuredSpawn = this.plugin.getGuiListener().getGUI().getConfiguredSpawnLocation();
         if (configuredSpawn != null && configuredSpawn.getWorld() != null) {
            return configuredSpawn;
         }
      }

      try {
         World world = (World)this.plugin.getServer().getWorlds().get(0);
         if (world != null) {
            return world.getSpawnLocation();
         }
      } catch (Exception var3) {
      }

      return null;
   }

   public void stop() {
      this.cancelTask(this.fluctuationTask);
      this.fluctuationTask = null;
   }

   private void cancelTask(Object task) {
      if (task != null) {
         try {
            if (task instanceof BukkitTask) {
               ((BukkitTask)task).cancel();
            } else if (task.getClass().getName().contains("ScheduledTask")) {
               task.getClass().getMethod("cancel").invoke(task);
            }
         } catch (Exception var3) {
         }
      }

   }

   private void loadFluctuationConfig() {
      ConfigurationSection fakesSection = this.plugin.getConfigManager().getFakesConfig();
      ConfigurationSection defaults = fakesSection.getConfigurationSection("defaults.fluctuation");
      boolean defaultEnabled = defaults != null ? defaults.getBoolean("enabled", true) : true;
      this.defaultRank = fakesSection.getString("defaults.rank", defaults != null ? defaults.getString("rank", (String)null) : null);
      if (this.defaultRank != null) {
         this.plugin.getLogger().info("Using default rank for fake players: " + this.defaultRank);
      }

      ConfigurationSection fakesConfig = fakesSection.getConfigurationSection("fakes");
      if (fakesConfig == null) {
         this.plugin.getLogger().warning("No 'fakes' section found in fakes.yml!");
      } else {
         for(String key : fakesConfig.getKeys(false)) {
            ConfigurationSection playerSection = fakesConfig.getConfigurationSection(key);
            if (playerSection != null) {
               String name = playerSection.getString("name", key);
               ConfigurationSection fluctuation = playerSection.getConfigurationSection("fluctuation");
               boolean fluctuationEnabled;
               if (fluctuation != null) {
                  fluctuationEnabled = fluctuation.getBoolean("enabled", defaultEnabled);
               } else {
                  fluctuationEnabled = defaultEnabled;
               }

               FluctuationState state = new FluctuationState(name, fluctuationEnabled);
               this.fluctuationStates.put(name.toLowerCase(), state);
               this.plugin.getLogger().fine("Loaded fluctuation for " + name + ": enabled=" + fluctuationEnabled);
            }
         }

         this.plugin.getLogger().info("Loaded " + this.fluctuationStates.size() + " fake players for fluctuation");
      }

   }

   private void processFluctuation() {
      if (this.enabled) {
         int realPlayerCount = this.getRealPlayerCount();
         int targetCount = this.minOnlineTarget + (int)((double)realPlayerCount * this.multiplier);
         if (this.timeBasedRestrictionsEnabled && this.isQuietHours()) {
            targetCount = (int)((double)targetCount * this.quietHoursMultiplier);
         }

         targetCount = Math.min(targetCount, this.maxOnlineTarget);
         int currentOnline = this.fakePlayerManager.getFakePlayerCount();
         this.plugin.getLogger().fine("[Fluctuation] Real players: " + realPlayerCount + ", Target: " + targetCount + ", Current fake: " + currentOnline);
         if (currentOnline < this.minPlayersOnline) {
            this.spawnPlayersToReachMinimum(this.minPlayersOnline);
         } else {
            long now = System.currentTimeMillis();
            long minSessionDuration = 60000L + (long)this.random.nextInt(120000);
            List<String> onlinePlayers = new ArrayList();
            List<String> offlinePlayers = new ArrayList();

            for(Map.Entry<String, FluctuationState> entry : this.fluctuationStates.entrySet()) {
               String name = ((FluctuationState)entry.getValue()).name;
               boolean isOnline = this.fakePlayerManager.hasFakePlayer(name);
               if (isOnline) {
                  onlinePlayers.add(name);
               } else {
                  offlinePlayers.add(name);
               }
            }

            Collections.shuffle(onlinePlayers);
            Collections.shuffle(offlinePlayers);
            int randomAdjustment = this.random.nextInt(5) - 2;
            int adjustedTarget = Math.max(this.minPlayersOnline, targetCount + randomAdjustment);
            adjustedTarget = Math.min(adjustedTarget, this.maxOnlineTarget);
            int maxChangeThisTick = this.maxPlayersPerCheck;
            if (this.allowLeaving && currentOnline > adjustedTarget) {
               int toRemove = Math.min(currentOnline - adjustedTarget, maxChangeThisTick);
               int removed = 0;

               for(String name : onlinePlayers) {
                  if (removed >= toRemove || this.fakePlayerManager.getFakePlayerCount() <= this.minPlayersOnline) {
                     break;
                  }

                  FluctuationState state = (FluctuationState)this.fluctuationStates.get(name.toLowerCase());
                  if ((state == null || state.lastSpawnTime == null || now - state.lastSpawnTime >= minSessionDuration) && this.random.nextInt(100) < 70) {
                     this.removeFakePlayer(name, "Over target");
                     ++removed;
                  }
               }
            } else if (currentOnline < adjustedTarget) {
               int toAdd = Math.min(adjustedTarget - currentOnline, maxChangeThisTick);
               toAdd = Math.min(toAdd, offlinePlayers.size());
               int added = 0;

               for(String name : offlinePlayers) {
                  if (added >= toAdd) {
                     break;
                  }

                  FluctuationState state = (FluctuationState)this.fluctuationStates.get(name.toLowerCase());
                  if ((state == null || state.lastRemoveTime == null || now - state.lastRemoveTime >= 120000L + (long)this.random.nextInt(180000)) && this.random.nextInt(100) < 60) {
                     this.spawnFakePlayer(name);
                     ++added;
                  }
               }
            }

            if (this.allowLeaving && !onlinePlayers.isEmpty() && this.random.nextInt(100) < 20) {
               String toRemove = null;

               for(String name : onlinePlayers) {
                  FluctuationState state = (FluctuationState)this.fluctuationStates.get(name.toLowerCase());
                  if (state != null && state.lastSpawnTime != null && now - state.lastSpawnTime >= minSessionDuration) {
                     toRemove = name;
                     break;
                  }
               }

               if (toRemove != null && this.fakePlayerManager.getFakePlayerCount() > this.minPlayersOnline) {
                  this.removeFakePlayer(toRemove, "Random logout");
                  if (!offlinePlayers.isEmpty()) {
                     String replacement = (String)offlinePlayers.get(0);
                     int spawnDelay = this.random.nextInt(60) + 20;
                     if (GlideSpoofer.isFolia()) {
                        Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> this.spawnFakePlayer(replacement), (long)spawnDelay);
                     } else {
                        Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.spawnFakePlayer(replacement), (long)spawnDelay);
                     }
                  }
               }
            }

         }
      }
   }

   private boolean isQuietHours() {
      LocalDateTime now = LocalDateTime.now();
      int hour = now.getHour();
      if (this.quietHoursStart <= this.quietHoursEnd) {
         return hour >= this.quietHoursStart && hour < this.quietHoursEnd;
      } else {
         return hour >= this.quietHoursStart || hour < this.quietHoursEnd;
      }
   }

   private int getRealPlayerCount() {
      int realCount = 0;

      for(Player player : Bukkit.getOnlinePlayers()) {
         if (!this.fakePlayerManager.isFakePlayer(player)) {
            ++realCount;
         }
      }

      return realCount;
   }

   private void spawnPlayersToReachMinimum(int minimum) {
      int currentOnline = this.fakePlayerManager.getFakePlayerCount();
      if (currentOnline < minimum) {
         int actualMinimum = Math.min(minimum, this.maxOnlineTarget);
         if (currentOnline < actualMinimum) {
            int needed = Math.min(actualMinimum - currentOnline, this.maxPlayersPerCheck);
            int spawned = 0;
            List<String> offlinePlayers = new ArrayList();

            for(Map.Entry<String, FluctuationState> entry : this.fluctuationStates.entrySet()) {
               FluctuationState state = (FluctuationState)entry.getValue();
               if (state.enabled && !this.fakePlayerManager.hasFakePlayer((String)entry.getKey())) {
                  offlinePlayers.add(state.name);
               }
            }

            Collections.shuffle(offlinePlayers);

            for(String playerName : offlinePlayers) {
               if (spawned >= needed) {
                  break;
               }

               this.spawnFakePlayer(playerName);
               ++spawned;
            }

            if (spawned > 0) {
               this.plugin.getLogger().fine("Spawned " + spawned + " players to reach minimum (" + actualMinimum + ")");
            }
         }
      }

   }

   private void removeFakePlayer(String name, String reason) {
      SimpleFakePlayerManager.FakePlayerData data = this.fakePlayerManager.getFakePlayer(name);
      if (data != null) {
         FluctuationState state = (FluctuationState)this.fluctuationStates.get(name.toLowerCase());
         if (state != null) {
            state.lastRemoveTime = System.currentTimeMillis();
            this.fakePlayerManager.despawnFakePlayer(name, true);
            this.executeLeaveCommands(name, data.player);
            if (this.plugin.getConfigManager().getConfig().getBoolean("debug.enabled", false)) {
               this.plugin.getLogger().fine("[Fluctuation] " + name + " left: " + reason);
            }
         }
      }

   }

   private void spawnFakePlayer(String name) {
      FluctuationState state = (FluctuationState)this.fluctuationStates.get(name.toLowerCase());
      if (state != null) {
         String defaultWorldName = this.plugin.getConfigManager().getConfig().getString("fake-players.default-world", "default");
         Location spawnLoc = this.getDefaultSpawnLocation(defaultWorldName);
         boolean visibleInWorld = true;
         boolean sitting = false;
         String skin = null;
         String rank = null;
         ConfigurationSection fakesConfig = this.plugin.getConfigManager().getFakesConfig();
         ConfigurationSection fakesSection = fakesConfig.getConfigurationSection("fakes");
         if (fakesSection != null) {
            for(String key : fakesSection.getKeys(false)) {
               ConfigurationSection playerSection = fakesSection.getConfigurationSection(key);
               String configName = playerSection != null ? playerSection.getString("name") : null;
               if (configName != null && name.equalsIgnoreCase(configName)) {
                  String simpleWorld = playerSection.getString("world", (String)null);
                  if (simpleWorld != null && !simpleWorld.isEmpty()) {
                     World w = this.plugin.getServer().getWorld(simpleWorld);
                     if (w != null) {
                        spawnLoc = w.getSpawnLocation();
                     }
                  }

                  ConfigurationSection locSection = playerSection.getConfigurationSection("location");
                  if (locSection != null) {
                     String world = locSection.getString("world", spawnLoc.getWorld() != null ? spawnLoc.getWorld().getName() : "world");
                     double x = locSection.getDouble("x", spawnLoc.getX());
                     double y = locSection.getDouble("y", spawnLoc.getY());
                     double z = locSection.getDouble("z", spawnLoc.getZ());
                     float yaw = (float)locSection.getDouble("yaw", (double)spawnLoc.getYaw());
                     float pitch = (float)locSection.getDouble("pitch", (double)spawnLoc.getPitch());
                     World w = this.plugin.getServer().getWorld(world);
                     if (w != null) {
                        spawnLoc = new Location(w, x, y, z, yaw, pitch);
                     }
                  }

                  visibleInWorld = playerSection.getBoolean("visible-in-world", true);
                  sitting = playerSection.getBoolean("sitting", false);
                  skin = playerSection.getString("skin", (String)null);
                  rank = playerSection.getString("rank", playerSection.getString("group", this.defaultRank));
                  break;
               }
            }
         }

         SimpleFakePlayerManager.FakePlayerData data = this.fakePlayerManager.spawnFakePlayer(name, spawnLoc, skin, rank, true, true);
         if (data != null) {
            state.lastSpawnTime = System.currentTimeMillis();
            if (sitting) {
               Player finalDataPlayer = data.player;
               if (GlideSpoofer.isFolia()) {
                  Bukkit.getRegionScheduler().runDelayed(this.plugin, finalDataPlayer.getLocation(), (task) -> {
                     try {
                        Object serverPlayer = this.fakePlayerManager.getNMSHandler().getServerPlayer(finalDataPlayer);
                        if (serverPlayer != null && this.fakePlayerManager.getNMSHandler() instanceof SimpleNMSHandler) {
                           this.fakePlayerManager.getNMSHandler().broadcastSittingPose(serverPlayer);
                        }
                     } catch (Exception var5x) {
                        this.plugin.getLogger().fine("Could not set sitting pose for " + name + ": " + var5x.getMessage());
                     }

                  }, 5L);
               } else {
                  Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                     try {
                        Object serverPlayer = this.fakePlayerManager.getNMSHandler().getServerPlayer(finalDataPlayer);
                        if (serverPlayer != null && this.fakePlayerManager.getNMSHandler() instanceof SimpleNMSHandler) {
                           this.fakePlayerManager.getNMSHandler().broadcastSittingPose(serverPlayer);
                        }
                     } catch (Exception var4x) {
                        this.plugin.getLogger().fine("Could not set sitting pose for " + name + ": " + var4x.getMessage());
                     }

                  }, 5L);
               }
            }

            this.fakePlayerManager.getNMSHandler().setVisibleInWorld(data.getUuid(), visibleInWorld);
            Player finalFakePlayer = data.player;
            if (GlideSpoofer.isFolia()) {
               Bukkit.getRegionScheduler().runDelayed(this.plugin, finalFakePlayer.getLocation(), (task) -> this.rebroadcastToAllPlayers(finalFakePlayer, name), 1L);
            } else {
               Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.rebroadcastToAllPlayers(finalFakePlayer, name), 1L);
            }

            this.executeJoinCommands(name, data.player);
            if (this.plugin.getConfigManager().getConfig().getBoolean("debug.enabled", false)) {
               this.plugin.getLogger().fine("[Fluctuation] " + name + " joined");
            }
         }
      }

   }

   private void executeJoinCommands(String playerName, Player fakePlayer) {
      if (this.plugin.getConfigManager().isJoinLeaveCommandsEnabled()) {
         List<String> commands = this.plugin.getConfigManager().getJoinCommands();
         if (!commands.isEmpty()) {
            int delay = this.plugin.getConfigManager().getJoinLeaveCommandsDelay();
            boolean randomMode = this.plugin.getConfigManager().isJoinLeaveCommandsRandomMode();
            int randomCount = this.plugin.getConfigManager().getJoinLeaveCommandsRandomCount();
            if (GlideSpoofer.isFolia()) {
               Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> this.executeJoinCommandsInternal(playerName, fakePlayer, commands, randomMode, randomCount), (long)delay);
            } else {
               Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.executeJoinCommandsInternal(playerName, fakePlayer, commands, randomMode, randomCount), (long)delay);
            }
         }
      }

   }

   private void executeJoinCommandsInternal(String playerName, Player fakePlayer, List<String> commands, boolean randomMode, int randomCount) {
      List<String> commandsToExecute;
      if (randomMode) {
         int count = randomCount == 0 ? commands.size() : Math.min(randomCount, commands.size());
         List<String> shuffled = new ArrayList(commands);
         Collections.shuffle(shuffled);
         commandsToExecute = new ArrayList(shuffled.subList(0, count));
      } else {
         commandsToExecute = commands;
      }

      for(String command : commandsToExecute) {
         try {
            String processedCommand = command.replace("%player%", playerName);
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processedCommand);
         } catch (Exception var10) {
            this.plugin.getLogger().warning("[Fluctuation] Error executing join command for " + playerName + ": " + var10.getMessage());
         }
      }

   }

   private void executeLeaveCommands(String playerName, Player fakePlayer) {
      if (this.plugin.getConfigManager().isJoinLeaveCommandsEnabled()) {
         List<String> commands = this.plugin.getConfigManager().getLeaveCommands();
         if (!commands.isEmpty()) {
            int delay = this.plugin.getConfigManager().getJoinLeaveCommandsDelay();
            boolean randomMode = this.plugin.getConfigManager().isJoinLeaveCommandsRandomMode();
            int randomCount = this.plugin.getConfigManager().getJoinLeaveCommandsRandomCount();
            if (GlideSpoofer.isFolia()) {
               Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> this.executeLeaveCommandsInternal(playerName, commands, randomMode, randomCount), (long)delay);
            } else {
               Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.executeLeaveCommandsInternal(playerName, commands, randomMode, randomCount), (long)delay);
            }
         }
      }

   }

   private void executeLeaveCommandsInternal(String playerName, List<String> commands, boolean randomMode, int randomCount) {
      List<String> commandsToExecute;
      if (randomMode) {
         int count = randomCount == 0 ? commands.size() : Math.min(randomCount, commands.size());
         List<String> shuffled = new ArrayList(commands);
         Collections.shuffle(shuffled);
         commandsToExecute = new ArrayList(shuffled.subList(0, count));
      } else {
         commandsToExecute = commands;
      }

      for(String command : commandsToExecute) {
         try {
            String processedCommand = command.replace("%player%", playerName);
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processedCommand);
         } catch (Exception var9) {
            this.plugin.getLogger().warning("[Fluctuation] Error executing leave command for " + playerName + ": " + var9.getMessage());
         }
      }

   }

   public void addFluctuationPlayer(String name, Location spawnLocation, boolean canLeave, boolean canJoin) {
      FluctuationState state = new FluctuationState(name, true);
      state.lastSpawnTime = System.currentTimeMillis();
      this.fluctuationStates.put(name.toLowerCase(), state);
   }

   public void removeFluctuationPlayer(String name) {
      this.fluctuationStates.remove(name.toLowerCase());
   }

   public boolean canLeave(String name) {
      FluctuationState state = (FluctuationState)this.fluctuationStates.get(name.toLowerCase());
      return state != null && state.enabled;
   }

   public void forceLeave(String name, String reason) {
      this.removeFakePlayer(name, reason);
   }

   public int getTargetPlayerCount() {
      int realPlayerCount = this.getRealPlayerCount();
      int target = this.minOnlineTarget + (int)((double)realPlayerCount * this.multiplier);
      return Math.min(target, this.maxOnlineTarget);
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void setEnabled(boolean enabled) {
      this.enabled = enabled;
   }

   public void reloadSettings() {
      boolean wasEnabled = this.enabled;
      this.loadFluctuationSettings();
      this.loadFluctuationConfig();
      this.enabled = this.plugin.getConfigManager().getFakesConfig().getBoolean("fluctuation.enabled", true);
      if (this.fluctuationTask != null) {
         this.cancelTask(this.fluctuationTask);
         this.fluctuationTask = null;
      }

      if (this.enabled && !wasEnabled) {
         this.start();
         this.plugin.getLogger().info("Fluctuation system enabled via reload");
      } else if (!this.enabled && wasEnabled) {
         this.plugin.getLogger().info("Fluctuation system disabled via reload");
      } else if (this.enabled) {
         this.start();
         this.plugin.getLogger().info("Fluctuation settings reloaded from fakes.yml");
      } else {
         this.plugin.getLogger().info("Fluctuation settings reloaded (currently disabled)");
      }

   }

   private void rebroadcastToAllPlayers(Player fakePlayer, String name) {
      if (fakePlayer != null) {
         try {
            Class<?> nmsHandlerClass = this.fakePlayerManager.getNMSHandler().getClass();
            Object serverPlayer = nmsHandlerClass.getMethod("getServerPlayer", Player.class).invoke(this.fakePlayerManager.getNMSHandler(), fakePlayer);
            if (serverPlayer == null) {
               return;
            }

            Method broadcastPlayerInfoMethod = null;
            Method broadcastSpawnEntityMethod = null;

            for(Method m : nmsHandlerClass.getDeclaredMethods()) {
               if (m.getName().equals("broadcastPlayerInfo") && m.getParameterCount() == 2) {
                  broadcastPlayerInfoMethod = m;
                  m.setAccessible(true);
               }

               if (m.getName().equals("broadcastSpawnEntity") && m.getParameterCount() == 1) {
                  broadcastSpawnEntityMethod = m;
                  m.setAccessible(true);
               }
            }

            if (broadcastPlayerInfoMethod != null) {
               broadcastPlayerInfoMethod.invoke(this.fakePlayerManager.getNMSHandler(), serverPlayer, true);
            }

            if (broadcastSpawnEntityMethod != null) {
               broadcastSpawnEntityMethod.invoke(this.fakePlayerManager.getNMSHandler(), serverPlayer);
            }

            this.plugin.getLogger().fine("Re-broadcasted " + name + " to all players");
         } catch (Exception var11) {
            this.plugin.getLogger().fine("Could not re-broadcast " + name + ": " + var11.getMessage());
         }
      }

   }

   private Location getDefaultSpawnLocation(String worldName) {
      if (this.plugin.getGuiListener() != null && this.plugin.getGuiListener().getGUI() != null) {
         Location fluctuationPoint = this.plugin.getGuiListener().getGUI().getRandomFluctuationPoint();
         if (fluctuationPoint != null) {
            return fluctuationPoint;
         }

         Location configuredSpawn = this.plugin.getGuiListener().getGUI().getConfiguredSpawnLocation();
         if (configuredSpawn != null && configuredSpawn.getWorld() != null) {
            return configuredSpawn;
         }
      }

      if ((worldName == null || worldName.equals("default") || worldName.isEmpty()) && !this.plugin.getServer().getWorlds().isEmpty()) {
         return ((World)this.plugin.getServer().getWorlds().get(0)).getSpawnLocation();
      } else {
         World world = this.plugin.getServer().getWorld(worldName);
         if (world != null) {
            return world.getSpawnLocation();
         } else {
            return !this.plugin.getServer().getWorlds().isEmpty() ? ((World)this.plugin.getServer().getWorlds().get(0)).getSpawnLocation() : new Location((World)null, (double)0.0F, (double)64.0F, (double)0.0F);
         }
      }
   }

   public static class FluctuationState {
      private final String name;
      private final boolean enabled;
      private Long lastSpawnTime;
      private Long lastRemoveTime;

      public FluctuationState(String name, boolean enabled) {
         this.name = name;
         this.enabled = enabled;
      }

      public Long getLastSpawnTime() {
         return this.lastSpawnTime;
      }

      public void setLastSpawnTime(long time) {
         this.lastSpawnTime = time;
      }

      public Long getLastRemoveTime() {
         return this.lastRemoveTime;
      }

      public void setLastRemoveTime(long time) {
         this.lastRemoveTime = time;
      }

      public String getName() {
         return this.name;
      }

      public boolean isEnabled() {
         return this.enabled;
      }
   }
}
