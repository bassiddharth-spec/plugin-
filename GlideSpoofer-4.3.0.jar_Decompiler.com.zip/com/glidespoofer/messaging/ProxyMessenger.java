package com.glidespoofer.messaging;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.FakePlayer;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class ProxyMessenger {
   private final GlideSpoofer plugin;
   private final Gson gson = new Gson();
   public static final String CHANNEL = "glidespoofer:main";
   private final Map<String, Integer> serverFakeCounts = new HashMap();
   private int totalFakeCount = 0;
   private Connection velocityDbConnection;
   private boolean velocityDbEnabled = false;

   public ProxyMessenger(GlideSpoofer plugin) {
      this.plugin = plugin;
   }

   public void register() {
      try {
         Bukkit.getMessenger().registerOutgoingPluginChannel(this.plugin, "glidespoofer:main");
         Bukkit.getMessenger().registerIncomingPluginChannel(this.plugin, "glidespoofer:main", new ProxyMessageListener(this));
         if (!Bukkit.getMessenger().isOutgoingChannelRegistered(this.plugin, "glidespoofer:main")) {
            this.plugin.getLogger().warning("Outgoing channel 'glidespoofer:main' is NOT registered!");
         }

         this.initializeVelocityDbSync();
         this.startSyncTask();
      } catch (Exception var2) {
         this.plugin.getLogger().warning("Failed to register proxy messaging: " + var2.getMessage());
         var2.printStackTrace();
      }

   }

   public void unregister() {
      try {
         Bukkit.getMessenger().unregisterOutgoingPluginChannel(this.plugin, "glidespoofer:main");
         Bukkit.getMessenger().unregisterIncomingPluginChannel(this.plugin, "glidespoofer:main");
         this.closeVelocityDbSync();
      } catch (Exception var2) {
         this.plugin.getLogger().warning("Failed to unregister proxy messaging: " + var2.getMessage());
      }

   }

   private void startSyncTask() {
      if (GlideSpoofer.isFolia()) {
         Bukkit.getGlobalRegionScheduler().runAtFixedRate(this.plugin, (task) -> this.sendSyncMessage(), 100L, 100L);
         Bukkit.getGlobalRegionScheduler().runAtFixedRate(this.plugin, (task) -> this.sendNamesMessage(), 200L, 200L);
      } else {
         Bukkit.getScheduler().runTaskTimer(this.plugin, this::sendSyncMessage, 100L, 100L);
         Bukkit.getScheduler().runTaskTimer(this.plugin, this::sendNamesMessage, 200L, 200L);
      }

   }

   public void sendSyncMessage() {
      try {
         if (!Bukkit.getMessenger().isOutgoingChannelRegistered(this.plugin, "glidespoofer:main")) {
            if (this.plugin.getConfigManager().isDebugEnabled()) {
               this.plugin.getLogger().warning("[ProxySync] Channel 'glidespoofer:main' is not registered! Re-registering...");
            }

            Bukkit.getMessenger().registerOutgoingPluginChannel(this.plugin, "glidespoofer:main");
            if (!Bukkit.getMessenger().isOutgoingChannelRegistered(this.plugin, "glidespoofer:main")) {
               this.plugin.getLogger().severe("[ProxySync] Channel still not registered after re-register attempt!");
               return;
            }
         }

         int fakeCount = this.getFakePlayerCount();
         int realCount = 0;
         Player conduitPlayer = null;

         for(Player p : Bukkit.getOnlinePlayers()) {
            boolean isFake = this.isFakePlayer(p);
            if (!isFake) {
               ++realCount;
               if (conduitPlayer == null) {
                  conduitPlayer = p;
               }
            }
         }

         String serverName = this.getServerName();
         JsonObject message = new JsonObject();
         message.addProperty("type", "sync");
         message.addProperty("server", serverName);
         message.addProperty("fake_players", (Number)fakeCount);
         message.addProperty("real_players", (Number)realCount);
         message.addProperty("max_players", (Number)Bukkit.getMaxPlayers());
         byte[] data = this.gson.toJson((JsonElement)message).getBytes();
         if (conduitPlayer != null && conduitPlayer.isOnline()) {
            try {
               conduitPlayer.sendPluginMessage(this.plugin, "glidespoofer:main", data);
            } catch (NullPointerException var8) {
               if (this.plugin.getConfigManager().isDebugEnabled()) {
                  this.plugin.getLogger().warning("[ProxySync] Conduit player has no channel, skipping sync");
               }
            }
         } else if (this.plugin.getConfigManager().isDebugEnabled()) {
            this.plugin.getLogger().warning("[ProxySync] Cannot send sync to proxy: No real players online (fake: " + fakeCount + ")");
         }

         this.totalFakeCount = fakeCount;
      } catch (Exception var7) {
         this.plugin.getLogger().warning("Failed to send sync message: " + var7.getMessage());
         var7.printStackTrace();
      }

   }

   public void sendNamesMessage() {
      try {
         List<String> fakeNames = this.getFakePlayerNames();
         String serverName = this.getServerName();
         JsonObject message = new JsonObject();
         message.addProperty("type", "names");
         message.addProperty("server", serverName);
         JsonArray namesArray = new JsonArray();

         for(String name : fakeNames) {
            namesArray.add(name);
         }

         message.add("names", namesArray);
         byte[] data = this.gson.toJson((JsonElement)message).getBytes();

         for(Player player : Bukkit.getOnlinePlayers()) {
            if (player.isOnline() && !this.isFakePlayer(player)) {
               player.sendPluginMessage(this.plugin, "glidespoofer:main", data);
               break;
            }
         }
      } catch (Exception var8) {
         this.plugin.getLogger().fine("Failed to send names message: " + var8.getMessage());
      }

   }

   private int getFakePlayerCount() {
      if (this.plugin.isUsingNMS() && this.plugin.getSimpleFakePlayerManager() != null) {
         return this.plugin.getSimpleFakePlayerManager().getFakePlayerCount();
      } else {
         return this.plugin.isUsingPacketEvents() && this.plugin.getFakePlayerManager() != null ? this.plugin.getFakePlayerManager().getSpawnedCount() : 0;
      }
   }

   private List<String> getFakePlayerNames() {
      List<String> names = new ArrayList();
      if (this.plugin.isUsingNMS() && this.plugin.getSimpleFakePlayerManager() != null) {
         SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();

         for(SimpleFakePlayerManager.FakePlayerData data : manager.getAllFakePlayers()) {
            names.add(data.getName());
         }
      } else if (this.plugin.isUsingPacketEvents() && this.plugin.getFakePlayerManager() != null) {
         for(FakePlayer fake : this.plugin.getFakePlayerManager().getFakePlayers()) {
            names.add(fake.getName());
         }
      }

      return names;
   }

   private boolean isFakePlayer(Player player) {
      if (this.plugin.isUsingNMS() && this.plugin.getSimpleFakePlayerManager() != null) {
         return this.plugin.getSimpleFakePlayerManager().isFakePlayer(player);
      } else {
         return this.plugin.isUsingPacketEvents() && this.plugin.getFakePlayerManager() != null ? this.plugin.getFakePlayerManager().isFakePlayer(player.getUniqueId()) : false;
      }
   }

   public void handleProxyMessage(byte[] data) {
      try {
         String jsonString = new String(data);
         JsonObject message = (JsonObject)this.gson.fromJson(jsonString, JsonObject.class);
         switch (message.get("type").getAsString()) {
            case "broadcast" -> this.handleBroadcast(message);
            case "set_count" -> this.handleSetCount(message);
            case "request_sync" -> this.sendSyncMessage();
         }
      } catch (Exception var7) {
         this.plugin.getLogger().warning("Failed to handle proxy message: " + var7.getMessage());
      }

   }

   private void handleBroadcast(JsonObject message) {
      int totalFakes = message.get("total_fakes").getAsInt();
      this.totalFakeCount = totalFakes;
      this.updatePlaceholders();
   }

   private void handleSetCount(JsonObject message) {
      int fakeCount = message.get("fake_players").getAsInt();
   }

   private void updatePlaceholders() {
   }

   private String getServerName() {
      return this.plugin.getConfigManager().getConfig().getString("proxy-sync.server-name", "server");
   }

   public int getTotalFakeCount() {
      return this.totalFakeCount;
   }

   public int getLocalFakeCount() {
      if (this.plugin.isUsingPacketEvents()) {
         return this.plugin.getFakePlayerManager().getSpawnedCount();
      } else {
         return this.plugin.getSimpleFakePlayerManager() != null ? this.plugin.getSimpleFakePlayerManager().getFakePlayerCount() : 0;
      }
   }

   public int getServerFakeCount(String serverName) {
      return (Integer)this.serverFakeCounts.getOrDefault(serverName, 0);
   }

   public void initializeVelocityDbSync() {
      ConfigurationSection dbConfig = this.plugin.getConfigManager().getConfig().getConfigurationSection("velocity-sync.database");
      if (dbConfig != null && dbConfig.getBoolean("enabled", false)) {
         try {
            String host = dbConfig.getString("host", "localhost");
            int port = dbConfig.getInt("port", 3306);
            String database = dbConfig.getString("database", "glidespoofer");
            String username = dbConfig.getString("username", "root");
            String password = dbConfig.getString("password", "");
            this.velocityDbConnection = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + database + "?useSSL=false&autoReconnect=true&useUnicode=true&characterEncoding=UTF-8", username, password);
            PreparedStatement stmt = this.velocityDbConnection.prepareStatement("CREATE TABLE IF NOT EXISTS server_data (\n    server_name VARCHAR(64) PRIMARY KEY,\n    fake_players INTEGER DEFAULT 0,\n    real_players INTEGER DEFAULT 0,\n    last_updated BIGINT,\n    fake_names TEXT\n)\n");

            try {
               stmt.executeUpdate();
            } catch (Throwable var14) {
               if (stmt != null) {
                  try {
                     stmt.close();
                  } catch (Throwable var10) {
                     var14.addSuppressed(var10);
                  }
               }

               throw var14;
            }

            if (stmt != null) {
               stmt.close();
            }

            try {
               stmt = this.velocityDbConnection.prepareStatement("ALTER TABLE server_data ADD COLUMN fake_names TEXT");

               try {
                  stmt.executeUpdate();
               } catch (Throwable var12) {
                  if (stmt != null) {
                     try {
                        stmt.close();
                     } catch (Throwable var11) {
                        var12.addSuppressed(var11);
                     }
                  }

                  throw var12;
               }

               if (stmt != null) {
                  stmt.close();
               }
            } catch (SQLException var13) {
               if (!var13.getMessage().contains("Duplicate column")) {
                  this.plugin.getLogger().fine("Note on fake_names column: " + var13.getMessage());
               }
            }

            this.velocityDbEnabled = true;
            if (GlideSpoofer.isFolia()) {
               Bukkit.getGlobalRegionScheduler().runAtFixedRate(this.plugin, (task) -> this.syncToDatabase(), 100L, 100L);
            } else {
               Bukkit.getScheduler().runTaskTimer(this.plugin, this::syncToDatabase, 100L, 100L);
            }
         } catch (SQLException var15) {
            this.plugin.getLogger().warning("Failed to connect to Velocity sync database: " + var15.getMessage());
            this.velocityDbEnabled = false;
         }
      }

   }

   private void syncToDatabase() {
      if (this.velocityDbEnabled && this.velocityDbConnection != null) {
         try {
            if (this.velocityDbConnection.isClosed()) {
               this.plugin.getLogger().warning("Velocity database connection closed, attempting reconnect...");
               this.initializeVelocityDbSync();
               return;
            }

            int fakeCount = this.getFakePlayerCount();
            int realCount = 0;

            for(Player p : Bukkit.getOnlinePlayers()) {
               if (!this.isFakePlayer(p)) {
                  ++realCount;
               }
            }

            String serverName = this.getServerName();
            List<String> fakeNames = this.getFakePlayerNames();
            String deleteSql = "DELETE FROM server_data WHERE server_name = ?";
            PreparedStatement delStmt = this.velocityDbConnection.prepareStatement(deleteSql);

            try {
               delStmt.setString(1, serverName);
               delStmt.executeUpdate();
            } catch (Throwable var17) {
               if (delStmt != null) {
                  try {
                     delStmt.close();
                  } catch (Throwable var14) {
                     var17.addSuppressed(var14);
                  }
               }

               throw var17;
            }

            if (delStmt != null) {
               delStmt.close();
            }

            boolean insertSuccess = false;

            try {
               JsonArray namesArray = new JsonArray();

               for(String name : fakeNames) {
                  namesArray.add(name);
               }

               String namesJson = (new Gson()).toJson((JsonElement)namesArray);
               String sql = "INSERT INTO server_data (server_name, fake_players, real_players, last_updated, fake_names) VALUES (?, ?, ?, ?, ?)";
               PreparedStatement pstmt = this.velocityDbConnection.prepareStatement(sql);

               try {
                  pstmt.setString(1, serverName);
                  pstmt.setInt(2, fakeCount);
                  pstmt.setInt(3, realCount);
                  pstmt.setLong(4, System.currentTimeMillis());
                  pstmt.setString(5, namesJson);
                  pstmt.executeUpdate();
                  insertSuccess = true;
                  if (this.plugin.getConfigManager().isDebugEnabled()) {
                     this.plugin.getLogger().info("[VelocityDB] Synced to database: " + serverName + " = " + fakeCount + " fakes, " + realCount + " real, " + fakeNames.size() + " names");
                  }
               } catch (Throwable var18) {
                  if (pstmt != null) {
                     try {
                        pstmt.close();
                     } catch (Throwable var15) {
                        var18.addSuppressed(var15);
                     }
                  }

                  throw var18;
               }

               if (pstmt != null) {
                  pstmt.close();
               }
            } catch (SQLException var19) {
               if (!var19.getMessage().contains("Unknown column")) {
                  throw var19;
               }

               this.plugin.getLogger().info("[VelocityDB] fake_names column not found, using legacy mode");
            }

            if (!insertSuccess) {
               String sql = "INSERT INTO server_data (server_name, fake_players, real_players, last_updated) VALUES (?, ?, ?, ?)";
               PreparedStatement pstmtx = this.velocityDbConnection.prepareStatement(sql);

               try {
                  pstmtx.setString(1, serverName);
                  pstmtx.setInt(2, fakeCount);
                  pstmtx.setInt(3, realCount);
                  pstmtx.setLong(4, System.currentTimeMillis());
                  pstmtx.executeUpdate();
                  if (this.plugin.getConfigManager().isDebugEnabled()) {
                     this.plugin.getLogger().info("[VelocityDB] Synced to database (legacy mode): " + serverName + " = " + fakeCount + " fakes, " + realCount + " real");
                  }
               } catch (Throwable var16) {
                  if (pstmtx != null) {
                     try {
                        pstmtx.close();
                     } catch (Throwable var13) {
                        var16.addSuppressed(var13);
                     }
                  }

                  throw var16;
               }

               if (pstmtx != null) {
                  pstmtx.close();
               }
            }
         } catch (SQLException var20) {
            this.plugin.getLogger().warning("Failed to sync to Velocity database: " + var20.getMessage());
         }
      }

   }

   private boolean checkColumnExists(String tableName, String columnName) {
      try {
         String query = "SHOW COLUMNS FROM " + tableName + " LIKE ?";
         PreparedStatement pstmt = this.velocityDbConnection.prepareStatement(query);

         boolean var6;
         try {
            pstmt.setString(1, columnName);
            ResultSet rs = pstmt.executeQuery();

            try {
               var6 = rs.next();
            } catch (Throwable var11) {
               if (rs != null) {
                  try {
                     rs.close();
                  } catch (Throwable var10) {
                     var11.addSuppressed(var10);
                  }
               }

               throw var11;
            }

            if (rs != null) {
               rs.close();
            }
         } catch (Throwable var12) {
            if (pstmt != null) {
               try {
                  pstmt.close();
               } catch (Throwable var9) {
                  var12.addSuppressed(var9);
               }
            }

            throw var12;
         }

         if (pstmt != null) {
            pstmt.close();
         }

         return var6;
      } catch (SQLException var13) {
         return false;
      }
   }

   public void closeVelocityDbSync() {
      try {
         if (this.velocityDbConnection != null && !this.velocityDbConnection.isClosed()) {
            this.velocityDbConnection.close();
         }
      } catch (SQLException var2) {
         this.plugin.getLogger().warning("Error closing Velocity database connection: " + var2.getMessage());
      }

      this.velocityDbConnection = null;
      this.velocityDbEnabled = false;
   }

   public void forceSync() {
      this.syncToDatabase();
      this.sendSyncMessage();
      this.sendNamesMessage();
   }
}
