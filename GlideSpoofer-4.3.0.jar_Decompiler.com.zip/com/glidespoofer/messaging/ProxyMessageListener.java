package com.glidespoofer.messaging;

import com.google.gson.Gson;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;

public class ProxyMessageListener implements PluginMessageListener {
   private final ProxyMessenger messenger;
   private final Gson gson = new Gson();

   public ProxyMessageListener(ProxyMessenger messenger) {
      this.messenger = messenger;
   }

   public void onPluginMessageReceived(String channel, Player player, byte[] data) {
      if (channel.equals("glidespoofer:main")) {
         try {
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(data));
            int available = in.available();
            if (available > 0) {
               byte[] messageData = new byte[available];
               in.readFully(messageData);
               this.messenger.handleProxyMessage(messageData);
            }
         } catch (IOException var7) {
            var7.printStackTrace();
         }
      }

   }
}
