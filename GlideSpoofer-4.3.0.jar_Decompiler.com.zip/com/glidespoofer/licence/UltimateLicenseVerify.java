package com.glidespoofer.licence;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.plugin.java.JavaPlugin;

public class UltimateLicenseVerify {
   private static final String API_BASE = "http://licence.zabjelo.online/api";
   private static final String PRODUCT = "GLIDESPOOFER";
   private static final String PRODUCT_SECRET = "glidespoofer_ult_2024_secret";
   private static final String VERSION = "4.3.0";
   private static final int TIMEOUT = 15000;
   private static final Gson GSON = (new GsonBuilder()).disableHtmlEscaping().create();
   private static JavaPlugin plugin;
   private static boolean valid = false;
   private static String status = "";
   private static String ownerName = "";
   private static String type = "permanent";
   private static long expiresAt = 0L;
   private static int maxServers = 1;
   public static String DEVICE_ID;

   public static void init(JavaPlugin p) {
      plugin = p;
      DEVICE_ID = hwId();
   }

   public static boolean verifyKey(String key) {
      if (plugin == null) {
         throw new IllegalStateException("Call init() first");
      } else if (key != null && !key.isEmpty() && !key.equals("YOUR_LICENSE_KEY_HERE") && !key.equals("none")) {
         try {
            JsonObject body = new JsonObject();
            body.addProperty("key", key);
            body.addProperty("product", "GLIDESPOOFER");
            body.addProperty("secret", "glidespoofer_ult_2024_secret");
            String resp = post("/licence/verify", body);
            JsonObject json = (JsonObject)GSON.fromJson(resp, JsonObject.class);
            if (json != null && json.has("valid") && json.get("valid").getAsBoolean()) {
               valid = true;
               status = json.has("status") ? json.get("status").getAsString() : "ACTIVE";
               ownerName = json.has("ownerName") ? json.get("ownerName").getAsString() : "Unknown";
               type = json.has("type") ? json.get("type").getAsString() : "permanent";
               expiresAt = json.has("expiresAt") && !json.get("expiresAt").isJsonNull() ? json.get("expiresAt").getAsLong() : 0L;
               maxServers = json.has("maxServers") ? json.get("maxServers").getAsInt() : 1;
               plugin.getLogger().info("╔════════════════════════════════════════════════════════════════╗");
               plugin.getLogger().info("║                    LICENCE VALIDATED                                ║");
               plugin.getLogger().info("╠════════════════════════════════════════════════════════════════╣");
               Logger var10000 = plugin.getLogger();
               String var10001 = maskKey(key);
               var10000.info("║  ✓ Key: " + var10001);
               var10000 = plugin.getLogger();
               var10001 = ownerName;
               var10000.info("║  ✓ Owner: " + var10001);
               plugin.getLogger().info("║  ✓ Type: " + (type.equals("trial") ? "Trial" : "Permanent"));
               if (expiresAt > 0L) {
                  var10000 = plugin.getLogger();
                  SimpleDateFormat var10 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                  Date var10002 = new Date(expiresAt);
                  var10000.info("║  ✓ Expires: " + var10.format(var10002));
               }

               plugin.getLogger().info("║  ✓ Max Servers: " + maxServers);
               plugin.getLogger().info("╚════════════════════════════════════════════════════════════════╝");
               return true;
            } else {
               String reason = json != null && json.has("reason") ? json.get("reason").getAsString() : "Unknown error";
               String statusCode = json != null && json.has("status") ? json.get("status").getAsString() : "FAILED";
               plugin.getLogger().severe("═══════════════════════════════════════════════════════");
               plugin.getLogger().severe("                 LICENCE VERIFICATION FAILED");
               plugin.getLogger().severe("═══════════════════════════════════════════════════════");
               plugin.getLogger().severe("  Key: " + maskKey(key));
               plugin.getLogger().severe("  Status: " + statusCode);
               plugin.getLogger().severe("  Reason: " + reason);
               plugin.getLogger().severe("═══════════════════════════════════════════════════════");
               return false;
            }
         } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Could not connect to licence server", e);
            plugin.getLogger().severe("═══════════════════════════════════════════════════════");
            plugin.getLogger().severe("                 CONNECTION FAILED");
            plugin.getLogger().severe("═══════════════════════════════════════════════════════");
            plugin.getLogger().severe("  Check your internet connection and try again.");
            plugin.getLogger().severe("═══════════════════════════════════════════════════════");
            return false;
         }
      } else {
         plugin.getLogger().severe("Invalid or empty licence key provided.");
         return false;
      }
   }

   public static void sendHeartbeat(String key, int onlinePlayers) {
      try {
         JsonObject body = new JsonObject();
         body.addProperty("key", key);
         body.addProperty("product", "GLIDESPOOFER");
         body.addProperty("secret", "glidespoofer_ult_2024_secret");
         body.addProperty("ip", "heartbeat");
         body.addProperty("onlinePlayers", (Number)onlinePlayers);
         int code = postCode("/licence/heartbeat", body);
         if (code >= 400) {
            plugin.getLogger().warning("Heartbeat failed: HTTP " + code);
         }
      } catch (Exception e) {
         plugin.getLogger().log(Level.WARNING, "Heartbeat failed: " + e.getMessage());
      }

   }

   public static boolean isValid() {
      return valid && "ACTIVE".equals(status);
   }

   public static String getStatus() {
      return status;
   }

   public static String getOwnerName() {
      return ownerName;
   }

   public static String getType() {
      return type;
   }

   public static boolean isTrial() {
      return "trial".equals(type);
   }

   public static boolean isExpired() {
      return expiresAt > 0L && expiresAt <= System.currentTimeMillis();
   }

   public static long getExpiresAt() {
      return expiresAt;
   }

   public static int getMaxServers() {
      return maxServers;
   }

   public static String getMaskedKey(String key) {
      return maskKey(key);
   }

   public static void shutdown() {
   }

   private static String post(String endpoint, JsonObject body) throws Exception {
      URL url = URI.create("http://licence.zabjelo.online/api" + endpoint).toURL();
      HttpURLConnection c = (HttpURLConnection)url.openConnection();
      c.setRequestMethod("POST");
      c.setRequestProperty("Content-Type", "application/json");
      c.setRequestProperty("User-Agent", "GlideSpoofer/4.3.0");
      c.setConnectTimeout(15000);
      c.setReadTimeout(15000);
      c.setDoOutput(true);
      OutputStream os = c.getOutputStream();

      try {
         os.write(body.toString().getBytes(StandardCharsets.UTF_8));
      } catch (Throwable var20) {
         if (os != null) {
            try {
               os.close();
            } catch (Throwable var19) {
               var20.addSuppressed(var19);
            }
         }

         throw var20;
      }

      if (os != null) {
         os.close();
      }

      String var8;
      try {
         InputStream is = c.getResponseCode() < 400 ? c.getInputStream() : c.getErrorStream();

         try {
            BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));

            try {
               StringBuilder sb = new StringBuilder();

               String line;
               while((line = br.readLine()) != null) {
                  sb.append(line);
               }

               var8 = sb.toString();
            } catch (Throwable var21) {
               try {
                  br.close();
               } catch (Throwable var18) {
                  var21.addSuppressed(var18);
               }

               throw var21;
            }

            br.close();
         } catch (Throwable var22) {
            if (is != null) {
               try {
                  is.close();
               } catch (Throwable var17) {
                  var22.addSuppressed(var17);
               }
            }

            throw var22;
         }

         if (is != null) {
            is.close();
         }
      } finally {
         c.disconnect();
      }

      return var8;
   }

   private static int postCode(String endpoint, JsonObject body) throws Exception {
      URL url = URI.create("http://licence.zabjelo.online/api" + endpoint).toURL();
      HttpURLConnection c = (HttpURLConnection)url.openConnection();
      c.setRequestMethod("POST");
      c.setRequestProperty("Content-Type", "application/json");
      c.setRequestProperty("User-Agent", "GlideSpoofer/4.3.0");
      c.setConnectTimeout(15000);
      c.setReadTimeout(15000);
      c.setDoOutput(true);
      OutputStream os = c.getOutputStream();

      try {
         os.write(body.toString().getBytes(StandardCharsets.UTF_8));
      } catch (Throwable var10) {
         if (os != null) {
            try {
               os.close();
            } catch (Throwable var8) {
               var10.addSuppressed(var8);
            }
         }

         throw var10;
      }

      if (os != null) {
         os.close();
      }

      int code = c.getResponseCode();

      try {
         InputStream is = c.getInputStream();

         try {
            is.read();
         } catch (Throwable var11) {
            if (is != null) {
               try {
                  is.close();
               } catch (Throwable var9) {
                  var11.addSuppressed(var9);
               }
            }

            throw var11;
         }

         if (is != null) {
            is.close();
         }
      } catch (Exception var12) {
      }

      c.disconnect();
      return code;
   }

   private static String hwId() {
      try {
         String var10000 = System.getProperty("os.name");
         String s = var10000 + System.getProperty("os.version") + System.getProperty("os.arch") + InetAddress.getLocalHost().getHostName();
         return UUID.nameUUIDFromBytes(s.getBytes()).toString();
      } catch (Exception var1) {
         return UUID.randomUUID().toString();
      }
   }

   private static String maskKey(String k) {
      if (k != null && k.length() >= 10) {
         String var10000 = k.substring(0, Math.min(8, k.length()));
         return var10000 + "..." + k.substring(k.length() - 4);
      } else {
         return "****";
      }
   }
}
