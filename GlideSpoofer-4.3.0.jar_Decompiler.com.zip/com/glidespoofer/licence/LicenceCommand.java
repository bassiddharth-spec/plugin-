package com.glidespoofer.licence;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Server;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;

public class LicenceCommand implements CommandExecutor, TabCompleter {
   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (args.length == 0) {
         this.showStatus(sender);
         return true;
      } else {
         switch (args[0].toLowerCase()) {
            case "reload":
               if (!sender.hasPermission("glidespoofer.admin")) {
                  sender.sendMessage(this.color("&cYou don't have permission to use this command."));
                  return true;
               }

               this.reloadLicence(sender);
               return true;
            case "set":
               if (!sender.hasPermission("glidespoofer.admin")) {
                  sender.sendMessage(this.color("&cYou don't have permission to use this command."));
                  return true;
               } else {
                  if (args.length < 2) {
                     sender.sendMessage(this.color("&cUsage: /" + label + " set <key>"));
                     return true;
                  }

                  this.setLicenceKey(sender, String.join(" ", (CharSequence[])Arrays.copyOfRange(args, 1, args.length)));
                  return true;
               }
            default:
               sender.sendMessage(this.color("&cUnknown subcommand. Use: /" + label + " [reload|set]"));
               return true;
         }
      }
   }

   private void showStatus(CommandSender sender) {
      boolean valid = UltimateLicenseVerify.isValid();
      String statusColor = valid ? "&a" : "&c";
      String statusLabel = valid ? "ACTIVE" : (UltimateLicenseVerify.getStatus().isEmpty() ? "NOT VERIFIED" : UltimateLicenseVerify.getStatus());
      sender.sendMessage("");
      sender.sendMessage(this.color("&8════════════════════════════════════════════"));
      sender.sendMessage(this.color("  &6&l GLIDESPOOFER LICENCE"));
      sender.sendMessage(this.color("&8════════════════════════════════════════════"));
      sender.sendMessage(this.color("  Status: " + statusColor + statusLabel));
      String var10002 = UltimateLicenseVerify.getOwnerName();
      sender.sendMessage(this.color("  Owner: &f" + var10002));
      sender.sendMessage(this.color("  Type: &f" + ("trial".equals(UltimateLicenseVerify.getType()) ? "Trial" : "Permanent")));
      long expiresAt = UltimateLicenseVerify.getExpiresAt();
      if (expiresAt > 0L) {
         String dateStr = (new SimpleDateFormat("yyyy-MM-dd HH:mm")).format(new Date(expiresAt));
         String color = expiresAt <= System.currentTimeMillis() ? "&c" : "&e";
         sender.sendMessage(this.color("  Expires: " + color + dateStr));
      } else {
         sender.sendMessage(this.color("  Expires: &aNever"));
      }

      sender.sendMessage(this.color("  Max Servers: &f" + UltimateLicenseVerify.getMaxServers()));
      sender.sendMessage(this.color("  Product: &fGLIDESPOOFER"));
      sender.sendMessage(this.color("&8════════════════════════════════════════════"));
      sender.sendMessage("");
   }

   private void reloadLicence(CommandSender sender) {
      String key = Bukkit.getPluginManager().getPlugin("GlideSpoofer").getConfig().getString("licence.license-key", "");
      if (!key.isEmpty() && !key.equals("YOUR_LICENSE_KEY_HERE")) {
         sender.sendMessage(this.color("&eRe-verifying licence..."));
         boolean result = UltimateLicenseVerify.verifyKey(key);
         if (result) {
            sender.sendMessage(this.color("&aLicence verified successfully."));
         } else {
            sender.sendMessage(this.color("&cLicence verification failed. Check the console for details."));
         }

      } else {
         Server var10002 = Bukkit.getServer();
         sender.sendMessage(this.color("&cNo licence key configured. Set one with /" + var10002.getPluginCommand("licence").getLabel() + " set <key>"));
      }
   }

   private void setLicenceKey(CommandSender sender, String newKey) {
      newKey = newKey.trim();
      FileConfiguration config = Bukkit.getPluginManager().getPlugin("GlideSpoofer").getConfig();
      config.set("licence.license-key", newKey);
      Bukkit.getPluginManager().getPlugin("GlideSpoofer").saveConfig();
      sender.sendMessage(this.color("&eLicence key updated. Verifying..."));
      boolean result = UltimateLicenseVerify.verifyKey(newKey);
      if (result) {
         sender.sendMessage(this.color("&aLicence verified and saved successfully."));
      } else {
         sender.sendMessage(this.color("&cVerification failed. Key saved but plugin may not function. Check console."));
      }

   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (args.length == 1) {
         String prefix = args[0].toLowerCase();
         if (sender.hasPermission("glidespoofer.admin")) {
            return Arrays.asList("reload", "set").stream().filter((s) -> s.startsWith(prefix)).toList();
         }
      }

      return Collections.emptyList();
   }

   private String color(String msg) {
      return ChatColor.translateAlternateColorCodes('&', msg);
   }
}
