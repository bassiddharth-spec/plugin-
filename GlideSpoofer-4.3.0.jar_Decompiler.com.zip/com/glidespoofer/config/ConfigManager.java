package com.glidespoofer.config;

import com.glidespoofer.core.GlideSpoofer;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class ConfigManager {
   private final GlideSpoofer plugin;
   private FileConfiguration config;
   private FileConfiguration fakesConfig;
   private FileConfiguration aiConfig;
   private File configFile;
   private File fakesFile;
   private File aiFile;

   public ConfigManager(GlideSpoofer plugin) {
      this.plugin = plugin;
   }

   public void loadAll() {
      if (!this.plugin.getDataFolder().exists()) {
         this.plugin.getDataFolder().mkdirs();
      }

      this.loadConfig();
      this.loadFakesConfig();
      this.loadAIConfig();
   }

   private void loadConfig() {
      this.configFile = new File(this.plugin.getDataFolder(), "config.yml");
      if (!this.configFile.exists()) {
         this.plugin.saveResource("config.yml", false);
      }

      this.config = YamlConfiguration.loadConfiguration(this.configFile);
   }

   private void loadFakesConfig() {
      this.fakesFile = new File(this.plugin.getDataFolder(), "fakes.yml");
      if (!this.fakesFile.exists()) {
         this.plugin.saveResource("fakes.yml", false);
      }

      this.fakesConfig = YamlConfiguration.loadConfiguration(this.fakesFile);
   }

   private void loadAIConfig() {
      this.aiFile = new File(this.plugin.getDataFolder(), "ai.yml");
      if (!this.aiFile.exists()) {
         this.plugin.saveResource("ai.yml", false);
      }

      this.aiConfig = YamlConfiguration.loadConfiguration(this.aiFile);
   }

   public void saveConfig() {
      try {
         this.config.save(this.configFile);
      } catch (IOException var2) {
         this.plugin.getLogger().severe("Could not save config.yml: " + var2.getMessage());
      }

   }

   public void saveFakesConfig() {
      try {
         this.fakesConfig.save(this.fakesFile);
      } catch (IOException var2) {
         this.plugin.getLogger().severe("Could not save fakes.yml: " + var2.getMessage());
      }

   }

   public FileConfiguration getRawAIConfig() {
      return this.aiConfig;
   }

   public void saveAIConfig() {
      try {
         this.aiConfig.save(this.aiFile);
      } catch (IOException var2) {
         this.plugin.getLogger().severe("Could not save ai.yml: " + var2.getMessage());
      }

   }

   public FileConfiguration getConfig() {
      return this.config;
   }

   public FileConfiguration getFakesConfig() {
      return this.fakesConfig;
   }

   public String getDisguisedPluginName() {
      return this.config.getString("plugin-disguise.name", "GlideSpoofer");
   }

   public String getDisguisedPluginVersion() {
      return this.config.getString("plugin-disguise.version", this.plugin.getDescription().getVersion());
   }

   public String getDisguisedPluginAuthor() {
      return this.config.getString("plugin-disguise.author", "GlideSpoofer");
   }

   public boolean isPluginDisguiseEnabled() {
      return this.config.getBoolean("plugin-disguise.enabled", false);
   }

   public boolean isDebugEnabled() {
      return this.config.getBoolean("debug.enabled", false);
   }

   public List<String> getFakePlayerNames() {
      List<String> names = new ArrayList();
      ConfigurationSection section = this.fakesConfig.getConfigurationSection("fakes");
      if (section != null) {
         for(String key : section.getKeys(false)) {
            names.add(section.getString(key + ".name", key));
         }
      }

      return names;
   }

   public String getFakePlayerPersonality(String playerName) {
      ConfigurationSection section = this.fakesConfig.getConfigurationSection("fakes");
      if (section != null) {
         for(String key : section.getKeys(false)) {
            String name = section.getString(key + ".name", key);
            if (name.equalsIgnoreCase(playerName)) {
               String personality = section.getString(key + ".ai-personality");
               return personality != null && !personality.isEmpty() ? personality : null;
            }
         }
      }

      return null;
   }

   public int getMinFakePlayers() {
      return this.config.getInt("fake-players.min", 5);
   }

   public int getMaxFakePlayers() {
      return this.config.getInt("fake-players.max", 30);
   }

   public double getMultiplier() {
      return this.config.getDouble("fake-players.multiplier", (double)1.0F);
   }

   public boolean isRandomCommandsEnabled() {
      return this.config.getBoolean("random-commands.enabled", false);
   }

   public int getRandomCommandsMinInterval() {
      return this.config.getInt("random-commands.min-interval", 30);
   }

   public int getRandomCommandsMaxInterval() {
      return this.config.getInt("random-commands.max-interval", 120);
   }

   public int getRandomCommandsChance() {
      return this.config.getInt("random-commands.chance", 25);
   }

   public List<String> getRandomCommands() {
      List<String> commands = this.config.getStringList("random-commands.commands");
      return commands != null ? commands : Collections.emptyList();
   }

   public List<String> getRandomTargetCommands() {
      List<String> commands = this.config.getStringList("random-commands.target-commands");
      return commands != null ? commands : Collections.emptyList();
   }

   public boolean isJoinLeaveCommandsEnabled() {
      return this.config.getBoolean("join-leave-commands.enabled", false);
   }

   public int getJoinLeaveCommandsDelay() {
      return this.config.getInt("join-leave-commands.delay", 20);
   }

   public List<String> getJoinCommands() {
      List<String> commands = this.config.getStringList("join-leave-commands.join-commands");
      return commands != null ? commands : Collections.emptyList();
   }

   public List<String> getLeaveCommands() {
      List<String> commands = this.config.getStringList("join-leave-commands.leave-commands");
      return commands != null ? commands : Collections.emptyList();
   }

   public boolean isJoinLeaveCommandsRandomMode() {
      return this.config.getBoolean("join-leave-commands.random-mode", true);
   }

   public int getJoinLeaveCommandsRandomCount() {
      return this.config.getInt("join-leave-commands.random-count", 1);
   }

   public boolean isProximityCheckEnabled() {
      return this.config.getBoolean("real-player-proximity.enabled", false);
   }

   public int getProximityRadius() {
      return this.config.getInt("real-player-proximity.radius", 10);
   }

   public int getProximityCheckInterval() {
      return this.config.getInt("real-player-proximity.check-interval", 10);
   }

   public boolean isProximityBroadcastQuit() {
      return this.config.getBoolean("real-player-proximity.broadcast-quit", true);
   }

   public boolean isBroadcastJoinEnabled() {
      return this.config.getBoolean("fake-players.broadcast-join", false);
   }

   public void setBroadcastJoinEnabled(boolean enabled) {
      this.config.set("fake-players.broadcast-join", enabled);
      this.plugin.saveConfig();
   }

   public boolean isBroadcastQuitEnabled() {
      return this.config.getBoolean("fake-players.broadcast-quit", false);
   }

   public void setBroadcastQuitEnabled(boolean enabled) {
      this.config.set("fake-players.broadcast-quit", enabled);
      this.plugin.saveConfig();
   }

   public int getPingMin() {
      return this.config.getInt("fake-players.ping.min", 20);
   }

   public int getPingMax() {
      return this.config.getInt("fake-players.ping.max", 150);
   }

   public int getPingRefreshInterval() {
      return this.config.getInt("fake-players.ping.refresh-interval", 40);
   }

   public List<String> getAuthorizedUUIDs() {
      return this.config.getStringList("authorized-players.uuids");
   }

   public boolean isOpOnly() {
      return this.config.getBoolean("authorized-players.op-only", false);
   }

   public boolean isAuthorized(Player player) {
      if (this.isOpOnly()) {
         return player.isOp();
      } else {
         List<String> uuids = this.getAuthorizedUUIDs();
         if (uuids != null && !uuids.isEmpty()) {
            String playerUUID = player.getUniqueId().toString();
            return uuids.contains(playerUUID);
         } else {
            return true;
         }
      }
   }

   public int getProximityRespawnDelay() {
      return this.config.getInt("real-player-proximity.respawn-delay", 30);
   }

   public String getMessagePrefix() {
      return this.translateColorCodes(this.config.getString("messages.prefix", "&8[&6GlideSpoofer&8] &7"));
   }

   public String getJoinMessage() {
      return this.translateColorCodes(this.config.getString("messages.join", "&e%player% joined the game"));
   }

   public String getQuitMessage() {
      return this.translateColorCodes(this.config.getString("messages.quit", "&e%player% left the game"));
   }

   public String getMessage(String key) {
      return this.translateColorCodes(this.config.getString("messages." + key, key));
   }

   public boolean isDatabaseEnabled() {
      return this.config.getBoolean("database.enabled", false);
   }

   public String getDatabaseType() {
      return this.config.getString("database.type", "SQLITE");
   }

   public AIConfig getAIConfig() {
      return new AIConfig(this.aiConfig);
   }

   public boolean isAIEnabled() {
      return this.aiConfig != null && this.aiConfig.getBoolean("enabled", false);
   }

   private String translateColorCodes(String text) {
      return text == null ? "" : text.replace("&", "§");
   }

   public static class AIConfig {
      private final FileConfiguration config;

      public AIConfig(FileConfiguration config) {
         this.config = config;
      }

      public boolean getBoolean(String path, boolean def) {
         return this.config != null ? this.config.getBoolean(path, def) : def;
      }

      public int getInt(String path, int def) {
         return this.config != null ? this.config.getInt(path, def) : def;
      }

      public double getDouble(String path, double def) {
         return this.config != null ? this.config.getDouble(path, def) : def;
      }

      public String getString(String path, String def) {
         return this.config != null ? this.config.getString(path, def) : def;
      }

      public List<String> getStringList(String path) {
         if (this.config == null) {
            return Collections.emptyList();
         } else {
            List<String> list = this.config.getStringList(path);
            return list != null ? list : Collections.emptyList();
         }
      }

      public List<String> getStringList(String path, List<String> def) {
         if (this.config == null) {
            return def;
         } else {
            List<String> list = this.config.getStringList(path);
            return list != null && !list.isEmpty() ? list : def;
         }
      }
   }
}
