package com.glidespoofer.commands;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.FakePlayer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public class FakeVotesCommand implements CommandExecutor, TabCompleter {
   private final GlideSpoofer plugin;
   private static final String PREFIX = "§8[§bFakeVotes§8] §7";

   public FakeVotesCommand(GlideSpoofer plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!this.plugin.getFakeVoteManager().isEnabled()) {
         sender.sendMessage("§8[§bFakeVotes§8] §7§cFake votes system is disabled!");
         return true;
      } else if (args.length == 0) {
         this.showStats(sender);
         return true;
      } else {
         switch (args[0].toLowerCase()) {
            case "top":
               this.showTop(sender, args);
               break;
            case "reload":
               if (!sender.hasPermission("glidespoofer.admin")) {
                  sender.sendMessage("§8[§bFakeVotes§8] §7§cNo permission!");
                  return true;
               }

               this.plugin.getFakeVoteManager().reload();
               sender.sendMessage("§8[§bFakeVotes§8] §7§aFake votes reloaded!");
               break;
            case "set":
               this.handleSet(sender, args);
               break;
            case "add":
               this.handleAdd(sender, args);
               break;
            default:
               this.showStats(sender);
         }

         return true;
      }
   }

   private void showStats(CommandSender sender) {
      sender.sendMessage("");
      sender.sendMessage("§b§l═══════ Fake Votes ═══════");
      sender.sendMessage("");
      sender.sendMessage("§8▪ §7Total Fake Votes: §b" + this.plugin.getFakeVoteManager().getTotalFakeVotes());
      sender.sendMessage("§8▪ §7Total Real Votes: §a" + this.plugin.getFakeVoteManager().getTotalRealVotes());
      sender.sendMessage("§8▪ §7Combined Total: §e" + this.plugin.getFakeVoteManager().getTotalVotes());
      sender.sendMessage("");
      sender.sendMessage("§7Use §e/fakevotes top §7to see top voters");
      sender.sendMessage("");
   }

   private void showTop(CommandSender sender, String[] args) {
      int limit = 10;
      if (args.length > 1) {
         try {
            limit = Integer.parseInt(args[1]);
         } catch (NumberFormatException var91) {
            limit = 10;
         }
      }

      limit = Math.max(1, Math.min(50, limit));
      List<FakePlayer> topVoters = this.plugin.getFakeVoteManager().getTopFakeVoters(limit);
      sender.sendMessage("");
      sender.sendMessage("§b§l═══════ Top Voters ═══════");
      sender.sendMessage("");
      int rank = 1;

      for(FakePlayer fake : topVoters) {
         String medal = "";
         if (rank == 1) {
            medal = "§6\ud83e\udd47 ";
         } else if (rank == 2) {
            medal = "§7\ud83e\udd48 ";
         } else if (rank == 3) {
            medal = "§c\ud83e\udd49 ";
         }

         sender.sendMessage(medal + "§7#" + rank + " §e" + fake.getName() + " §8- §b" + fake.getFakeVotes() + " votes");
         ++rank;
      }

      sender.sendMessage("");
   }

   private void handleSet(CommandSender sender, String[] args) {
      if (!sender.hasPermission("glidespoofer.admin")) {
         sender.sendMessage("§8[§bFakeVotes§8] §7§cNo permission!");
      } else if (args.length < 3) {
         sender.sendMessage("§8[§bFakeVotes§8] §7§cUsage: /fakevotes set <player> <amount>");
      } else {
         FakePlayer fake = this.plugin.getFakePlayerManager().getFakePlayer(args[1]);
         if (fake == null) {
            sender.sendMessage("§8[§bFakeVotes§8] §7§cFake player not found!");
         } else {
            try {
               int amount = Integer.parseInt(args[2]);
               amount = Math.max(0, Math.min(amount, this.plugin.getFakeVoteManager().getMaxVotesPerFake()));
               fake.setFakeVotes(amount);
               String var10001 = fake.getName();
               sender.sendMessage("§8[§bFakeVotes§8] §7§aSet §e" + var10001 + "§a's votes to §b" + amount);
            } catch (NumberFormatException var5) {
               sender.sendMessage("§8[§bFakeVotes§8] §7§cInvalid number!");
            }
         }
      }

   }

   private void handleAdd(CommandSender sender, String[] args) {
      if (!sender.hasPermission("glidespoofer.admin")) {
         sender.sendMessage("§8[§bFakeVotes§8] §7§cNo permission!");
      } else if (args.length < 3) {
         sender.sendMessage("§8[§bFakeVotes§8] §7§cUsage: /fakevotes add <player> <amount>");
      } else {
         FakePlayer fake = this.plugin.getFakePlayerManager().getFakePlayer(args[1]);
         if (fake == null) {
            sender.sendMessage("§8[§bFakeVotes§8] §7§cFake player not found!");
         } else {
            try {
               int amount = Integer.parseInt(args[2]);
               fake.addFakeVotes(amount);
               sender.sendMessage("§8[§bFakeVotes§8] §7§aAdded §b" + amount + " §avotes to §e" + fake.getName());
            } catch (NumberFormatException var5) {
               sender.sendMessage("§8[§bFakeVotes§8] §7§cInvalid number!");
            }
         }
      }

   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      List<String> completions = new ArrayList();
      if (args.length == 1) {
         for(String sub : Arrays.asList("top", "reload", "set", "add")) {
            if (sub.startsWith(args[0].toLowerCase())) {
               completions.add(sub);
            }
         }
      } else if (args.length == 2) {
         String cmd = args[0].toLowerCase();
         if (cmd.equals("set") || cmd.equals("add")) {
            for(FakePlayer fake : this.plugin.getFakePlayerManager().getFakePlayers()) {
               if (fake.getName().toLowerCase().startsWith(args[1].toLowerCase())) {
                  completions.add(fake.getName());
               }
            }
         }
      }

      return completions;
   }
}
