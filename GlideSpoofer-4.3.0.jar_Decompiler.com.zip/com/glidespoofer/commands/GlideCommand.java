package com.glidespoofer.commands;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import com.glidespoofer.listener.FakePlayerGUIListener;
import com.glidespoofer.nms.NMSHandler;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class GlideCommand implements CommandExecutor, TabCompleter {
   private final GlideSpoofer plugin;
   private FakePlayerGUIListener guiListener;

   public GlideCommand(GlideSpoofer plugin) {
      this.plugin = plugin;
   }

   public void setGUIListener(FakePlayerGUIListener guiListener) {
      this.guiListener = guiListener;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         if (!this.plugin.getConfigManager().isAuthorized(player)) {
            sender.sendMessage("§cYou don't have permission to use this command.");
            return true;
         }
      } else if (!sender.hasPermission("glidespoofer.admin")) {
         sender.sendMessage("§cYou don't have permission to use this command.");
         return true;
      }

      if (args.length == 0) {
         this.showHelp(sender);
         return true;
      } else {
         String sub = args[0].toLowerCase();
         SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
         switch (sub) {
            case "help":
               this.showHelp(sender);
               break;
            case "add":
               this.handleAdd(sender, args, manager);
               break;
            case "gui":
               this.handleGUI(sender, manager);
               break;
            case "reload":
               this.handleReload(sender);
               break;
            case "remove":
            case "despawn":
               this.handleRemove(sender, args, manager);
               break;
            case "removeall":
            case "despawnall":
            case "clear":
               this.handleRemoveAll(sender, manager);
               break;
            case "list":
               this.handleList(sender, manager);
               break;
            case "info":
               this.handleInfo(sender, args, manager);
               break;
            case "tp":
            case "teleport":
               this.handleTeleport(sender, args, manager);
               break;
            case "tphere":
            case "bring":
               this.handleTpHere(sender, args, manager);
               break;
            case "action":
               this.handleAction(sender, args, manager);
               break;
            case "rtp":
            case "randomtp":
               this.handleRTP(sender, args, manager);
               break;
            case "cmd":
            case "command":
               this.handleCommand(sender, args, manager);
               break;
            case "stats":
               this.handleStats(sender, manager);
               break;
            default:
               sender.sendMessage("§cUnknown subcommand. Use §6/" + label + " help");
         }

         return true;
      }
   }

   private void showHelp(CommandSender sender) {
      sender.sendMessage("§6§l═══ GlideSpoofer v4.0.8 Commands ═══");
      sender.sendMessage("§ePlayer Management:");
      sender.sendMessage("§e/gs add <count> §7- Add fake players gradually (1 min)");
      sender.sendMessage("§e/gs remove <name|count> §7- Remove player or bulk remove");
      sender.sendMessage("§e/gs removeall §7- Remove all fake players");
      sender.sendMessage("§e/gs list §7- List all fake players");
      sender.sendMessage("§e/gs info <name> §7- View fake player info");
      sender.sendMessage("§e/gs gui §7- Open GUI to manage fake players");
      sender.sendMessage("§e/gs tp <name> §7- Teleport to fake player");
      sender.sendMessage("§e/gs tphere <name> §7- Teleport fake player to you");
      sender.sendMessage("§e/gs rtp <name> §7- Random teleport fake player");
      sender.sendMessage("§e");
      sender.sendMessage("§eActions:");
      sender.sendMessage("§e/gs action <name> <action> §7- Perform action");
      sender.sendMessage("§e");
      sender.sendMessage("§eOther:");
      sender.sendMessage("§e/gs cmd <name> <command> §7- Execute command as fake");
      sender.sendMessage("§e/gs stats §7- View statistics");
      sender.sendMessage("§e/gs reload §7- Reload configuration");
      sender.sendMessage("§7Actions: swing, sneak, unsneak, sprint, unsprint, jump");
   }

   private void handleRemove(CommandSender sender, String[] args, SimpleFakePlayerManager manager) {
      if (manager == null) {
         sender.sendMessage("§cFake player system not initialized!");
      } else if (args.length < 2) {
         sender.sendMessage("§cUsage: /gs remove <name|count>");
      } else {
         String nameOrCount = args[1];

         try {
            int count = Integer.parseInt(nameOrCount);
            if (count > 0) {
               int removed = manager.gradualDespawn(count);
               if (removed > 0) {
                  sender.sendMessage("§aRemoving §f" + removed + "§a fake players over 1 minute...");
               } else {
                  sender.sendMessage("§cNo fake players to remove!");
               }
            } else {
               sender.sendMessage("§cCount must be greater than 0!");
            }
         } catch (NumberFormatException var7) {
            if (manager.hasFakePlayer(nameOrCount)) {
               manager.despawnFakePlayer(nameOrCount);
               sender.sendMessage("§aRemoved fake player: §f" + nameOrCount);
            } else {
               sender.sendMessage("§cFake player not found: §f" + nameOrCount);
            }
         }
      }

   }

   private void handleAdd(CommandSender sender, String[] args, SimpleFakePlayerManager manager) {
      if (manager == null) {
         sender.sendMessage("§cFake player system not initialized!");
      } else if (args.length < 2) {
         sender.sendMessage("§cUsage: /gs add <count>");
      } else {
         try {
            int count = Integer.parseInt(args[1]);
            if (count <= 0) {
               sender.sendMessage("§cCount must be greater than 0!");
               return;
            }

            if (count > 100) {
               sender.sendMessage("§cCannot add more than 100 fake players at once!");
               return;
            }

            int added = manager.gradualSpawn(count);
            if (added > 0) {
               sender.sendMessage("§aAdding §f" + added + "§a fake players over 1 minute...");
            } else {
               sender.sendMessage("§cFailed to add fake players. NMS may not be available.");
            }
         } catch (NumberFormatException var6) {
            sender.sendMessage("§cInvalid number: §f" + args[1]);
         }
      }

   }

   private void handleRemoveAll(CommandSender sender, SimpleFakePlayerManager manager) {
      if (manager == null) {
         sender.sendMessage("§cFake player system not initialized!");
      } else {
         int count = manager.getFakePlayerCount();
         manager.despawnAll();
         sender.sendMessage("§aRemoved §f" + count + "§a fake players.");
      }

   }

   private void handleList(CommandSender sender, SimpleFakePlayerManager manager) {
      if (manager == null) {
         sender.sendMessage("§cFake player system not initialized!");
      } else if (sender instanceof Player) {
         manager.listFakePlayers((Player)sender);
      } else {
         sender.sendMessage("§6Fake Players §7(" + manager.getFakePlayerCount() + "):");

         for(SimpleFakePlayerManager.FakePlayerData data : manager.getAllFakePlayers()) {
            int ping = manager.getPing(data.getName());
            sender.sendMessage("  §f" + data.getName() + " §7(Ping: " + ping + "ms, Skin: " + data.getSkinName() + ")");
         }
      }

   }

   private void handleInfo(CommandSender sender, String[] args, SimpleFakePlayerManager manager) {
      if (manager == null) {
         sender.sendMessage("§cFake player system not initialized!");
      } else if (args.length < 2) {
         sender.sendMessage("§cUsage: /gs info <name>");
      } else {
         String name = args[1];
         SimpleFakePlayerManager.FakePlayerData data = manager.getFakePlayer(name);
         if (data == null) {
            sender.sendMessage("§cFake player not found: §f" + name);
         } else {
            int ping = manager.getPing(name);
            double health = manager.getNMSHandler().getHealth(data.getUuid());
            sender.sendMessage("§6§l═══ Fake Player Info ═══");
            sender.sendMessage("§eName: §f" + data.getName());
            sender.sendMessage("§eUUID: §7" + String.valueOf(data.getUuid()));
            sender.sendMessage("§eSkin: §b" + data.getSkinName());
            sender.sendMessage("§ePing: §a" + ping + "ms");
            Object[] var10002 = new Object[]{health};
            sender.sendMessage("§eHealth: §c" + String.format("%.1f", var10002) + "/20.0");
            String var10001 = data.getRank() != null ? data.getRank() : "none";
            sender.sendMessage("§eRank: §d" + var10001);
            var10001 = data.isMovementEnabled() ? "§aEnabled" : "§cDisabled";
            sender.sendMessage("§eMovement: " + var10001);
            var10001 = manager.getNMSHandler().isMuted(data.getUuid()) ? "§cYes" : "§aNo";
            sender.sendMessage("§eMuted: " + var10001);
            var10001 = manager.getNMSHandler().isBanned(data.getUuid()) ? "§cYes" : "§aNo";
            sender.sendMessage("§eBanned: " + var10001);
            if (data.getPlayer() != null) {
               Location loc = data.getPlayer().getLocation();
               var10001 = loc.getWorld().getName();
               sender.sendMessage("§eLocation: §f" + var10001 + " " + String.format("%.1f, %.1f, %.1f", loc.getX(), loc.getY(), loc.getZ()));
            }
         }
      }

   }

   private void handleTeleport(CommandSender sender, String[] args, SimpleFakePlayerManager manager) {
      if (!(sender instanceof Player)) {
         sender.sendMessage("§cThis command can only be used by players!");
      } else if (manager == null) {
         sender.sendMessage("§cFake player system not initialized!");
      } else if (args.length < 2) {
         sender.sendMessage("§cUsage: /gs tp <name>");
      } else {
         String name = args[1];
         SimpleFakePlayerManager.FakePlayerData data = manager.getFakePlayer(name);
         if (data != null && data.getPlayer() != null) {
            ((Player)sender).teleport(data.getPlayer().getLocation());
            sender.sendMessage("§aTeleported to §f" + name);
         } else {
            sender.sendMessage("§cFake player not found: §f" + name);
         }
      }

   }

   private void handleTpHere(CommandSender sender, String[] args, SimpleFakePlayerManager manager) {
      if (!(sender instanceof Player)) {
         sender.sendMessage("§cThis command can only be used by players!");
      } else if (manager == null) {
         sender.sendMessage("§cFake player system not initialized!");
      } else if (args.length < 2) {
         sender.sendMessage("§cUsage: /gs tphere <name>");
      } else {
         String name = args[1];
         if (!manager.hasFakePlayer(name)) {
            sender.sendMessage("§cFake player not found: §f" + name);
         } else {
            manager.teleportFakePlayer(name, ((Player)sender).getLocation());
            sender.sendMessage("§aTeleported §f" + name + "§a to your location.");
         }
      }

   }

   private void handleAction(CommandSender sender, String[] args, SimpleFakePlayerManager manager) {
      if (manager == null) {
         sender.sendMessage("§cFake player system not initialized!");
      } else if (args.length < 3) {
         sender.sendMessage("§cUsage: /gs action <name> <action>");
         sender.sendMessage("§7Actions: swing, sneak, unsneak, sprint, unsprint, jump");
      } else {
         String name = args[1];
         String action = args[2].toLowerCase();
         if (!manager.hasFakePlayer(name)) {
            sender.sendMessage("§cFake player not found: §f" + name);
         } else {
            NMSHandler.FakePlayerAction fakeAction;
            switch (action) {
               case "swing":
                  fakeAction = NMSHandler.FakePlayerAction.SWING_MAIN_ARM;
                  break;
               case "sneak":
                  fakeAction = NMSHandler.FakePlayerAction.SNEAK_START;
                  break;
               case "unsneak":
                  fakeAction = NMSHandler.FakePlayerAction.SNEAK_END;
                  break;
               case "sprint":
                  fakeAction = NMSHandler.FakePlayerAction.SPRINT_START;
                  break;
               case "unsprint":
                  fakeAction = NMSHandler.FakePlayerAction.SPRINT_END;
                  break;
               case "jump":
                  fakeAction = NMSHandler.FakePlayerAction.JUMP;
                  break;
               default:
                  sender.sendMessage("§cUnknown action: §f" + action);
                  return;
            }

            manager.performAction(name, fakeAction);
            sender.sendMessage("§aPerformed §f" + action + "§a on §f" + name);
         }
      }

   }

   private void handleRTP(CommandSender sender, String[] args, SimpleFakePlayerManager manager) {
      if (manager == null) {
         sender.sendMessage("§cFake player system not initialized!");
      } else if (args.length < 2) {
         sender.sendMessage("§cUsage: /gs rtp <name>");
      } else {
         String name = args[1];
         if (!manager.hasFakePlayer(name)) {
            sender.sendMessage("§cFake player not found: §f" + name);
         } else if (manager.randomTeleport(name)) {
            sender.sendMessage("§aRandomly teleported §f" + name + "§a.");
         } else {
            sender.sendMessage("§cFailed to RTP §f" + name);
         }
      }

   }

   private void handleCommand(CommandSender sender, String[] args, SimpleFakePlayerManager manager) {
      if (manager == null) {
         sender.sendMessage("§cFake player system not initialized!");
      } else if (args.length < 3) {
         sender.sendMessage("§cUsage: /gs cmd <name> <command>");
      } else {
         String name = args[1];
         if (!manager.hasFakePlayer(name)) {
            sender.sendMessage("§cFake player not found: §f" + name);
         } else {
            String command = String.join(" ", (CharSequence[])Arrays.copyOfRange(args, 2, args.length));
            boolean success = manager.executeCommand(name, command);
            if (success) {
               sender.sendMessage("§aExecuted command as §f" + name + "§a.");
            } else {
               sender.sendMessage("§cFailed to execute command as §f" + name);
            }
         }
      }

   }

   private void handleGUI(CommandSender sender, SimpleFakePlayerManager manager) {
      if (sender instanceof Player player) {
         if (this.guiListener == null) {
            this.guiListener = new FakePlayerGUIListener(this.plugin, this.plugin.getPathfinding(), this.plugin.getFollowModeManager());
            this.plugin.getServer().getPluginManager().registerEvents(this.guiListener, this.plugin);
         }

         this.guiListener.getGUI().openMainGUI(player);
      } else {
         sender.sendMessage("§cThis command can only be used by players!");
      }

   }

   private void handleReload(CommandSender sender) {
      this.plugin.getConfigManager().loadAll();
      sender.sendMessage("§7Reloaded: §fconfig.yml§7, §ffakes.yml§7, §fai.yml");
      if (this.plugin.getFluctuationManager() != null) {
         this.plugin.getFluctuationManager().reloadSettings();
      }

      if (this.plugin.getAIManager() != null) {
         this.plugin.getAIManager().reload();
      }

      if (this.plugin.getLuckPermsHook() != null && this.plugin.getLuckPermsHook().isEnabled() && this.plugin.getSimpleFakePlayerManager() != null) {
         for(SimpleFakePlayerManager.FakePlayerData data : this.plugin.getSimpleFakePlayerManager().getAllFakePlayers()) {
            this.plugin.getLuckPermsHook().setupFakePlayer(data.getUuid(), data.getName(), data.getRank());
         }
      }

      sender.sendMessage("§aConfiguration reloaded!");
      sender.sendMessage("§7(AI settings take effect immediately)");
      sender.sendMessage("§7(Fake players remain spawned - use /gs removeall to respawn with new config)");
   }

   private void handleStats(CommandSender sender, SimpleFakePlayerManager manager) {
      sender.sendMessage("§6§l═══ GlideSpoofer Statistics ═══");
      sender.sendMessage("§eVersion: §f4.0.6 (NMS Only)");
      sender.sendMessage("§eMinecraft: §f" + this.plugin.getMinecraftVersion());
      if (manager != null) {
         int var10001 = manager.getFakePlayerCount();
         sender.sendMessage("§eFake Players: §f" + var10001);
         sender.sendMessage("§eNMS Available: §a" + (manager.isNMSAvailable() ? "Yes" : "No"));
         if (manager.getFakePlayerCount() > 0) {
            int totalPing = 0;

            for(SimpleFakePlayerManager.FakePlayerData data : manager.getAllFakePlayers()) {
               totalPing += manager.getPing(data.getName());
            }

            int avgPing = totalPing / manager.getFakePlayerCount();
            sender.sendMessage("§eAverage Ping: §f" + avgPing + "ms");
         }
      } else {
         sender.sendMessage("§eFake Players: §cNot Initialized");
      }

   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      List<String> completions = new ArrayList();
      SimpleFakePlayerManager manager = this.plugin.getSimpleFakePlayerManager();
      if (args.length == 1) {
         completions.addAll(Arrays.asList("help", "add", "remove", "removeall", "list", "info", "tp", "tphere", "action", "rtp", "cmd", "stats", "reload", "gui"));
      } else if (args.length == 2) {
         String sub = args[0].toLowerCase();
         if (Arrays.asList("remove", "info", "tp", "tphere", "action", "rtp", "cmd").contains(sub) && manager != null) {
            completions.addAll((Collection)manager.getAllFakePlayers().stream().map(SimpleFakePlayerManager.FakePlayerData::getName).collect(Collectors.toList()));
         }
      } else if (args.length == 3 && args[0].equalsIgnoreCase("action")) {
         completions.addAll(Arrays.asList("swing", "sneak", "unsneak", "sprint", "unsprint", "jump"));
      }

      String lastArg = args[args.length - 1].toLowerCase();
      return (List)completions.stream().filter((s) -> s.toLowerCase().startsWith(lastArg)).collect(Collectors.toList());
   }
}
