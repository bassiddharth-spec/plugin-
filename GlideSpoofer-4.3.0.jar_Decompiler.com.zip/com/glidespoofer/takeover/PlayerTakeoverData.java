package com.glidespoofer.takeover;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PlayerTakeoverData {
   private final File dataFile;
   private final Gson gson;
   private final Logger logger;
   private Map<String, TakeoverEntry> takeoverData;

   public PlayerTakeoverData(File dataFolder, Logger logger) {
      this.dataFile = new File(dataFolder, "player_takeovers.json");
      this.logger = logger;
      this.gson = (new GsonBuilder()).setPrettyPrinting().create();
      this.takeoverData = new HashMap();
      this.load();
   }

   public void load() {
      if (!this.dataFile.exists()) {
         this.logger.info("[PlayerTakeover] No existing takeover data found");
         this.takeoverData = new HashMap();
      } else {
         try {
            Reader reader = new FileReader(this.dataFile);

            try {
               Type type = (new TypeToken<Map<String, TakeoverEntry>>() {
               }).getType();
               this.takeoverData = (Map)this.gson.fromJson(reader, type);
               if (this.takeoverData == null) {
                  this.takeoverData = new HashMap();
               }

               this.logger.info("[PlayerTakeover] Loaded " + this.takeoverData.size() + " takeover entries");
            } catch (Throwable var5) {
               try {
                  reader.close();
               } catch (Throwable var4) {
                  var5.addSuppressed(var4);
               }

               throw var5;
            }

            reader.close();
         } catch (Exception var6) {
            this.logger.log(Level.WARNING, "[PlayerTakeover] Failed to load takeover data", var6);
            this.takeoverData = new HashMap();
         }
      }

   }

   public void save() {
      try {
         File tempFile = new File(this.dataFile.getParent(), this.dataFile.getName() + ".tmp");
         Writer writer = new FileWriter(tempFile);

         try {
            this.gson.toJson((Object)this.takeoverData, (Appendable)writer);
         } catch (Throwable var6) {
            try {
               writer.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }

            throw var6;
         }

         writer.close();
         Files.move(tempFile.toPath(), this.dataFile.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
      } catch (Exception var7) {
         this.logger.log(Level.WARNING, "[PlayerTakeover] Failed to save takeover data", var7);
      }

   }

   public void addTakeover(UUID realPlayerUuid, String fakePlayerName, String realPlayerName, String serializedInventory, String world, double x, double y, double z, float yaw, float pitch) {
      TakeoverEntry entry = new TakeoverEntry(realPlayerUuid.toString(), fakePlayerName, realPlayerName, serializedInventory, System.currentTimeMillis(), world, x, y, z, yaw, pitch);
      this.takeoverData.put(realPlayerUuid.toString(), entry);
      this.save();
   }

   public void addTakeover(UUID realPlayerUuid, String fakePlayerName, String realPlayerName, String serializedInventory) {
      this.addTakeover(realPlayerUuid, fakePlayerName, realPlayerName, serializedInventory, (String)null, (double)0.0F, (double)0.0F, (double)0.0F, 0.0F, 0.0F);
   }

   public void removeTakeover(UUID realPlayerUuid) {
      if (this.takeoverData.remove(realPlayerUuid.toString()) != null) {
         this.save();
      }

   }

   public TakeoverEntry getTakeover(UUID realPlayerUuid) {
      return (TakeoverEntry)this.takeoverData.get(realPlayerUuid.toString());
   }

   public Map<String, TakeoverEntry> getAllTakeovers() {
      return new HashMap(this.takeoverData);
   }

   public boolean hasTakeover(UUID realPlayerUuid) {
      return this.takeoverData.containsKey(realPlayerUuid.toString());
   }

   public void markAsDied(UUID realPlayerUuid) {
      TakeoverEntry entry = (TakeoverEntry)this.takeoverData.get(realPlayerUuid.toString());
      if (entry != null) {
         entry.setDied(true);
         this.save();
      }

   }

   public void updateTakeover(UUID realPlayerUuid, String serializedInventory, String world, double x, double y, double z, float yaw, float pitch) {
      TakeoverEntry existing = (TakeoverEntry)this.takeoverData.get(realPlayerUuid.toString());
      if (existing != null) {
         boolean wasDead = existing.hasDied();
         this.takeoverData.put(realPlayerUuid.toString(), new TakeoverEntry(existing.getRealPlayerUuid(), existing.getFakePlayerName(), existing.getRealPlayerName(), serializedInventory, existing.getTimestamp(), world, x, y, z, yaw, pitch));
         if (wasDead) {
            ((TakeoverEntry)this.takeoverData.get(realPlayerUuid.toString())).setDied(true);
         }

         this.save();
      }

   }

   public void clear() {
      this.takeoverData.clear();
      this.save();
   }

   public void updateLocation(UUID realPlayerUuid, String world, double x, double y, double z, float yaw, float pitch) {
      TakeoverEntry existing = (TakeoverEntry)this.takeoverData.get(realPlayerUuid.toString());
      if (existing != null) {
         boolean wasDead = existing.hasDied();
         String serializedInventory = existing.getSerializedInventory();
         this.takeoverData.put(realPlayerUuid.toString(), new TakeoverEntry(existing.getRealPlayerUuid(), existing.getFakePlayerName(), existing.getRealPlayerName(), serializedInventory, existing.getTimestamp(), world, x, y, z, yaw, pitch));
         if (wasDead) {
            ((TakeoverEntry)this.takeoverData.get(realPlayerUuid.toString())).setDied(true);
         }

         this.save();
      }

   }

   public static class TakeoverEntry {
      private final String realPlayerUuid;
      private final String fakePlayerName;
      private final String realPlayerName;
      private final String serializedInventory;
      private final long timestamp;
      private final String world;
      private final double x;
      private final double y;
      private final double z;
      private final float yaw;
      private final float pitch;
      private boolean died;

      public TakeoverEntry(String realPlayerUuid, String fakePlayerName, String realPlayerName, String serializedInventory, long timestamp, String world, double x, double y, double z, float yaw, float pitch) {
         this.realPlayerUuid = realPlayerUuid;
         this.fakePlayerName = fakePlayerName;
         this.realPlayerName = realPlayerName;
         this.serializedInventory = serializedInventory;
         this.timestamp = timestamp;
         this.world = world;
         this.x = x;
         this.y = y;
         this.z = z;
         this.yaw = yaw;
         this.pitch = pitch;
         this.died = false;
      }

      public String getRealPlayerUuid() {
         return this.realPlayerUuid;
      }

      public String getFakePlayerName() {
         return this.fakePlayerName;
      }

      public String getRealPlayerName() {
         return this.realPlayerName;
      }

      public String getSerializedInventory() {
         return this.serializedInventory;
      }

      public long getTimestamp() {
         return this.timestamp;
      }

      public String getWorld() {
         return this.world;
      }

      public double getX() {
         return this.x;
      }

      public double getY() {
         return this.y;
      }

      public double getZ() {
         return this.z;
      }

      public float getYaw() {
         return this.yaw;
      }

      public float getPitch() {
         return this.pitch;
      }

      public boolean hasLocation() {
         return this.world != null && !this.world.isEmpty();
      }

      public boolean hasDied() {
         return this.died;
      }

      public void setDied(boolean died) {
         this.died = died;
      }
   }
}
