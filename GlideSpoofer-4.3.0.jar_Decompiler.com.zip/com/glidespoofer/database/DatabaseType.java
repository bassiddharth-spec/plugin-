package com.glidespoofer.database;

public enum DatabaseType {
   SQLITE,
   MYSQL,
   MONGODB,
   REDIS;

   public static DatabaseType fromString(String type) {
      if (type == null) {
         return SQLITE;
      } else {
         try {
            return valueOf(type.toUpperCase());
         } catch (IllegalArgumentException var2) {
            return SQLITE;
         }
      }
   }

   // $FF: synthetic method
   private static DatabaseType[] $values() {
      return new DatabaseType[]{SQLITE, MYSQL, MONGODB, REDIS};
   }
}
