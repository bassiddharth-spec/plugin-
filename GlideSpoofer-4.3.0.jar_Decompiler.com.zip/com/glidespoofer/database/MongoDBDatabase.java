package com.glidespoofer.database;

import com.glidespoofer.core.GlideSpoofer;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.ReplaceOptions;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bukkit.configuration.ConfigurationSection;

public class MongoDBDatabase implements Database {
   private final GlideSpoofer plugin;
   private final ConfigurationSection config;
   private MongoClient mongoClient;
   private MongoDatabase database;
   private MongoCollection<Document> fakePlayersCollection;
   private MongoCollection<Document> votesCollection;
   private MongoCollection<Document> statsCollection;
   private boolean connected;

   public MongoDBDatabase(GlideSpoofer plugin, ConfigurationSection config) {
      this.plugin = plugin;
      this.config = config;
      this.connected = false;
   }

   public boolean initialize() {
      try {
         ConfigurationSection mongoConfig = this.config.getConfigurationSection("mongodb");
         if (mongoConfig == null) {
            this.plugin.getLogger().severe("MongoDB configuration not found!");
            return false;
         } else {
            String connectionString = mongoConfig.getString("connection-string", "mongodb://localhost:27017");
            String dbName = mongoConfig.getString("database", "glidespoofer");
            String collectionName = mongoConfig.getString("collection", "fake_players");
            this.mongoClient = MongoClients.create(connectionString);
            this.database = this.mongoClient.getDatabase(dbName);
            this.fakePlayersCollection = this.database.getCollection(collectionName);
            this.votesCollection = this.database.getCollection(collectionName + "_votes");
            this.statsCollection = this.database.getCollection(collectionName + "_stats");
            this.connected = true;
            this.plugin.getLogger().info("MongoDB connected successfully: " + dbName);
            this.createTables();
            return true;
         }
      } catch (Exception var5) {
         this.plugin.getLogger().log(Level.SEVERE, "Failed to connect to MongoDB: " + var5.getMessage(), var5);
         return false;
      }
   }

   public void shutdown() {
      if (this.mongoClient != null) {
         this.mongoClient.close();
      }

      this.connected = false;
   }

   public boolean isConnected() {
      return this.connected && this.mongoClient != null;
   }

   public DatabaseType getType() {
      return DatabaseType.MONGODB;
   }

   public void createTables() {
      try {
         this.fakePlayersCollection.createIndex(new Document("name", 1));
         this.fakePlayersCollection.createIndex(new Document("rank", 1));
         this.fakePlayersCollection.createIndex(new Document("lastSeen", -1));
         this.votesCollection.createIndex(new Document("playerName", 1));
         this.votesCollection.createIndex(new Document("votes", -1));
         this.statsCollection.createIndex(new Document("playerName", 1));
         this.plugin.getLogger().info("MongoDB indexes created successfully.");
      } catch (Exception var2) {
         this.plugin.getLogger().log(Level.WARNING, "Error creating MongoDB indexes: " + var2.getMessage(), var2);
      }

   }

   public void saveFakePlayer(FakePlayerData player) {
      try {
         Document doc = (new Document("name", player.getName())).append("uuid", player.getUuid().toString()).append("skinName", player.getSkinName()).append("rank", player.getRank()).append("visibleInTab", player.isVisibleInTab()).append("visibleInPing", player.isVisibleInPing()).append("visibleInWorld", player.isVisibleInWorld()).append("votes", player.getVotes()).append("fluctuationEnabled", player.isFluctuationEnabled()).append("lastSeen", player.getLastSeen()).append("totalPlayTime", player.getTotalPlayTime()).append("updatedAt", System.currentTimeMillis());
         if (player.getSpawnLocation() != null) {
            doc.append("location", (new Document()).append("world", player.getSpawnLocation().getWorld().getName()).append("x", player.getSpawnLocation().getX()).append("y", player.getSpawnLocation().getY()).append("z", player.getSpawnLocation().getZ()).append("yaw", player.getSpawnLocation().getYaw()).append("pitch", player.getSpawnLocation().getPitch()));
         }

         this.fakePlayersCollection.replaceOne((Bson)Filters.eq("name", player.getName()), doc, (new ReplaceOptions()).upsert(true));
      } catch (Exception var3) {
         this.plugin.getLogger().log(Level.WARNING, "Error saving fake player: " + var3.getMessage(), var3);
      }

   }

   public FakePlayerData loadFakePlayer(String name) {
      try {
         Document doc = (Document)this.fakePlayersCollection.find(Filters.eq("name", name)).first();
         if (doc != null) {
            return this.mapDocumentToFakePlayer(doc);
         }
      } catch (Exception var3) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading fake player: " + var3.getMessage(), var3);
      }

      return null;
   }

   public void deleteFakePlayer(String name) {
      try {
         this.fakePlayersCollection.deleteOne(Filters.eq("name", name));
      } catch (Exception var3) {
         this.plugin.getLogger().log(Level.WARNING, "Error deleting fake player: " + var3.getMessage(), var3);
      }

   }

   public List<FakePlayerData> getAllFakePlayers() {
      List<FakePlayerData> players = new ArrayList();

      try {
         for(Document doc : this.fakePlayersCollection.find()) {
            players.add(this.mapDocumentToFakePlayer(doc));
         }
      } catch (Exception var4) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading fake players: " + var4.getMessage(), var4);
      }

      return players;
   }

   public void saveVotes(String playerName, int votes) {
      try {
         Document doc = (new Document("playerName", playerName)).append("votes", votes).append("lastUpdated", System.currentTimeMillis());
         this.votesCollection.replaceOne((Bson)Filters.eq("playerName", playerName), doc, (new ReplaceOptions()).upsert(true));
      } catch (Exception var4) {
         this.plugin.getLogger().log(Level.WARNING, "Error saving votes: " + var4.getMessage(), var4);
      }

   }

   public int loadVotes(String playerName) {
      try {
         Document doc = (Document)this.votesCollection.find(Filters.eq("playerName", playerName)).first();
         if (doc != null) {
            return doc.getInteger("votes", 0);
         }
      } catch (Exception var3) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading votes: " + var3.getMessage(), var3);
      }

      return 0;
   }

   public void savePlayerStats(PlayerStats stats) {
      try {
         Document doc = (new Document("playerName", stats.getPlayerName())).append("totalPlayTime", stats.getTotalPlayTime()).append("timesJoined", stats.getTimesJoined()).append("timesLeft", stats.getTimesLeft()).append("lastJoinTime", stats.getLastJoinTime()).append("lastLeaveTime", stats.getLastLeaveTime()).append("messagesSent", stats.getMessagesSent()).append("commandsExecuted", stats.getCommandsExecuted()).append("updatedAt", System.currentTimeMillis());
         this.statsCollection.replaceOne((Bson)Filters.eq("playerName", stats.getPlayerName()), doc, (new ReplaceOptions()).upsert(true));
      } catch (Exception var3) {
         this.plugin.getLogger().log(Level.WARNING, "Error saving player stats: " + var3.getMessage(), var3);
      }

   }

   public PlayerStats loadPlayerStats(String playerName) {
      try {
         Document doc = (Document)this.statsCollection.find(Filters.eq("playerName", playerName)).first();
         if (doc != null) {
            PlayerStats stats = new PlayerStats(playerName);
            stats.setTotalPlayTime(doc.getLong("totalPlayTime") != null ? doc.getLong("totalPlayTime") : 0L);

            for(int i = 0; i < (doc.getInteger("timesJoined") != null ? doc.getInteger("timesJoined") : 0); ++i) {
               stats.incrementTimesJoined();
            }

            for(int i = 0; i < (doc.getInteger("timesLeft") != null ? doc.getInteger("timesLeft") : 0); ++i) {
               stats.incrementTimesLeft();
            }

            stats.setLastJoinTime(doc.getLong("lastJoinTime") != null ? doc.getLong("lastJoinTime") : 0L);
            stats.setLastLeaveTime(doc.getLong("lastLeaveTime") != null ? doc.getLong("lastLeaveTime") : 0L);

            for(int i = 0; i < (doc.getInteger("messagesSent") != null ? doc.getInteger("messagesSent") : 0); ++i) {
               stats.incrementMessagesSent();
            }

            for(int i = 0; i < (doc.getInteger("commandsExecuted") != null ? doc.getInteger("commandsExecuted") : 0); ++i) {
               stats.incrementCommandsExecuted();
            }

            return stats;
         }
      } catch (Exception var5) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading player stats: " + var5.getMessage(), var5);
      }

      return null;
   }

   public Map<String, Object> executeQuery(String query) {
      this.plugin.getLogger().warning("Raw MongoDB queries are not supported. Use the native API.");
      return Map.of();
   }

   public boolean executeUpdate(String query) {
      this.plugin.getLogger().warning("Raw MongoDB updates are not supported. Use the native API.");
      return false;
   }

   private FakePlayerData mapDocumentToFakePlayer(Document doc) {
      String name = doc.getString("name");
      UUID uuid = UUID.fromString(doc.getString("uuid"));
      FakePlayerData data = new FakePlayerData(name, uuid);
      data.setSkinName(doc.getString("skinName") != null ? doc.getString("skinName") : name);
      data.setRank(doc.getString("rank") != null ? doc.getString("rank") : "default");
      data.setVisibleInTab(doc.getBoolean("visibleInTab") != null ? doc.getBoolean("visibleInTab") : true);
      data.setVisibleInPing(doc.getBoolean("visibleInPing") != null ? doc.getBoolean("visibleInPing") : true);
      data.setVisibleInWorld(doc.getBoolean("visibleInWorld") != null ? doc.getBoolean("visibleInWorld") : true);
      data.setVotes(doc.getInteger("votes") != null ? doc.getInteger("votes") : 0);
      data.setFluctuationEnabled(doc.getBoolean("fluctuationEnabled") != null ? doc.getBoolean("fluctuationEnabled") : true);
      data.setLastSeen(doc.getLong("lastSeen") != null ? doc.getLong("lastSeen") : System.currentTimeMillis());
      data.setTotalPlayTime(doc.getLong("totalPlayTime") != null ? doc.getLong("totalPlayTime") : 0L);
      return data;
   }
}
