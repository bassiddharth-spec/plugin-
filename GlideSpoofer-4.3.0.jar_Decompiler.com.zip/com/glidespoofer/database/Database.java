package com.glidespoofer.database;

import java.util.List;
import java.util.Map;

public interface Database {
   boolean initialize();

   void shutdown();

   boolean isConnected();

   DatabaseType getType();

   void createTables();

   void saveFakePlayer(FakePlayerData var1);

   FakePlayerData loadFakePlayer(String var1);

   void deleteFakePlayer(String var1);

   List<FakePlayerData> getAllFakePlayers();

   void saveVotes(String var1, int var2);

   int loadVotes(String var1);

   void savePlayerStats(PlayerStats var1);

   PlayerStats loadPlayerStats(String var1);

   Map<String, Object> executeQuery(String var1);

   boolean executeUpdate(String var1);
}
