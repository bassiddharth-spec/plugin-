package com.glidespoofer.database;

import com.glidespoofer.core.GlideSpoofer;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import org.bukkit.configuration.ConfigurationSection;

public class SQLiteDatabase implements Database {
   private final GlideSpoofer plugin;
   private final ConfigurationSection config;
   private Connection connection;
   private final String filePath;
   private boolean connected;

   public SQLiteDatabase(GlideSpoofer plugin, ConfigurationSection config) {
      this.plugin = plugin;
      this.config = config;
      String var10001 = plugin.getDataFolder().getAbsolutePath();
      this.filePath = var10001 + File.separator + config.getConfigurationSection("sqlite").getString("file", "database.db");
      this.connected = false;
   }

   public boolean initialize() {
      try {
         Class.forName("org.sqlite.JDBC");
         String url = "jdbc:sqlite:" + this.filePath;
         this.connection = DriverManager.getConnection(url);
         this.connected = true;
         this.plugin.getLogger().info("SQLite database created at: " + this.filePath);
         this.createTables();
         return true;
      } catch (ClassNotFoundException var2) {
         this.plugin.getLogger().severe("SQLite JDBC driver not found! Make sure the plugin is built correctly.");
         return false;
      } catch (SQLException var3) {
         this.plugin.getLogger().log(Level.SEVERE, "Failed to connect to SQLite database: " + var3.getMessage(), var3);
         return false;
      }
   }

   public void shutdown() {
      try {
         if (this.connection != null && !this.connection.isClosed()) {
            this.connection.close();
         }
      } catch (SQLException var2) {
         this.plugin.getLogger().log(Level.WARNING, "Error closing SQLite connection: " + var2.getMessage(), var2);
      }

      this.connected = false;
   }

   public boolean isConnected() {
      try {
         return this.connected && this.connection != null && !this.connection.isClosed();
      } catch (SQLException var2) {
         return false;
      }
   }

   public DatabaseType getType() {
      return DatabaseType.SQLITE;
   }

   public void createTables() {
      try {
         Statement stmt = this.connection.createStatement();

         try {
            stmt.execute("CREATE TABLE IF NOT EXISTS fake_players (name TEXT PRIMARY KEY,uuid TEXT NOT NULL,skin_name TEXT,rank TEXT DEFAULT 'default',visible_in_tab INTEGER DEFAULT 1,visible_in_ping INTEGER DEFAULT 1,visible_in_world INTEGER DEFAULT 1,world TEXT,x REAL,y REAL,z REAL,yaw REAL,pitch REAL,votes INTEGER DEFAULT 0,fluctuation_enabled INTEGER DEFAULT 1,last_seen INTEGER,total_play_time INTEGER DEFAULT 0)");
            stmt.execute("CREATE TABLE IF NOT EXISTS fake_votes (player_name TEXT PRIMARY KEY,votes INTEGER DEFAULT 0,last_updated INTEGER)");
            stmt.execute("CREATE TABLE IF NOT EXISTS player_stats (player_name TEXT PRIMARY KEY,total_play_time INTEGER DEFAULT 0,times_joined INTEGER DEFAULT 0,times_left INTEGER DEFAULT 0,last_join_time INTEGER,last_leave_time INTEGER,messages_sent INTEGER DEFAULT 0,commands_executed INTEGER DEFAULT 0)");
            stmt.execute("CREATE TABLE IF NOT EXISTS chat_history (id INTEGER PRIMARY KEY AUTOINCREMENT,player_name TEXT,message TEXT,timestamp INTEGER,is_fake INTEGER DEFAULT 1)");
            this.plugin.getLogger().info("SQLite tables created successfully.");
         } catch (Throwable var5) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var4) {
                  var5.addSuppressed(var4);
               }
            }

            throw var5;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException var6) {
         this.plugin.getLogger().log(Level.SEVERE, "Error creating tables: " + var6.getMessage(), var6);
      }

   }

   public void saveFakePlayer(FakePlayerData player) {
      try {
         PreparedStatement stmt = this.connection.prepareStatement("INSERT OR REPLACE INTO fake_players (name, uuid, skin_name, rank, visible_in_tab, visible_in_ping, visible_in_world,world, x, y, z, yaw, pitch, votes, fluctuation_enabled, last_seen, total_play_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

         try {
            stmt.setString(1, player.getName());
            stmt.setString(2, player.getUuid().toString());
            stmt.setString(3, player.getSkinName());
            stmt.setString(4, player.getRank());
            stmt.setInt(5, player.isVisibleInTab() ? 1 : 0);
            stmt.setInt(6, player.isVisibleInPing() ? 1 : 0);
            stmt.setInt(7, player.isVisibleInWorld() ? 1 : 0);
            if (player.getSpawnLocation() != null) {
               stmt.setString(8, player.getSpawnLocation().getWorld().getName());
               stmt.setDouble(9, player.getSpawnLocation().getX());
               stmt.setDouble(10, player.getSpawnLocation().getY());
               stmt.setDouble(11, player.getSpawnLocation().getZ());
               stmt.setDouble(12, (double)player.getSpawnLocation().getYaw());
               stmt.setDouble(13, (double)player.getSpawnLocation().getPitch());
            } else {
               stmt.setNull(8, 12);
               stmt.setNull(9, 8);
               stmt.setNull(10, 8);
               stmt.setNull(11, 8);
               stmt.setNull(12, 8);
               stmt.setNull(13, 8);
            }

            stmt.setInt(14, player.getVotes());
            stmt.setInt(15, player.isFluctuationEnabled() ? 1 : 0);
            stmt.setLong(16, player.getLastSeen());
            stmt.setLong(17, player.getTotalPlayTime());
            stmt.executeUpdate();
         } catch (Throwable var6) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException var7) {
         this.plugin.getLogger().log(Level.WARNING, "Error saving fake player: " + var7.getMessage(), var7);
      }

   }

   public FakePlayerData loadFakePlayer(String name) {
      try {
         PreparedStatement stmt = this.connection.prepareStatement("SELECT * FROM fake_players WHERE name = ?");

         FakePlayerData var4;
         try {
            stmt.setString(1, name);
            ResultSet rs = stmt.executeQuery();
            var4 = rs.next() ? this.mapRowToFakePlayer(rs) : null;
         } catch (Throwable var6) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (stmt != null) {
            stmt.close();
         }

         return var4;
      } catch (SQLException var7) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading fake player: " + var7.getMessage(), var7);
         return null;
      }
   }

   public void deleteFakePlayer(String name) {
      try {
         PreparedStatement stmt = this.connection.prepareStatement("DELETE FROM fake_players WHERE name = ?");

         try {
            stmt.setString(1, name);
            stmt.executeUpdate();
         } catch (Throwable var6) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException var7) {
         this.plugin.getLogger().log(Level.WARNING, "Error deleting fake player: " + var7.getMessage(), var7);
      }

   }

   public List<FakePlayerData> getAllFakePlayers() {
      List<FakePlayerData> players = new ArrayList();

      try {
         Statement stmt = this.connection.createStatement();

         try {
            ResultSet rs = stmt.executeQuery("SELECT * FROM fake_players");

            try {
               while(rs.next()) {
                  players.add(this.mapRowToFakePlayer(rs));
               }
            } catch (Throwable var8) {
               if (rs != null) {
                  try {
                     rs.close();
                  } catch (Throwable var7) {
                     var8.addSuppressed(var7);
                  }
               }

               throw var8;
            }

            if (rs != null) {
               rs.close();
            }
         } catch (Throwable var9) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var6) {
                  var9.addSuppressed(var6);
               }
            }

            throw var9;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException var10) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading fake players: " + var10.getMessage(), var10);
      }

      return players;
   }

   public void saveVotes(String playerName, int votes) {
      try {
         PreparedStatement stmt = this.connection.prepareStatement("INSERT OR REPLACE INTO fake_votes (player_name, votes, last_updated) VALUES (?, ?, ?)");

         try {
            stmt.setString(1, playerName);
            stmt.setInt(2, votes);
            stmt.setLong(3, System.currentTimeMillis());
            stmt.executeUpdate();
         } catch (Throwable var7) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException var8) {
         this.plugin.getLogger().log(Level.WARNING, "Error saving votes: " + var8.getMessage(), var8);
      }

   }

   public int loadVotes(String playerName) {
      try {
         PreparedStatement stmt = this.connection.prepareStatement("SELECT votes FROM fake_votes WHERE player_name = ?");

         int var4;
         try {
            stmt.setString(1, playerName);
            ResultSet rs = stmt.executeQuery();
            var4 = rs.next() ? rs.getInt("votes") : 0;
         } catch (Throwable var6) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (stmt != null) {
            stmt.close();
         }

         return var4;
      } catch (SQLException var7) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading votes: " + var7.getMessage(), var7);
         return 0;
      }
   }

   public void savePlayerStats(PlayerStats stats) {
      try {
         PreparedStatement stmt = this.connection.prepareStatement("INSERT OR REPLACE INTO player_stats (player_name, total_play_time, times_joined, times_left,last_join_time, last_leave_time, messages_sent, commands_executed) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

         try {
            stmt.setString(1, stats.getPlayerName());
            stmt.setLong(2, stats.getTotalPlayTime());
            stmt.setInt(3, stats.getTimesJoined());
            stmt.setInt(4, stats.getTimesLeft());
            stmt.setLong(5, stats.getLastJoinTime());
            stmt.setLong(6, stats.getLastLeaveTime());
            stmt.setInt(7, stats.getMessagesSent());
            stmt.setInt(8, stats.getCommandsExecuted());
            stmt.executeUpdate();
         } catch (Throwable var6) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException var7) {
         this.plugin.getLogger().log(Level.WARNING, "Error saving player stats: " + var7.getMessage(), var7);
      }

   }

   public PlayerStats loadPlayerStats(String playerName) {
      try {
         PreparedStatement stmt = this.connection.prepareStatement("SELECT * FROM player_stats WHERE player_name = ?");

         PlayerStats var13;
         label84: {
            Object stats;
            try {
               stmt.setString(1, playerName);
               ResultSet rs = stmt.executeQuery();
               if (rs.next()) {
                  PlayerStats stats = new PlayerStats(playerName);
                  stats.setTotalPlayTime(rs.getLong("total_play_time"));

                  for(int i = 0; i < rs.getInt("times_joined"); ++i) {
                     stats.incrementTimesJoined();
                  }

                  for(int i = 0; i < rs.getInt("times_left"); ++i) {
                     stats.incrementTimesLeft();
                  }

                  stats.setLastJoinTime(rs.getLong("last_join_time"));
                  stats.setLastLeaveTime(rs.getLong("last_leave_time"));

                  for(int i = 0; i < rs.getInt("messages_sent"); ++i) {
                     stats.incrementMessagesSent();
                  }

                  for(int i = 0; i < rs.getInt("commands_executed"); ++i) {
                     stats.incrementCommandsExecuted();
                  }

                  var13 = stats;
                  break label84;
               }

               stats = null;
            } catch (Throwable var7) {
               if (stmt != null) {
                  try {
                     stmt.close();
                  } catch (Throwable var6) {
                     var7.addSuppressed(var6);
                  }
               }

               throw var7;
            }

            if (stmt != null) {
               stmt.close();
            }

            return (PlayerStats)stats;
         }

         if (stmt != null) {
            stmt.close();
         }

         return var13;
      } catch (SQLException var8) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading player stats: " + var8.getMessage(), var8);
         return null;
      }
   }

   public Map<String, Object> executeQuery(String query) {
      try {
         Statement stmt = this.connection.createStatement();

         Object var13;
         try {
            ResultSet rs = stmt.executeQuery(query);

            try {
               ResultSetMetaData metaData = rs.getMetaData();
               int columnCount = metaData.getColumnCount();
               Map<String, Object> result = new HashMap();
               if (rs.next()) {
                  for(int i = 1; i <= columnCount; ++i) {
                     result.put(metaData.getColumnName(i), rs.getObject(i));
                  }
               }

               var13 = result;
            } catch (Throwable var11) {
               if (rs != null) {
                  try {
                     rs.close();
                  } catch (Throwable var10) {
                     var11.addSuppressed(var10);
                  }
               }

               throw var11;
            }

            if (rs != null) {
               rs.close();
            }
         } catch (Throwable var121) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var9) {
                  var121.addSuppressed(var9);
               }
            }

            throw var121;
         }

         if (stmt != null) {
            stmt.close();
         }

         return (Map)var13;
      } catch (SQLException var12) {
         this.plugin.getLogger().log(Level.WARNING, "Error executing query: " + var12.getMessage(), var12);
         return Map.of();
      }
   }

   public boolean executeUpdate(String query) {
      try {
         Statement stmt = this.connection.createStatement();

         boolean var3;
         try {
            stmt.executeUpdate(query);
            var3 = true;
         } catch (Throwable var71) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var6) {
                  var71.addSuppressed(var6);
               }
            }

            throw var71;
         }

         if (stmt != null) {
            stmt.close();
         }

         return var3;
      } catch (SQLException var7) {
         this.plugin.getLogger().log(Level.WARNING, "Error executing update: " + var7.getMessage(), var7);
         return false;
      }
   }

   private FakePlayerData mapRowToFakePlayer(ResultSet rs) throws SQLException {
      String name = rs.getString("name");
      UUID uuid = UUID.fromString(rs.getString("uuid"));
      FakePlayerData data = new FakePlayerData(name, uuid);
      data.setSkinName(rs.getString("skin_name"));
      data.setRank(rs.getString("rank"));
      data.setVisibleInTab(rs.getInt("visible_in_tab") == 1);
      data.setVisibleInPing(rs.getInt("visible_in_ping") == 1);
      data.setVisibleInWorld(rs.getInt("visible_in_world") == 1);
      data.setVotes(rs.getInt("votes"));
      data.setFluctuationEnabled(rs.getInt("fluctuation_enabled") == 1);
      data.setLastSeen(rs.getLong("last_seen"));
      data.setTotalPlayTime(rs.getLong("total_play_time"));
      return data;
   }
}
