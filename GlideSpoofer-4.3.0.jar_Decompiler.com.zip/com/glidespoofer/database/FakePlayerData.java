package com.glidespoofer.database;

import java.util.UUID;
import org.bukkit.Location;

public class FakePlayerData {
   private final String name;
   private final UUID uuid;
   private String skinName;
   private String rank;
   private boolean visibleInTab;
   private boolean visibleInPing;
   private boolean visibleInWorld;
   private Location spawnLocation;
   private int votes;
   private boolean fluctuationEnabled;
   private long lastSeen;
   private long totalPlayTime;
   private String aiPersonality;

   public FakePlayerData(String name, UUID uuid) {
      this.name = name;
      this.uuid = uuid;
      this.skinName = name;
      this.rank = "default";
      this.visibleInTab = true;
      this.visibleInPing = true;
      this.visibleInWorld = true;
      this.votes = 0;
      this.fluctuationEnabled = true;
      this.lastSeen = System.currentTimeMillis();
      this.totalPlayTime = 0L;
   }

   public String getName() {
      return this.name;
   }

   public UUID getUuid() {
      return this.uuid;
   }

   public String getSkinName() {
      return this.skinName;
   }

   public void setSkinName(String skinName) {
      this.skinName = skinName;
   }

   public String getRank() {
      return this.rank;
   }

   public void setRank(String rank) {
      this.rank = rank;
   }

   public boolean isVisibleInTab() {
      return this.visibleInTab;
   }

   public void setVisibleInTab(boolean visibleInTab) {
      this.visibleInTab = visibleInTab;
   }

   public boolean isVisibleInPing() {
      return this.visibleInPing;
   }

   public void setVisibleInPing(boolean visibleInPing) {
      this.visibleInPing = visibleInPing;
   }

   public boolean isVisibleInWorld() {
      return this.visibleInWorld;
   }

   public void setVisibleInWorld(boolean visibleInWorld) {
      this.visibleInWorld = visibleInWorld;
   }

   public Location getSpawnLocation() {
      return this.spawnLocation;
   }

   public void setSpawnLocation(Location spawnLocation) {
      this.spawnLocation = spawnLocation;
   }

   public int getVotes() {
      return this.votes;
   }

   public void setVotes(int votes) {
      this.votes = votes;
   }

   public boolean isFluctuationEnabled() {
      return this.fluctuationEnabled;
   }

   public void setFluctuationEnabled(boolean fluctuationEnabled) {
      this.fluctuationEnabled = fluctuationEnabled;
   }

   public long getLastSeen() {
      return this.lastSeen;
   }

   public void setLastSeen(long lastSeen) {
      this.lastSeen = lastSeen;
   }

   public long getTotalPlayTime() {
      return this.totalPlayTime;
   }

   public void setTotalPlayTime(long totalPlayTime) {
      this.totalPlayTime = totalPlayTime;
   }

   public void addPlayTime(long time) {
      this.totalPlayTime += time;
   }

   public String getAiPersonality() {
      return this.aiPersonality;
   }

   public void setAiPersonality(String aiPersonality) {
      this.aiPersonality = aiPersonality;
   }
}
