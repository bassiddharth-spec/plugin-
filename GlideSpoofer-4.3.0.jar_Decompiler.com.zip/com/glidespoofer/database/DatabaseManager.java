package com.glidespoofer.database;

import com.glidespoofer.config.ConfigManager;
import com.glidespoofer.core.GlideSpoofer;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import org.bukkit.configuration.ConfigurationSection;

public class DatabaseManager {
   private final GlideSpoofer plugin;
   private final ConfigManager config;
   private Database database;
   private boolean enabled;

   public DatabaseManager(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.config = plugin.getConfigManager();
      this.enabled = false;
   }

   public boolean initialize() {
      ConfigurationSection dbConfig = this.config.getConfig().getConfigurationSection("database");
      if (dbConfig == null) {
         this.plugin.getLogger().warning("Database configuration not found!");
         return false;
      } else {
         this.enabled = dbConfig.getBoolean("enabled", false);
         if (!this.enabled) {
            this.plugin.getLogger().info("Database storage is disabled.");
            return false;
         } else {
            String typeStr = dbConfig.getString("type", "SQLITE").toUpperCase();
            DatabaseType type = DatabaseType.fromString(typeStr);
            this.plugin.getLogger().info("Initializing database: " + String.valueOf(type) + "...");

            try {
               switch (type) {
                  case SQLITE -> this.database = new SQLiteDatabase(this.plugin, dbConfig);
                  case MYSQL -> this.database = new MySQLDatabase(this.plugin, dbConfig);
                  case MONGODB -> this.database = new MongoDBDatabase(this.plugin, dbConfig);
                  case REDIS -> this.database = new RedisDatabase(this.plugin, dbConfig);
                  default -> this.database = new SQLiteDatabase(this.plugin, dbConfig);
               }

               if (this.database.initialize()) {
                  this.plugin.getLogger().info("Database connected successfully: " + String.valueOf(type));
                  return true;
               } else {
                  this.plugin.getLogger().severe("Failed to connect to database: " + String.valueOf(type));
                  this.database = null;
                  return false;
               }
            } catch (Exception var5) {
               this.plugin.getLogger().log(Level.SEVERE, "Error initializing database: " + var5.getMessage(), var5);
               this.database = null;
               return false;
            }
         }
      }
   }

   public void shutdown() {
      if (this.database != null) {
         this.database.shutdown();
         this.database = null;
      }

   }

   public boolean isEnabled() {
      return this.enabled && this.database != null && this.database.isConnected();
   }

   public Database getDatabase() {
      return this.database;
   }

   public void saveFakePlayer(FakePlayerData player) {
      if (this.isEnabled()) {
         try {
            this.database.saveFakePlayer(player);
         } catch (Exception var3) {
            this.plugin.getLogger().log(Level.WARNING, "Error saving fake player: " + var3.getMessage(), var3);
         }
      }

   }

   public FakePlayerData loadFakePlayer(String name) {
      if (!this.isEnabled()) {
         return null;
      } else {
         try {
            return this.database.loadFakePlayer(name);
         } catch (Exception var3) {
            this.plugin.getLogger().log(Level.WARNING, "Error loading fake player: " + var3.getMessage(), var3);
            return null;
         }
      }
   }

   public List<FakePlayerData> getAllFakePlayers() {
      if (!this.isEnabled()) {
         return List.of();
      } else {
         try {
            return this.database.getAllFakePlayers();
         } catch (Exception var2) {
            this.plugin.getLogger().log(Level.WARNING, "Error loading fake players: " + var2.getMessage(), var2);
            return List.of();
         }
      }
   }

   public void saveVotes(String playerName, int votes) {
      if (this.isEnabled()) {
         try {
            this.database.saveVotes(playerName, votes);
         } catch (Exception var4) {
            this.plugin.getLogger().log(Level.WARNING, "Error saving votes: " + var4.getMessage(), var4);
         }
      }

   }

   public int loadVotes(String playerName) {
      if (!this.isEnabled()) {
         return 0;
      } else {
         try {
            return this.database.loadVotes(playerName);
         } catch (Exception var3) {
            this.plugin.getLogger().log(Level.WARNING, "Error loading votes: " + var3.getMessage(), var3);
            return 0;
         }
      }
   }

   public void savePlayerStats(PlayerStats stats) {
      if (this.isEnabled()) {
         try {
            this.database.savePlayerStats(stats);
         } catch (Exception var3) {
            this.plugin.getLogger().log(Level.WARNING, "Error saving player stats: " + var3.getMessage(), var3);
         }
      }

   }

   public PlayerStats loadPlayerStats(String playerName) {
      if (!this.isEnabled()) {
         return null;
      } else {
         try {
            return this.database.loadPlayerStats(playerName);
         } catch (Exception var3) {
            this.plugin.getLogger().log(Level.WARNING, "Error loading player stats: " + var3.getMessage(), var3);
            return null;
         }
      }
   }

   public Map<String, Object> executeQuery(String query) {
      if (!this.isEnabled()) {
         return Map.of();
      } else {
         try {
            return this.database.executeQuery(query);
         } catch (Exception var3) {
            this.plugin.getLogger().log(Level.WARNING, "Error executing query: " + var3.getMessage(), var3);
            return Map.of();
         }
      }
   }

   public boolean executeUpdate(String query) {
      if (!this.isEnabled()) {
         return false;
      } else {
         try {
            return this.database.executeUpdate(query);
         } catch (Exception var3) {
            this.plugin.getLogger().log(Level.WARNING, "Error executing update: " + var3.getMessage(), var3);
            return false;
         }
      }
   }

   public boolean reload() {
      this.shutdown();
      return this.initialize();
   }
}
