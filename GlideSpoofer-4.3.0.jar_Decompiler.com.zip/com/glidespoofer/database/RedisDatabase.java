package com.glidespoofer.database;

import com.glidespoofer.core.GlideSpoofer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import org.bukkit.configuration.ConfigurationSection;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisPubSub;

public class RedisDatabase implements Database {
   private final GlideSpoofer plugin;
   private final ConfigurationSection config;
   private JedisPool jedisPool;
   private boolean connected;
   private static final String PREFIX = "glidespoofer:";

   public RedisDatabase(GlideSpoofer plugin, ConfigurationSection config) {
      this.plugin = plugin;
      this.config = config;
      this.connected = false;
   }

   public boolean initialize() {
      try {
         ConfigurationSection redisConfig = this.config.getConfigurationSection("redis");
         if (redisConfig == null) {
            this.plugin.getLogger().severe("Redis configuration not found!");
            return false;
         } else {
            String host = redisConfig.getString("host", "localhost");
            int port = redisConfig.getInt("port", 6379);
            String password = redisConfig.getString("password", "");
            int database = redisConfig.getInt("database", 0);
            JedisPoolConfig poolConfig = new JedisPoolConfig();
            poolConfig.setMaxTotal(10);
            poolConfig.setMaxIdle(5);
            poolConfig.setMinIdle(1);
            poolConfig.setTestOnBorrow(true);
            poolConfig.setTestWhileIdle(true);
            poolConfig.setTestOnReturn(false);
            poolConfig.setBlockWhenExhausted(false);
            poolConfig.setMaxWaitMillis(3000L);
            if (!password.isEmpty()) {
               this.jedisPool = new JedisPool(poolConfig, host, port, 2000, password, database);
            } else {
               this.jedisPool = new JedisPool(poolConfig, host, port, database);
            }

            Jedis jedis = this.jedisPool.getResource();

            try {
               jedis.ping();
            } catch (Throwable var11) {
               if (jedis != null) {
                  try {
                     jedis.close();
                  } catch (Throwable var10) {
                     var11.addSuppressed(var10);
                  }
               }

               throw var11;
            }

            if (jedis != null) {
               jedis.close();
            }

            this.connected = true;
            this.plugin.getLogger().info("Redis connected successfully: " + host + ":" + port);
            return true;
         }
      } catch (Exception var12) {
         this.plugin.getLogger().log(Level.SEVERE, "Failed to connect to Redis: " + var12.getMessage(), var12);
         return false;
      }
   }

   public void shutdown() {
      if (this.jedisPool != null) {
         this.jedisPool.close();
      }

      this.connected = false;
   }

   public boolean isConnected() {
      return this.connected && this.jedisPool != null && !this.jedisPool.isClosed();
   }

   public DatabaseType getType() {
      return DatabaseType.REDIS;
   }

   public void createTables() {
      this.plugin.getLogger().info("Redis initialized successfully.");
   }

   public void saveFakePlayer(FakePlayerData player) {
      try {
         Jedis jedis = this.jedisPool.getResource();

         try {
            String key = "glidespoofer:fake_player:" + player.getName();
            Map<String, String> data = Map.ofEntries(Map.entry("uuid", player.getUuid().toString()), Map.entry("skinName", player.getSkinName()), Map.entry("rank", player.getRank()), Map.entry("visibleInTab", String.valueOf(player.isVisibleInTab())), Map.entry("visibleInPing", String.valueOf(player.isVisibleInPing())), Map.entry("visibleInWorld", String.valueOf(player.isVisibleInWorld())), Map.entry("votes", String.valueOf(player.getVotes())), Map.entry("fluctuationEnabled", String.valueOf(player.isFluctuationEnabled())), Map.entry("lastSeen", String.valueOf(player.getLastSeen())), Map.entry("totalPlayTime", String.valueOf(player.getTotalPlayTime())));
            if (player.getSpawnLocation() != null) {
               data = new HashMap(data);
               data.put("world", player.getSpawnLocation().getWorld().getName());
               data.put("x", String.valueOf(player.getSpawnLocation().getX()));
               data.put("y", String.valueOf(player.getSpawnLocation().getY()));
               data.put("z", String.valueOf(player.getSpawnLocation().getZ()));
               data.put("yaw", String.valueOf(player.getSpawnLocation().getYaw()));
               data.put("pitch", String.valueOf(player.getSpawnLocation().getPitch()));
            }

            jedis.hmset(key, data);
            jedis.sadd("glidespoofer:fake_players_set", player.getName());
         } catch (Throwable var6) {
            if (jedis != null) {
               try {
                  jedis.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (jedis != null) {
            jedis.close();
         }
      } catch (Exception var7) {
         this.plugin.getLogger().log(Level.WARNING, "Error saving fake player: " + var7.getMessage(), var7);
      }

   }

   public FakePlayerData loadFakePlayer(String name) {
      try {
         Jedis jedis = this.jedisPool.getResource();

         FakePlayerData var5;
         try {
            String key = "glidespoofer:fake_player:" + name;
            Map<String, String> data = jedis.hgetAll(key);
            var5 = !data.isEmpty() ? this.mapMapToFakePlayer(name, data) : null;
         } catch (Throwable var7) {
            if (jedis != null) {
               try {
                  jedis.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (jedis != null) {
            jedis.close();
         }

         return var5;
      } catch (Exception var8) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading fake player: " + var8.getMessage(), var8);
         return null;
      }
   }

   public void deleteFakePlayer(String name) {
      try {
         Jedis jedis = this.jedisPool.getResource();

         try {
            jedis.del("glidespoofer:fake_player:" + name);
            jedis.srem("glidespoofer:fake_players_set", name);
         } catch (Throwable var6) {
            if (jedis != null) {
               try {
                  jedis.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (jedis != null) {
            jedis.close();
         }
      } catch (Exception var7) {
         this.plugin.getLogger().log(Level.WARNING, "Error deleting fake player: " + var7.getMessage(), var7);
      }

   }

   public List<FakePlayerData> getAllFakePlayers() {
      List<FakePlayerData> players = new ArrayList();

      try {
         Jedis jedis = this.jedisPool.getResource();

         try {
            for(String name : jedis.smembers("glidespoofer:fake_players_set")) {
               FakePlayerData player = this.loadFakePlayer(name);
               if (player != null) {
                  players.add(player);
               }
            }
         } catch (Throwable var7) {
            if (jedis != null) {
               try {
                  jedis.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (jedis != null) {
            jedis.close();
         }
      } catch (Exception var9) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading fake players: " + var9.getMessage(), var9);
      }

      return players;
   }

   public void saveVotes(String playerName, int votes) {
      try {
         Jedis jedis = this.jedisPool.getResource();

         try {
            String key = "glidespoofer:votes:" + playerName;
            jedis.set(key, String.valueOf(votes));
            jedis.set(key + ":updated", String.valueOf(System.currentTimeMillis()));
         } catch (Throwable var7) {
            if (jedis != null) {
               try {
                  jedis.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (jedis != null) {
            jedis.close();
         }
      } catch (Exception var8) {
         this.plugin.getLogger().log(Level.WARNING, "Error saving votes: " + var8.getMessage(), var8);
      }

   }

   public int loadVotes(String playerName) {
      try {
         Jedis jedis = this.jedisPool.getResource();

         int var4;
         try {
            String value = jedis.get("glidespoofer:votes:" + playerName);
            var4 = value != null ? Integer.parseInt(value) : 0;
         } catch (Throwable var6) {
            if (jedis != null) {
               try {
                  jedis.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (jedis != null) {
            jedis.close();
         }

         return var4;
      } catch (Exception var7) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading votes: " + var7.getMessage(), var7);
         return 0;
      }
   }

   public void savePlayerStats(PlayerStats stats) {
      try {
         Jedis jedis = this.jedisPool.getResource();

         try {
            String key = "glidespoofer:stats:" + stats.getPlayerName();
            Map<String, String> data = Map.ofEntries(Map.entry("totalPlayTime", String.valueOf(stats.getTotalPlayTime())), Map.entry("timesJoined", String.valueOf(stats.getTimesJoined())), Map.entry("timesLeft", String.valueOf(stats.getTimesLeft())), Map.entry("lastJoinTime", String.valueOf(stats.getLastJoinTime())), Map.entry("lastLeaveTime", String.valueOf(stats.getLastLeaveTime())), Map.entry("messagesSent", String.valueOf(stats.getMessagesSent())), Map.entry("commandsExecuted", String.valueOf(stats.getCommandsExecuted())), Map.entry("updatedAt", String.valueOf(System.currentTimeMillis())));
            jedis.hmset(key, data);
         } catch (Throwable var6) {
            if (jedis != null) {
               try {
                  jedis.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (jedis != null) {
            jedis.close();
         }
      } catch (Exception var7) {
         this.plugin.getLogger().log(Level.WARNING, "Error saving player stats: " + var7.getMessage(), var7);
      }

   }

   public PlayerStats loadPlayerStats(String playerName) {
      try {
         Jedis jedis = this.jedisPool.getResource();

         PlayerStats var14;
         label84: {
            Object stats;
            try {
               String key = "glidespoofer:stats:" + playerName;
               Map<String, String> data = jedis.hgetAll(key);
               if (!data.isEmpty()) {
                  PlayerStats stats = new PlayerStats(playerName);
                  stats.setTotalPlayTime(this.parseLong((String)data.get("totalPlayTime")));

                  for(int i = 0; i < this.parseInt((String)data.get("timesJoined")); ++i) {
                     stats.incrementTimesJoined();
                  }

                  for(int i = 0; i < this.parseInt((String)data.get("timesLeft")); ++i) {
                     stats.incrementTimesLeft();
                  }

                  stats.setLastJoinTime(this.parseLong((String)data.get("lastJoinTime")));
                  stats.setLastLeaveTime(this.parseLong((String)data.get("lastLeaveTime")));

                  for(int i = 0; i < this.parseInt((String)data.get("messagesSent")); ++i) {
                     stats.incrementMessagesSent();
                  }

                  for(int i = 0; i < this.parseInt((String)data.get("commandsExecuted")); ++i) {
                     stats.incrementCommandsExecuted();
                  }

                  var14 = stats;
                  break label84;
               }

               stats = null;
            } catch (Throwable var8) {
               if (jedis != null) {
                  try {
                     jedis.close();
                  } catch (Throwable var7) {
                     var8.addSuppressed(var7);
                  }
               }

               throw var8;
            }

            if (jedis != null) {
               jedis.close();
            }

            return (PlayerStats)stats;
         }

         if (jedis != null) {
            jedis.close();
         }

         return var14;
      } catch (Exception var9) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading player stats: " + var9.getMessage(), var9);
         return null;
      }
   }

   public Map<String, Object> executeQuery(String query) {
      this.plugin.getLogger().warning("Raw Redis queries are not supported. Use the native API.");
      return Map.of();
   }

   public boolean executeUpdate(String query) {
      this.plugin.getLogger().warning("Raw Redis updates are not supported. Use the native API.");
      return false;
   }

   public void publish(String channel, String message) {
      try {
         Jedis jedis = this.jedisPool.getResource();

         try {
            jedis.publish("glidespoofer:" + channel, message);
         } catch (Throwable var7) {
            if (jedis != null) {
               try {
                  jedis.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (jedis != null) {
            jedis.close();
         }
      } catch (Exception var8) {
         this.plugin.getLogger().log(Level.WARNING, "Error publishing message: " + var8.getMessage(), var8);
      }

   }

   public void subscribe(String channel, JedisPubSub callback) {
      try {
         Jedis jedis = this.jedisPool.getResource();

         try {
            jedis.subscribe(callback, "glidespoofer:" + channel);
         } catch (Throwable var7) {
            if (jedis != null) {
               try {
                  jedis.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (jedis != null) {
            jedis.close();
         }
      } catch (Exception var8) {
         this.plugin.getLogger().log(Level.WARNING, "Error subscribing to channel: " + var8.getMessage(), var8);
      }

   }

   public void setEx(String key, String value, int seconds) {
      try {
         Jedis jedis = this.jedisPool.getResource();

         try {
            jedis.setex("glidespoofer:" + key, (long)seconds, value);
         } catch (Throwable var8) {
            if (jedis != null) {
               try {
                  jedis.close();
               } catch (Throwable var7) {
                  var8.addSuppressed(var7);
               }
            }

            throw var8;
         }

         if (jedis != null) {
            jedis.close();
         }
      } catch (Exception var9) {
         this.plugin.getLogger().log(Level.WARNING, "Error setting value: " + var9.getMessage(), var9);
      }

   }

   public String get(String key) {
      try {
         Jedis jedis = this.jedisPool.getResource();

         String var3;
         try {
            var3 = jedis.get("glidespoofer:" + key);
         } catch (Throwable var71) {
            if (jedis != null) {
               try {
                  jedis.close();
               } catch (Throwable var6) {
                  var71.addSuppressed(var6);
               }
            }

            throw var71;
         }

         if (jedis != null) {
            jedis.close();
         }

         return var3;
      } catch (Exception var7) {
         this.plugin.getLogger().log(Level.WARNING, "Error getting value: " + var7.getMessage(), var7);
         return null;
      }
   }

   private FakePlayerData mapMapToFakePlayer(String name, Map<String, String> data) {
      try {
         UUID uuid = UUID.fromString((String)data.get("uuid"));
         FakePlayerData player = new FakePlayerData(name, uuid);
         player.setSkinName((String)data.getOrDefault("skinName", name));
         player.setRank((String)data.getOrDefault("rank", "default"));
         player.setVisibleInTab(Boolean.parseBoolean((String)data.getOrDefault("visibleInTab", "true")));
         player.setVisibleInPing(Boolean.parseBoolean((String)data.getOrDefault("visibleInPing", "true")));
         player.setVisibleInWorld(Boolean.parseBoolean((String)data.getOrDefault("visibleInWorld", "true")));
         player.setVotes(this.parseInt((String)data.getOrDefault("votes", "0")));
         player.setFluctuationEnabled(Boolean.parseBoolean((String)data.getOrDefault("fluctuationEnabled", "true")));
         player.setLastSeen(this.parseLong((String)data.getOrDefault("lastSeen", String.valueOf(System.currentTimeMillis()))));
         player.setTotalPlayTime(this.parseLong((String)data.getOrDefault("totalPlayTime", "0")));
         return player;
      } catch (Exception var5) {
         this.plugin.getLogger().log(Level.WARNING, "Error mapping fake player data: " + var5.getMessage(), var5);
         return null;
      }
   }

   private long parseLong(String value) {
      try {
         return Long.parseLong(value);
      } catch (Exception var3) {
         return 0L;
      }
   }

   private int parseInt(String value) {
      try {
         return Integer.parseInt(value);
      } catch (Exception var3) {
         return 0;
      }
   }
}
