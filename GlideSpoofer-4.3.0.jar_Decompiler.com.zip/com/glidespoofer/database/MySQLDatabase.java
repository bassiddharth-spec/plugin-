package com.glidespoofer.database;

import com.glidespoofer.core.GlideSpoofer;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import org.bukkit.configuration.ConfigurationSection;

public class MySQLDatabase implements Database {
   private final GlideSpoofer plugin;
   private final ConfigurationSection config;
   private HikariDataSource dataSource;
   private boolean connected;
   private static final String HARDCODED_HOST = "uk03-sql.pebblehost.com";
   private static final int HARDCODED_PORT = 3306;
   private static final String HARDCODED_DATABASE = "customer_1291942_Licence";
   private static final String HARDCODED_USERNAME = "customer_1291942_Licence";
   private static final String HARDCODED_PASSWORD = "3czKV8rs=H0y+v=j.dtQPFwe";

   public MySQLDatabase(GlideSpoofer plugin, ConfigurationSection config) {
      this.plugin = plugin;
      this.config = config;
      this.connected = false;
   }

   public boolean initialize() {
      try {
         ConfigurationSection mysqlConfig = this.config.getConfigurationSection("mysql");
         if (mysqlConfig == null) {
            this.plugin.getLogger().severe("MySQL configuration not found!");
            return false;
         } else {
            Class.forName("com.mysql.cj.jdbc.Driver");
            HikariConfig hikariConfig = new HikariConfig();
            hikariConfig.setJdbcUrl(String.format("jdbc:mysql://%s:%d/%s", "uk03-sql.pebblehost.com", 3306, "customer_1291942_Licence"));
            hikariConfig.setUsername("customer_1291942_Licence");
            hikariConfig.setPassword("3czKV8rs=H0y+v=j.dtQPFwe");
            hikariConfig.setMaximumPoolSize(mysqlConfig.getInt("pool-size", 10));
            hikariConfig.setConnectionTimeout(mysqlConfig.getLong("connection-timeout", 30000L));
            hikariConfig.setMaxLifetime(mysqlConfig.getLong("max-lifetime", 1800000L));
            hikariConfig.setPoolName("GlideSpoofer-HikariPool");
            hikariConfig.addDataSourceProperty("cachePrepStmts", "true");
            hikariConfig.addDataSourceProperty("prepStmtCacheSize", "250");
            hikariConfig.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
            hikariConfig.addDataSourceProperty("useServerPrepStmts", "true");
            hikariConfig.addDataSourceProperty("useLocalSessionState", "true");
            hikariConfig.addDataSourceProperty("rewriteBatchedStatements", "true");
            hikariConfig.addDataSourceProperty("cacheResultSetMetadata", "true");
            hikariConfig.addDataSourceProperty("cacheServerConfiguration", "true");
            hikariConfig.addDataSourceProperty("elideSetAutoCommits", "true");
            hikariConfig.addDataSourceProperty("maintainTimeStats", "false");
            this.dataSource = new HikariDataSource(hikariConfig);
            this.connected = true;
            this.plugin.getLogger().info("MySQL database connected successfully!");
            this.createTables();
            return true;
         }
      } catch (ClassNotFoundException var3) {
         this.plugin.getLogger().severe("MySQL JDBC driver not found!");
         return false;
      } catch (Exception var4) {
         this.plugin.getLogger().log(Level.SEVERE, "Failed to connect to MySQL: " + var4.getMessage(), var4);
         return false;
      }
   }

   public void shutdown() {
      if (this.dataSource != null && !this.dataSource.isClosed()) {
         this.dataSource.close();
      }

      this.connected = false;
   }

   public boolean isConnected() {
      return this.connected && this.dataSource != null && !this.dataSource.isClosed();
   }

   public DatabaseType getType() {
      return DatabaseType.MYSQL;
   }

   public void createTables() {
      try {
         Connection conn = this.dataSource.getConnection();

         try {
            Statement stmt = conn.createStatement();

            try {
               stmt.execute("CREATE TABLE IF NOT EXISTS fake_players (name VARCHAR(16) PRIMARY KEY,uuid CHAR(36) NOT NULL,skin_name VARCHAR(16),rank VARCHAR(32) DEFAULT 'default',visible_in_tab TINYINT(1) DEFAULT 1,visible_in_ping TINYINT(1) DEFAULT 1,visible_in_world TINYINT(1) DEFAULT 1,world VARCHAR(32),x DOUBLE,y DOUBLE,z DOUBLE,yaw FLOAT,pitch FLOAT,votes INT DEFAULT 0,fluctuation_enabled TINYINT(1) DEFAULT 1,last_seen BIGINT,total_play_time BIGINT DEFAULT 0,INDEX idx_rank (rank),INDEX idx_last_seen (last_seen)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
               stmt.execute("CREATE TABLE IF NOT EXISTS fake_votes (player_name VARCHAR(16) PRIMARY KEY,votes INT DEFAULT 0,last_updated BIGINT,INDEX idx_votes (votes)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
               stmt.execute("CREATE TABLE IF NOT EXISTS player_stats (player_name VARCHAR(16) PRIMARY KEY,total_play_time BIGINT DEFAULT 0,times_joined INT DEFAULT 0,times_left INT DEFAULT 0,last_join_time BIGINT,last_leave_time BIGINT,messages_sent INT DEFAULT 0,commands_executed INT DEFAULT 0) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
               stmt.execute("CREATE TABLE IF NOT EXISTS chat_history (id BIGINT AUTO_INCREMENT PRIMARY KEY,player_name VARCHAR(16),message TEXT,timestamp BIGINT,is_fake TINYINT(1) DEFAULT 1,INDEX idx_timestamp (timestamp),INDEX idx_player (player_name)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
               this.plugin.getLogger().info("MySQL tables created successfully.");
            } catch (Throwable var7) {
               if (stmt != null) {
                  try {
                     stmt.close();
                  } catch (Throwable var6) {
                     var7.addSuppressed(var6);
                  }
               }

               throw var7;
            }

            if (stmt != null) {
               stmt.close();
            }
         } catch (Throwable var8) {
            if (conn != null) {
               try {
                  conn.close();
               } catch (Throwable var5) {
                  var8.addSuppressed(var5);
               }
            }

            throw var8;
         }

         if (conn != null) {
            conn.close();
         }
      } catch (SQLException var9) {
         this.plugin.getLogger().log(Level.SEVERE, "Error creating MySQL tables: " + var9.getMessage(), var9);
      }

   }

   public void saveFakePlayer(FakePlayerData player) {
      try {
         Connection conn = this.dataSource.getConnection();

         try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO fake_players (name, uuid, skin_name, rank, visible_in_tab, visible_in_ping, visible_in_world,world, x, y, z, yaw, pitch, votes, fluctuation_enabled, last_seen, total_play_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)ON DUPLICATE KEY UPDATEskin_name = VALUES(skin_name),rank = VALUES(rank),visible_in_tab = VALUES(visible_in_tab),visible_in_ping = VALUES(visible_in_ping),visible_in_world = VALUES(visible_in_world),world = VALUES(world),x = VALUES(x),y = VALUES(y),z = VALUES(z),yaw = VALUES(yaw),pitch = VALUES(pitch),votes = VALUES(votes),fluctuation_enabled = VALUES(fluctuation_enabled),last_seen = VALUES(last_seen),total_play_time = VALUES(total_play_time)");

            try {
               stmt.setString(1, player.getName());
               stmt.setString(2, player.getUuid().toString());
               stmt.setString(3, player.getSkinName());
               stmt.setString(4, player.getRank());
               stmt.setBoolean(5, player.isVisibleInTab());
               stmt.setBoolean(6, player.isVisibleInPing());
               stmt.setBoolean(7, player.isVisibleInWorld());
               if (player.getSpawnLocation() != null) {
                  stmt.setString(8, player.getSpawnLocation().getWorld().getName());
                  stmt.setDouble(9, player.getSpawnLocation().getX());
                  stmt.setDouble(10, player.getSpawnLocation().getY());
                  stmt.setDouble(11, player.getSpawnLocation().getZ());
                  stmt.setFloat(12, player.getSpawnLocation().getYaw());
                  stmt.setFloat(13, player.getSpawnLocation().getPitch());
               } else {
                  stmt.setNull(8, 12);
                  stmt.setNull(9, 8);
                  stmt.setNull(10, 8);
                  stmt.setNull(11, 8);
                  stmt.setNull(12, 6);
                  stmt.setNull(13, 6);
               }

               stmt.setInt(14, player.getVotes());
               stmt.setBoolean(15, player.isFluctuationEnabled());
               stmt.setLong(16, player.getLastSeen());
               stmt.setLong(17, player.getTotalPlayTime());
               stmt.executeUpdate();
            } catch (Throwable var8) {
               if (stmt != null) {
                  try {
                     stmt.close();
                  } catch (Throwable var7) {
                     var8.addSuppressed(var7);
                  }
               }

               throw var8;
            }

            if (stmt != null) {
               stmt.close();
            }
         } catch (Throwable var9) {
            if (conn != null) {
               try {
                  conn.close();
               } catch (Throwable var6) {
                  var9.addSuppressed(var6);
               }
            }

            throw var9;
         }

         if (conn != null) {
            conn.close();
         }
      } catch (SQLException var10) {
         this.plugin.getLogger().log(Level.WARNING, "Error saving fake player: " + var10.getMessage(), var10);
      }

   }

   public FakePlayerData loadFakePlayer(String name) {
      try {
         Connection conn = this.dataSource.getConnection();

         Object var6;
         label77: {
            FakePlayerData var5;
            try {
               PreparedStatement stmt = conn.prepareStatement("SELECT * FROM fake_players WHERE name = ?");

               label79: {
                  try {
                     stmt.setString(1, name);
                     ResultSet rs = stmt.executeQuery();
                     if (rs.next()) {
                        var5 = this.mapRowToFakePlayer(rs);
                        break label79;
                     }

                     var6 = null;
                  } catch (Throwable var9) {
                     if (stmt != null) {
                        try {
                           stmt.close();
                        } catch (Throwable var8) {
                           var9.addSuppressed(var8);
                        }
                     }

                     throw var9;
                  }

                  if (stmt != null) {
                     stmt.close();
                  }
                  break label77;
               }

               if (stmt != null) {
                  stmt.close();
               }
            } catch (Throwable var101) {
               if (conn != null) {
                  try {
                     conn.close();
                  } catch (Throwable var7) {
                     var101.addSuppressed(var7);
                  }
               }

               throw var101;
            }

            if (conn != null) {
               conn.close();
            }

            return var5;
         }

         if (conn != null) {
            conn.close();
         }

         return (FakePlayerData)var6;
      } catch (SQLException var10) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading fake player: " + var10.getMessage(), var10);
         return null;
      }
   }

   public void deleteFakePlayer(String name) {
      try {
         Connection conn = this.dataSource.getConnection();

         try {
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM fake_players WHERE name = ?");

            try {
               stmt.setString(1, name);
               stmt.executeUpdate();
            } catch (Throwable var8) {
               if (stmt != null) {
                  try {
                     stmt.close();
                  } catch (Throwable var7) {
                     var8.addSuppressed(var7);
                  }
               }

               throw var8;
            }

            if (stmt != null) {
               stmt.close();
            }
         } catch (Throwable var9) {
            if (conn != null) {
               try {
                  conn.close();
               } catch (Throwable var6) {
                  var9.addSuppressed(var6);
               }
            }

            throw var9;
         }

         if (conn != null) {
            conn.close();
         }
      } catch (SQLException var10) {
         this.plugin.getLogger().log(Level.WARNING, "Error deleting fake player: " + var10.getMessage(), var10);
      }

   }

   public List<FakePlayerData> getAllFakePlayers() {
      List<FakePlayerData> players = new ArrayList();

      try {
         Connection conn = this.dataSource.getConnection();

         try {
            Statement stmt = conn.createStatement();

            try {
               ResultSet rs = stmt.executeQuery("SELECT * FROM fake_players");

               try {
                  while(rs.next()) {
                     players.add(this.mapRowToFakePlayer(rs));
                  }
               } catch (Throwable var10) {
                  if (rs != null) {
                     try {
                        rs.close();
                     } catch (Throwable var9) {
                        var10.addSuppressed(var9);
                     }
                  }

                  throw var10;
               }

               if (rs != null) {
                  rs.close();
               }
            } catch (Throwable var11) {
               if (stmt != null) {
                  try {
                     stmt.close();
                  } catch (Throwable var8) {
                     var11.addSuppressed(var8);
                  }
               }

               throw var11;
            }

            if (stmt != null) {
               stmt.close();
            }
         } catch (Throwable var12) {
            if (conn != null) {
               try {
                  conn.close();
               } catch (Throwable var7) {
                  var12.addSuppressed(var7);
               }
            }

            throw var12;
         }

         if (conn != null) {
            conn.close();
         }
      } catch (SQLException var13) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading fake players: " + var13.getMessage(), var13);
      }

      return players;
   }

   public void saveVotes(String playerName, int votes) {
      try {
         Connection conn = this.dataSource.getConnection();

         try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO fake_votes (player_name, votes, last_updated)VALUES (?, ?, ?)ON DUPLICATE KEY UPDATEvotes = VALUES(votes),last_updated = VALUES(last_updated)");

            try {
               stmt.setString(1, playerName);
               stmt.setInt(2, votes);
               stmt.setLong(3, System.currentTimeMillis());
               stmt.executeUpdate();
            } catch (Throwable var9) {
               if (stmt != null) {
                  try {
                     stmt.close();
                  } catch (Throwable var8) {
                     var9.addSuppressed(var8);
                  }
               }

               throw var9;
            }

            if (stmt != null) {
               stmt.close();
            }
         } catch (Throwable var10) {
            if (conn != null) {
               try {
                  conn.close();
               } catch (Throwable var7) {
                  var10.addSuppressed(var7);
               }
            }

            throw var10;
         }

         if (conn != null) {
            conn.close();
         }
      } catch (SQLException var11) {
         this.plugin.getLogger().log(Level.WARNING, "Error saving votes: " + var11.getMessage(), var11);
      }

   }

   public int loadVotes(String playerName) {
      try {
         Connection conn = this.dataSource.getConnection();

         byte var6;
         label77: {
            int var5;
            try {
               PreparedStatement stmt = conn.prepareStatement("SELECT votes FROM fake_votes WHERE player_name = ?");

               label79: {
                  try {
                     stmt.setString(1, playerName);
                     ResultSet rs = stmt.executeQuery();
                     if (rs.next()) {
                        var5 = rs.getInt("votes");
                        break label79;
                     }

                     var6 = 0;
                  } catch (Throwable var9) {
                     if (stmt != null) {
                        try {
                           stmt.close();
                        } catch (Throwable var8) {
                           var9.addSuppressed(var8);
                        }
                     }

                     throw var9;
                  }

                  if (stmt != null) {
                     stmt.close();
                  }
                  break label77;
               }

               if (stmt != null) {
                  stmt.close();
               }
            } catch (Throwable var101) {
               if (conn != null) {
                  try {
                     conn.close();
                  } catch (Throwable var7) {
                     var101.addSuppressed(var7);
                  }
               }

               throw var101;
            }

            if (conn != null) {
               conn.close();
            }

            return var5;
         }

         if (conn != null) {
            conn.close();
         }

         return var6;
      } catch (SQLException var10) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading votes: " + var10.getMessage(), var10);
         return 0;
      }
   }

   public void savePlayerStats(PlayerStats stats) {
      try {
         Connection conn = this.dataSource.getConnection();

         try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO player_stats (player_name, total_play_time, times_joined, times_left,last_join_time, last_leave_time, messages_sent, commands_executed) VALUES (?, ?, ?, ?, ?, ?, ?, ?)ON DUPLICATE KEY UPDATEtotal_play_time = VALUES(total_play_time),times_joined = VALUES(times_joined),times_left = VALUES(times_left),last_join_time = VALUES(last_join_time),last_leave_time = VALUES(last_leave_time),messages_sent = VALUES(messages_sent),commands_executed = VALUES(commands_executed)");

            try {
               stmt.setString(1, stats.getPlayerName());
               stmt.setLong(2, stats.getTotalPlayTime());
               stmt.setInt(3, stats.getTimesJoined());
               stmt.setInt(4, stats.getTimesLeft());
               stmt.setLong(5, stats.getLastJoinTime());
               stmt.setLong(6, stats.getLastLeaveTime());
               stmt.setInt(7, stats.getMessagesSent());
               stmt.setInt(8, stats.getCommandsExecuted());
               stmt.executeUpdate();
            } catch (Throwable var8) {
               if (stmt != null) {
                  try {
                     stmt.close();
                  } catch (Throwable var7) {
                     var8.addSuppressed(var7);
                  }
               }

               throw var8;
            }

            if (stmt != null) {
               stmt.close();
            }
         } catch (Throwable var9) {
            if (conn != null) {
               try {
                  conn.close();
               } catch (Throwable var6) {
                  var9.addSuppressed(var6);
               }
            }

            throw var9;
         }

         if (conn != null) {
            conn.close();
         }
      } catch (SQLException var10) {
         this.plugin.getLogger().log(Level.WARNING, "Error saving player stats: " + var10.getMessage(), var10);
      }

   }

   public PlayerStats loadPlayerStats(String playerName) {
      try {
         Connection conn = this.dataSource.getConnection();

         Object var6;
         label113: {
            PlayerStats var15;
            try {
               PreparedStatement stmt = conn.prepareStatement("SELECT * FROM player_stats WHERE player_name = ?");

               label115: {
                  try {
                     stmt.setString(1, playerName);
                     ResultSet rs = stmt.executeQuery();
                     if (rs.next()) {
                        PlayerStats stats = new PlayerStats(playerName);
                        stats.setTotalPlayTime(rs.getLong("total_play_time"));

                        for(int i = 0; i < rs.getInt("times_joined"); ++i) {
                           stats.incrementTimesJoined();
                        }

                        for(int i = 0; i < rs.getInt("times_left"); ++i) {
                           stats.incrementTimesLeft();
                        }

                        stats.setLastJoinTime(rs.getLong("last_join_time"));
                        stats.setLastLeaveTime(rs.getLong("last_leave_time"));

                        for(int i = 0; i < rs.getInt("messages_sent"); ++i) {
                           stats.incrementMessagesSent();
                        }

                        for(int i = 0; i < rs.getInt("commands_executed"); ++i) {
                           stats.incrementCommandsExecuted();
                        }

                        var15 = stats;
                        break label115;
                     }

                     var6 = null;
                  } catch (Throwable var10) {
                     if (stmt != null) {
                        try {
                           stmt.close();
                        } catch (Throwable var9) {
                           var10.addSuppressed(var9);
                        }
                     }

                     throw var10;
                  }

                  if (stmt != null) {
                     stmt.close();
                  }
                  break label113;
               }

               if (stmt != null) {
                  stmt.close();
               }
            } catch (Throwable var111) {
               if (conn != null) {
                  try {
                     conn.close();
                  } catch (Throwable var8) {
                     var111.addSuppressed(var8);
                  }
               }

               throw var111;
            }

            if (conn != null) {
               conn.close();
            }

            return var15;
         }

         if (conn != null) {
            conn.close();
         }

         return (PlayerStats)var6;
      } catch (SQLException var11) {
         this.plugin.getLogger().log(Level.WARNING, "Error loading player stats: " + var11.getMessage(), var11);
         return null;
      }
   }

   public Map<String, Object> executeQuery(String query) {
      try {
         Connection conn = this.dataSource.getConnection();

         Object var16;
         try {
            Statement stmt = conn.createStatement();

            try {
               ResultSet rs = stmt.executeQuery(query);

               try {
                  ResultSetMetaData metaData = rs.getMetaData();
                  int columnCount = metaData.getColumnCount();
                  Map<String, Object> result = new HashMap();
                  if (rs.next()) {
                     for(int i = 1; i <= columnCount; ++i) {
                        result.put(metaData.getColumnName(i), rs.getObject(i));
                     }
                  }

                  var16 = result;
               } catch (Throwable var13) {
                  if (rs != null) {
                     try {
                        rs.close();
                     } catch (Throwable var12) {
                        var13.addSuppressed(var12);
                     }
                  }

                  throw var13;
               }

               if (rs != null) {
                  rs.close();
               }
            } catch (Throwable var14) {
               if (stmt != null) {
                  try {
                     stmt.close();
                  } catch (Throwable var11) {
                     var14.addSuppressed(var11);
                  }
               }

               throw var14;
            }

            if (stmt != null) {
               stmt.close();
            }
         } catch (Throwable var151) {
            if (conn != null) {
               try {
                  conn.close();
               } catch (Throwable var10) {
                  var151.addSuppressed(var10);
               }
            }

            throw var151;
         }

         if (conn != null) {
            conn.close();
         }

         return (Map)var16;
      } catch (SQLException var15) {
         this.plugin.getLogger().log(Level.WARNING, "Error executing query: " + var15.getMessage(), var15);
         return Map.of();
      }
   }

   public boolean executeUpdate(String query) {
      try {
         Connection conn = this.dataSource.getConnection();

         boolean var4;
         try {
            Statement stmt = conn.createStatement();

            try {
               stmt.executeUpdate(query);
               var4 = true;
            } catch (Throwable var9) {
               if (stmt != null) {
                  try {
                     stmt.close();
                  } catch (Throwable var8) {
                     var9.addSuppressed(var8);
                  }
               }

               throw var9;
            }

            if (stmt != null) {
               stmt.close();
            }
         } catch (Throwable var101) {
            if (conn != null) {
               try {
                  conn.close();
               } catch (Throwable var7) {
                  var101.addSuppressed(var7);
               }
            }

            throw var101;
         }

         if (conn != null) {
            conn.close();
         }

         return var4;
      } catch (SQLException var10) {
         this.plugin.getLogger().log(Level.WARNING, "Error executing update: " + var10.getMessage(), var10);
         return false;
      }
   }

   private FakePlayerData mapRowToFakePlayer(ResultSet rs) throws SQLException {
      String name = rs.getString("name");
      UUID uuid = UUID.fromString(rs.getString("uuid"));
      FakePlayerData data = new FakePlayerData(name, uuid);
      data.setSkinName(rs.getString("skin_name"));
      data.setRank(rs.getString("rank"));
      data.setVisibleInTab(rs.getBoolean("visible_in_tab"));
      data.setVisibleInPing(rs.getBoolean("visible_in_ping"));
      data.setVisibleInWorld(rs.getBoolean("visible_in_world"));
      data.setVotes(rs.getInt("votes"));
      data.setFluctuationEnabled(rs.getBoolean("fluctuation_enabled"));
      data.setLastSeen(rs.getLong("last_seen"));
      data.setTotalPlayTime(rs.getLong("total_play_time"));
      return data;
   }
}
