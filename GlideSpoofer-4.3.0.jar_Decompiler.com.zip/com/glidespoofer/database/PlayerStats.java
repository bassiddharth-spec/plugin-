package com.glidespoofer.database;

public class PlayerStats {
   private final String playerName;
   private long totalPlayTime;
   private int timesJoined;
   private int timesLeft;
   private long lastJoinTime;
   private long lastLeaveTime;
   private int messagesSent;
   private int commandsExecuted;

   public PlayerStats(String playerName) {
      this.playerName = playerName;
      this.totalPlayTime = 0L;
      this.timesJoined = 0;
      this.timesLeft = 0;
      this.lastJoinTime = 0L;
      this.lastLeaveTime = 0L;
      this.messagesSent = 0;
      this.commandsExecuted = 0;
   }

   public String getPlayerName() {
      return this.playerName;
   }

   public long getTotalPlayTime() {
      return this.totalPlayTime;
   }

   public void setTotalPlayTime(long totalPlayTime) {
      this.totalPlayTime = totalPlayTime;
   }

   public void addPlayTime(long time) {
      this.totalPlayTime += time;
   }

   public int getTimesJoined() {
      return this.timesJoined;
   }

   public void incrementTimesJoined() {
      ++this.timesJoined;
   }

   public int getTimesLeft() {
      return this.timesLeft;
   }

   public void incrementTimesLeft() {
      ++this.timesLeft;
   }

   public long getLastJoinTime() {
      return this.lastJoinTime;
   }

   public void setLastJoinTime(long lastJoinTime) {
      this.lastJoinTime = lastJoinTime;
   }

   public long getLastLeaveTime() {
      return this.lastLeaveTime;
   }

   public void setLastLeaveTime(long lastLeaveTime) {
      this.lastLeaveTime = lastLeaveTime;
   }

   public int getMessagesSent() {
      return this.messagesSent;
   }

   public void incrementMessagesSent() {
      ++this.messagesSent;
   }

   public int getCommandsExecuted() {
      return this.commandsExecuted;
   }

   public void incrementCommandsExecuted() {
      ++this.commandsExecuted;
   }
}
