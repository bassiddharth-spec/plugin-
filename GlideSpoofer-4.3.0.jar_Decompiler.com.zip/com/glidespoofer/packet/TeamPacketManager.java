package com.glidespoofer.packet;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Stream;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class TeamPacketManager {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-TeamPacketManager");
   private static final Map<UUID, TeamData> teamDataMap = new HashMap();
   private static Class<?> packetClass;
   private static Class<?> componentClass;
   private static Class<?> playerTeamClass;
   private static Class<?> scoreboardClass;
   private static Class<?> parametersClass;
   private static boolean initialized = false;
   private static String serverVersion = "unknown";

   private static void logPacketClassInfo() {
      try {
         StringBuilder info = new StringBuilder("\n[TeamPacketManager] Packet class info:\n");
         info.append("Constructors:\n");

         for(Constructor<?> c : packetClass.getConstructors()) {
            info.append("  ").append(c).append("\n");
         }

         info.append("Static methods:\n");

         for(Method m : packetClass.getMethods()) {
            if (Modifier.isStatic(m.getModifiers())) {
               info.append("  ").append(m.getName()).append(Arrays.toString(m.getParameterTypes())).append("\n");
            }
         }

         LOGGER.info(info.toString());
      } catch (Exception e) {
         LOGGER.warning("[TeamPacketManager] Failed to log packet class info: " + e.getMessage());
      }

   }

   public static void sendTeamToAllPlayers(UUID fakeUuid, String fakeName, String prefix, String suffix) {
      if (!initialized) {
         LOGGER.warning("[TeamPacketManager] Not initialized, skipping team packet for " + fakeName);
      } else {
         try {
            String var10000 = fakeName.length() > 12 ? fakeName.substring(0, 12) : fakeName;
            String teamName = "GS_" + var10000;
            LOGGER.info("[TeamPacketManager] Creating team packet for " + fakeName + " (team: " + teamName + ") with prefix: " + prefix);
            boolean success = createAndBroadcastTeamPacket(teamName, fakeName, prefix, suffix);
            if (success) {
               teamDataMap.put(fakeUuid, new TeamData(teamName, fakeName, prefix, suffix));
               LOGGER.info("[TeamPacketManager] Successfully sent team packet for " + fakeName);
            } else {
               LOGGER.warning("[TeamPacketManager] Failed to create team packet for " + fakeName);
            }
         } catch (Exception e) {
            LOGGER.warning("[TeamPacketManager] Failed to send team packet: " + e.getMessage());
            e.printStackTrace();
         }

      }
   }

   private static boolean createAndBroadcastTeamPacket(String teamName, String playerName, String prefix, String suffix) {
      try {
         Object packet = createPacketModern(teamName, playerName, prefix, suffix);
         if (packet != null) {
            broadcastPacket(packet);
            return true;
         } else {
            packet = createPacketLegacy(teamName, playerName, prefix, suffix);
            if (packet != null) {
               broadcastPacket(packet);
               return true;
            } else {
               packet = createPacketDirect(teamName, playerName, prefix, suffix);
               if (packet != null) {
                  broadcastPacket(packet);
                  return true;
               } else {
                  LOGGER.warning("[TeamPacketManager] All packet creation methods failed");
                  return false;
               }
            }
         }
      } catch (Exception e) {
         LOGGER.warning("[TeamPacketManager] Error creating team packet: " + e.getMessage());
         e.printStackTrace();
         return false;
      }
   }

   private static Object createPacketModern(String teamName, String playerName, String prefix, String suffix) {
      if (parametersClass == null) {
         return null;
      } else {
         try {
            Object displayNameComponent = createComponent(teamName);
            Object prefixComponent = createComponent(ChatColor.translateAlternateColorCodes('&', prefix));
            Object suffixComponent = createComponent(ChatColor.translateAlternateColorCodes('&', suffix));
            if (displayNameComponent != null && prefixComponent != null) {
               Object parameters = null;

               for(Constructor<?> c : parametersClass.getConstructors()) {
                  Class<?>[] params = c.getParameterTypes();

                  try {
                     if (params.length >= 3) {
                        Object[] args = new Object[params.length];
                        int idx = 0;

                        for(Class<?> param : params) {
                           if (componentClass.isAssignableFrom(param)) {
                              if (idx == 0) {
                                 args[idx] = displayNameComponent;
                              } else if (idx == 1) {
                                 args[idx] = prefixComponent;
                              } else if (idx == 2) {
                                 args[idx] = suffixComponent;
                              } else {
                                 args[idx] = createComponent("");
                              }
                           } else if (param == String.class) {
                              args[idx] = "";
                           } else if (param == Boolean.TYPE) {
                              args[idx] = true;
                           } else if (param == Integer.TYPE) {
                              args[idx] = 0;
                           } else {
                              args[idx] = null;
                           }

                           ++idx;
                        }

                        parameters = c.newInstance(args);
                        LOGGER.info("[TeamPacketManager] Created Parameters object");
                        break;
                     }
                  } catch (Exception e) {
                     LOGGER.fine("[TeamPacketManager] Parameters constructor attempt failed: " + e.getMessage());
                  }
               }

               if (parameters == null) {
                  LOGGER.fine("[TeamPacketManager] Could not create Parameters object");
                  return null;
               } else {
                  Collection<String> players = Collections.singleton(playerName);

                  for(Constructor<?> c : packetClass.getConstructors()) {
                     Class<?>[] params = c.getParameterTypes();

                     try {
                        if (params.length == 4 && params[0] == String.class && params[1].getName().contains("Optional") && params[2] == Integer.TYPE) {
                           Object optionalParams = Optional.of(parameters);
                           return c.newInstance(teamName, optionalParams, 0, players);
                        }

                        if (params.length == 3 && params[0] == String.class && params[1].getName().contains("Optional")) {
                           Object optionalParams = Optional.of(parameters);
                           return c.newInstance(teamName, optionalParams, players);
                        }
                     } catch (Exception e) {
                        LOGGER.fine("[TeamPacketManager] Packet constructor attempt failed: " + e.getMessage());
                     }
                  }

                  return null;
               }
            } else {
               LOGGER.warning("[TeamPacketManager] Failed to create components");
               return null;
            }
         } catch (Exception e) {
            LOGGER.fine("[TeamPacketManager] Modern packet creation failed: " + e.getMessage());
            return null;
         }
      }
   }

   private static Object createPacketLegacy(String teamName, String playerName, String prefix, String suffix) {
      try {
         if (playerTeamClass != null && scoreboardClass != null) {
            Object scoreboard = scoreboardClass.getConstructor().newInstance();
            Object playerTeam = null;

            for(Method m : scoreboardClass.getMethods()) {
               if (m.getParameterCount() == 1 && m.getParameterTypes()[0] == String.class) {
                  try {
                     Object result = m.invoke(scoreboard, teamName);
                     if (result != null && playerTeamClass.isInstance(result)) {
                        playerTeam = result;
                        LOGGER.fine("[TeamPacketManager] Created PlayerTeam via " + m.getName());
                        break;
                     }
                  } catch (Exception var15) {
                  }
               }
            }

            if (playerTeam == null) {
               try {
                  playerTeam = playerTeamClass.getConstructor(scoreboardClass, String.class).newInstance(scoreboard, teamName);
                  LOGGER.fine("[TeamPacketManager] Created PlayerTeam via constructor");
               } catch (Exception e) {
                  LOGGER.fine("[TeamPacketManager] PlayerTeam constructor failed: " + e.getMessage());
               }
            }

            if (playerTeam == null) {
               return null;
            } else {
               setTeamProperty(playerTeam, "setDisplayName", createComponent(teamName));
               setTeamProperty(playerTeam, "setPrefix", createComponent(ChatColor.translateAlternateColorCodes('&', prefix)));
               setTeamProperty(playerTeam, "setSuffix", createComponent(ChatColor.translateAlternateColorCodes('&', suffix)));
               addPlayerToTeam(playerTeam, playerName);

               for(Method m : packetClass.getMethods()) {
                  if (Modifier.isStatic(m.getModifiers()) && m.getParameterCount() >= 1) {
                     Class<?>[] params = m.getParameterTypes();
                     if (params[0] == playerTeamClass) {
                        try {
                           if (m.getParameterCount() == 1) {
                              return m.invoke((Object)null, playerTeam);
                           }

                           if (m.getParameterCount() == 2 && params[1] == Boolean.TYPE) {
                              return m.invoke((Object)null, playerTeam, true);
                           }

                           if (m.getParameterCount() == 2 && params[1] == Integer.TYPE) {
                              return m.invoke((Object)null, playerTeam, 0);
                           }
                        } catch (Exception e) {
                           Logger var10000 = LOGGER;
                           String var10001 = m.getName();
                           var10000.fine("[TeamPacketManager] Static method " + var10001 + " failed: " + e.getMessage());
                        }
                     }
                  }
               }

               for(Constructor<?> c : packetClass.getConstructors()) {
                  Class<?>[] params = c.getParameterTypes();
                  if (params.length >= 1 && params[0] == playerTeamClass) {
                     try {
                        if (params.length == 1) {
                           return c.newInstance(playerTeam);
                        }

                        if (params.length == 2 && params[1] == Boolean.TYPE) {
                           return c.newInstance(playerTeam, true);
                        }
                     } catch (Exception e) {
                        LOGGER.fine("[TeamPacketManager] PlayerTeam constructor failed: " + e.getMessage());
                     }
                  }
               }

               return null;
            }
         } else {
            return null;
         }
      } catch (Exception e) {
         LOGGER.fine("[TeamPacketManager] Legacy packet creation failed: " + e.getMessage());
         return null;
      }
   }

   private static Object createPacketDirect(String teamName, String playerName, String prefix, String suffix) {
      try {
         Collection<String> players = Collections.singleton(playerName);

         for(Constructor<?> c : packetClass.getConstructors()) {
            Class<?>[] params = c.getParameterTypes();

            try {
               if (params.length == 3 && params[0] == String.class && params[1] == Integer.TYPE && params[2] == Collection.class) {
                  return c.newInstance(teamName, 0, players);
               }
            } catch (Exception e) {
               LOGGER.fine("[TeamPacketManager] Direct constructor failed: " + e.getMessage());
            }
         }

         return null;
      } catch (Exception var12) {
         return null;
      }
   }

   private static void setTeamProperty(Object team, String setterName, Object value) {
      if (value != null) {
         try {
            Method setter = team.getClass().getMethod(setterName, value.getClass());
            setter.invoke(team, value);
         } catch (Exception e) {
            LOGGER.fine("[TeamPacketManager] Failed to set " + setterName + ": " + e.getMessage());
         }

      }
   }

   private static void addPlayerToTeam(Object team, String playerName) {
      try {
         String[] getterNames = new String[]{"getPlayers", "getPlayerNameSet", "e", "d", "c", "f"};

         for(String getterName : getterNames) {
            try {
               Method getter = team.getClass().getMethod(getterName);
               Object result = getter.invoke(team);
               if (result instanceof Set<String> nameSet) {
                  nameSet.add(playerName);
                  LOGGER.info("[TeamPacketManager] Added " + playerName + " to team via " + getterName + "()");
                  return;
               }
            } catch (NoSuchMethodException var16) {
            } catch (Exception e) {
               LOGGER.fine("[TeamPacketManager] Getter " + getterName + " failed: " + e.getMessage());
            }
         }

         for(Method m : team.getClass().getMethods()) {
            if (m.getParameterCount() == 0) {
               Class<?> returnType = m.getReturnType();
               if (Collection.class.isAssignableFrom(returnType)) {
                  try {
                     Object collection = m.invoke(team);
                     if (collection instanceof Set) {
                        Set<String> nameSet = (Set)collection;
                        nameSet.add(playerName);
                        LOGGER.info("[TeamPacketManager] Added " + playerName + " to team via " + m.getName() + "()");
                        return;
                     }
                  } catch (Exception var15) {
                  }
               }
            }
         }

         String[] addMethodNames = new String[]{"addPlayer", "a", "b", "c", "add"};

         for(String methodName : addMethodNames) {
            for(Method m : team.getClass().getMethods()) {
               if (m.getName().equals(methodName) && m.getParameterCount() == 1) {
                  Class<?> paramType = m.getParameterTypes()[0];
                  if (paramType == String.class || paramType == Object.class) {
                     try {
                        m.invoke(team, playerName);
                        LOGGER.info("[TeamPacketManager] Added " + playerName + " to team via " + methodName + "(String)");
                        return;
                     } catch (Exception var18) {
                     }
                  }
               }
            }
         }

         for(Field f : team.getClass().getDeclaredFields()) {
            if (Set.class.isAssignableFrom(f.getType())) {
               try {
                  f.setAccessible(true);
                  Object setObj = f.get(team);
                  if (setObj instanceof Set) {
                     Set<String> nameSet = (Set)setObj;
                     nameSet.add(playerName);
                     LOGGER.info("[TeamPacketManager] Added " + playerName + " to team via field " + f.getName());
                     return;
                  }
               } catch (Exception e) {
                  Logger var10000 = LOGGER;
                  String var10001 = f.getName();
                  var10000.fine("[TeamPacketManager] Field access " + var10001 + " failed: " + e.getMessage());
               }
            }
         }

         for(Method m : team.getClass().getMethods()) {
            String methodNameLower = m.getName().toLowerCase(Locale.ROOT);
            if ((methodNameLower.contains("player") || methodNameLower.contains("name")) && m.getParameterCount() == 1 && m.getParameterTypes()[0] == String.class) {
               try {
                  m.invoke(team, playerName);
                  LOGGER.info("[TeamPacketManager] Added " + playerName + " to team via " + m.getName());
                  return;
               } catch (Exception var19) {
               }
            }
         }

         LOGGER.warning("[TeamPacketManager] Could not add player to team entries - all methods failed");
         Logger var46 = LOGGER;
         Stream var47 = Arrays.stream(team.getClass().getMethods());
         var46.fine("[TeamPacketManager] Available methods: " + Arrays.toString(var47.map(Method::getName).distinct().toArray()));
      } catch (Exception e) {
         LOGGER.warning("[TeamPacketManager] Error adding player to team: " + e.getMessage());
      }

   }

   private static Object createComponent(String text) {
      try {
         if (text == null) {
            text = "";
         }

         try {
            Method literalMethod = componentClass.getMethod("a", String.class);
            return literalMethod.invoke((Object)null, text);
         } catch (Exception var8) {
            try {
               Class<?> textComponentClass = Class.forName("net.minecraft.network.chat.TextComponent");
               return textComponentClass.getConstructor(String.class).newInstance(text);
            } catch (Exception var7) {
               try {
                  Class<?> serializerClass = Class.forName("net.minecraft.network.chat.ChatSerializer");
                  Method serializeMethod = serializerClass.getMethod("a", String.class);
                  String json = "{\"text\":\"" + escapeJson(text) + "\"}";
                  return serializeMethod.invoke((Object)null, json);
               } catch (Exception var6) {
                  LOGGER.warning("[TeamPacketManager] All component creation methods failed");
                  return null;
               }
            }
         }
      } catch (Exception e) {
         LOGGER.warning("[TeamPacketManager] Component creation error: " + e.getMessage());
         return null;
      }
   }

   private static String escapeJson(String text) {
      return text == null ? "" : text.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
   }

   public static void updateTeamForAllPlayers(UUID fakeUuid, String prefix, String suffix) {
      TeamData data = (TeamData)teamDataMap.get(fakeUuid);
      if (data != null) {
         data.prefix = prefix;
         data.suffix = suffix;
         createAndBroadcastTeamPacket(data.teamName, data.playerName, prefix, suffix);
      }

   }

   public static void removeTeamForAllPlayers(UUID fakeUuid) {
      TeamData data = (TeamData)teamDataMap.remove(fakeUuid);
      if (data != null) {
         try {
            for(Constructor<?> c : packetClass.getConstructors()) {
               Class<?>[] params = c.getParameterTypes();
               if (params.length >= 2 && params[0] == String.class && params[1] == Integer.TYPE) {
                  try {
                     Object packet = c.newInstance(data.teamName, 1, Collections.emptySet());
                     broadcastPacket(packet);
                     return;
                  } catch (Exception var8) {
                  }
               }
            }
         } catch (Exception e) {
            LOGGER.fine("[TeamPacketManager] Failed to remove team packet: " + e.getMessage());
         }
      }

   }

   public static void sendAllTeamsToPlayer(Player player) {
      if (teamDataMap.isEmpty()) {
         LOGGER.fine("[TeamPacketManager] No team data to send to " + player.getName());
      } else {
         int sent = 0;

         for(Map.Entry<UUID, TeamData> entry : teamDataMap.entrySet()) {
            TeamData data = (TeamData)entry.getValue();

            try {
               boolean success = createAndSendTeamPacket(player, data.teamName, data.playerName, data.prefix, data.suffix);
               if (success) {
                  ++sent;
               }
            } catch (Exception var6) {
               String var10001 = data.teamName;
               LOGGER.warning("[TeamPacketManager] Failed to send team " + var10001 + " to " + player.getName());
            }
         }

         LOGGER.info("[TeamPacketManager] Sent " + sent + "/" + teamDataMap.size() + " teams to " + player.getName());
      }
   }

   private static boolean createAndSendTeamPacket(Player player, String teamName, String playerName, String prefix, String suffix) {
      Object packet = createPacketModern(teamName, playerName, prefix, suffix);
      if (packet == null) {
         packet = createPacketLegacy(teamName, playerName, prefix, suffix);
      }

      if (packet == null) {
         packet = createPacketDirect(teamName, playerName, prefix, suffix);
      }

      if (packet != null) {
         sendPacketToPlayer(player, packet);
         return true;
      } else {
         return false;
      }
   }

   private static void broadcastPacket(Object packet) {
      if (packet != null) {
         int sent = 0;

         for(Player player : Bukkit.getOnlinePlayers()) {
            try {
               sendPacketToPlayer(player, packet);
               ++sent;
            } catch (Exception var5) {
               LOGGER.fine("[TeamPacketManager] Failed to send to " + player.getName());
            }
         }

         LOGGER.info("[TeamPacketManager] Broadcast to " + sent + " players");
      }
   }

   private static void sendPacketToPlayer(Player player, Object packet) {
      try {
         Method getHandleMethod = player.getClass().getMethod("getHandle");
         Object entityPlayer = getHandleMethod.invoke(player);
         Field connectionField = null;

         for(Field f : entityPlayer.getClass().getDeclaredFields()) {
            String typeName = f.getType().getName();
            if (typeName.contains("ServerGamePacketListener") || typeName.contains("PlayerConnection")) {
               connectionField = f;
               break;
            }
         }

         if (connectionField == null) {
            for(String fieldName : new String[]{"c", "connection", "b"}) {
               try {
                  connectionField = entityPlayer.getClass().getDeclaredField(fieldName);
                  if (connectionField != null) {
                     break;
                  }
               } catch (Exception var12) {
               }
            }
         }

         if (connectionField == null) {
            LOGGER.warning("[TeamPacketManager] No connection field found");
            return;
         }

         connectionField.setAccessible(true);
         Object connection = connectionField.get(entityPlayer);
         if (connection == null) {
            LOGGER.warning("[TeamPacketManager] Connection is null");
            return;
         }

         Method sendMethod = null;

         for(Method m : connection.getClass().getMethods()) {
            if ((m.getName().equals("a") || m.getName().equals("send")) && m.getParameterCount() == 1) {
               Class<?> param = m.getParameterTypes()[0];
               if (param.getName().contains("Packet")) {
                  sendMethod = m;
                  break;
               }
            }
         }

         if (sendMethod != null) {
            sendMethod.invoke(connection, packet);
         }
      } catch (Exception e) {
         Logger var10000 = LOGGER;
         String var10001 = player.getName();
         var10000.warning("[TeamPacketManager] Failed to send packet to " + var10001 + ": " + e.getMessage());
      }

   }

   public static void initialize() {
      LOGGER.info("[TeamPacketManager] Ready - initialized: " + initialized);
   }

   static {
      try {
         try {
            serverVersion = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
         } catch (Exception var2) {
            serverVersion = "unknown";
         }

         LOGGER.info("[TeamPacketManager] Server version: " + serverVersion);
         packetClass = Class.forName("net.minecraft.network.protocol.game.ClientboundSetPlayerTeamPacket");
         componentClass = Class.forName("net.minecraft.network.chat.Component");
         playerTeamClass = Class.forName("net.minecraft.world.scores.PlayerTeam");
         scoreboardClass = Class.forName("net.minecraft.world.scores.Scoreboard");

         try {
            parametersClass = Class.forName("net.minecraft.network.protocol.game.ClientboundSetPlayerTeamPacket$Parameters");
            LOGGER.info("[TeamPacketManager] Found Parameters class for 1.21+");
         } catch (ClassNotFoundException var1) {
            LOGGER.info("[TeamPacketManager] Parameters class not found (pre-1.21)");
         }

         logPacketClassInfo();
         initialized = true;
         LOGGER.info("[TeamPacketManager] Initialized successfully");
      } catch (Exception e) {
         LOGGER.log(Level.WARNING, "[TeamPacketManager] Failed to initialize", e);
      }

   }

   private static class TeamData {
      String teamName;
      String playerName;
      String prefix;
      String suffix;

      TeamData(String teamName, String playerName, String prefix, String suffix) {
         this.teamName = teamName;
         this.playerName = playerName;
         this.prefix = prefix;
         this.suffix = suffix;
      }
   }
}
