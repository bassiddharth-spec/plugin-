package com.glidespoofer.packet;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.FakePlayer;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class PacketManager {
   private final GlideSpoofer plugin;

   public PacketManager(GlideSpoofer plugin) {
      this.plugin = plugin;
   }

   public void sendTeamCreate(Player viewer, FakePlayer fake) {
   }

   public void sendPlayerInfoAdd(Player viewer, FakePlayer fake) {
   }

   public void sendSpawnPlayer(Player viewer, FakePlayer fake, int entityId) {
   }

   public void sendHeadRotation(Player viewer, int entityId, float yaw) {
   }

   public void sendEntityMetadata(Player viewer, FakePlayer fake, int entityId) {
   }

   public void sendEquipment(Player viewer, FakePlayer fake, int entityId) {
   }

   public void sendDestroyEntity(Player viewer, Integer entityId) {
   }

   public void sendPlayerInfoRemove(Player viewer, FakePlayer fake) {
   }

   public void sendTeamRemove(Player viewer, FakePlayer fake) {
   }

   public void sendPlayerInfoUpdatePing(Player viewer, FakePlayer fake) {
   }

   public int getNextEntityId() {
      return -1;
   }

   public void sendHurtAnimation(Player viewer, int entityId) {
   }

   public void sendSwingArm(Player viewer, int entityId, boolean mainHand) {
   }

   public void sendEntityRotation(Player viewer, int entityId, float yaw, float pitch) {
   }

   public void sendTeleport(Player viewer, int entityId, Location location) {
   }

   public void sendRelativeMoveAndRotation(Player viewer, int entityId, double dx, double dy, double dz, float yaw, float pitch, boolean onGround) {
   }

   public void sendEquipmentToAll(FakePlayer fake) {
   }
}
