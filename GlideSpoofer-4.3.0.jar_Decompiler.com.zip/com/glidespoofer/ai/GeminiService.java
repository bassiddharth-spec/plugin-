package com.glidespoofer.ai;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.logging.Logger;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class GeminiService implements AIService {
   private final Logger logger;
   private final Gson gson;
   private final OkHttpClient httpClient;
   private final String apiKey;
   private final String model;
   private final String systemPrompt;
   private final String contextBoost;
   private final int maxTokens;
   private final double temperature;
   private final boolean enabled;
   private final Map<String, LinkedList<AIService.ChatMessage>> conversationMemory;
   private final int memorySize;

   public GeminiService(AIConfigProvider configProvider) {
      this.logger = configProvider.getLogger();
      this.gson = new Gson();
      this.apiKey = configProvider.getGeminiKey();
      this.model = configProvider.getGeminiModel();
      this.systemPrompt = configProvider.getSystemPrompt();
      this.contextBoost = configProvider.getContextBoost();
      this.maxTokens = configProvider.getMaxTokens();
      this.temperature = configProvider.getTemperature();
      this.memorySize = configProvider.getMemorySize();
      this.enabled = this.apiKey != null && !this.apiKey.isEmpty() && !this.apiKey.equals("your-api-key-here");
      this.httpClient = (new OkHttpClient.Builder()).connectTimeout(30L, TimeUnit.SECONDS).writeTimeout(30L, TimeUnit.SECONDS).readTimeout(30L, TimeUnit.SECONDS).build();
      this.conversationMemory = new ConcurrentHashMap();
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public String getSystemPrompt(String playerName) {
      String basePrompt = this.systemPrompt.replace("{player}", playerName);
      return this.contextBoost != null && !this.contextBoost.trim().isEmpty() ? basePrompt + "\n\n" + this.contextBoost.trim() : basePrompt;
   }

   public CompletableFuture<String> getChatResponse(String playerName, String message, List<AIService.ChatMessage> history) {
      final CompletableFuture<String> future = new CompletableFuture();
      if (!this.enabled) {
         future.complete((Object)null);
         return future;
      } else {
         final LinkedList<AIService.ChatMessage> memory = (LinkedList)this.conversationMemory.computeIfAbsent(playerName, (k) -> new LinkedList());
         memory.add(new AIService.ChatMessage("user", message));

         while(memory.size() > this.memorySize) {
            memory.removeFirst();
         }

         JsonObject requestBody = new JsonObject();
         JsonArray contents = new JsonArray();
         JsonArray parts = new JsonArray();
         String var10002 = this.getSystemPrompt(playerName);
         parts.add((JsonElement)this.createTextPart(var10002 + "\n\nPrevious conversation:\n" + this.buildConversationText(memory)));
         JsonObject content = new JsonObject();
         content.add("parts", parts);
         contents.add((JsonElement)content);
         requestBody.add("contents", contents);
         JsonObject generationConfig = new JsonObject();
         generationConfig.addProperty("temperature", (Number)this.temperature);
         generationConfig.addProperty("maxOutputTokens", (Number)this.maxTokens);
         requestBody.add("generationConfig", generationConfig);
         RequestBody body = RequestBody.create(requestBody.toString(), MediaType.parse("application/json"));
         String url = "https://generativelanguage.googleapis.com/v1beta/models/" + this.model + ":generateContent?key=" + this.apiKey;
         Request request = (new Request.Builder()).url(url).addHeader("Content-Type", "application/json").post(body).build();
         this.httpClient.newCall(request).enqueue(new Callback() {
            public void onFailure(Call call, IOException e) {
               GeminiService.this.logger.warning("[Gemini] Request failed: " + e.getMessage());
               future.complete((Object)null);
            }

            public void onResponse(Call call, Response response) throws IOException {
               try {
                  if (!response.isSuccessful()) {
                     GeminiService.this.logger.warning("[Gemini] Error: " + response.code());
                     future.complete((Object)null);
                     return;
                  }

                  String responseBody = response.body().string();
                  JsonObject jsonResponse = (JsonObject)GeminiService.this.gson.fromJson(responseBody, JsonObject.class);
                  String content = jsonResponse.getAsJsonArray("candidates").get(0).getAsJsonObject().getAsJsonObject("content").getAsJsonArray("parts").get(0).getAsJsonObject().get("text").getAsString();
                  memory.add(new AIService.ChatMessage("assistant", content));
                  future.complete(content.trim());
               } catch (Exception var9) {
                  GeminiService.this.logger.warning("[Gemini] Parse error: " + var9.getMessage());
                  future.complete((Object)null);
                  return;
               } finally {
                  response.close();
               }

            }
         });
         return future;
      }
   }

   private String buildConversationText(LinkedList<AIService.ChatMessage> memory) {
      StringBuilder sb = new StringBuilder();

      for(AIService.ChatMessage msg : memory) {
         sb.append(msg.getRole()).append(": ").append(msg.getContent()).append("\n");
      }

      return sb.toString();
   }

   private JsonObject createTextPart(String text) {
      JsonObject part = new JsonObject();
      part.addProperty("text", text);
      return part;
   }

   public void clearMemory(String playerName) {
      this.conversationMemory.remove(playerName);
   }

   public void clearAllMemory() {
      this.conversationMemory.clear();
   }

   public CompletableFuture<String> getChatResponseStreamed(String playerName, String message, List<AIService.ChatMessage> conversationHistory, Consumer<String> chunkCallback, Runnable completeCallback) {
      CompletableFuture<String> future = this.getChatResponse(playerName, message, conversationHistory);
      if (completeCallback != null) {
         future.thenRun(completeCallback);
      }

      return future;
   }
}
