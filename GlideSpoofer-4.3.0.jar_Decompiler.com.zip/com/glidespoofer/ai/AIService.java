package com.glidespoofer.ai;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

public interface AIService {
   boolean isEnabled();

   CompletableFuture<String> getChatResponse(String var1, String var2, List<ChatMessage> var3);

   CompletableFuture<String> getChatResponseStreamed(String var1, String var2, List<ChatMessage> var3, Consumer<String> var4, Runnable var5);

   String getSystemPrompt(String var1);

   public static class ChatMessage {
      private final String role;
      private final String content;

      public ChatMessage(String role, String content) {
         this.role = role;
         this.content = content;
      }

      public String getRole() {
         return this.role;
      }

      public String getContent() {
         return this.content;
      }
   }
}
