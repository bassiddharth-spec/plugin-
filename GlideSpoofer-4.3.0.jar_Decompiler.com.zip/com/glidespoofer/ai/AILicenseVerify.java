package com.glidespoofer.ai;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.logging.Level;
import org.bukkit.plugin.java.JavaPlugin;

public class AILicenseVerify {
   private static final String API_BASE_URL = "http://licence.zabjelo.online/api";
   private static final String PRODUCT = "GLIDESPOOFER";
   private static final String PRODUCT_SECRET = "glidespoofer_ult_2024_secret";
   private static final int TIMEOUT_MILLIS = 15000;
   private static JavaPlugin pluginInstance;
   private static boolean isUnlimited = false;
   private static String deviceIdentifier;
   private static int messagesSent = 0;
   private static final Gson GSON = (new GsonBuilder()).disableHtmlEscaping().create();

   public static void init(JavaPlugin plugin) {
      pluginInstance = plugin;
      deviceIdentifier = getHardwareIdentifier();
   }

   public static boolean verifyAILicense(String licenseKey) {
      if (pluginInstance == null) {
         return false;
      } else if (licenseKey != null && !licenseKey.isEmpty() && !licenseKey.equals("your-ai-license-key-here") && !licenseKey.equals("none")) {
         try {
            JsonObject body = new JsonObject();
            body.addProperty("key", licenseKey);
            body.addProperty("product", "GLIDESPOOFER");
            body.addProperty("secret", "glidespoofer_ult_2024_secret");
            String urlString = "http://licence.zabjelo.online/api/licence/verify";
            URL url = URI.create(urlString).toURL();
            HttpURLConnection connection = (HttpURLConnection)url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("User-Agent", "GlideAI/1.0.0");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(15000);
            connection.setDoOutput(true);
            OutputStream os = connection.getOutputStream();

            try {
               byte[] input = body.toString().getBytes(StandardCharsets.UTF_8);
               os.write(input, 0, input.length);
            } catch (Throwable var26) {
               if (os != null) {
                  try {
                     os.close();
                  } catch (Throwable var25) {
                     var26.addSuppressed(var25);
                  }
               }

               throw var26;
            }

            if (os != null) {
               os.close();
            }

            int responseCode = connection.getResponseCode();

            boolean var13;
            try {
               InputStream is;
               label344: {
                  is = responseCode < 400 ? connection.getInputStream() : connection.getErrorStream();

                  boolean var33;
                  try {
                     label322: {
                        BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));

                        label294: {
                           try {
                              StringBuilder response = new StringBuilder();

                              String line;
                              while((line = br.readLine()) != null) {
                                 response.append(line);
                              }

                              if (responseCode == 200) {
                                 JsonObject json = (JsonObject)GSON.fromJson(response.toString(), JsonObject.class);
                                 boolean valid = json != null && json.has("valid") && json.get("valid").getAsBoolean();
                                 if (valid) {
                                    boolean isTrial = json.has("type") && "trial".equals(json.get("type").getAsString());
                                    isUnlimited = !isTrial;
                                    if (isUnlimited) {
                                       printAIUnlimited("Licence Key");
                                    } else {
                                       pluginInstance.getLogger().warning("[GlideAI] Trial licence detected. Using free tier (150 messages).");
                                    }

                                    var13 = isUnlimited;
                                    break label294;
                                 }
                              }

                              pluginInstance.getLogger().warning("[GlideAI] AI license verification failed. Using free tier (150 messages).");
                              var33 = false;
                           } catch (Throwable var27) {
                              try {
                                 br.close();
                              } catch (Throwable var24) {
                                 var27.addSuppressed(var24);
                              }

                              throw var27;
                           }

                           br.close();
                           break label322;
                        }

                        br.close();
                        break label344;
                     }
                  } catch (Throwable var28) {
                     if (is != null) {
                        try {
                           is.close();
                        } catch (Throwable var23) {
                           var28.addSuppressed(var23);
                        }
                     }

                     throw var28;
                  }

                  if (is != null) {
                     is.close();
                  }

                  return var33;
               }

               if (is != null) {
                  is.close();
               }
            } finally {
               connection.disconnect();
            }

            return var13;
         } catch (Exception var5) {
            pluginInstance.getLogger().log(Level.WARNING, "[GlideAI] Could not verify AI license: " + var5.getMessage());
            return false;
         }
      } else {
         return false;
      }
   }

   public static boolean isUnlimited() {
      return isUnlimited;
   }

   public static boolean unlockWithApiKey(String apiKey) {
      if (apiKey != null && !apiKey.isEmpty() && !apiKey.equals("your-glideai-api-key-here") && !apiKey.equals("YOUR_GLIDEAI_API_KEY_HERE")) {
         isUnlimited = true;
         printAIUnlimited("API Key");
         return true;
      } else {
         return false;
      }
   }

   public static int getMessageLimit() {
      return Integer.MAX_VALUE;
   }

   public static void incrementMessageCount() {
      ++messagesSent;
   }

   public static int getMessagesSent() {
      return messagesSent;
   }

   public static void resetMessageCount() {
      messagesSent = 0;
   }

   private static String getHardwareIdentifier() {
      try {
         String osName = System.getProperty("os.name");
         String osVersion = System.getProperty("os.version");
         String osArch = System.getProperty("os.arch");
         String hostname = InetAddress.getLocalHost().getHostName();
         String combinedIdentifier = osName + osVersion + osArch + hostname;
         return UUID.nameUUIDFromBytes(combinedIdentifier.getBytes()).toString();
      } catch (Exception var5) {
         return UUID.randomUUID().toString();
      }
   }

   private static void printAIUnlimited(String source) {
      pluginInstance.getLogger().info("╔════════════════════════════════════════════════════════════════╗");
      pluginInstance.getLogger().info("║                    GLIDEAI UNLIMITED ACTIVATED                            ║");
      pluginInstance.getLogger().info("╠════════════════════════════════════════════════════════════════╣");
      pluginInstance.getLogger().info("║  ✓ Unlimited AI Messages (via " + source + ")                            ║");
      pluginInstance.getLogger().info("║  ✓ No Rate Limits                                                         ║");
      pluginInstance.getLogger().info("║  ✓ Premium AI Features                                                    ║");
      pluginInstance.getLogger().info("╚════════════════════════════════════════════════════════════════╝");
   }
}
