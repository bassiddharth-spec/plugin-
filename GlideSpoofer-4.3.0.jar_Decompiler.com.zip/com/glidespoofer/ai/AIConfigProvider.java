package com.glidespoofer.ai;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

public interface AIConfigProvider {
   boolean isEnabled();

   Logger getLogger();

   String getOpenAIKey();

   String getOpenAIModel();

   String getGeminiKey();

   String getGeminiModel();

   String getGlideAIKey();

   String getGlideAIModel();

   default int getGlideAIMaxTokens() {
      return 100;
   }

   default double getGlideAITemperature() {
      return 0.85;
   }

   default int getGlideAIConnectTimeout() {
      return 5;
   }

   default int getGlideAIWriteTimeout() {
      return 10;
   }

   default int getGlideAIReadTimeout() {
      return 15;
   }

   default int getGlideAIMaxConcurrentRequests() {
      return 3;
   }

   default int getGlideAIMinRequestInterval() {
      return 2000;
   }

   default int getResponseTimeoutTicks() {
      return 100;
   }

   String getSystemPrompt();

   String getSystemPrompt(String var1);

   String getContextBoost();

   String getLanguage();

   int getMaxTokens();

   double getTemperature();

   int getMemorySize();

   String getTriggerMode();

   List<String> getTriggerKeywords();

   default List<String> getBlacklistWords() {
      return Collections.emptyList();
   }

   double getResponseChance();

   int getMinResponseDelay();

   int getMaxResponseDelay();

   long getChatCooldown();

   boolean isAutoChatEnabled();

   int getAutoChatInterval();

   double getAutoChatChance();

   List<String> getAutoChatTopics();

   boolean isAiToAiChatEnabled();

   int getAiToAiChatInterval();

   default List<String> getAiToAiTopics() {
      return Collections.emptyList();
   }

   default List<String> getAiToAiConversationStarters() {
      return Arrays.asList("{target} yo", "{target} sup", "yo {target}", "{target} wanna pvp", "{target} what u doing", "hey {target}", "{target} u there");
   }

   default int getAiToAiMinChainLength() {
      return 2;
   }

   default int getAiToAiMaxChainLength() {
      return 5;
   }

   default int getAiToAiMinReplyDelay() {
      return 40;
   }

   default int getAiToAiMaxReplyDelay() {
      return 100;
   }

   default List<String> getAiToAiFollowUpResponses() {
      return Arrays.asList("yeah", "true", "fr", "same", "valid", "bet", "nah", "idk", "lol", "lmao", "nice", "bruh", "oof", "rip", "ok", "k");
   }

   default List<String> getFallbackMentionResponses() {
      return Arrays.asList("yeah?", "yo", "sup", "what", "hm?", "?", "yea", "whats up", "im here", "ye?", "wut", "huh");
   }

   default List<String> getFallbackQuestionResponses() {
      return Arrays.asList("idk", "not sure", "maybe", "i think so", "prob", "no idea", "hmm idk", "yea i think", "nope", "yeah", "nah");
   }

   default List<String> getFallbackGreetingResponses() {
      return Arrays.asList("yo", "hey", "sup", "hi", "heyo", "ay", "yoo", "heyy", "wassup", "ayy", "ayo", "whats good");
   }

   default List<String> getFallbackGeneralResponses() {
      return Arrays.asList("lol", "true", "same", "nice", "cool", "oh", "haha", "yea", "nah", "ok", "maybe");
   }

   default List<String> getFallbackAiToAiResponses() {
      return Arrays.asList("yo", "sup", "hey", "yeah", "nah", "lol", "bet", "ok", "k", "yea", "no", "maybe", "idk");
   }

   default List<String> getFallbackAutoChatMessages() {
      return Arrays.asList("gg", "nice", "bored", "brb", "back", "finally", "lol", "sup", "yo");
   }

   String getChatFormat();

   List<String> getFakePlayerNames();

   boolean isFakePlayer(String var1);

   void broadcastChat(String var1, String var2);

   void scheduleSyncTask(Runnable var1);

   void scheduleSyncTask(Runnable var1, long var2);
}
