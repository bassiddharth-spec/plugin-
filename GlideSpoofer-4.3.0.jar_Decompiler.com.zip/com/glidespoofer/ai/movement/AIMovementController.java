package com.glidespoofer.ai.movement;

import com.glidespoofer.ai.MovementAIService;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Logger;
import org.bukkit.Location;
import org.bukkit.util.Vector;

public class AIMovementController {
   private final Logger logger;
   private final MovementAIService aiService;
   private long lastAIDecisionTime = 0L;
   private static final long AI_DECISION_COOLDOWN = 2000L;
   private MovementState currentState;
   private Location currentTarget;
   private boolean sprinting = false;
   private Location currentLocation;

   public AIMovementController(Logger logger, MovementAIService aiService, Location location) {
      this.logger = logger;
      this.aiService = aiService;
      this.currentLocation = location != null ? location.clone() : null;
      this.currentState = AIMovementController.MovementState.IDLE;
   }

   public CompletableFuture<MovementDecision> decideNextAction(Location currentLoc) {
      this.currentLocation = currentLoc != null ? currentLoc.clone() : null;
      long now = System.currentTimeMillis();
      boolean useAI = now - this.lastAIDecisionTime >= 2000L;
      if (useAI && this.aiService != null && this.aiService.isEnabled()) {
         this.lastAIDecisionTime = now;
         String context = this.buildMovementContext(currentLoc);
         return this.aiService.getMovementDecision(currentLoc.getBlock().toString(), context).thenApply((aiDecision) -> aiDecision != null ? this.convertAIDecision(aiDecision, currentLoc) : this.fallbackDecision(currentLoc));
      } else {
         return CompletableFuture.completedFuture(this.fallbackDecision(currentLoc));
      }
   }

   private String buildMovementContext(Location loc) {
      StringBuilder context = new StringBuilder();
      context.append("Position: X=").append((double)Math.round(loc.getX() * (double)10.0F) / (double)10.0F).append(" Y=").append(loc.getBlockY()).append(" Z=").append((double)Math.round(loc.getZ() * (double)10.0F) / (double)10.0F);
      context.append(", On: ").append(loc.getBlock().getType().name());
      context.append(", Below: ").append(loc.clone().add((double)0.0F, (double)-1.0F, (double)0.0F).getBlock().getType().name());
      context.append("\nCurrentState: ").append(this.currentState);
      return context.toString();
   }

   private MovementDecision convertAIDecision(MovementAIService.MovementDecision aiDecision, Location currentLoc) {
      String action = aiDecision.getAction().toLowerCase();
      int duration = aiDecision.getDuration();
      MovementDecision decision = new MovementDecision();
      decision.action = action;
      decision.duration = duration;
      decision.physicallyPossible = true;
      this.currentState = this.interpretState(action);
      return decision;
   }

   private MovementDecision fallbackDecision(Location currentLoc) {
      MovementDecision decision = new MovementDecision();
      decision.physicallyPossible = true;
      decision.override = false;
      double random = Math.random();
      if (random < 0.6) {
         decision.action = "walk";
         decision.duration = 60 + (int)(Math.random() * (double)40.0F);
      } else if (random < 0.8) {
         decision.action = "idle";
         decision.duration = 40;
      } else {
         decision.action = "look";
         decision.duration = 20;
      }

      this.currentState = this.interpretState(decision.action);
      return decision;
   }

   private Vector getFacingDirection(Location loc) {
      float yaw = loc.getYaw();
      double radians = Math.toRadians((double)(-yaw));
      double x = Math.sin(radians);
      double z = Math.cos(radians);
      return (new Vector(x, (double)0.0F, z)).normalize();
   }

   private MovementState interpretState(String action) {
      switch (action.toLowerCase()) {
         case "walk":
         case "wander":
            return AIMovementController.MovementState.WALKING;
         case "jump":
            return AIMovementController.MovementState.JUMPING;
         case "swim":
            return AIMovementController.MovementState.SWIMMING;
         case "look":
            return AIMovementController.MovementState.LOOKING;
         case "idle":
         default:
            return AIMovementController.MovementState.IDLE;
      }
   }

   public Location executeMovement(MovementDecision decision, Location currentLoc) {
      if (decision == null) {
         return currentLoc;
      } else {
         Location newLoc = currentLoc.clone();
         switch (decision.action.toLowerCase()) {
            case "walk":
            case "wander":
               Vector forward = this.getFacingDirection(currentLoc);
               double speed = this.sprinting ? 0.13 : 0.1;
               newLoc.add(forward.multiply(speed));
               break;
            case "jump":
               Vector jumpDir = this.getFacingDirection(currentLoc);
               newLoc.add(jumpDir.multiply(0.2));
               newLoc.setY(newLoc.getY() + 0.1);
               break;
            case "drop":
               Vector dropDir = this.getFacingDirection(currentLoc);
               newLoc.add(dropDir.multiply(0.3));
               break;
            case "swim":
               Vector swimDir = this.getFacingDirection(currentLoc);
               newLoc.add(swimDir.multiply(0.04));
            case "idle":
            case "look":
         }

         return newLoc;
      }
   }

   public void updateLocation(Location newLoc) {
      this.currentLocation = newLoc != null ? newLoc.clone() : null;
   }

   public MovementState getCurrentState() {
      return this.currentState;
   }

   public boolean isSprinting() {
      return this.sprinting;
   }

   public void setSprinting(boolean sprinting) {
      this.sprinting = sprinting;
   }

   public static class MovementDecision {
      public String action = "idle";
      public int duration = 40;
      public String reason = "";
      public boolean physicallyPossible = true;
      public boolean override = false;
      public double targetX = (double)0.0F;
      public double targetY = (double)0.0F;
      public double targetZ = (double)0.0F;

      public String toString() {
         return "MovementDecision{action='" + this.action + "', duration=" + this.duration + ", reason='" + this.reason + "', override=" + this.override + "}";
      }
   }

   public static enum MovementState {
      IDLE,
      WALKING,
      SPRINTING,
      JUMPING,
      FALLING,
      SWIMMING,
      CLIMBING,
      LOOKING;

      // $FF: synthetic method
      private static MovementState[] $values() {
         return new MovementState[]{IDLE, WALKING, SPRINTING, JUMPING, FALLING, SWIMMING, CLIMBING, LOOKING};
      }
   }
}
