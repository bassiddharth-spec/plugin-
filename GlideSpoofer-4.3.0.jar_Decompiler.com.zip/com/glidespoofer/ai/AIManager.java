package com.glidespoofer.ai;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.FakeChatManager;
import com.glidespoofer.nms.SimpleNMSHandler;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class AIManager implements AIConfigProvider, Listener {
   private final AIService aiService;
   private AIConfigProvider configProvider;
   private boolean enabled;
   private String triggerMode;
   private Set<String> triggerKeywords;
   private Set<String> blacklistWords;
   private double responseChance;
   private int minResponseDelay;
   private int maxResponseDelay;
   private long chatCooldown;
   private String chatFormat;
   private boolean autoChatEnabled;
   private int autoChatInterval;
   private double autoChatChance;
   private List<String> autoChatTopics;
   private boolean aiToAiChatEnabled;
   private int aiToAiChatInterval;
   private List<String> aiToAiTopics;
   private List<String> aiToAiConversationStarters;
   private final Map<String, Long> lastChatTime = new ConcurrentHashMap();
   private final Map<String, Long> lastMentionTime = new ConcurrentHashMap();
   private final Map<String, AtomicBoolean> pendingResponse = new ConcurrentHashMap();
   private final Map<String, Map<String, Integer>> mentionMemory = new ConcurrentHashMap();
   private static final int MENTION_MEMORY_COUNT = 10;
   private final Map<String, Map<String, List<String>>> conversationHistory = new ConcurrentHashMap();
   private static final int CONVERSATION_HISTORY_SIZE = 15;
   private final Map<String, Integer> aiToAiConversations = new ConcurrentHashMap();
   private final Map<String, List<String>> aiToAiHistory = new ConcurrentHashMap();
   private static final int AI_TO_AI_CONV_LENGTH = 10;
   private static final int AI_TO_AI_HISTORY_SIZE = 6;
   private final Map<String, List<String>> chatHistory = new ConcurrentHashMap();
   private final Map<String, String> lastSpeaker = new ConcurrentHashMap();
   private static final int MAX_HISTORY = 20;
   private final Plugin pluginRef;
   private final FakePlayerAccessor fakePlayerAccessor;
   private final FakeChatManager fakeChatManager;
   private Object autoChatTask;
   private Object aiToAiTask;
   private String systemPrompt;
   private String contextBoost;
   private String language;
   private final Map<String, String> playerPersonalities = new ConcurrentHashMap();
   private boolean interactiveChatEnabled;

   public AIManager(Object plugin, FakePlayerAccessor fakePlayerAccessor, AIConfigProvider configProvider, FakeChatManager fakeChatManager) {
      this.pluginRef = (Plugin)plugin;
      this.fakePlayerAccessor = fakePlayerAccessor;
      this.fakeChatManager = fakeChatManager;
      this.configProvider = configProvider;
      this.enabled = configProvider.isEnabled();
      this.triggerMode = configProvider.getTriggerMode();
      this.responseChance = configProvider.getResponseChance();
      this.minResponseDelay = configProvider.getMinResponseDelay();
      this.maxResponseDelay = configProvider.getMaxResponseDelay();
      this.chatCooldown = configProvider.getChatCooldown();
      this.chatFormat = configProvider.getChatFormat();
      this.triggerKeywords = new HashSet(configProvider.getTriggerKeywords());
      this.blacklistWords = new HashSet();

      try {
         List<String> blacklist = configProvider.getBlacklistWords();
         if (blacklist != null) {
            for(String word : blacklist) {
               this.blacklistWords.add(word.toLowerCase());
            }
         }
      } catch (Exception var9) {
         this.blacklistWords.addAll(Arrays.asList("spam", "hack", "cheat"));
      }

      this.autoChatEnabled = configProvider.isAutoChatEnabled();
      this.autoChatInterval = configProvider.getAutoChatInterval();
      this.autoChatChance = configProvider.getAutoChatChance();
      this.autoChatTopics = configProvider.getAutoChatTopics();
      this.aiToAiChatEnabled = configProvider.isAiToAiChatEnabled();
      this.aiToAiChatInterval = configProvider.getAiToAiChatInterval();
      this.aiToAiTopics = configProvider.getAiToAiTopics();
      this.aiToAiConversationStarters = configProvider.getAiToAiConversationStarters();
      this.systemPrompt = configProvider.getSystemPrompt();
      this.contextBoost = configProvider.getContextBoost();
      this.language = configProvider.getLanguage();
      this.loadPlayerPersonalities();
      this.interactiveChatEnabled = Bukkit.getPluginManager().getPlugin("InteractiveChat") != null;
      if (this.interactiveChatEnabled && SimpleNMSHandler.isDebugMode()) {
         this.getLogger().info("[AI] InteractiveChat detected");
      }

      String provider = "glideai";
      switch (provider.toLowerCase()) {
         case "gemini":
            this.aiService = new GeminiService(this);
            break;
         case "glideai":
            this.aiService = new GlideAIService(this);
            break;
         case "openai":
         default:
            this.aiService = new OpenAIService(this);
      }

      if (this.aiService.isEnabled()) {
         if (SimpleNMSHandler.isDebugMode()) {
            this.getLogger().info("[AI] AI Chat enabled with provider: " + provider);
         }

         Bukkit.getPluginManager().registerEvents(this, this.pluginRef);
      } else {
         this.getLogger().warning("[AI] AI Chat disabled - no valid API key");
      }

      if (this.enabled && this.aiService.isEnabled()) {
         if (this.autoChatEnabled) {
            this.startAutoChatTask();
         }

         if (this.aiToAiChatEnabled) {
            this.startAiToAiChatTask();
         }
      }

   }

   public void reload() {
      if (this.configProvider != null) {
         this.stopAutoChatTask();
         this.stopAiToAiTask();
         this.enabled = this.configProvider.isEnabled();
         this.triggerMode = this.configProvider.getTriggerMode();
         this.responseChance = this.configProvider.getResponseChance();
         this.minResponseDelay = this.configProvider.getMinResponseDelay();
         this.maxResponseDelay = this.configProvider.getMaxResponseDelay();
         this.chatCooldown = this.configProvider.getChatCooldown();
         this.chatFormat = this.configProvider.getChatFormat();
         this.triggerKeywords = new HashSet(this.configProvider.getTriggerKeywords());
         this.blacklistWords = new HashSet();

         try {
            List<String> blacklist = this.configProvider.getBlacklistWords();
            if (blacklist != null) {
               for(String word : blacklist) {
                  this.blacklistWords.add(word.toLowerCase());
               }
            }
         } catch (Exception var4) {
            this.blacklistWords.addAll(Arrays.asList("spam", "hack", "cheat"));
         }

         this.autoChatEnabled = this.configProvider.isAutoChatEnabled();
         this.autoChatInterval = this.configProvider.getAutoChatInterval();
         this.autoChatChance = this.configProvider.getAutoChatChance();
         this.autoChatTopics = this.configProvider.getAutoChatTopics();
         this.aiToAiChatEnabled = this.configProvider.isAiToAiChatEnabled();
         this.aiToAiChatInterval = this.configProvider.getAiToAiChatInterval();
         this.aiToAiTopics = this.configProvider.getAiToAiTopics();
         this.aiToAiConversationStarters = this.configProvider.getAiToAiConversationStarters();
         this.systemPrompt = this.configProvider.getSystemPrompt();
         this.contextBoost = this.configProvider.getContextBoost();
         this.language = this.configProvider.getLanguage();
         if (this.enabled && this.aiService != null && this.aiService.isEnabled()) {
            if (this.autoChatEnabled) {
               this.startAutoChatTask();
            }

            if (this.aiToAiChatEnabled) {
               this.startAiToAiChatTask();
            }
         }

         if (SimpleNMSHandler.isDebugMode()) {
            this.getLogger().info("[AI] Reloaded settings - enabled: " + this.enabled + ", autoChat: " + this.autoChatEnabled + ", aiToAi: " + this.aiToAiChatEnabled + ", language: " + this.language);
         }
      }

   }

   private void loadPlayerPersonalities() {
      try {
         Object configManager = this.pluginRef.getClass().getMethod("getConfigManager").invoke(this.pluginRef);
         if (configManager != null) {
            Method getPersonalityMethod = configManager.getClass().getMethod("getFakePlayerPersonality", String.class);

            for(String fakeName : this.fakePlayerAccessor.getAllFakePlayerNames()) {
               try {
                  String personality = (String)getPersonalityMethod.invoke(configManager, fakeName);
                  if (personality != null && !personality.isEmpty()) {
                     this.playerPersonalities.put(fakeName.toLowerCase(), personality);
                  }
               } catch (Exception var6) {
               }
            }
         }
      } catch (Exception var7) {
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onPlayerChat(AsyncPlayerChatEvent event) {
      if (this.enabled && this.aiService != null && this.aiService.isEnabled()) {
         Player sender = event.getPlayer();
         String message = event.getMessage();
         String senderName = sender.getName();
         if (!this.fakePlayerAccessor.isFakePlayer(sender)) {
            this.trackChat(senderName, message);
            if (!this.containsBlacklistedWord(message)) {
               List<String> onlineFakes = new ArrayList(this.fakePlayerAccessor.getAllFakePlayerNames());
               if (!onlineFakes.isEmpty()) {
                  for(String fakeName : onlineFakes) {
                     this.addToConversationHistory(fakeName, senderName, senderName, message);
                  }

                  String lowerMessage = message.toLowerCase();
                  String mentionedFake = null;

                  for(String fakeName : onlineFakes) {
                     String lowerFakeName = fakeName.toLowerCase();
                     if (lowerMessage.contains("@" + lowerFakeName) || lowerMessage.startsWith(lowerFakeName + " ") || lowerMessage.startsWith(lowerFakeName + ",") || lowerMessage.equals(lowerFakeName) || lowerMessage.contains(" " + lowerFakeName + " ") || lowerMessage.endsWith(" " + lowerFakeName)) {
                        mentionedFake = fakeName;
                        break;
                     }
                  }

                  switch (this.triggerMode.toLowerCase()) {
                     case "mention":
                        if (mentionedFake != null) {
                           this.respondToMention(mentionedFake, senderName, message);
                        }
                        break;
                     case "keyword":
                        if (mentionedFake != null) {
                           this.respondToMention(mentionedFake, senderName, message);
                        } else {
                           for(String keyword : this.triggerKeywords) {
                              if (lowerMessage.contains(keyword.toLowerCase())) {
                                 String responder = this.pickRandomResponder(onlineFakes, senderName);
                                 if (responder != null) {
                                    this.respondToGeneral(responder, senderName, message);
                                 }

                                 return;
                              }
                           }
                        }
                        break;
                     case "direct":
                        if (mentionedFake != null) {
                           String firstWord = lowerMessage.split(" ")[0].replace("@", "");
                           if (mentionedFake.toLowerCase().equals(firstWord)) {
                              this.respondToMention(mentionedFake, senderName, message);
                           }
                        }
                        break;
                     case "auto":
                        if (ThreadLocalRandom.current().nextDouble() < this.responseChance) {
                           String responder = this.pickRandomResponder(onlineFakes, senderName);
                           if (responder != null) {
                              this.respondToGeneral(responder, senderName, message);
                           }
                        }
                        break;
                     case "all":
                        if (mentionedFake != null) {
                           this.clearMentionMemoryForSender(senderName);
                           this.setMentionMemory(mentionedFake, senderName);
                           this.respondToMention(mentionedFake, senderName, message);
                        } else {
                           String memoryResponder = this.getMentionMemoryResponder(senderName, onlineFakes);
                           if (memoryResponder != null) {
                              this.respondToGeneral(memoryResponder, senderName, message);
                              this.decrementMentionMemory(memoryResponder, senderName);
                           }

                           int extraResponders = 1 + ThreadLocalRandom.current().nextInt(2);
                           List<String> available = new ArrayList(onlineFakes);
                           Collections.shuffle(available);

                           for(int i = 0; i < extraResponders && i < available.size(); ++i) {
                              String responder = (String)available.get(i);
                              if (memoryResponder == null || !responder.equals(memoryResponder)) {
                                 Long lastChat = (Long)this.lastChatTime.get(responder);
                                 long now = System.currentTimeMillis();
                                 if ((lastChat == null || now - lastChat > 200L) && ThreadLocalRandom.current().nextDouble() < (double)1.0F) {
                                    this.respondToGeneral(responder, senderName, message);
                                 }
                              }
                           }
                        }
                        break;
                     default:
                        if (ThreadLocalRandom.current().nextDouble() < this.responseChance) {
                           String defaultResponder = this.pickRandomResponder(onlineFakes, senderName);
                           if (defaultResponder != null) {
                              this.respondToGeneral(defaultResponder, senderName, message);
                           }
                        }
                  }
               }
            }
         }
      }

   }

   private String pickRandomResponder(List<String> fakes, String exclude) {
      List<String> available = new ArrayList();
      long now = System.currentTimeMillis();

      for(String fake : fakes) {
         Long lastChat = (Long)this.lastChatTime.get(fake);
         if (lastChat == null || now - lastChat > 500L) {
            available.add(fake);
         }
      }

      return available.isEmpty() ? null : (String)available.get(ThreadLocalRandom.current().nextInt(available.size()));
   }

   private void respondToMention(String fakeName, String sender, String message) {
      AtomicBoolean oldFlag = (AtomicBoolean)this.pendingResponse.get(fakeName);
      if (oldFlag != null) {
         oldFlag.set(false);
      }

      this.pendingResponse.put(fakeName, new AtomicBoolean(true));
      String cleanMessage = message.toLowerCase().replace("@" + fakeName.toLowerCase(), "").replace(fakeName.toLowerCase(), "").trim();
      int delay = 10 + ThreadLocalRandom.current().nextInt(30);
      this.scheduleSyncTask(() -> {
         AtomicBoolean flag = (AtomicBoolean)this.pendingResponse.get(fakeName);
         if (flag != null && flag.get()) {
            try {
               if (this.canMakeApiCall()) {
                  String prompt = this.buildConversationalPrompt(fakeName, sender, cleanMessage.isEmpty() ? message : cleanMessage);
                  this.getAIResponse(fakeName, prompt, sender);
               } else {
                  String response = this.getQuickMentionResponse(sender);
                  this.broadcastChat(fakeName, response);
                  this.lastChatTime.put(fakeName, System.currentTimeMillis());
               }
            } finally {
               this.pendingResponse.remove(fakeName);
            }
         } else if (SimpleNMSHandler.isDebugMode()) {
            this.getLogger().info("[AI] Response to " + fakeName + " was cancelled by newer message");
         }

      }, (long)delay);
   }

   private String buildConversationalPrompt(String fakeName, String sender, String message) {
      StringBuilder prompt = new StringBuilder();
      List<String> history = this.getConversationHistory(fakeName, sender);
      if (!history.isEmpty()) {
         prompt.append("You are ").append(fakeName).append(", talking to ").append(sender).append(".\n\n");
         prompt.append("Your recent conversation:\n");

         for(String msg : history) {
            prompt.append(msg).append("\n");
         }

         prompt.append("\n");
      }

      prompt.append(sender).append(" said: \"").append(message).append("\"");
      return prompt.toString();
   }

   private String buildAiToAiPrompt(String fromPlayer, String toPlayer, String message) {
      return fromPlayer + " said: \"" + message + "\"";
   }

   private String buildAiToAiPromptWithContext(String convKey, String speaker, String other, String lastMessage) {
      StringBuilder prompt = new StringBuilder();
      if (convKey != null) {
         List<String> history = (List)this.aiToAiHistory.get(convKey);
         if (history != null && !history.isEmpty()) {
            prompt.append("Conversation:\n");
            int start = Math.max(0, history.size() - 6);

            for(int i = start; i < history.size(); ++i) {
               prompt.append((String)history.get(i)).append("\n");
            }

            prompt.append("\n");
         }
      }

      prompt.append(other).append(" said: \"").append(lastMessage).append("\"");
      return prompt.toString();
   }

   private void respondToQuestion(String fakeName, String sender, String message) {
      int delay = 40 + ThreadLocalRandom.current().nextInt(80);
      this.scheduleSyncTask(() -> {
         if (this.canMakeApiCall()) {
            String prompt = sender + " asked: \"" + message + "\"";
            this.getAIResponse(fakeName, prompt, sender);
         } else {
            String response = this.getQuickQuestionResponse();
            this.broadcastChat(fakeName, response);
            this.lastChatTime.put(fakeName, System.currentTimeMillis());
         }

      }, (long)delay);
   }

   private void respondToGreeting(String fakeName, String sender, String message) {
      int delay = 5 + ThreadLocalRandom.current().nextInt(11);
      this.scheduleSyncTask(() -> {
         if (this.canMakeApiCall()) {
            String prompt = sender + " greeted: \"" + message + "\"";
            this.getAIResponse(fakeName, prompt, sender);
         } else {
            String response = this.getGreetingResponse(sender);
            this.broadcastChat(fakeName, response);
            this.lastChatTime.put(fakeName, System.currentTimeMillis());
         }

      }, (long)delay);
   }

   private void respondToGeneral(String fakeName, String sender, String message) {
      AtomicBoolean existingFlag = (AtomicBoolean)this.pendingResponse.get(fakeName);
      if (existingFlag != null && existingFlag.get()) {
         if (SimpleNMSHandler.isDebugMode()) {
            this.getLogger().info("[AI] Skipping general response from " + fakeName + " - already has pending response");
         }
      } else {
         this.pendingResponse.put(fakeName, new AtomicBoolean(true));
         int delay = 10 + ThreadLocalRandom.current().nextInt(50);
         this.scheduleSyncTask(() -> {
            AtomicBoolean flag = (AtomicBoolean)this.pendingResponse.get(fakeName);
            if (flag != null && flag.get()) {
               try {
                  if (this.canMakeApiCall()) {
                     String prompt = this.buildConversationalPrompt(fakeName, sender, message);
                     this.getAIResponse(fakeName, prompt, sender);
                  } else {
                     String response = this.getGeneralResponse();
                     this.broadcastChat(fakeName, response);
                     this.lastChatTime.put(fakeName, System.currentTimeMillis());
                  }
               } finally {
                  this.pendingResponse.remove(fakeName);
               }
            }

         }, (long)delay);
      }

   }

   private boolean canMakeApiCall() {
      return this.aiService.isEnabled();
   }

   private void getAIResponse(String fakeName, String prompt, String sender) {
      AtomicBoolean responseSent = new AtomicBoolean(false);
      this.aiService.getChatResponseStreamed(fakeName, prompt, (List)null, (chunk) -> {
      }, () -> {
      }).thenAccept((response) -> {
         if (response != null && !response.isEmpty() && !responseSent.get()) {
            String cleaned = this.cleanResponse(response);
            if (!cleaned.isEmpty()) {
               responseSent.set(true);
               this.scheduleSyncTask(() -> {
                  this.broadcastChat(fakeName, cleaned);
                  this.lastChatTime.put(fakeName, System.currentTimeMillis());
                  this.trackChat(fakeName, cleaned);
                  if (sender != null) {
                     this.addToConversationHistory(fakeName, sender, fakeName, cleaned);
                  }

               }, 0L);
               return;
            }
         }

         if (!responseSent.get()) {
            responseSent.set(true);
            this.sendFallbackResponse(fakeName, prompt, sender);
         }

      }).exceptionally((ex) -> {
         this.getLogger().warning("[AI] Error: " + ex.getMessage() + " - sending fallback");
         if (!responseSent.get()) {
            responseSent.set(true);
            this.sendFallbackResponse(fakeName, prompt, sender);
         }

         return null;
      });
      int quickTimeoutTicks = this.getResponseTimeoutTicks();
      this.scheduleSyncTask(() -> {
         if (!responseSent.get()) {
            responseSent.set(true);
            if (SimpleNMSHandler.isDebugMode()) {
               this.getLogger().info("[AI] Quick timeout - sending fallback for " + fakeName);
            }

            String quickResponse = this.getContextualFallback(prompt);
            this.broadcastChat(fakeName, quickResponse);
            this.lastChatTime.put(fakeName, System.currentTimeMillis());
            if (sender != null) {
               this.addToConversationHistory(fakeName, sender, fakeName, quickResponse);
            }
         }

      }, (long)quickTimeoutTicks);
   }

   private void sendFallbackResponse(String fakeName, String originalMessage, String sender) {
      String response = this.getContextualFallback(originalMessage);
      this.scheduleSyncTask(() -> {
         this.broadcastChat(fakeName, response);
         this.lastChatTime.put(fakeName, System.currentTimeMillis());
         if (sender != null) {
            this.addToConversationHistory(fakeName, sender, fakeName, response);
         }

      }, 0L);
   }

   private String getContextualFallback(String prompt) {
      if (prompt != null && !prompt.isEmpty()) {
         String actualMessage = prompt;
         int quoteStart = prompt.indexOf(34);
         if (quoteStart != -1) {
            int quoteEnd = prompt.indexOf(34, quoteStart + 1);
            if (quoteEnd != -1) {
               actualMessage = prompt.substring(quoteStart + 1, quoteEnd);
            }
         }

         String lower = actualMessage.toLowerCase();
         boolean isQuestion = lower.contains("?") || lower.startsWith("who ") || lower.startsWith("what ") || lower.startsWith("where ") || lower.startsWith("when ") || lower.startsWith("why ") || lower.startsWith("how ") || lower.startsWith("is ") || lower.startsWith("are ") || lower.startsWith("do ") || lower.startsWith("does ") || lower.startsWith("did ") || lower.startsWith("can ") || lower.startsWith("could ") || lower.startsWith("would ") || lower.startsWith("will ") || lower.startsWith("should ") || lower.startsWith("have ") || lower.startsWith("you ") || lower.startsWith("your ");
         if (!isQuestion) {
            if (this.isGreeting(lower)) {
               return this.getGreetingResponse("bro");
            } else if (!lower.contains("trash") && !lower.contains("bad") && !lower.contains("suck") && !lower.contains("noob")) {
               return this.getGeneralResponse();
            } else {
               String[] responses = new String[]{"u too", "takes one to know one", "sure", "ok", "lol", "whatever", "and?"};
               return responses[ThreadLocalRandom.current().nextInt(responses.length)];
            }
         } else if (!lower.contains("kids") && !lower.contains("children") && !lower.contains("son") && !lower.contains("daughter") && !lower.contains("child")) {
            if (!lower.contains("age") && !lower.contains("old")) {
               if (!lower.contains("where") || !lower.contains("live") && !lower.contains("from") && !lower.contains("at") && !lower.contains("located")) {
                  if (!lower.contains("doing") && !lower.contains("up to") && !lower.contains("up to?")) {
                     if (!lower.contains("want") && !lower.contains("wanna")) {
                        String[] questionResponses = new String[]{"idk", "maybe", "not sure", "why", "what do u think", "dunno", "probably", "no idea"};
                        return questionResponses[ThreadLocalRandom.current().nextInt(questionResponses.length)];
                     } else {
                        String[] responses = new String[]{"sure", "maybe", "nah", "idk", "what", "depends", "yea why not"};
                        return responses[ThreadLocalRandom.current().nextInt(responses.length)];
                     }
                  } else {
                     String[] responses = new String[]{"nothing", "chilling", "just playing", "stuff", "minecraft lol", "grinding"};
                     return responses[ThreadLocalRandom.current().nextInt(responses.length)];
                  }
               } else {
                  String[] responses = new String[]{"home", "spawn", "my base", "here", "around", "why u ask", "none of ur business"};
                  return responses[ThreadLocalRandom.current().nextInt(responses.length)];
               }
            } else {
               String[] responses = new String[]{"16", "17", "18", "19", "15", "why", "old enough", "none of ur business", "idk", "young"};
               return responses[ThreadLocalRandom.current().nextInt(responses.length)];
            }
         } else {
            String[] responses = new String[]{"nah", "no", "dont have any", "too young lol", "maybe someday", "no kids yet", "not yet"};
            return responses[ThreadLocalRandom.current().nextInt(responses.length)];
         }
      } else {
         return this.getGeneralResponse();
      }
   }

   private String cleanResponse(String response) {
      if (response == null) {
         return "";
      } else {
         response = response.trim();
         if (response.startsWith("\"") && response.endsWith("\"") || response.startsWith("'") && response.endsWith("'")) {
            response = response.substring(1, response.length() - 1);
         }

         response = response.replaceAll("\\*[^*]+\\*", "").trim();
         response = response.replaceAll("(?i)^(sure|of course|certainly|I'd be happy to|I can help|I think)[,!.]?\\s*", "");
         response = response.replaceAll("(?i)^(well|so|okay so|alright|let me)[,]?\\s*", "");

         for(response = response.replaceAll("(?i)^(hey there|hello there|hi there)[,!]?\\s*", ""); response.endsWith(".") && !response.endsWith("..."); response = response.substring(0, response.length() - 1).trim()) {
         }

         response = response.replaceAll("(?i)^(my response:?|response:?|answer:?)\\s*", "");
         if (response.length() > 2000) {
            int space = response.lastIndexOf(32, 2000);
            if (space > 100) {
               response = response.substring(0, space);
            } else {
               response = response.substring(0, 1997) + "...";
            }
         }

         if (ThreadLocalRandom.current().nextDouble() < 0.8) {
            StringBuilder result = new StringBuilder();
            String[] words = response.split(" ");

            for(int i = 0; i < words.length; ++i) {
               String word = words[i];
               if (word.equals(word.toUpperCase()) && word.length() >= 2 && word.matches("(LMAO|LOL|BRO|BRUH|WHAT|WTF|OMG|RIP|GG|NO|YES|WAIT|HUH).*")) {
                  result.append(word);
               } else {
                  result.append(word.toLowerCase());
               }

               if (i < words.length - 1) {
                  result.append(" ");
               }
            }

            response = result.toString();
         }

         response = response.replaceAll("[.!?]+$", "").trim();
         return response.trim();
      }
   }

   private String getQuickMentionResponse(String sender) {
      List<String> responses = this.getFallbackMentionResponses();
      return responses != null && !responses.isEmpty() ? (String)responses.get(ThreadLocalRandom.current().nextInt(responses.size())) : "yeah?";
   }

   private String getQuickQuestionResponse() {
      List<String> responses = this.getFallbackQuestionResponses();
      return responses != null && !responses.isEmpty() ? (String)responses.get(ThreadLocalRandom.current().nextInt(responses.size())) : "idk";
   }

   private String getGreetingResponse(String sender) {
      List<String> responses = this.getFallbackGreetingResponses();
      return responses != null && !responses.isEmpty() ? (String)responses.get(ThreadLocalRandom.current().nextInt(responses.size())) : "yo";
   }

   private String getGeneralResponse() {
      List<String> responses = this.getFallbackGeneralResponses();
      return responses != null && !responses.isEmpty() ? (String)responses.get(ThreadLocalRandom.current().nextInt(responses.size())) : "lol";
   }

   private String getQuickAiToAiResponse() {
      List<String> responses = this.getFallbackAiToAiResponses();
      return responses != null && !responses.isEmpty() ? (String)responses.get(ThreadLocalRandom.current().nextInt(responses.size())) : "yo";
   }

   private void setMentionMemory(String fakeName, String senderName) {
      ((Map)this.mentionMemory.computeIfAbsent(fakeName, (k) -> new ConcurrentHashMap())).put(senderName, 10);
      if (SimpleNMSHandler.isDebugMode()) {
         this.getLogger().info("[AI] Mention memory set: " + fakeName + " will respond to next 10 messages from " + senderName);
      }

   }

   private void clearMentionMemoryForSender(String senderName) {
      for(Map.Entry<String, Map<String, Integer>> entry : this.mentionMemory.entrySet()) {
         Map<String, Integer> playerMemory = (Map)entry.getValue();
         if (playerMemory.remove(senderName) != null) {
            if (SimpleNMSHandler.isDebugMode()) {
               Logger var10000 = this.getLogger();
               String var10001 = (String)entry.getKey();
               var10000.info("[AI] Cleared mention memory for " + var10001 + " from " + senderName + " (new fake mentioned)");
            }

            if (playerMemory.isEmpty()) {
               this.mentionMemory.remove(entry.getKey());
            }
         }
      }

   }

   private String getMentionMemoryResponder(String senderName, List<String> onlineFakes) {
      for(String fakeName : onlineFakes) {
         Map<String, Integer> playerMemory = (Map)this.mentionMemory.get(fakeName);
         if (playerMemory != null) {
            Integer remaining = (Integer)playerMemory.get(senderName);
            if (remaining != null && remaining > 0) {
               return fakeName;
            }
         }
      }

      return null;
   }

   private void decrementMentionMemory(String fakeName, String senderName) {
      Map<String, Integer> playerMemory = (Map)this.mentionMemory.get(fakeName);
      if (playerMemory != null) {
         Integer remaining = (Integer)playerMemory.get(senderName);
         if (remaining != null) {
            if (remaining <= 1) {
               playerMemory.remove(senderName);
               if (playerMemory.isEmpty()) {
                  this.mentionMemory.remove(fakeName);
               }

               if (SimpleNMSHandler.isDebugMode()) {
                  this.getLogger().info("[AI] Mention memory expired for " + fakeName + " from " + senderName);
               }
            } else {
               playerMemory.put(senderName, remaining - 1);
               if (SimpleNMSHandler.isDebugMode()) {
                  this.getLogger().info("[AI] Mention memory: " + fakeName + " has " + (remaining - 1) + " responses remaining for " + senderName);
               }
            }
         }
      }

   }

   private boolean isQuestion(String message) {
      String lower = message.toLowerCase();
      return lower.endsWith("?") || lower.startsWith("who ") || lower.startsWith("what ") || lower.startsWith("where ") || lower.startsWith("when ") || lower.startsWith("why ") || lower.startsWith("how ") || lower.startsWith("is ") || lower.startsWith("are ") || lower.startsWith("do ") || lower.startsWith("does ") || lower.startsWith("can ") || lower.startsWith("anyone ");
   }

   private boolean isGreeting(String message) {
      String lower = message.toLowerCase().trim();
      String[] greetings = new String[]{"hi", "hey", "hello", "yo", "sup", "heyo", "hii", "heyy", "ayy", "ayo", "whats up", "wassup", "gm", "morning"};

      for(String g : greetings) {
         if (lower.equals(g) || lower.startsWith(g + " ") || lower.startsWith(g + "!")) {
            return true;
         }
      }

      return false;
   }

   private boolean containsBlacklistedWord(String message) {
      String lower = message.toLowerCase();

      for(String word : this.blacklistWords) {
         if (lower.contains(word)) {
            return true;
         }
      }

      return false;
   }

   private void trackChat(String player, String message) {
      List<String> history = (List)this.chatHistory.computeIfAbsent("global", (k) -> new ArrayList());
      history.add(player + ": " + message);

      while(history.size() > 20) {
         history.remove(0);
      }

   }

   private List<String> getConversationHistory(String fakeName, String sender) {
      Map<String, List<String>> fakeHistory = (Map)this.conversationHistory.get(fakeName);
      if (fakeHistory == null) {
         return Collections.emptyList();
      } else {
         List<String> history = (List)fakeHistory.get(sender);
         return (List<String>)(history == null ? Collections.emptyList() : new ArrayList(history));
      }
   }

   private void addToConversationHistory(String fakeName, String sender, String speaker, String message) {
      Map<String, List<String>> fakeHistory = (Map)this.conversationHistory.computeIfAbsent(fakeName, (k) -> new ConcurrentHashMap());
      List<String> history = (List)fakeHistory.computeIfAbsent(sender, (k) -> new ArrayList());
      history.add(speaker + ": " + message);

      while(history.size() > 15) {
         history.remove(0);
      }

   }

   private void stopAutoChatTask() {
      if (this.autoChatTask != null) {
         this.cancelTask(this.autoChatTask);
         this.autoChatTask = null;
      }

   }

   private void stopAiToAiTask() {
      if (this.aiToAiTask != null) {
         this.cancelTask(this.aiToAiTask);
         this.aiToAiTask = null;
      }

   }

   private void cancelTask(Object task) {
      try {
         if (task instanceof BukkitTask) {
            ((BukkitTask)task).cancel();
         } else {
            task.getClass().getMethod("cancel").invoke(task);
         }
      } catch (Exception var3) {
      }

   }

   private void startAutoChatTask() {
      this.stopAutoChatTask();
      int interval = this.autoChatInterval;
      if (GlideSpoofer.isFolia()) {
         this.autoChatTask = this.runFoliaGlobalTask(() -> this.tryAutoChat(), (long)interval, (long)interval);
      } else {
         this.autoChatTask = Bukkit.getScheduler().runTaskTimer(this.pluginRef, this::tryAutoChat, (long)interval, (long)interval);
      }

      if (SimpleNMSHandler.isDebugMode()) {
         this.getLogger().info("[AI] Auto chat task started with interval: " + interval + " ticks");
      }

   }

   private void tryAutoChat() {
      if (this.autoChatEnabled && this.aiService.isEnabled()) {
         List<String> fakes = new ArrayList(this.fakePlayerAccessor.getAllFakePlayerNames());
         if (!fakes.isEmpty()) {
            long realPlayers = Bukkit.getOnlinePlayers().stream().filter((p) -> !this.fakePlayerAccessor.isFakePlayer(p)).count();
            if (realPlayers != 0L && !(ThreadLocalRandom.current().nextDouble() > this.autoChatChance)) {
               String chatter = this.pickRandomResponder(fakes, (String)null);
               if (chatter != null) {
                  String message = this.getRandomAutoMessage();
                  this.broadcastChat(chatter, message);
                  this.lastChatTime.put(chatter, System.currentTimeMillis());
               }
            }
         }
      }

   }

   private String getRandomAutoMessage() {
      if (this.autoChatTopics != null && !this.autoChatTopics.isEmpty()) {
         return (String)this.autoChatTopics.get(ThreadLocalRandom.current().nextInt(this.autoChatTopics.size()));
      } else {
         List<String> fallback = this.getFallbackAutoChatMessages();
         return fallback != null && !fallback.isEmpty() ? (String)fallback.get(ThreadLocalRandom.current().nextInt(fallback.size())) : "lol";
      }
   }

   private void startAiToAiChatTask() {
      this.stopAiToAiTask();
      int interval = this.aiToAiChatInterval;
      if (GlideSpoofer.isFolia()) {
         this.aiToAiTask = this.runFoliaGlobalTask(() -> this.tryAiToAi(), (long)interval, (long)interval);
      } else {
         this.aiToAiTask = Bukkit.getScheduler().runTaskTimer(this.pluginRef, this::tryAiToAi, (long)interval, (long)interval);
      }

      if (SimpleNMSHandler.isDebugMode()) {
         this.getLogger().info("[AI] AI-to-AI chat task started with interval: " + interval + " ticks");
      }

   }

   private void tryAiToAi() {
      if (this.aiToAiChatEnabled && this.aiService.isEnabled()) {
         List<String> fakes = new ArrayList(this.fakePlayerAccessor.getAllFakePlayerNames());
         if (fakes.size() >= 2) {
            long realPlayers = Bukkit.getOnlinePlayers().stream().filter((p) -> !this.fakePlayerAccessor.isFakePlayer(p)).count();
            if (realPlayers != 0L) {
               String ongoingConv = null;
               String[] ongoingPlayers = null;
               boolean isOngoing = false;

               for(Map.Entry<String, Integer> entry : this.aiToAiConversations.entrySet()) {
                  if ((Integer)entry.getValue() > 0) {
                     ongoingConv = (String)entry.getKey();
                     ongoingPlayers = ongoingConv.split(":");
                     isOngoing = true;
                     break;
                  }
               }

               String lastMessage = null;
               String lastSpeaker = null;
               String player1;
               String player2;
               if (isOngoing && ongoingPlayers != null && ongoingPlayers.length == 2) {
                  player1 = ongoingPlayers[0];
                  player2 = ongoingPlayers[1];
                  List<String> history = (List)this.aiToAiHistory.get(ongoingConv);
                  if (history != null && !history.isEmpty()) {
                     lastMessage = (String)history.get(history.size() - 1);
                     int colonIdx = lastMessage.indexOf(": ");
                     if (colonIdx != -1) {
                        lastSpeaker = lastMessage.substring(0, colonIdx);
                     }
                  }

                  String nextSpeaker;
                  if (player1.equals(lastSpeaker)) {
                     nextSpeaker = player2;
                  } else {
                     nextSpeaker = player1;
                  }

                  if (!nextSpeaker.equals(player2)) {
                     String temp = player1;
                     player1 = player2;
                     player2 = temp;
                  }

                  int remaining = (Integer)this.aiToAiConversations.get(ongoingConv) - 1;
                  if (remaining <= 0) {
                     this.aiToAiConversations.remove(ongoingConv);
                     this.aiToAiHistory.remove(ongoingConv);
                     if (SimpleNMSHandler.isDebugMode()) {
                        this.getLogger().info("[AI-AI] Conversation between " + player1 + " and " + player2 + " ended");
                     }
                  } else {
                     this.aiToAiConversations.put(ongoingConv, remaining);
                  }
               } else {
                  if (ThreadLocalRandom.current().nextDouble() > 0.9) {
                     return;
                  }

                  Collections.shuffle(fakes);
                  player1 = (String)fakes.get(0);
                  player2 = (String)fakes.get(1);
                  String convKey = player1 + ":" + player2;
                  this.aiToAiConversations.put(convKey, 100);
                  this.aiToAiHistory.put(convKey, new ArrayList());
                  if (SimpleNMSHandler.isDebugMode()) {
                     this.getLogger().info("[AI-AI] Starting new conversation: " + player1 + " <-> " + player2);
                  }
               }

               Long last1 = (Long)this.lastChatTime.get(player1);
               long now = System.currentTimeMillis();
               if (last1 == null || now - last1 >= 500L) {
                  String prompt = this.buildAiToAiPromptWithContext(ongoingConv, player1, player2, lastMessage);
                  this.scheduleSyncTask(() -> this.getAIResponse(player1, prompt, (String)null), (long)(10 + ThreadLocalRandom.current().nextInt(20)));
               }
            }
         }
      }

   }

   private String getAiToAiConversationStarter(String target) {
      if (this.aiToAiConversationStarters != null && !this.aiToAiConversationStarters.isEmpty()) {
         String starter = (String)this.aiToAiConversationStarters.get(ThreadLocalRandom.current().nextInt(this.aiToAiConversationStarters.size()));
         return starter.replace("{target}", target);
      } else {
         String[] defaultStarters = new String[]{target + " yo", target + " sup", "yo " + target, "hey " + target, target + "?", target + " u there", target + " wanna pvp", "yo " + target + " u there"};
         return defaultStarters[ThreadLocalRandom.current().nextInt(defaultStarters.length)];
      }
   }

   public boolean isEnabled() {
      return this.enabled && this.aiService != null && this.aiService.isEnabled();
   }

   public void shutdown() {
      this.lastChatTime.clear();
      this.chatHistory.clear();
   }

   public Logger getLogger() {
      return this.pluginRef.getLogger();
   }

   public String getOpenAIKey() {
      return this.getConfigString("openai.api-key", "");
   }

   public String getOpenAIModel() {
      return this.getConfigString("openai.model", "gpt-3.5-turbo");
   }

   public String getGeminiKey() {
      return this.getConfigString("gemini.api-key", "");
   }

   public String getGeminiModel() {
      return this.getConfigString("gemini.model", "gemini-pro");
   }

   public String getGlideAIKey() {
      return this.getConfigString("glideai.api-key", "");
   }

   public String getGlideAIModel() {
      return this.getConfigString("glideai.model", "glm-4-flash");
   }

   public int getGlideAIMaxTokens() {
      return this.getConfigInt("glideai.max-tokens", 100);
   }

   public double getGlideAITemperature() {
      return this.getConfigDouble("glideai.temperature", 0.85);
   }

   public int getGlideAIConnectTimeout() {
      return this.getConfigInt("glideai.connect-timeout", 5);
   }

   public int getGlideAIWriteTimeout() {
      return this.getConfigInt("glideai.write-timeout", 10);
   }

   public int getGlideAIReadTimeout() {
      return this.getConfigInt("glideai.read-timeout", 15);
   }

   public int getGlideAIMaxConcurrentRequests() {
      return this.getConfigInt("glideai.max-concurrent-requests", 3);
   }

   public int getGlideAIMinRequestInterval() {
      return this.getConfigInt("glideai.min-request-interval", 2000);
   }

   public int getResponseTimeoutTicks() {
      return this.getConfigInt("response-timeout-ticks", 100);
   }

   public String getSystemPrompt() {
      return this.systemPrompt.replace("{language}", this.getLanguageName());
   }

   public String getSystemPrompt(String playerName) {
      String custom = (String)this.playerPersonalities.get(playerName.toLowerCase());
      return custom != null && !custom.isEmpty() ? custom.replace("{player}", playerName) : this.systemPrompt.replace("{player}", playerName).replace("{language}", this.getLanguageName());
   }

   public String getContextBoost() {
      return this.contextBoost;
   }

   public String getLanguage() {
      return this.language;
   }

   public int getMaxTokens() {
      return 5000;
   }

   public double getTemperature() {
      return 0.8;
   }

   public int getMemorySize() {
      return 10;
   }

   public String getTriggerMode() {
      return this.triggerMode;
   }

   public List<String> getTriggerKeywords() {
      return new ArrayList(this.triggerKeywords);
   }

   public List<String> getBlacklistWords() {
      return new ArrayList(this.blacklistWords);
   }

   public double getResponseChance() {
      return this.responseChance;
   }

   public int getMinResponseDelay() {
      return this.minResponseDelay;
   }

   public int getMaxResponseDelay() {
      return this.maxResponseDelay;
   }

   public long getChatCooldown() {
      return this.chatCooldown;
   }

   public boolean isAutoChatEnabled() {
      return this.autoChatEnabled;
   }

   public int getAutoChatInterval() {
      return this.autoChatInterval;
   }

   public double getAutoChatChance() {
      return this.autoChatChance;
   }

   public List<String> getAutoChatTopics() {
      return this.autoChatTopics;
   }

   public boolean isAiToAiChatEnabled() {
      return this.aiToAiChatEnabled;
   }

   public int getAiToAiChatInterval() {
      return this.aiToAiChatInterval;
   }

   public List<String> getAiToAiTopics() {
      return this.aiToAiTopics;
   }

   public String getChatFormat() {
      return this.chatFormat;
   }

   public List<String> getFakePlayerNames() {
      return this.fakePlayerAccessor.getAllFakePlayerNames();
   }

   public boolean isFakePlayer(String name) {
      return this.fakePlayerAccessor.hasFakePlayer(name);
   }

   public void broadcastChat(String playerName, String message) {
      AILicenseVerify.incrementMessageCount();
      if (this.fakeChatManager != null) {
         this.fakeChatManager.say(playerName, message);
      } else {
         String formatted = ChatColor.translateAlternateColorCodes('&', this.chatFormat.replace("{player}", playerName).replace("{message}", message));

         for(Player player : Bukkit.getOnlinePlayers()) {
            if (!this.fakePlayerAccessor.isFakePlayer(player)) {
               player.sendMessage(formatted);
            }
         }
      }

      this.addToAiToAiHistory(playerName, message);
      this.checkForFakeToFakeMention(playerName, message);
   }

   private void addToAiToAiHistory(String speaker, String message) {
      if (this.fakePlayerAccessor.hasFakePlayer(speaker)) {
         for(String convKey : this.aiToAiConversations.keySet()) {
            String[] players = convKey.split(":");
            if (players.length == 2 && (players[0].equals(speaker) || players[1].equals(speaker))) {
               List<String> history = (List)this.aiToAiHistory.computeIfAbsent(convKey, (k) -> new ArrayList());
               history.add(speaker + ": " + message);
               if (history.size() > 12) {
                  history.remove(0);
               }
               break;
            }
         }
      }

   }

   private void checkForFakeToFakeMention(String speaker, String message) {
      if (this.fakePlayerAccessor.hasFakePlayer(speaker)) {
         List<String> allFakes = new ArrayList(this.fakePlayerAccessor.getAllFakePlayerNames());
         String lowerMsg = message.toLowerCase();

         for(String otherFake : allFakes) {
            if (!otherFake.equals(speaker)) {
               String lowerOther = otherFake.toLowerCase();
               if (lowerMsg.contains("@" + lowerOther) || lowerMsg.contains(" " + lowerOther + " ") || lowerMsg.startsWith(lowerOther + " ") || lowerMsg.endsWith(" " + lowerOther) || lowerMsg.equals(lowerOther)) {
                  String convKey = speaker + ":" + otherFake;
                  if (!this.aiToAiConversations.containsKey(convKey)) {
                     this.aiToAiConversations.put(convKey, 100);
                     if (SimpleNMSHandler.isDebugMode()) {
                        this.getLogger().info("[AI-AI] " + speaker + " mentioned " + otherFake + " - starting 10-message conversation");
                     }

                     int delay = 30 + ThreadLocalRandom.current().nextInt(60);
                     this.scheduleSyncTask(() -> {
                        String prompt = this.buildAiToAiPrompt(speaker, otherFake, message);
                        this.getAIResponse(otherFake, prompt, (String)null);
                     }, (long)delay);
                  }
                  break;
               }
            }
         }
      }

   }

   public void scheduleSyncTask(Runnable task) {
      if (GlideSpoofer.isFolia()) {
         this.runFoliaGlobalTask(task);
      } else {
         Bukkit.getScheduler().runTask(this.pluginRef, task);
      }

   }

   public void scheduleSyncTask(Runnable task, long delay) {
      if (GlideSpoofer.isFolia()) {
         this.runFoliaGlobalDelayedTask(task, Math.max(1L, delay));
      } else {
         Bukkit.getScheduler().runTaskLater(this.pluginRef, task, delay);
      }

   }

   private Object runFoliaGlobalTask(Runnable task, long initialDelay, long period) {
      try {
         Method getGlobalRegionScheduler = Bukkit.class.getMethod("getGlobalRegionScheduler");
         Object regionScheduler = getGlobalRegionScheduler.invoke((Object)null);
         Method runAtFixedRate = regionScheduler.getClass().getMethod("runAtFixedRate", Plugin.class, Consumer.class, Long.TYPE, Long.TYPE);
         Consumer<Object> taskWrapper = (ignored) -> task.run();
         return runAtFixedRate.invoke(regionScheduler, this.pluginRef, taskWrapper, initialDelay, period);
      } catch (Exception var10) {
         this.getLogger().severe("Failed to schedule Folia task: " + var10.getMessage());
         throw new UnsupportedOperationException("Folia scheduling failed", var10);
      }
   }

   private void runFoliaGlobalTask(Runnable task) {
      try {
         Method getGlobalRegionScheduler = Bukkit.class.getMethod("getGlobalRegionScheduler");
         Object regionScheduler = getGlobalRegionScheduler.invoke((Object)null);
         Method execute = regionScheduler.getClass().getMethod("execute", Plugin.class, Runnable.class);
         execute.invoke(regionScheduler, this.pluginRef, task);
      } catch (Exception var5) {
         this.getLogger().warning("Failed to execute Folia task, running directly: " + var5.getMessage());
         task.run();
      }

   }

   private void runFoliaGlobalDelayedTask(Runnable task, long delay) {
      try {
         Method getGlobalRegionScheduler = Bukkit.class.getMethod("getGlobalRegionScheduler");
         Object regionScheduler = getGlobalRegionScheduler.invoke((Object)null);
         Method runDelayed = regionScheduler.getClass().getMethod("runDelayed", Plugin.class, Consumer.class, Long.TYPE);
         Consumer<Object> taskWrapper = (ignored) -> task.run();
         runDelayed.invoke(regionScheduler, this.pluginRef, taskWrapper, delay);
      } catch (Exception var8) {
         this.getLogger().severe("Failed to schedule delayed Folia task: " + var8.getMessage());
         throw new UnsupportedOperationException("Folia scheduling failed", var8);
      }
   }

   private String getConfigString(String path, String def) {
      try {
         Object configManager = this.pluginRef.getClass().getMethod("getConfigManager").invoke(this.pluginRef);
         Object aiConfig = configManager.getClass().getMethod("getAIConfig").invoke(configManager);
         return (String)aiConfig.getClass().getMethod("getString", String.class, String.class).invoke(aiConfig, path, def);
      } catch (Exception var5) {
         return def;
      }
   }

   private int getConfigInt(String path, int def) {
      try {
         Object configManager = this.pluginRef.getClass().getMethod("getConfigManager").invoke(this.pluginRef);
         Object aiConfig = configManager.getClass().getMethod("getAIConfig").invoke(configManager);
         return (Integer)aiConfig.getClass().getMethod("getInt", String.class, Integer.TYPE).invoke(aiConfig, path, def);
      } catch (Exception var5) {
         return def;
      }
   }

   private double getConfigDouble(String path, double def) {
      try {
         Object configManager = this.pluginRef.getClass().getMethod("getConfigManager").invoke(this.pluginRef);
         Object aiConfig = configManager.getClass().getMethod("getAIConfig").invoke(configManager);
         return (Double)aiConfig.getClass().getMethod("getDouble", String.class, Double.TYPE).invoke(aiConfig, path, def);
      } catch (Exception var6) {
         return def;
      }
   }

   private String getLanguageName() {
      switch (this.language.toLowerCase()) {
         case "en" -> {
            return "English";
         }
         case "es" -> {
            return "Spanish";
         }
         case "de" -> {
            return "German";
         }
         case "fr" -> {
            return "French";
         }
         case "pt" -> {
            return "Portuguese";
         }
         case "pt-br" -> {
            return "Portuguese (Brazil)";
         }
         case "ru" -> {
            return "Russian";
         }
         case "zh" -> {
            return "Chinese";
         }
         case "ja" -> {
            return "Japanese";
         }
         case "ko" -> {
            return "Korean";
         }
         case "it" -> {
            return "Italian";
         }
         case "nl" -> {
            return "Dutch";
         }
         case "pl" -> {
            return "Polish";
         }
         case "ar" -> {
            return "Arabic";
         }
         case "tr" -> {
            return "Turkish";
         }
         case "vi" -> {
            return "Vietnamese";
         }
         case "th" -> {
            return "Thai";
         }
         case "id" -> {
            return "Indonesian";
         }
         case "hi" -> {
            return "Hindi";
         }
         case "uk" -> {
            return "Ukrainian";
         }
         case "ro" -> {
            return "Romanian";
         }
         case "cs" -> {
            return "Czech";
         }
         case "el" -> {
            return "Greek";
         }
         case "sv" -> {
            return "Swedish";
         }
         case "da" -> {
            return "Danish";
         }
         case "no" -> {
            return "Norwegian";
         }
         case "fi" -> {
            return "Finnish";
         }
         case "hu" -> {
            return "Hungarian";
         }
         case "bn" -> {
            return "Bengali";
         }
         default -> {
            return this.language;
         }
      }
   }

   public interface FakePlayerAccessor {
      List<String> getAllFakePlayerNames();

      boolean hasFakePlayer(String var1);

      boolean isFakePlayer(Object var1);
   }
}
