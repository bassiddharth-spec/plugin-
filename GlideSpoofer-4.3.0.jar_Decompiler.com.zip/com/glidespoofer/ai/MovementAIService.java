package com.glidespoofer.ai;

import com.glidespoofer.nms.SimpleNMSHandler;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Dispatcher;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MovementAIService {
   private static final String[] MOVEMENT_API_KEYS = new String[]{"9f22c55b36b148bd87769f171202410b.DIDXHPEAFUMovmPy", "740323cf702e44a5b34711bf5b43a5b5.KKJPzrqW19VtpDIg", "3ed495c49196481f989d87b6fec314fc.hNwxgjphYZjZ09K7", "e5442ecab2b6471f8106e3fc2697ad2c.JXmF3Flz0CiAjYjy", "0b77043b601a493e965bab3335e23752.8HNEZclvg7T976XO", "d70b6ecebd8d422c9fd45b7271b53848.PWWJWm2S46o7RTKc", "13d434ba2fd94e74aae14e5e7f710701.o8pSOcLPtZNOTZL4", "8dbb878e79ad4c15b3bfceba49ef9294.g3b4zQXZMgfTVRbp", "7b99b41fc0284b8c90bb0082968affeb.YFAftZm5ObF4E2hU", "1d06d9ab847d49b080beae987898de12.OGim7OemOqgHCznj", "2a57d9369808494fa3c459aa36216bfc.iqRclcGnl0fEBfTH", "4f0320858f0f4f21917fc5d69856e0af.DTuPU22ovxVD8CkD", "ba11e4f68f22485a90727c7c2b5bc791.8kSV54dqepyOLm61", "1012a35226094daea22f40381ab34bcc.vILLTCSGT5Mnk5pk", "be69f636c7294f6aa80c632c9627bff8.0V0XCSYo04Bmtwo6", "3f354edd401c40b79465b6f7fce8e600.muS1swJ3snmV3WA5", "c469bc1b0326456e8de45a5527a8456e.Z87YfQoxjnZyl7Ns", "6d3c619c5e7c4fb3870ac469be14d480.hPUCKX7EWdUHjX2B", "76bf19fcbe3247f48e119475aa964b70.rCIMCtgYP4TGJIEB", "5955e60d427a42db8f064e529f731053.e6sBLsQym9uUEPXP", "e8b24d8bc9934747ae83ddcacd14636f.tpomq0Dk479Le2R4", "51eec60041354395871dc02f3fa706a5.OPjHXWdKlGqabDBC", "c8b867177f364bd3982a203b39b291f8.2he54i1JevtY3bA4", "c8a347dd318f4843b33041a4034389f1.abNhKymjL6TwfrKL", "83208d72924947b68829eb2edf55d72d.gQSghNmgBtMOLfZm", "06ba7a0b03cb4dcfa8cb0e8dca3fec01.DPbWCm68DtiOEmy2", "724377c10ce948abadc67e97d33af5af.vTmox0f5fFj4MWR6", "54649d99897e41f5b09d13d4130775db.ulBZSlz6TFTf9rDx", "9e04b70b28c54c5f9acc2bc5269eb19c.Y2JAZVfw6N0XuWE9", "18bbd4ea97ec4000beecf63bb5d7f27c.ohki8xYFLW0y1DOc", "ed5272c9eb1a4c04bbe3bf2c83a74864.0Ki2QjW7WZKpzRBC", "b191683453994d518611fcfbb7f89c80.10ucOv9JOsbUIdAi", "ea50db43201c49afa8127d5f2ed84335.RvdUz3YSJbuMGvgi", "364c794856fe459cb2ace9b56da8f5a4.oeKuwwSfbMdJXscO", "8f677db1f30f4b249e129499c1b2caf2.oSV5hCoof2uh9Cn0", "cd15045a5daf4b11ab2500d2a04621e5.jG24KGtEPxgQy7bR"};
   private final AtomicInteger roundRobinIndex = new AtomicInteger(0);
   private final Logger logger;
   private final Gson gson;
   private final OkHttpClient httpClient;
   private final String model;
   private final int maxTokens;
   private final double temperature;
   private final boolean enabled;
   private final Map<String, Long> lastRequestTimePerKey = new ConcurrentHashMap();
   private final Map<String, AtomicInteger> activeRequestsPerKey = new ConcurrentHashMap();
   private final int perKeyMaxConcurrent;
   private final long perKeyMinInterval;
   private final Map<String, Long> keyBackoffUntil = new ConcurrentHashMap();
   private final Map<String, Integer> keyConsecutive429s = new ConcurrentHashMap();
   private static final long BASE_429_BACKOFF_MS = 0L;
   private static final long MAX_429_BACKOFF_MS = 0L;
   private final AtomicInteger totalRequests = new AtomicInteger(0);
   private final AtomicInteger successfulRequests = new AtomicInteger(0);
   private final AtomicInteger failedRequests = new AtomicInteger(0);

   private String getNextApiKey() {
      int index = this.roundRobinIndex.getAndIncrement() % MOVEMENT_API_KEYS.length;
      return MOVEMENT_API_KEYS[index];
   }

   private String getKeyId(String apiKey) {
      if (apiKey == null) {
         return "unknown";
      } else {
         String[] parts = apiKey.split("\\.");
         return parts.length > 0 ? parts[0].substring(0, Math.min(8, parts[0].length())) : "unknown";
      }
   }

   private String getAvailableApiKey() {
      long now = System.currentTimeMillis();
      int startIndex = this.roundRobinIndex.get() % MOVEMENT_API_KEYS.length;

      for(int i = 0; i < MOVEMENT_API_KEYS.length; ++i) {
         int index = (startIndex + i) % MOVEMENT_API_KEYS.length;
         String apiKey = MOVEMENT_API_KEYS[index];
         String keyId = this.getKeyId(apiKey);
         Long backoffUntil = (Long)this.keyBackoffUntil.get(keyId);
         if (backoffUntil == null || now >= backoffUntil) {
            AtomicInteger keyActive = (AtomicInteger)this.activeRequestsPerKey.get(keyId);
            if (keyActive == null || keyActive.get() < this.perKeyMaxConcurrent) {
               Long lastTime = (Long)this.lastRequestTimePerKey.get(keyId);
               if (lastTime == null || now - lastTime >= this.perKeyMinInterval) {
                  this.roundRobinIndex.set((index + 1) % MOVEMENT_API_KEYS.length);
                  return apiKey;
               }
            }
         }
      }

      return this.getNextApiKey();
   }

   private void handle429Error(String apiKey) {
      String keyId = this.getKeyId(apiKey);
      int consecutive429s = (Integer)this.keyConsecutive429s.getOrDefault(keyId, 0) + 1;
      this.keyConsecutive429s.put(keyId, consecutive429s);
      long backoffMs = Math.min(5000L * (1L << Math.min(consecutive429s, 4)), 60000L);
      this.keyBackoffUntil.put(keyId, System.currentTimeMillis() + backoffMs);
      this.logger.warning("[MovementAI] Rate limit for key " + keyId + " - backing off " + backoffMs / 1000L + "s (429s: " + consecutive429s + ")");
   }

   private void clear429Backoff(String apiKey) {
      String keyId = this.getKeyId(apiKey);
      this.keyConsecutive429s.remove(keyId);
      this.keyBackoffUntil.remove(keyId);
   }

   private void startRequest(String apiKey) {
      String keyId = this.getKeyId(apiKey);
      ((AtomicInteger)this.activeRequestsPerKey.computeIfAbsent(keyId, (k) -> new AtomicInteger(0))).incrementAndGet();
      this.lastRequestTimePerKey.put(keyId, System.currentTimeMillis());
      this.totalRequests.incrementAndGet();
   }

   private void completeRequest(String apiKey, boolean success) {
      String keyId = this.getKeyId(apiKey);
      AtomicInteger keyActive = (AtomicInteger)this.activeRequestsPerKey.get(keyId);
      if (keyActive != null) {
         keyActive.decrementAndGet();
      }

      if (success) {
         this.successfulRequests.incrementAndGet();
         this.clear429Backoff(apiKey);
      } else {
         this.failedRequests.incrementAndGet();
      }

   }

   private static String generateToken(String apiKey, long expMillis) {
      try {
         String[] parts = apiKey.split("\\.");
         if (parts.length != 2) {
            return null;
         } else {
            String id = parts[0];
            String secret = parts[1];
            long timestamp = System.currentTimeMillis();
            long expTimestamp = timestamp + expMillis;
            String headerJson = "{\"alg\":\"HS256\",\"sign_type\":\"SIGN\"}";
            String encodedHeader = base64UrlEncode(headerJson);
            String payloadJson = "{\"api_key\":\"" + id + "\",\"exp\":" + expTimestamp + ",\"timestamp\":" + timestamp + "}";
            String encodedPayload = base64UrlEncode(payloadJson);
            String data = encodedHeader + "." + encodedPayload;
            String signature = hmacSha256(data, secret);
            return data + "." + signature;
         }
      } catch (Exception var16) {
         return null;
      }
   }

   private static String base64UrlEncode(String data) {
      return Base64.getUrlEncoder().withoutPadding().encodeToString(data.getBytes(StandardCharsets.UTF_8));
   }

   private static String hmacSha256(String data, String secret) throws NoSuchAlgorithmException, InvalidKeyException {
      Mac mac = Mac.getInstance("HmacSHA256");
      SecretKeySpec secretKeySpec = new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
      mac.init(secretKeySpec);
      byte[] hash = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
      return Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
   }

   public MovementAIService(Logger logger, String model, int maxTokens, double temperature, int perKeyMaxConcurrent, long perKeyMinInterval) {
      this.logger = logger;
      this.gson = new Gson();
      this.model = model;
      this.maxTokens = maxTokens;
      this.temperature = temperature;
      this.perKeyMaxConcurrent = perKeyMaxConcurrent;
      this.perKeyMinInterval = perKeyMinInterval;
      this.enabled = MOVEMENT_API_KEYS.length > 0;
      Dispatcher dispatcher = new Dispatcher();
      dispatcher.setMaxRequests(50);
      dispatcher.setMaxRequestsPerHost(50);
      this.httpClient = (new OkHttpClient.Builder()).connectTimeout(10L, TimeUnit.SECONDS).writeTimeout(10L, TimeUnit.SECONDS).readTimeout(30L, TimeUnit.SECONDS).retryOnConnectionFailure(true).dispatcher(dispatcher).build();
      if (SimpleNMSHandler.isDebugMode()) {
         logger.info("[MovementAI] Initialized with " + MOVEMENT_API_KEYS.length + " API keys (20 chat + 16 movement)");
      }

      if (SimpleNMSHandler.isDebugMode()) {
         logger.info("[MovementAI] Model: " + model + " | MaxTokens: " + maxTokens);
      }

      if (SimpleNMSHandler.isDebugMode()) {
         logger.info("[MovementAI] Rate limiting: " + perKeyMaxConcurrent + " concurrent/key, " + perKeyMinInterval + "ms interval/key");
      }

   }

   public CompletableFuture<MovementDecision> getMovementDecision(final String playerName, String context) {
      final CompletableFuture<MovementDecision> future = new CompletableFuture();
      if (!this.enabled) {
         future.complete((Object)null);
         return future;
      } else {
         final String apiKey = this.getAvailableApiKey();
         String systemPrompt = this.buildMovementSystemPrompt();
         String userPrompt = this.buildMovementPrompt(playerName, context);
         JsonObject requestBody = new JsonObject();
         requestBody.addProperty("model", this.model);
         requestBody.addProperty("max_tokens", (Number)this.maxTokens);
         requestBody.addProperty("temperature", (Number)this.temperature);
         JsonArray messages = new JsonArray();
         JsonObject systemMsg = new JsonObject();
         systemMsg.addProperty("role", "system");
         systemMsg.addProperty("content", systemPrompt);
         messages.add((JsonElement)systemMsg);
         JsonObject userMsg = new JsonObject();
         userMsg.addProperty("role", "user");
         userMsg.addProperty("content", userPrompt);
         messages.add((JsonElement)userMsg);
         requestBody.add("messages", messages);
         String token = generateToken(apiKey, 3600000L);
         if (token == null) {
            this.logger.warning("[MovementAI] Failed to generate token for " + playerName);
            future.complete((Object)null);
            return future;
         } else {
            RequestBody body = RequestBody.create(requestBody.toString(), MediaType.parse("application/json"));
            Request request = (new Request.Builder()).url("https://api.z.ai/api/paas/v4/chat/completions").addHeader("Authorization", "Bearer " + token).addHeader("Content-Type", "application/json").post(body).build();
            this.startRequest(apiKey);
            this.httpClient.newCall(request).enqueue(new Callback() {
               public void onFailure(Call call, IOException e) {
                  MovementAIService.this.completeRequest(apiKey, false);
                  String var10001 = playerName;
                  MovementAIService.this.logger.fine("[MovementAI] Request failed for " + var10001 + ": " + e.getMessage());
                  future.complete((Object)null);
               }

               public void onResponse(Call call, Response response) throws IOException {
                  try {
                     if (!response.isSuccessful()) {
                        if (response.code() == 429) {
                           MovementAIService.this.handle429Error(apiKey);
                        }

                        MovementAIService.this.completeRequest(apiKey, false);
                        Logger var10000 = MovementAIService.this.logger;
                        int var15 = response.code();
                        var10000.fine("[MovementAI] Error " + var15 + " for " + playerName);
                        future.complete((Object)null);
                     } else {
                        String responseBody = response.body().string();
                        JsonObject jsonResponse = (JsonObject)MovementAIService.this.gson.fromJson(responseBody, JsonObject.class);

                        try {
                           JsonArray choices = jsonResponse.getAsJsonArray("choices");
                           if (choices != null && choices.size() > 0) {
                              JsonObject choice = choices.get(0).getAsJsonObject();
                              JsonObject message = choice.getAsJsonObject("message");
                              if (message != null) {
                                 String content = message.get("content").getAsString();
                                 MovementDecision decision = MovementAIService.this.parseMovementDecision(content);
                                 MovementAIService.this.completeRequest(apiKey, true);
                                 future.complete(decision);
                                 return;
                              }
                           }
                        } catch (Exception var13) {
                           String var10001 = playerName;
                           MovementAIService.this.logger.fine("[MovementAI] Parse error for " + var10001 + ": " + var13.getMessage());
                        }

                        MovementAIService.this.completeRequest(apiKey, false);
                        future.complete((Object)null);
                     }
                  } finally {
                     response.close();
                  }
               }
            });
            return future;
         }
      }
   }

   private String buildMovementSystemPrompt() {
      return "You are a Minecraft player movement AI. Decide realistic player actions.\nRespond ONLY with valid JSON in this exact format:\n{\"action\":\"idle|walk|look|wander\",\"duration\":20-100,\"priority\":0-100}\n\nActions:\n- idle: stand still, occasionally look around\n- walk: walk to a nearby random location\n- look: look around without moving\n- wander: explore the area randomly\n\nDuration: in ticks (20 ticks = 1 second), typical range 20-100\nPriority: 0-100, higher means more urgent (use default 50)";
   }

   private String buildMovementPrompt(String playerName, String context) {
      return "Player: " + playerName + "\nContext: " + context + "\nProvide a movement decision JSON.";
   }

   private MovementDecision parseMovementDecision(String response) {
      try {
         String jsonStr = response;
         int jsonStart = response.indexOf("{");
         int jsonEnd = response.lastIndexOf("}");
         if (jsonStart >= 0 && jsonEnd > jsonStart) {
            jsonStr = response.substring(jsonStart, jsonEnd + 1);
         }

         JsonObject json = (JsonObject)this.gson.fromJson(jsonStr, JsonObject.class);
         String action = json.has("action") ? json.get("action").getAsString() : "idle";
         int duration = json.has("duration") ? json.get("duration").getAsInt() : 40;
         int priority = json.has("priority") ? json.get("priority").getAsInt() : 50;
         return new MovementDecision(action, duration, priority);
      } catch (Exception var9) {
         this.logger.fine("[MovementAI] Failed to parse decision: " + response);
         return new MovementDecision("idle", 40, 50);
      }
   }

   public String getStatistics() {
      int total = this.totalRequests.get();
      int success = this.successfulRequests.get();
      int failed = this.failedRequests.get();
      double successRate = total > 0 ? (double)success * (double)100.0F / (double)total : (double)0.0F;
      return String.format("[MovementAI] Stats: %d requests, %d success, %d failed (%.1f%% success)", total, success, failed, successRate);
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public static class MovementDecision {
      private final String action;
      private final int duration;
      private final int priority;

      public MovementDecision(String action, int duration, int priority) {
         this.action = action;
         this.duration = Math.max(10, Math.min(200, duration));
         this.priority = Math.max(0, Math.min(100, priority));
      }

      public String getAction() {
         return this.action;
      }

      public int getDuration() {
         return this.duration;
      }

      public int getPriority() {
         return this.priority;
      }

      public String toString() {
         return String.format("MovementDecision{action='%s', duration=%dt, priority=%d}", this.action, this.duration, this.priority);
      }
   }
}
