package com.glidespoofer.ai;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.logging.Logger;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class OpenAIService implements AIService {
   private final Logger logger;
   private final Gson gson;
   private final OkHttpClient httpClient;
   private final String apiKey;
   private final String model;
   private final String systemPrompt;
   private final String contextBoost;
   private final int maxTokens;
   private final double temperature;
   private final boolean enabled;
   private final Map<String, LinkedList<AIService.ChatMessage>> conversationMemory;
   private final int memorySize;

   public OpenAIService(AIConfigProvider configProvider) {
      this.logger = configProvider.getLogger();
      this.gson = new Gson();
      this.apiKey = configProvider.getOpenAIKey();
      this.model = configProvider.getOpenAIModel();
      this.systemPrompt = configProvider.getSystemPrompt();
      this.contextBoost = configProvider.getContextBoost();
      this.maxTokens = configProvider.getMaxTokens();
      this.temperature = configProvider.getTemperature();
      this.memorySize = configProvider.getMemorySize();
      this.enabled = this.apiKey != null && !this.apiKey.isEmpty() && !this.apiKey.equals("your-api-key-here");
      this.httpClient = (new OkHttpClient.Builder()).connectTimeout(30L, TimeUnit.SECONDS).writeTimeout(30L, TimeUnit.SECONDS).readTimeout(30L, TimeUnit.SECONDS).build();
      this.conversationMemory = new ConcurrentHashMap();
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public String getSystemPrompt(String playerName) {
      String basePrompt = this.systemPrompt.replace("{player}", playerName);
      return this.contextBoost != null && !this.contextBoost.trim().isEmpty() ? basePrompt + "\n\n" + this.contextBoost.trim() : basePrompt;
   }

   public CompletableFuture<String> getChatResponse(String playerName, String message, List<AIService.ChatMessage> history) {
      final CompletableFuture<String> future = new CompletableFuture();
      if (!this.enabled) {
         future.complete((Object)null);
         return future;
      } else {
         final LinkedList<AIService.ChatMessage> memory = (LinkedList)this.conversationMemory.computeIfAbsent(playerName, (k) -> new LinkedList());
         memory.add(new AIService.ChatMessage("user", message));

         while(memory.size() > this.memorySize) {
            memory.removeFirst();
         }

         JsonObject requestBody = new JsonObject();
         requestBody.addProperty("model", this.model);
         requestBody.addProperty("max_tokens", (Number)this.maxTokens);
         requestBody.addProperty("temperature", (Number)this.temperature);
         JsonArray messages = new JsonArray();
         messages.add((JsonElement)this.createMessage("system", this.getSystemPrompt(playerName)));

         for(AIService.ChatMessage msg : memory) {
            messages.add((JsonElement)this.createMessage(msg.getRole(), msg.getContent()));
         }

         requestBody.add("messages", messages);
         RequestBody body = RequestBody.create(requestBody.toString(), MediaType.parse("application/json"));
         Request request = (new Request.Builder()).url("https://api.openai.com/v1/chat/completions").addHeader("Authorization", "Bearer " + this.apiKey).addHeader("Content-Type", "application/json").post(body).build();
         this.httpClient.newCall(request).enqueue(new Callback() {
            public void onFailure(Call call, IOException e) {
               OpenAIService.this.logger.warning("[OpenAI] Request failed: " + e.getMessage());
               future.complete((Object)null);
            }

            public void onResponse(Call call, Response response) throws IOException {
               try {
                  if (!response.isSuccessful()) {
                     OpenAIService.this.logger.warning("[OpenAI] Error: " + response.code());
                     future.complete((Object)null);
                     return;
                  }

                  String responseBody = response.body().string();
                  JsonObject jsonResponse = (JsonObject)OpenAIService.this.gson.fromJson(responseBody, JsonObject.class);
                  String content = jsonResponse.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message").get("content").getAsString();
                  memory.add(new AIService.ChatMessage("assistant", content));
                  future.complete(content.trim());
               } catch (Exception var9) {
                  OpenAIService.this.logger.warning("[OpenAI] Parse error: " + var9.getMessage());
                  future.complete((Object)null);
                  return;
               } finally {
                  response.close();
               }

            }
         });
         return future;
      }
   }

   private JsonObject createMessage(String role, String content) {
      JsonObject msg = new JsonObject();
      msg.addProperty("role", role);
      msg.addProperty("content", content);
      return msg;
   }

   public void clearMemory(String playerName) {
      this.conversationMemory.remove(playerName);
   }

   public void clearAllMemory() {
      this.conversationMemory.clear();
   }

   public CompletableFuture<String> getChatResponseStreamed(String playerName, String message, List<AIService.ChatMessage> conversationHistory, Consumer<String> chunkCallback, Runnable completeCallback) {
      CompletableFuture<String> future = this.getChatResponse(playerName, message, conversationHistory);
      if (completeCallback != null) {
         future.thenRun(completeCallback);
      }

      return future;
   }
}
