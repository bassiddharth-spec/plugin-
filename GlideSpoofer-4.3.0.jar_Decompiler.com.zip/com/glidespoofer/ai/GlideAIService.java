package com.glidespoofer.ai;

import com.glidespoofer.nms.SimpleNMSHandler;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.logging.Logger;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Dispatcher;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class GlideAIService implements AIService {
   private static final String ENCODED_API_KEY = "MzRkZDNjMDViYTRlNDljNmJkY2FhNjUxMWM0OGU2OGYuVGR2dDdmRGR3QzVPcVk1Qw==";
   private static final Map<String, String> PLAYER_API_KEYS = new HashMap();
   private static final Map<String, String> PLAYER_NAME_TO_KEY = new HashMap();
   private final AtomicInteger roundRobinCounter = new AtomicInteger(0);
   private final Logger logger;
   private final Gson gson;
   private final AIConfigProvider configProvider;
   private final OkHttpClient httpClient;
   private final String defaultApiKey;
   private final String model;
   private final String systemPrompt;
   private final int maxTokens;
   private final double temperature;
   private final boolean enabled;
   private final Map<String, LinkedList<AIService.ChatMessage>> conversationMemory;
   private final int memorySize;
   private final Map<String, LinkedList<String>> recentResponses;
   private static final int RECENT_RESPONSES_LIMIT = 5;
   private int messageLimit;
   private int messageCount = 0;
   private boolean limitWarningShown = false;
   private volatile long lastRequestTime = 0L;
   private final int minRequestInterval;
   private final AtomicInteger activeRequests = new AtomicInteger(0);
   private final int maxConcurrentRequests;
   private final Map<String, Long> lastRequestTimePerKey = new ConcurrentHashMap();
   private final Map<String, AtomicInteger> activeRequestsPerKey = new ConcurrentHashMap();
   private int perKeyMaxConcurrent = 1;
   private long perKeyMinInterval = 5000L;
   private final Map<String, Long> keyBackoffUntil = new ConcurrentHashMap();
   private final Map<String, Integer> keyConsecutive429s = new ConcurrentHashMap();
   private static final long BASE_429_BACKOFF_MS = 0L;
   private static final long MAX_429_BACKOFF_MS = 0L;
   private final LinkedBlockingQueue<Runnable> globalRequestQueue = new LinkedBlockingQueue();
   private Thread requestQueueThread;
   private volatile boolean queueRunning = true;

   private String getApiKeyForPlayer(String playerName) {
      String glideKey = (String)PLAYER_NAME_TO_KEY.get(playerName.toLowerCase());
      if (glideKey != null) {
         String apiKey = (String)PLAYER_API_KEYS.get(glideKey);
         if (apiKey != null) {
            this.logger.fine("[GlideAI] Using dedicated key " + glideKey + " for " + playerName);
            return apiKey;
         }
      }

      int keyCount = PLAYER_API_KEYS.size();
      int index = this.roundRobinCounter.getAndIncrement() % keyCount;
      String roundRobinKey = "GLIDE" + (index + 1);
      String apiKey = (String)PLAYER_API_KEYS.get(roundRobinKey);
      if (apiKey != null) {
         this.logger.fine("[GlideAI] Using round-robin key " + roundRobinKey + " for " + playerName);
         return apiKey;
      } else {
         this.logger.fine("[GlideAI] Using default key for " + playerName);
         return this.defaultApiKey;
      }
   }

   private boolean canMakeRequest() {
      if (this.activeRequests.get() >= this.maxConcurrentRequests) {
         this.logger.warning("[GlideAI] Too many concurrent requests, queuing...");
         return false;
      } else {
         long now = System.currentTimeMillis();
         long timeSinceLastRequest = now - this.lastRequestTime;
         if (timeSinceLastRequest < (long)this.minRequestInterval) {
            this.logger.fine("[GlideAI] Request too soon, waiting...");
            return false;
         } else {
            return true;
         }
      }
   }

   private void waitAndExecute(String apiKey, Runnable request) {
      String keyId = this.getKeyId(apiKey);
      synchronized(keyId.intern()) {
         long now = System.currentTimeMillis();
         Long lastKeyTime = (Long)this.lastRequestTimePerKey.get(keyId);
         AtomicInteger keyActiveRequests = (AtomicInteger)this.activeRequestsPerKey.computeIfAbsent(keyId, (k) -> new AtomicInteger(0));
         long delayMs = 0L;
         Long backoffUntil = (Long)this.keyBackoffUntil.get(keyId);
         if (backoffUntil != null && now < backoffUntil) {
            delayMs = backoffUntil - now;
            this.logger.warning("[GlideAI] Key " + keyId + " is in 429 backoff for " + delayMs + "ms");
         }

         if (keyActiveRequests.get() >= this.perKeyMaxConcurrent) {
            delayMs = Math.max(delayMs, 100L);
            this.logger.fine("[GlideAI] Key " + keyId + " has " + keyActiveRequests.get() + " active requests, waiting...");
         }

         if (lastKeyTime != null && now - lastKeyTime < this.perKeyMinInterval) {
            long keyDelay = this.perKeyMinInterval - (now - lastKeyTime);
            delayMs = Math.max(delayMs, keyDelay);
            this.logger.fine("[GlideAI] Key " + keyId + " needs " + keyDelay + "ms more cooldown");
         }

         if (this.activeRequests.get() >= this.maxConcurrentRequests) {
            delayMs = Math.max(delayMs, 200L);
            this.logger.fine("[GlideAI] Too many global concurrent requests");
         }

         if (now - this.lastRequestTime < (long)this.minRequestInterval) {
            long globalDelay = (long)this.minRequestInterval - (now - this.lastRequestTime);
            delayMs = Math.max(delayMs, globalDelay);
         }

         if (delayMs > 0L) {
            long finalDelayMs = delayMs + 50L;
            CompletableFuture.delayedExecutor(finalDelayMs, TimeUnit.MILLISECONDS).execute(() -> this.waitAndExecute(apiKey, request));
            return;
         }

         this.activeRequests.incrementAndGet();
         this.lastRequestTime = now;
         keyActiveRequests.incrementAndGet();
         this.lastRequestTimePerKey.put(keyId, now);
      }

      request.run();
   }

   private void completeRequest(String apiKey) {
      this.activeRequests.decrementAndGet();
      String keyId = this.getKeyId(apiKey);
      AtomicInteger keyActive = (AtomicInteger)this.activeRequestsPerKey.get(keyId);
      if (keyActive != null) {
         keyActive.decrementAndGet();
      }

   }

   private void handle429Error(String apiKey, String playerName) {
      String keyId = this.getKeyId(apiKey);
      long now = System.currentTimeMillis();
      int consecutive429s = (Integer)this.keyConsecutive429s.getOrDefault(keyId, 0);
      ++consecutive429s;
      this.keyConsecutive429s.put(keyId, consecutive429s);
      long backoffMs = Math.min(10000L * (1L << Math.min(consecutive429s, 4)), 120000L);
      long backoffUntil = now + backoffMs;
      this.keyBackoffUntil.put(keyId, backoffUntil);
      this.logger.warning("[GlideAI] Rate limit hit for " + playerName + " (key: " + keyId + ") - backing off for " + backoffMs / 1000L + "s (consecutive 429s: " + consecutive429s + ")");
   }

   private void clear429Backoff(String apiKey) {
      String keyId = this.getKeyId(apiKey);
      this.keyConsecutive429s.remove(keyId);
      this.keyBackoffUntil.remove(keyId);
   }

   private String getKeyId(String apiKey) {
      if (apiKey == null) {
         return "unknown";
      } else {
         String[] parts = apiKey.split("\\.");
         return parts.length > 0 ? parts[0].substring(0, Math.min(8, parts[0].length())) : "unknown";
      }
   }

   private int getIntConfig(String key, int defaultValue) {
      try {
         Object configManager = this.configProvider.getClass().getMethod("getConfigManager").invoke(this.configProvider);
         if (configManager != null) {
            Object aiConfig = configManager.getClass().getMethod("getAIConfig").invoke(configManager);
            if (aiConfig != null) {
               Object glideaiConfig = aiConfig.getClass().getMethod("getConfigurationSection", String.class).invoke(aiConfig, "glideai");
               if (glideaiConfig != null) {
                  return (Integer)glideaiConfig.getClass().getMethod("getInt", String.class, Integer.TYPE).invoke(glideaiConfig, key, defaultValue);
               }
            }
         }
      } catch (Exception var6) {
      }

      return defaultValue;
   }

   private static String decodeApiKey() {
      try {
         byte[] decodedBytes = Base64.getDecoder().decode("MzRkZDNjMDViYTRlNDljNmJkY2FhNjUxMWM0OGU2OGYuVGR2dDdmRGR3QzVPcVk1Qw==");
         return new String(decodedBytes);
      } catch (Exception var1) {
         return null;
      }
   }

   private static String generateToken(String apiKey, long expMillis) {
      try {
         String[] parts = apiKey.split("\\.");
         if (parts.length != 2) {
            return null;
         } else {
            String id = parts[0];
            String secret = parts[1];
            long timestamp = System.currentTimeMillis();
            long expTimestamp = timestamp + expMillis;
            String headerJson = "{\"alg\":\"HS256\",\"sign_type\":\"SIGN\"}";
            String encodedHeader = base64UrlEncode(headerJson);
            String payloadJson = "{\"api_key\":\"" + id + "\",\"exp\":" + expTimestamp + ",\"timestamp\":" + timestamp + "}";
            String encodedPayload = base64UrlEncode(payloadJson);
            String data = encodedHeader + "." + encodedPayload;
            String signature = hmacSha256(data, secret);
            return data + "." + signature;
         }
      } catch (Exception var16) {
         return null;
      }
   }

   private static String base64UrlEncode(String data) {
      return Base64.getUrlEncoder().withoutPadding().encodeToString(data.getBytes(StandardCharsets.UTF_8));
   }

   private static String hmacSha256(String data, String secret) throws NoSuchAlgorithmException, InvalidKeyException {
      Mac mac = Mac.getInstance("HmacSHA256");
      SecretKeySpec secretKeySpec = new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
      mac.init(secretKeySpec);
      byte[] hash = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
      return Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
   }

   public GlideAIService(AIConfigProvider configProvider) {
      this.logger = configProvider.getLogger();
      this.gson = new Gson();
      this.configProvider = configProvider;
      String embeddedKey = decodeApiKey();
      this.defaultApiKey = embeddedKey != null ? embeddedKey : configProvider.getGlideAIKey();
      this.model = configProvider.getGlideAIModel();
      int configTokens = configProvider.getGlideAIMaxTokens();
      this.maxTokens = Math.max(200, configTokens);
      this.temperature = configProvider.getGlideAITemperature();
      if (SimpleNMSHandler.isDebugMode()) {
         this.logger.info("[GlideAI] Model: " + this.model);
      }

      if (SimpleNMSHandler.isDebugMode()) {
         this.logger.info("[GlideAI] Max Tokens: " + this.maxTokens + " | Temperature: " + this.temperature);
      }

      if (SimpleNMSHandler.isDebugMode()) {
         this.logger.info("[GlideAI] Multi-Key System: " + PLAYER_API_KEYS.size() + " API keys loaded (20 chat + 16 movement)");
      }

      this.systemPrompt = configProvider.getSystemPrompt();
      this.memorySize = configProvider.getMemorySize();
      this.enabled = this.defaultApiKey != null && !this.defaultApiKey.isEmpty();
      this.messageLimit = Integer.MAX_VALUE;
      if (SimpleNMSHandler.isDebugMode()) {
         this.logger.info("[GlideAI] Unlimited AI messages enabled!");
      }

      int connectTimeout = Math.max(3, configProvider.getGlideAIConnectTimeout());
      int writeTimeout = Math.max(5, configProvider.getGlideAIWriteTimeout());
      int readTimeout = Math.max(8, configProvider.getGlideAIReadTimeout());
      int maxRequests = configProvider.getGlideAIMaxConcurrentRequests();
      this.minRequestInterval = configProvider.getGlideAIMinRequestInterval();
      this.maxConcurrentRequests = maxRequests;
      this.perKeyMaxConcurrent = this.getIntConfig("per-key-max-concurrent", 1);
      this.perKeyMinInterval = (long)this.getIntConfig("per-key-min-interval", 10000);
      Dispatcher dispatcher = new Dispatcher();
      dispatcher.setMaxRequests(maxRequests * 2);
      dispatcher.setMaxRequestsPerHost(maxRequests * 2);
      this.httpClient = (new OkHttpClient.Builder()).connectTimeout((long)connectTimeout, TimeUnit.SECONDS).writeTimeout((long)writeTimeout, TimeUnit.SECONDS).readTimeout((long)readTimeout, TimeUnit.SECONDS).retryOnConnectionFailure(true).dispatcher(dispatcher).build();
      if (SimpleNMSHandler.isDebugMode()) {
         this.logger.info("[GlideAI] Timeouts - Connect: " + connectTimeout + "s, Write: " + writeTimeout + "s, Read: " + readTimeout + "s");
      }

      if (SimpleNMSHandler.isDebugMode()) {
         this.logger.info("[GlideAI] Rate Limiting - Global: " + maxRequests + " concurrent, " + this.minRequestInterval + "ms interval");
      }

      if (SimpleNMSHandler.isDebugMode()) {
         this.logger.info("[GlideAI] Per-Key Rate Limiting - " + this.perKeyMaxConcurrent + " concurrent/key, " + this.perKeyMinInterval + "ms interval/key");
      }

      this.conversationMemory = new ConcurrentHashMap();
      this.recentResponses = new ConcurrentHashMap();
   }

   private boolean wasRecentlyUsed(String playerName, String response) {
      LinkedList<String> recent = (LinkedList)this.recentResponses.get(playerName.toLowerCase());
      if (recent != null) {
         String normalized = response.toLowerCase().trim();

         for(String r : recent) {
            if (r.toLowerCase().trim().equals(normalized)) {
               return true;
            }
         }
      }

      return false;
   }

   private void trackResponse(String playerName, String response) {
      LinkedList<String> recent = (LinkedList)this.recentResponses.computeIfAbsent(playerName.toLowerCase(), (k) -> new LinkedList());
      recent.add(response);

      while(recent.size() > 5) {
         recent.removeFirst();
      }

   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public String getSystemPrompt(String playerName) {
      String basePrompt;
      try {
         String personalizedPrompt = this.configProvider.getSystemPrompt(playerName);
         if (personalizedPrompt != null && !personalizedPrompt.isEmpty()) {
            basePrompt = personalizedPrompt;
         } else {
            basePrompt = this.systemPrompt.replace("{player}", playerName);
         }
      } catch (Exception var5) {
         basePrompt = this.systemPrompt.replace("{player}", playerName);
      }

      try {
         String contextBoost = this.configProvider.getContextBoost();
         if (contextBoost != null && !contextBoost.trim().isEmpty()) {
            return basePrompt + "\n\n" + contextBoost.trim();
         }
      } catch (Exception var4) {
      }

      return basePrompt;
   }

   public CompletableFuture<String> getChatResponse(String playerName, String message, List<AIService.ChatMessage> history) {
      CompletableFuture<String> future = new CompletableFuture();
      if (!this.enabled) {
         future.complete((Object)null);
         return future;
      } else {
         String apiKey = this.getApiKeyForPlayer(playerName);
         this.waitAndExecute(apiKey, () -> this.executeRequest(playerName, message, apiKey, future));
         return future;
      }
   }

   private void executeRequest(final String playerName, String message, final String apiKey, final CompletableFuture<String> future) {
      final LinkedList<AIService.ChatMessage> memory = (LinkedList)this.conversationMemory.computeIfAbsent(playerName, (k) -> new LinkedList());
      memory.add(new AIService.ChatMessage("user", message));

      while(memory.size() > this.memorySize) {
         memory.removeFirst();
      }

      JsonObject requestBody = new JsonObject();
      requestBody.addProperty("model", this.model);
      requestBody.addProperty("max_tokens", (Number)this.maxTokens);
      requestBody.addProperty("temperature", (Number)this.temperature);
      JsonArray messages = new JsonArray();
      JsonObject systemMsg = new JsonObject();
      systemMsg.addProperty("role", "system");
      systemMsg.addProperty("content", this.getSystemPrompt(playerName));
      messages.add((JsonElement)systemMsg);

      for(AIService.ChatMessage msg : memory) {
         JsonObject msgObj = new JsonObject();
         msgObj.addProperty("role", msg.getRole());
         msgObj.addProperty("content", msg.getContent());
         messages.add((JsonElement)msgObj);
      }

      requestBody.add("messages", messages);
      String token = generateToken(apiKey, 3600000L);
      if (token == null) {
         this.logger.warning("[GlideAI] Failed to generate token for " + playerName);
         this.completeRequest(apiKey);
         future.complete((Object)null);
      } else {
         RequestBody body = RequestBody.create(requestBody.toString(), MediaType.parse("application/json"));
         Request request = (new Request.Builder()).url("https://api.z.ai/api/paas/v4/chat/completions").addHeader("Authorization", "Bearer " + token).addHeader("Content-Type", "application/json").post(body).build();
         this.httpClient.newCall(request).enqueue(new Callback() {
            public void onFailure(Call call, IOException e) {
               GlideAIService.this.completeRequest(apiKey);
               String var10001 = playerName;
               GlideAIService.this.logger.warning("[GlideAI] Request failed for " + var10001 + ": " + e.getMessage());
               future.complete((Object)null);
            }

            public void onResponse(Call call, Response response) throws IOException {
               try {
                  if (!response.isSuccessful()) {
                     String errorBody = response.body() != null ? response.body().string() : "no body";
                     if (response.code() == 429) {
                        GlideAIService.this.handle429Error(apiKey, playerName);
                     }

                     GlideAIService.this.logger.warning("[GlideAI] Error " + response.code() + " for " + playerName + ": " + errorBody);
                     future.complete((Object)null);
                     return;
                  }

                  GlideAIService.this.clear429Backoff(apiKey);
                  String responseBody = response.body().string();
                  JsonObject jsonResponse = (JsonObject)GlideAIService.this.gson.fromJson(responseBody, JsonObject.class);
                  JsonObject messageObj = jsonResponse.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message");
                  String content = messageObj.get("content").getAsString();
                  if ((content == null || content.isEmpty()) && messageObj.has("reasoning_content")) {
                     content = messageObj.get("reasoning_content").getAsString();
                  }

                  if ((content == null || content.isEmpty()) && messageObj.has("thought")) {
                     content = messageObj.get("thought").getAsString();
                  }

                  String finalContent = content != null ? content.trim() : "";
                  if (!finalContent.isEmpty()) {
                     GlideAIService.this.trackResponse(playerName, finalContent);
                     memory.add(new AIService.ChatMessage("assistant", finalContent));
                     ++GlideAIService.this.messageCount;
                     future.complete(finalContent);
                     return;
                  }

                  future.complete((Object)null);
               } catch (Exception var11) {
                  String var10001 = playerName;
                  GlideAIService.this.logger.warning("[GlideAI] Parse error for " + var10001 + ": " + var11.getMessage());
                  future.complete((Object)null);
                  return;
               } finally {
                  response.close();
                  GlideAIService.this.completeRequest(apiKey);
               }

            }
         });
      }

   }

   public CompletableFuture<String> getChatResponseStreamed(String playerName, String message, List<AIService.ChatMessage> history, Consumer<String> chunkCallback, Runnable completeCallback) {
      CompletableFuture<String> future = new CompletableFuture();
      if (!this.enabled) {
         future.complete((Object)null);
         if (completeCallback != null) {
            completeCallback.run();
         }

         return future;
      } else {
         String apiKey = this.getApiKeyForPlayer(playerName);
         this.waitAndExecute(apiKey, () -> this.executeStreamedRequest(playerName, message, apiKey, future, chunkCallback, completeCallback));
         return future;
      }
   }

   private void executeStreamedRequest(final String playerName, String message, final String apiKey, final CompletableFuture<String> future, final Consumer<String> chunkCallback, final Runnable completeCallback) {
      final LinkedList<AIService.ChatMessage> memory = (LinkedList)this.conversationMemory.computeIfAbsent(playerName, (k) -> new LinkedList());
      memory.add(new AIService.ChatMessage("user", message));

      while(memory.size() > this.memorySize) {
         memory.removeFirst();
      }

      JsonObject requestBody = new JsonObject();
      requestBody.addProperty("model", this.model);
      requestBody.addProperty("max_tokens", (Number)this.maxTokens);
      requestBody.addProperty("temperature", (Number)this.temperature);
      requestBody.addProperty("stream", true);
      JsonArray messages = new JsonArray();
      JsonObject systemMsg = new JsonObject();
      systemMsg.addProperty("role", "system");
      systemMsg.addProperty("content", this.getSystemPrompt(playerName));
      messages.add((JsonElement)systemMsg);

      for(AIService.ChatMessage msg : memory) {
         JsonObject msgObj = new JsonObject();
         msgObj.addProperty("role", msg.getRole());
         msgObj.addProperty("content", msg.getContent());
         messages.add((JsonElement)msgObj);
      }

      requestBody.add("messages", messages);
      String token = generateToken(apiKey, 3600000L);
      if (token == null) {
         this.logger.warning("[GlideAI] Failed to generate token for " + playerName);
         this.completeRequest(apiKey);
         future.complete((Object)null);
         if (completeCallback != null) {
            completeCallback.run();
         }
      } else {
         RequestBody body = RequestBody.create(requestBody.toString(), MediaType.parse("application/json"));
         Request request = (new Request.Builder()).url("https://api.z.ai/api/paas/v4/chat/completions").addHeader("Authorization", "Bearer " + token).addHeader("Content-Type", "application/json").post(body).build();
         final StringBuilder fullResponse = new StringBuilder();
         this.httpClient.newCall(request).enqueue(new Callback() {
            public void onFailure(Call call, IOException e) {
               GlideAIService.this.completeRequest(apiKey);
               String var10001 = playerName;
               GlideAIService.this.logger.warning("[GlideAI] Request failed for " + var10001 + ": " + e.getMessage());
               future.complete((Object)null);
               if (completeCallback != null) {
                  completeCallback.run();
               }

            }

            public void onResponse(Call call, Response response) throws IOException {
               try {
                  if (!response.isSuccessful()) {
                     String errorBody = response.body() != null ? response.body().string() : "no body";
                     if (response.code() == 429) {
                        GlideAIService.this.handle429Error(apiKey, playerName);
                     }

                     GlideAIService.this.logger.warning("[GlideAI] Error " + response.code() + " for " + playerName + ": " + errorBody);
                     future.complete((Object)null);
                     if (completeCallback != null) {
                        completeCallback.run();
                     }

                     return;
                  }

                  GlideAIService.this.clear429Backoff(apiKey);
                  ResponseBody responseBody = response.body();

                  try {
                     InputStream inputStream = responseBody.byteStream();
                     BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));

                     String line;
                     while((line = reader.readLine()) != null) {
                        if (line.startsWith("data: ")) {
                           String data = line.substring(6).trim();
                           if (!"[DONE]".equals(data)) {
                              try {
                                 JsonObject chunkJson = (JsonObject)GlideAIService.this.gson.fromJson(data, JsonObject.class);
                                 JsonArray choices = chunkJson.getAsJsonArray("choices");
                                 if (choices != null && choices.size() > 0) {
                                    JsonObject choice = choices.get(0).getAsJsonObject();
                                    if (choice.has("delta")) {
                                       JsonObject delta = choice.getAsJsonObject("delta");
                                       if (delta.has("content")) {
                                          String deltaContent = delta.get("content").getAsString();
                                          if (!deltaContent.isEmpty()) {
                                             fullResponse.append(deltaContent);
                                             if (chunkCallback != null) {
                                                chunkCallback.accept(deltaContent);
                                             }
                                          }
                                       }
                                    }
                                 }
                              } catch (Exception var20) {
                              }
                           }
                        }
                     }
                  } catch (Throwable var21) {
                     if (responseBody != null) {
                        try {
                           responseBody.close();
                        } catch (Throwable var19) {
                           var21.addSuppressed(var19);
                        }
                     }

                     throw var21;
                  }

                  if (responseBody != null) {
                     responseBody.close();
                  }

                  String completeResponse = fullResponse.toString().trim();
                  if (!completeResponse.isEmpty()) {
                     if (GlideAIService.this.wasRecentlyUsed(playerName, completeResponse)) {
                     }

                     GlideAIService.this.trackResponse(playerName, completeResponse);
                     memory.add(new AIService.ChatMessage("assistant", completeResponse));
                     ++GlideAIService.this.messageCount;
                     future.complete(completeResponse);
                  } else {
                     future.complete((Object)null);
                  }

                  if (completeCallback != null) {
                     completeCallback.run();
                  }
               } catch (Exception var22) {
                  String var10001 = playerName;
                  GlideAIService.this.logger.warning("[GlideAI] Stream parse error for " + var10001 + ": " + var22.getMessage());
                  future.complete((Object)null);
                  if (completeCallback != null) {
                     completeCallback.run();
                  }

                  return;
               } finally {
                  response.close();
                  GlideAIService.this.completeRequest(apiKey);
               }

            }
         });
      }

   }

   private void showLimitWarning() {
      this.logger.warning("╔════════════════════════════════════════════════════════════════════════════╗");
      this.logger.warning("║                    GLIDE AI MESSAGE LIMIT REACHED                         ║");
      this.logger.warning("║                                                                           ║");
      this.logger.warning("║  The free AI message limit of " + this.messageLimit + " has been reached.                      ║");
      this.logger.warning("║  AI responses will stop until server restart.                             ║");
      this.logger.warning("║                                                                           ║");
      this.logger.warning("║  ▶ UPGRADE to unlock the FULL POTENTIAL of GlideSpoofer!                  ║");
      this.logger.warning("║                                                                           ║");
      this.logger.warning("║  Premium Features:                                                        ║");
      this.logger.warning("║    • UNLIMITED AI messages                                                ║");
      this.logger.warning("║    • Faster response time                                                 ║");
      this.logger.warning("║    • Better deepthinking models                                           ║");
      this.logger.warning("║    • Advanced AI features                                                 ║");
      this.logger.warning("║                                                                           ║");
      this.logger.warning("║  Only $4/month!                                                           ║");
      this.logger.warning("║                                                                           ║");
      this.logger.warning("║  Contact: ultimatesetups on Discord                                       ║");
      this.logger.warning("║                                                                           ║");
      this.logger.warning("╚════════════════════════════════════════════════════════════════════════════╝");
   }

   public void clearMemory(String playerName) {
      this.conversationMemory.remove(playerName);
   }

   public void clearAllMemory() {
      this.conversationMemory.clear();
   }

   static {
      PLAYER_API_KEYS.put("GLIDE1", "9f22c55b36b148bd87769f171202410b.DIDXHPEAFUMovmPy");
      PLAYER_API_KEYS.put("GLIDE2", "740323cf702e44a5b34711bf5b43a5b5.KKJPzrqW19VtpDIg");
      PLAYER_API_KEYS.put("GLIDE3", "3ed495c49196481f989d87b6fec314fc.hNwxgjphYZjZ09K7");
      PLAYER_API_KEYS.put("GLIDE4", "e5442ecab2b6471f8106e3fc2697ad2c.JXmF3Flz0CiAjYjy");
      PLAYER_API_KEYS.put("GLIDE5", "0b77043b601a493e965bab3335e23752.8HNEZclvg7T976XO");
      PLAYER_API_KEYS.put("GLIDE6", "d70b6ecebd8d422c9fd45b7271b53848.PWWJWm2S46o7RTKc");
      PLAYER_API_KEYS.put("GLIDE7", "13d434ba2fd94e74aae14e5e7f710701.o8pSOcLPtZNOTZL4");
      PLAYER_API_KEYS.put("GLIDE8", "8dbb878e79ad4c15b3bfceba49ef9294.g3b4zQXZMgfTVRbp");
      PLAYER_API_KEYS.put("GLIDE9", "7b99b41fc0284b8c90bb0082968affeb.YFAftZm5ObF4E2hU");
      PLAYER_API_KEYS.put("GLIDE10", "1d06d9ab847d49b080beae987898de12.OGim7OemOqgHCznj");
      PLAYER_API_KEYS.put("GLIDE11", "2a57d9369808494fa3c459aa36216bfc.iqRclcGnl0fEBfTH");
      PLAYER_API_KEYS.put("GLIDE12", "4f0320858f0f4f21917fc5d69856e0af.DTuPU22ovxVD8CkD");
      PLAYER_API_KEYS.put("GLIDE13", "ba11e4f68f22485a90727c7c2b5bc791.8kSV54dqepyOLm61");
      PLAYER_API_KEYS.put("GLIDE14", "1012a35226094daea22f40381ab34bcc.vILLTCSGT5Mnk5pk");
      PLAYER_API_KEYS.put("GLIDE15", "be69f636c7294f6aa80c632c9627bff8.0V0XCSYo04Bmtwo6");
      PLAYER_API_KEYS.put("GLIDE16", "3f354edd401c40b79465b6f7fce8e600.muS1swJ3snmV3WA5");
      PLAYER_API_KEYS.put("GLIDE17", "c469bc1b0326456e8de45a5527a8456e.Z87YfQoxjnZyl7Ns");
      PLAYER_API_KEYS.put("GLIDE18", "6d3c619c5e7c4fb3870ac469be14d480.hPUCKX7EWdUHjX2B");
      PLAYER_API_KEYS.put("GLIDE19", "76bf19fcbe3247f48e119475aa964b70.rCIMCtgYP4TGJIEB");
      PLAYER_API_KEYS.put("GLIDE20", "5955e60d427a42db8f064e529f731053.e6sBLsQym9uUEPXP");
      PLAYER_API_KEYS.put("GLIDE21", "e8b24d8bc9934747ae83ddcacd14636f.tpomq0Dk479Le2R4");
      PLAYER_API_KEYS.put("GLIDE22", "51eec60041354395871dc02f3fa706a5.OPjHXWdKlGqabDBC");
      PLAYER_API_KEYS.put("GLIDE23", "c8b867177f364bd3982a203b39b291f8.2he54i1JevtY3bA4");
      PLAYER_API_KEYS.put("GLIDE24", "c8a347dd318f4843b33041a4034389f1.abNhKymjL6TwfrKL");
      PLAYER_API_KEYS.put("GLIDE25", "83208d72924947b68829eb2edf55d72d.gQSghNmgBtMOLfZm");
      PLAYER_API_KEYS.put("GLIDE26", "06ba7a0b03cb4dcfa8cb0e8dca3fec01.DPbWCm68DtiOEmy2");
      PLAYER_API_KEYS.put("GLIDE27", "724377c10ce948abadc67e97d33af5af.vTmox0f5fFj4MWR6");
      PLAYER_API_KEYS.put("GLIDE28", "54649d99897e41f5b09d13d4130775db.ulBZSlz6TFTf9rDx");
      PLAYER_API_KEYS.put("GLIDE29", "9e04b70b28c54c5f9acc2bc5269eb19c.Y2JAZVfw6N0XuWE9");
      PLAYER_API_KEYS.put("GLIDE30", "18bbd4ea97ec4000beecf63bb5d7f27c.ohki8xYFLW0y1DOc");
      PLAYER_API_KEYS.put("GLIDE31", "ed5272c9eb1a4c04bbe3bf2c83a74864.0Ki2QjW7WZKpzRBC");
      PLAYER_API_KEYS.put("GLIDE32", "b191683453994d518611fcfbb7f89c80.10ucOv9JOsbUIdAi");
      PLAYER_API_KEYS.put("GLIDE33", "ea50db43201c49afa8127d5f2ed84335.RvdUz3YSJbuMGvgi");
      PLAYER_API_KEYS.put("GLIDE34", "364c794856fe459cb2ace9b56da8f5a4.oeKuwwSfbMdJXscO");
      PLAYER_API_KEYS.put("GLIDE35", "8f677db1f30f4b249e129499c1b2caf2.oSV5hCoof2uh9Cn0");
      PLAYER_API_KEYS.put("GLIDE36", "cd15045a5daf4b11ab2500d2a04621e5.jG24KGtEPxgQy7bR");
      PLAYER_NAME_TO_KEY.put("xdarkslayer", "GLIDE1");
      PLAYER_NAME_TO_KEY.put("minehelper64", "GLIDE2");
      PLAYER_NAME_TO_KEY.put("vibecheck2k", "GLIDE3");
      PLAYER_NAME_TO_KEY.put("buildersteve", "GLIDE4");
      PLAYER_NAME_TO_KEY.put("farmkingog", "GLIDE5");
      PLAYER_NAME_TO_KEY.put("noobmaster99", "GLIDE6");
      PLAYER_NAME_TO_KEY.put("silentgamer", "GLIDE7");
      PLAYER_NAME_TO_KEY.put("dankmemelord", "GLIDE8");
      PLAYER_NAME_TO_KEY.put("afkandy", "GLIDE9");
      PLAYER_NAME_TO_KEY.put("shopmaster", "GLIDE10");
      PLAYER_NAME_TO_KEY.put("ogplayer2019", "GLIDE16");
      PLAYER_NAME_TO_KEY.put("clanwarrior", "GLIDE17");
      PLAYER_NAME_TO_KEY.put("alwaysbuggin", "GLIDE18");
      PLAYER_NAME_TO_KEY.put("explorermax", "GLIDE19");
      PLAYER_NAME_TO_KEY.put("flexgod", "GLIDE20");
      PLAYER_NAME_TO_KEY.put("bear2", "GLIDE11");
      PLAYER_NAME_TO_KEY.put("ice_samurai", "GLIDE12");
      PLAYER_NAME_TO_KEY.put("crimson_elite", "GLIDE13");
      PLAYER_NAME_TO_KEY.put("dark_ranger", "GLIDE14");
      PLAYER_NAME_TO_KEY.put("shadowhunter", "GLIDE15");
   }
}
