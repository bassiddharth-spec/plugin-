package com.glidespoofer.nms;

import com.glidespoofer.fake.FakePlayer;
import java.util.UUID;
import java.util.function.Consumer;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public interface NMSHandler {
   Player spawnFakePlayer(String var1, UUID var2, Location var3);

   default Player spawnFakePlayer(String name, UUID uuid, Location location, String skinName) {
      return this.spawnFakePlayer(name, uuid, location);
   }

   void setupClientOptions(Player var1);

   void removeFakePlayer(Player var1);

   default void removeFakePlayer(UUID uuid) {
   }

   default void forceRemoveFakePlayer(UUID uuid) {
      this.removeFakePlayer(uuid);
   }

   boolean isCompatible();

   default String getVersion() {
      return "unknown";
   }

   default boolean isFakePlayer(Player player) {
      return false;
   }

   default boolean isFakePlayer(UUID uuid) {
      return false;
   }

   default void performAction(Player player, FakePlayerAction action) {
   }

   default void updatePosition(Player player, Location location, boolean smooth) {
      player.teleport(location);
   }

   default void updateRotation(Player player, float yaw, float pitch) {
      Location loc = player.getLocation();
      loc.setYaw(yaw);
      loc.setPitch(pitch);
      player.teleport(loc);
   }

   default void registerWithPlugin(Plugin plugin) {
   }

   default void setMessageHandler(UUID uuid, Consumer<String> handler) {
   }

   default Player getFakePlayer(UUID uuid) {
      return null;
   }

   default Player getFakePlayer(String name) {
      return null;
   }

   default int getPing(UUID uuid) {
      return 50;
   }

   default int getFakePlayerCount() {
      return 0;
   }

   default void setLookAtPlayers(UUID uuid, boolean enabled) {
   }

   default boolean isLookingAtPlayers(UUID uuid) {
      return false;
   }

   default void setVisibleInWorld(UUID uuid, boolean visible) {
   }

   default boolean isVisibleInWorld(UUID uuid) {
      return true;
   }

   default void setVisibleInTab(UUID uuid, boolean visible) {
   }

   default void setVisibleInPing(UUID uuid, boolean visible) {
   }

   default void sendEntityMetadata(Player viewer, FakePlayer fake, int entityId, boolean isSprinting) {
   }

   default void sendEntityAnimation(Player viewer, int entityId, int animationId) {
   }

   default void sendEntityVelocity(Player viewer, Player entity, double vx, double vy, double vz) {
   }

   public static enum FakePlayerAction {
      SWING_MAIN_ARM,
      SWING_OFF_HAND,
      DAMAGE_ANIMATION,
      START_DEATH_ANIMATION,
      LEAVE_BED,
      CRITICAL_EFFECT,
      MAGIC_CRITICAL_EFFECT,
      SNEAK_START,
      SNEAK_END,
      SPRINT_START,
      SPRINT_END,
      JUMP;

      // $FF: synthetic method
      private static FakePlayerAction[] $values() {
         return new FakePlayerAction[]{SWING_MAIN_ARM, SWING_OFF_HAND, DAMAGE_ANIMATION, START_DEATH_ANIMATION, LEAVE_BED, CRITICAL_EFFECT, MAGIC_CRITICAL_EFFECT, SNEAK_START, SNEAK_END, SPRINT_START, SPRINT_END, JUMP};
      }
   }
}
