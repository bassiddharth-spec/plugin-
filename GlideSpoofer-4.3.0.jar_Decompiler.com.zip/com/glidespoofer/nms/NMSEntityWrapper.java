package com.glidespoofer.nms;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class NMSEntityWrapper {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-NMSEntity");
   private static String nmsVersion;
   private static boolean isModern = false;
   private static boolean is1_21Plus = false;
   private static boolean is1_19Plus = false;
   private static boolean is1_18Plus = false;
   private static Class<?> entityClass;
   private static Class<?> livingEntityClass;
   private static Class<?> playerClass;
   private static Method getBukkitEntityMethod;
   private static Method tickMethod;
   private static Method knockbackMethod;
   private static Method hurtMethod;
   private static Method moveToMethod;
   private static Method setPosMethod;
   private static Method setRotMethod;
   private static Method getXMethod;
   private static Method getYMethod;
   private static Method getZMethod;
   private static Method getYawMethod;
   private static Method getPitchMethod;
   private static Field idField;
   private static Field invulnerableField;
   private static Field noGravityField;
   private static Field onGroundField;
   private static Field xxaField;
   private static Field zzaField;
   private static Field yRotField;
   private static Field xRotField;
   private static Field deadField;
   private static Field hurtTimeField;
   private static Field hurtDurationField;
   private static Field hurtDirectionField;
   private static Field healthField;
   private static Field maxHealthField;
   private final Object nmsEntity;
   private final Player bukkitPlayer;
   private boolean initialized = false;

   private static void initializeReflection() {
      try {
         String mcVersion = getMinecraftVersion();
         isModern = !mcVersion.startsWith("1.8") && !mcVersion.startsWith("1.9") && !mcVersion.startsWith("1.10") && !mcVersion.startsWith("1.11") && !mcVersion.startsWith("1.12") && !mcVersion.startsWith("1.13") && !mcVersion.startsWith("1.14") && !mcVersion.startsWith("1.15") && !mcVersion.startsWith("1.16");
         is1_18Plus = compareVersions(mcVersion, "1.18") >= 0;
         is1_19Plus = compareVersions(mcVersion, "1.19") >= 0;
         is1_21Plus = compareVersions(mcVersion, "1.21") >= 0;

         try {
            String[] parts = Bukkit.getServer().getClass().getPackage().getName().split("\\.");
            if (parts.length > 3) {
               nmsVersion = parts[3];
            } else {
               nmsVersion = "";
            }
         } catch (Exception var36) {
            nmsVersion = "";
         }

         if (SimpleNMSHandler.isDebugMode()) {
            LOGGER.info("[NMSEntityWrapper] Detected version: " + mcVersion + ", modern: " + isModern);
         }

         if (is1_18Plus) {
            entityClass = Class.forName("net.minecraft.world.entity.Entity");
            livingEntityClass = Class.forName("net.minecraft.world.entity.LivingEntity");
            playerClass = Class.forName("net.minecraft.server.level.ServerPlayer");
         } else {
            entityClass = Class.forName("net.minecraft.server." + nmsVersion + ".Entity");
            livingEntityClass = Class.forName("net.minecraft.server." + nmsVersion + ".EntityLiving");
            playerClass = Class.forName("net.minecraft.server." + nmsVersion + ".EntityPlayer");
         }

         getBukkitEntityMethod = entityClass.getMethod("getBukkitEntity");
         tickMethod = entityClass.getMethod("tick");

         try {
            moveToMethod = entityClass.getMethod("moveTo", Double.TYPE, Double.TYPE, Double.TYPE);
         } catch (NoSuchMethodException var35) {
            try {
               moveToMethod = entityClass.getMethod("setPosition", Double.TYPE, Double.TYPE, Double.TYPE);
            } catch (NoSuchMethodException var34) {
            }
         }

         try {
            setPosMethod = entityClass.getMethod("setPos", Double.TYPE, Double.TYPE, Double.TYPE);
         } catch (NoSuchMethodException var33) {
         }

         try {
            setRotMethod = entityClass.getMethod("setRot", Float.TYPE, Float.TYPE);
         } catch (NoSuchMethodException var32) {
         }

         try {
            knockbackMethod = livingEntityClass.getDeclaredMethod("knockback", Double.TYPE, Double.TYPE, Double.TYPE);
            knockbackMethod.setAccessible(true);
         } catch (NoSuchMethodException var31) {
            try {
               knockbackMethod = livingEntityClass.getDeclaredMethod("a", Double.TYPE, Double.TYPE, Double.TYPE);
               knockbackMethod.setAccessible(true);
            } catch (NoSuchMethodException var301) {
               LOGGER.fine("[NMSEntityWrapper] Could not find knockback method");
            }
         }

         try {
            if (is1_19Plus) {
               try {
                  hurtMethod = entityClass.getDeclaredMethod("hurt", Class.forName("net.minecraft.world.damagesource.DamageSource"), Float.TYPE, Float.TYPE);
               } catch (NoSuchMethodException var28) {
                  try {
                     hurtMethod = entityClass.getDeclaredMethod("hurt", Class.forName("net.minecraft.world.damagesource.DamageSource"), Float.TYPE);
                  } catch (NoSuchMethodException var27) {
                     try {
                        hurtMethod = livingEntityClass.getDeclaredMethod("hurt", Class.forName("net.minecraft.world.damagesource.DamageSource"), Float.TYPE);
                     } catch (NoSuchMethodException var26) {
                        hurtMethod = entityClass.getMethod("hurt", Class.forName("net.minecraft.world.damagesource.DamageSource"), Float.TYPE);
                     }
                  }
               }
            } else if (is1_18Plus) {
               try {
                  hurtMethod = entityClass.getDeclaredMethod("hurt", Class.forName("net.minecraft.world.damagesource.DamageSource"), Float.TYPE);
               } catch (NoSuchMethodException var25) {
                  hurtMethod = livingEntityClass.getDeclaredMethod("hurt", Class.forName("net.minecraft.world.damagesources.DamageSource"), Float.TYPE);
               }
            } else {
               hurtMethod = livingEntityClass.getDeclaredMethod("damageEntity", Class.forName("net.minecraft.util.DamageSource"), Float.TYPE);
            }

            hurtMethod.setAccessible(true);
            if (SimpleNMSHandler.isDebugMode()) {
               LOGGER.info("[NMSEntityWrapper] Found hurt method: " + String.valueOf(hurtMethod));
            }
         } catch (NoSuchMethodException var29) {
            LOGGER.warning("[NMSEntityWrapper] Could not find hurt method in Entity or LivingEntity classes");
            var29.printStackTrace();
         }

         try {
            idField = entityClass.getDeclaredField("id");
            idField.setAccessible(true);
         } catch (NoSuchFieldException var24) {
         }

         try {
            invulnerableField = entityClass.getDeclaredField("invulnerable");
            invulnerableField.setAccessible(true);
         } catch (NoSuchFieldException var23) {
            try {
               Field f = entityClass.getDeclaredField("d");
               f.setAccessible(true);
               invulnerableField = f;
            } catch (Exception var22) {
            }
         }

         try {
            noGravityField = entityClass.getDeclaredField("noGravity");
            noGravityField.setAccessible(true);
         } catch (NoSuchFieldException var21) {
            try {
               Field f = entityClass.getDeclaredField("N");
               f.setAccessible(true);
               noGravityField = f;
            } catch (Exception var20) {
            }
         }

         try {
            onGroundField = entityClass.getDeclaredField("onGround");
            onGroundField.setAccessible(true);
         } catch (NoSuchFieldException var19) {
            try {
               Field f = entityClass.getDeclaredField("onGround");
               f.setAccessible(true);
               onGroundField = f;
            } catch (Exception var18) {
            }
         }

         try {
            xxaField = livingEntityClass.getDeclaredField("xxa");
            xxaField.setAccessible(true);
         } catch (NoSuchFieldException var39) {
            try {
               for(Field f : livingEntityClass.getDeclaredFields()) {
                  if (f.getType() == Float.TYPE && f.getName().length() <= 3) {
                     f.setAccessible(true);

                     try {
                        if (f.getFloat((Object)null) == 0.0F) {
                           xxaField = f;
                           break;
                        }
                     } catch (Exception var37) {
                     }
                  }
               }
            } catch (Exception var38) {
            }
         }

         try {
            zzaField = livingEntityClass.getDeclaredField("zza");
            zzaField.setAccessible(true);
         } catch (NoSuchFieldException var17) {
         }

         try {
            yRotField = entityClass.getDeclaredField("yRot");
            yRotField.setAccessible(true);
         } catch (NoSuchFieldException var16) {
         }

         try {
            xRotField = entityClass.getDeclaredField("xRot");
            xRotField.setAccessible(true);
         } catch (NoSuchFieldException var15) {
         }

         try {
            deadField = livingEntityClass.getDeclaredField("dead");
            deadField.setAccessible(true);
         } catch (NoSuchFieldException var14) {
            try {
               Field fx = livingEntityClass.getDeclaredField("dead");
               fx.setAccessible(true);
               deadField = fx;
            } catch (Exception var13) {
            }
         }

         try {
            hurtTimeField = livingEntityClass.getDeclaredField("hurtTime");
            hurtTimeField.setAccessible(true);
         } catch (NoSuchFieldException var12) {
         }

         try {
            hurtDurationField = livingEntityClass.getDeclaredField("hurtDuration");
            hurtDurationField.setAccessible(true);
         } catch (NoSuchFieldException var11) {
         }

         try {
            hurtDirectionField = livingEntityClass.getDeclaredField("hurtDir");
            hurtDirectionField.setAccessible(true);
         } catch (NoSuchFieldException var10) {
            try {
               hurtDirectionField = livingEntityClass.getDeclaredField("hurtDirection");
               hurtDirectionField.setAccessible(true);
            } catch (Exception var9) {
            }
         }

         try {
            healthField = livingEntityClass.getDeclaredField("health");
            healthField.setAccessible(true);
         } catch (NoSuchFieldException var8) {
         }

         try {
            maxHealthField = livingEntityClass.getDeclaredField("maxHealth");
            maxHealthField.setAccessible(true);
         } catch (NoSuchFieldException var7) {
         }

         if (SimpleNMSHandler.isDebugMode()) {
            LOGGER.info("[NMSEntityWrapper] Reflection initialized successfully");
         }
      } catch (Exception var40) {
         LOGGER.log(Level.SEVERE, "[NMSEntityWrapper] Failed to initialize reflection", var40);
      }

   }

   private static String getMinecraftVersion() {
      try {
         Method method = Bukkit.class.getMethod("getMinecraftVersion");
         return (String)method.invoke((Object)null);
      } catch (Exception var1) {
         return "1.8.8";
      }
   }

   private static int compareVersions(String v1, String v2) {
      String[] p1 = v1.split("\\.");
      String[] p2 = v2.split("\\.");

      for(int i = 0; i < Math.max(p1.length, p2.length); ++i) {
         int n1 = i < p1.length ? Integer.parseInt(p1[i]) : 0;
         int n2 = i < p2.length ? Integer.parseInt(p2[i]) : 0;
         if (n1 != n2) {
            return n1 - n2;
         }
      }

      return 0;
   }

   public NMSEntityWrapper(Player player) {
      this.bukkitPlayer = player;
      this.nmsEntity = getNMSEntity(player);
      this.initialized = this.nmsEntity != null;
   }

   public NMSEntityWrapper(Object nmsEntity) {
      this.nmsEntity = nmsEntity;
      this.bukkitPlayer = null;
      this.initialized = nmsEntity != null;
   }

   private static Object getNMSEntity(Player player) {
      try {
         Method getHandle = player.getClass().getMethod("getHandle");
         return getHandle.invoke(player);
      } catch (Exception var2) {
         LOGGER.log(Level.WARNING, "[NMSEntityWrapper] Failed to get NMS entity", var2);
         return null;
      }
   }

   public List<Player> getTrackingPlayers() {
      if (!this.initialized) {
         return new ArrayList();
      } else {
         try {
            Object trackerEntry = this.getEntityTrackerEntry();
            if (trackerEntry == null) {
               return new ArrayList();
            } else {
               List<Player> trackers = new ArrayList();
               String[] fieldNames = new String[]{"trackedPlayers", "seenBy", "c"};

               for(String fieldName : fieldNames) {
                  try {
                     Field trackedPlayersField = trackerEntry.getClass().getDeclaredField(fieldName);
                     trackedPlayersField.setAccessible(true);
                     Object trackedPlayers = trackedPlayersField.get(trackerEntry);
                     if (trackedPlayers instanceof Collection) {
                        for(Object obj : (Collection)trackedPlayers) {
                           Player p = this.toBukkitPlayer(obj);
                           if (p != null) {
                              trackers.add(p);
                           }
                        }
                        break;
                     }

                     if (trackedPlayers instanceof Map) {
                        for(Object key : ((Map)trackedPlayers).keySet()) {
                           Player p = this.toBukkitPlayer(key);
                           if (p != null) {
                              trackers.add(p);
                           }
                        }
                        break;
                     }
                  } catch (NoSuchFieldException var13) {
                  }
               }

               return trackers;
            }
         } catch (Exception var14) {
            LOGGER.log(Level.WARNING, "[NMSEntityWrapper] Failed to get tracking players", var14);
            return new ArrayList();
         }
      }
   }

   private Object getEntityTrackerEntry() {
      try {
         World world = this.bukkitPlayer != null ? this.bukkitPlayer.getWorld() : null;
         if (world == null) {
            return null;
         } else {
            Object serverLevel = this.getServerLevel(world);
            if (serverLevel == null) {
               return null;
            } else {
               Method getTracker = serverLevel.getClass().getMethod("getTracker");
               Object tracker = getTracker.invoke(serverLevel);
               int entityId = this.getEntityId();
               Method getTrackedEntity = tracker.getClass().getMethod("getEntity", Integer.TYPE);
               return getTrackedEntity.invoke(tracker, entityId);
            }
         }
      } catch (Exception var7) {
         return null;
      }
   }

   private Object getServerLevel(World world) {
      try {
         Method getHandle = world.getClass().getMethod("getHandle");
         return getHandle.invoke(world);
      } catch (Exception var3) {
         return null;
      }
   }

   private Player toBukkitPlayer(Object obj) {
      try {
         if (obj == null) {
            return null;
         }

         if (playerClass.isInstance(obj)) {
            Object bukkit = getBukkitEntityMethod.invoke(obj);
            if (bukkit instanceof Player) {
               return (Player)bukkit;
            }
         }

         Method getPlayer = obj.getClass().getMethod("getPlayer");
         Object player = getPlayer.invoke(obj);
         if (player instanceof Player) {
            return (Player)player;
         }
      } catch (Exception var4) {
      }

      return null;
   }

   public void damage(float amount, Player source) {
      if (this.initialized) {
         try {
            Object damageSource = this.createDamageSource(source);
            if (hurtMethod != null) {
               int paramCount = hurtMethod.getParameterCount();
               if (paramCount == 3) {
                  hurtMethod.invoke(this.nmsEntity, damageSource, amount, 0.0F);
               } else {
                  hurtMethod.invoke(this.nmsEntity, damageSource, amount);
               }
            }
         } catch (Exception var5) {
            LOGGER.log(Level.WARNING, "[NMSEntityWrapper] Failed to apply damage", var5);
         }
      }

   }

   public void damageWithKnockback(float amount, Location sourceLoc, double knockbackStrength) {
      if (this.initialized) {
         try {
            this.damage(amount, (Player)null);
            if (sourceLoc != null) {
               Location entityLoc = this.getLocation();
               double dx = entityLoc.getX() - sourceLoc.getX();
               double dz = entityLoc.getZ() - sourceLoc.getZ();
               double length = Math.sqrt(dx * dx + dz * dz);
               if (length > (double)0.0F) {
                  dx /= length;
                  dz /= length;
               }

               this.applyKnockback(knockbackStrength, dx, dz);
            }
         } catch (Exception var12) {
            LOGGER.fine("[NMSEntityWrapper] Failed to damage with knockback: " + var12.getMessage());
         }
      }

   }

   public void applyKnockback(double strength, double dx, double dz) {
      if (this.initialized) {
         try {
            Class<?> vec3Class = isModern ? Class.forName("net.minecraft.world.phys.Vec3") : Class.forName("net.minecraft.server.v1_17_R1.Vec3D");
            Object vec3 = vec3Class.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE).newInstance(dx * strength * (double)2.0F, 0.55, dz * strength * (double)2.0F);
            Method setDeltaMethod = this.nmsEntity.getClass().getMethod("setDeltaMovement", vec3Class);
            setDeltaMethod.invoke(this.nmsEntity, vec3);
         } catch (Exception var10) {
            LOGGER.fine("[NMSEntityWrapper] Failed to apply knockback: " + var10.getMessage());
         }
      }

   }

   private Object createDamageSource(Player source) {
      try {
         Class<?> damageSourceClass;
         if (is1_19Plus) {
            damageSourceClass = Class.forName("net.minecraft.world.damagesource.DamageSource");
         } else if (is1_18Plus) {
            damageSourceClass = Class.forName("net.minecraft.world.damagesources.DamageSource");
         } else {
            damageSourceClass = Class.forName("net.minecraft.util.DamageSource");
         }

         Method playerAttackMethod = damageSourceClass.getMethod("playerAttack", Class.forName("net.minecraft.world.entity.Entity"));
         Object nmsSource = source != null ? getNMSEntity(source) : this.nmsEntity;
         return playerAttackMethod.invoke((Object)null, nmsSource);
      } catch (Exception var5) {
         LOGGER.log(Level.WARNING, "[NMSEntityWrapper] Failed to create damage source", var5);
         return null;
      }
   }

   public float getHealth() {
      if (this.initialized && healthField != null) {
         try {
            return healthField.getFloat(this.nmsEntity);
         } catch (Exception var2) {
            return 20.0F;
         }
      } else {
         return 20.0F;
      }
   }

   public void setHealth(float health) {
      if (this.initialized && healthField != null) {
         try {
            healthField.setFloat(this.nmsEntity, health);
         } catch (Exception var3) {
            LOGGER.log(Level.WARNING, "[NMSEntityWrapper] Failed to set health", var3);
         }
      }

   }

   public float getMaxHealth() {
      if (this.initialized && maxHealthField != null) {
         try {
            return maxHealthField.getFloat(this.nmsEntity);
         } catch (Exception var2) {
            return 20.0F;
         }
      } else {
         return 20.0F;
      }
   }

   public boolean isDead() {
      if (this.initialized && deadField != null) {
         try {
            return deadField.getBoolean(this.nmsEntity);
         } catch (Exception var2) {
            return false;
         }
      } else {
         return false;
      }
   }

   public void setDead(boolean dead) {
      if (this.initialized && deadField != null) {
         try {
            deadField.setBoolean(this.nmsEntity, dead);
         } catch (Exception var3) {
            LOGGER.log(Level.WARNING, "[NMSEntityWrapper] Failed to set dead state", var3);
         }
      }

   }

   public int getHurtTime() {
      if (this.initialized && hurtTimeField != null) {
         try {
            return hurtTimeField.getInt(this.nmsEntity);
         } catch (Exception var2) {
            return 0;
         }
      } else {
         return 0;
      }
   }

   public void setHurtTime(int ticks) {
      if (this.initialized && hurtTimeField != null) {
         try {
            hurtTimeField.setInt(this.nmsEntity, ticks);
         } catch (Exception var3) {
         }
      }

   }

   public void triggerHurtAnimation() {
      if (this.initialized) {
         try {
            if (hurtTimeField != null) {
               hurtTimeField.setInt(this.nmsEntity, 10);
            }

            if (hurtDurationField != null) {
               hurtDurationField.setInt(this.nmsEntity, 10);
            }

            if (hurtDirectionField != null) {
               hurtDirectionField.setInt(this.nmsEntity, (new Random()).nextInt(4));
            }
         } catch (Exception var2) {
         }
      }

   }

   public void tick() {
      if (this.initialized && tickMethod != null) {
         try {
            tickMethod.invoke(this.nmsEntity);
         } catch (Exception var2) {
            LOGGER.log(Level.WARNING, "[NMSEntityWrapper] Failed to tick entity", var2);
         }
      }

   }

   public void moveTo(double x, double y, double z) {
      if (this.initialized) {
         try {
            if (moveToMethod != null) {
               moveToMethod.invoke(this.nmsEntity, x, y, z);
            } else if (setPosMethod != null) {
               setPosMethod.invoke(this.nmsEntity, x, y, z);
            }
         } catch (Exception var8) {
            LOGGER.log(Level.WARNING, "[NMSEntityWrapper] Failed to move entity", var8);
         }
      }

   }

   public void setRotation(float yaw, float pitch) {
      if (this.initialized && setRotMethod != null) {
         try {
            setRotMethod.invoke(this.nmsEntity, yaw, pitch);
         } catch (Exception var4) {
            LOGGER.log(Level.WARNING, "[NMSEntityWrapper] Failed to set rotation", var4);
         }
      }

   }

   public Location getLocation() {
      if (this.bukkitPlayer != null) {
         return this.bukkitPlayer.getLocation();
      } else if (!this.initialized) {
         return null;
      } else {
         try {
            double x = this.getX();
            double y = this.getY();
            double z = this.getZ();
            float yaw = this.getYaw();
            float pitch = this.getPitch();
            return new Location(this.getWorld(), x, y, z, yaw, pitch);
         } catch (Exception var9) {
            return null;
         }
      }
   }

   public void setMovementInput(float strafe, float forward) {
      if (this.initialized) {
         try {
            if (xxaField != null) {
               xxaField.setFloat(this.nmsEntity, strafe);
            }

            if (zzaField != null) {
               zzaField.setFloat(this.nmsEntity, forward);
            }
         } catch (Exception var4) {
            LOGGER.log(Level.WARNING, "[NMSEntityWrapper] Failed to set movement input", var4);
         }
      }

   }

   public void setFacingDirection(float yaw, float pitch) {
      if (this.initialized) {
         try {
            if (yRotField != null) {
               yRotField.setFloat(this.nmsEntity, yaw);
            }

            if (xRotField != null) {
               xRotField.setFloat(this.nmsEntity, pitch);
            }
         } catch (Exception var4) {
            LOGGER.log(Level.WARNING, "[NMSEntityWrapper] Failed to set facing direction", var4);
         }
      }

   }

   private double getX() {
      try {
         if (getXMethod == null) {
            getXMethod = entityClass.getMethod("getX");
         }

         return (Double)getXMethod.invoke(this.nmsEntity);
      } catch (Exception var2) {
         return (double)0.0F;
      }
   }

   private double getY() {
      try {
         if (getYMethod == null) {
            getYMethod = entityClass.getMethod("getY");
         }

         return (Double)getYMethod.invoke(this.nmsEntity);
      } catch (Exception var2) {
         return (double)0.0F;
      }
   }

   private double getZ() {
      try {
         if (getZMethod == null) {
            getZMethod = entityClass.getMethod("getZ");
         }

         return (Double)getZMethod.invoke(this.nmsEntity);
      } catch (Exception var2) {
         return (double)0.0F;
      }
   }

   private float getYaw() {
      try {
         if (getYawMethod == null) {
            getYawMethod = entityClass.getMethod("getYRot");
         }

         return (Float)getYawMethod.invoke(this.nmsEntity);
      } catch (Exception var2) {
         return 0.0F;
      }
   }

   private float getPitch() {
      try {
         if (getPitchMethod == null) {
            getPitchMethod = entityClass.getMethod("getXRot");
         }

         return (Float)getPitchMethod.invoke(this.nmsEntity);
      } catch (Exception var2) {
         return 0.0F;
      }
   }

   private World getWorld() {
      if (this.bukkitPlayer != null) {
         return this.bukkitPlayer.getWorld();
      } else {
         try {
            Method getLevel = entityClass.getMethod("level");
            Object level = getLevel.invoke(this.nmsEntity);
            Method getWorld = level.getClass().getMethod("getWorld");
            return (World)getWorld.invoke(level);
         } catch (Exception var4) {
            return null;
         }
      }
   }

   public int getEntityId() {
      if (this.initialized && idField != null) {
         try {
            return idField.getInt(this.nmsEntity);
         } catch (Exception var2) {
            return -1;
         }
      } else {
         return -1;
      }
   }

   public boolean isOnGround() {
      if (this.initialized && onGroundField != null) {
         try {
            return onGroundField.getBoolean(this.nmsEntity);
         } catch (Exception var2) {
            return false;
         }
      } else {
         return false;
      }
   }

   public Object getNMSEntity() {
      return this.nmsEntity;
   }

   public Player getBukkitPlayer() {
      return this.bukkitPlayer;
   }

   public boolean isInitialized() {
      return this.initialized;
   }

   static {
      initializeReflection();
   }
}
