package com.glidespoofer.nms;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

public class PlayerListInjectorStandalone {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-PlayerListInjector");
   private Object plugin;
   private Object playerList;
   private Field playersField;
   private Field playersByUUIDField;
   private Field playersByNameField;
   private final Map<UUID, Object> fakePlayers = new ConcurrentHashMap();
   private final Map<UUID, String> fakePlayerNames = new ConcurrentHashMap();
   private final Map<UUID, Integer> fakeEntityIds = new ConcurrentHashMap();
   private int entityIdCounter = 50000;

   public PlayerListInjectorStandalone() {
      this.inject();
   }

   public void inject() {
      try {
         Class<?> bukkitClass = Class.forName("org.bukkit.Bukkit");
         Object bukkit = bukkitClass.getMethod("getServer").invoke((Object)null);
         Object minecraftServer = bukkitClass.getMethod("getHandle").invoke(bukkit);
         Method getPlayerListMethod = minecraftServer.getClass().getMethod("getPlayerList");
         this.playerList = getPlayerListMethod.invoke(minecraftServer);
         this.playersField = this.playerList.getClass().getDeclaredField("players");
         this.playersField.setAccessible(true);
         this.playersByUUIDField = this.playerList.getClass().getDeclaredField("playersByUUID");
         this.playersByUUIDField.setAccessible(true);
         this.playersByNameField = this.playerList.getClass().getDeclaredField("playersByName");
         this.playersByNameField.setAccessible(true);
         LOGGER.info("Successfully injected into PlayerList");
      } catch (Exception e) {
         LOGGER.severe("Failed to inject into PlayerList: " + e.getMessage());
         e.printStackTrace();
      }

   }

   public void addFakePlayer(UUID uuid, String name) {
      if (this.playerList == null) {
         LOGGER.warning("PlayerList not injected, cannot add fake player");
      } else {
         try {
            this.fakePlayers.put(uuid, uuid);
            this.fakePlayerNames.put(uuid, name);
            Object playerProxy = this.createPlayerProxy(uuid, name);
            if (playerProxy != null) {
               this.addToLists(uuid, name, playerProxy);
               LOGGER.info("Added fake player to PlayerList: " + name);
            }
         } catch (Exception e) {
            LOGGER.severe("Error adding fake player: " + e.getMessage());
            e.printStackTrace();
         }

      }
   }

   public void removeFakePlayer(UUID uuid, String name) {
      if (this.playerList != null) {
         try {
            Object serverPlayer = this.fakePlayers.remove(uuid);
            if (serverPlayer != null) {
               this.removeFromLists(uuid, name, serverPlayer);
            }

            this.fakePlayerNames.remove(uuid);
            this.fakeEntityIds.remove(uuid);
            LOGGER.info("Removed fake player from PlayerList: " + name);
         } catch (Exception e) {
            LOGGER.severe("Error removing fake player: " + e.getMessage());
            e.printStackTrace();
         }

      }
   }

   private Object createPlayerProxy(UUID uuid, String name) {
      try {
         ClassLoader loader = this.getClass().getClassLoader();
         Class<?> playerClass = Class.forName("org.bukkit.entity.Player");
         Object playerProxy = Proxy.newProxyInstance(loader, new Class[]{playerClass}, new PlayerInvocationHandler(uuid, name));
         return playerProxy;
      } catch (Exception e) {
         LOGGER.warning("Could not create Player proxy: " + e.getMessage());
         return null;
      }
   }

   private void addToLists(UUID uuid, String name, Object serverPlayer) {
      try {
         if (this.playersField != null) {
            Collection<Object> players = (Collection)this.playersField.get(this.playerList);
            if (!players.contains(serverPlayer)) {
               players.add(serverPlayer);
            }
         }

         if (this.playersByUUIDField != null) {
            Map<UUID, Object> playersByUUID = (Map)this.playersByUUIDField.get(this.playerList);
            if (!playersByUUID.containsKey(uuid)) {
               playersByUUID.put(uuid, serverPlayer);
            }
         }

         if (this.playersByNameField != null) {
            Map<String, Object> playersByName = (Map)this.playersByNameField.get(this.playerList);
            String lowerName = name.toLowerCase(Locale.ROOT);
            if (!playersByName.containsKey(lowerName)) {
               playersByName.put(lowerName, serverPlayer);
            }
         }
      } catch (Exception e) {
         LOGGER.severe("Error adding to lists: " + e.getMessage());
         e.printStackTrace();
      }

   }

   private void removeFromLists(UUID uuid, String name, Object serverPlayer) {
      try {
         if (this.playersField != null) {
            Collection<Object> players = (Collection)this.playersField.get(this.playerList);
            players.remove(serverPlayer);
         }

         if (this.playersByUUIDField != null) {
            Map<UUID, Object> playersByUUID = (Map)this.playersByUUIDField.get(this.playerList);
            playersByUUID.remove(uuid);
         }

         if (this.playersByNameField != null) {
            Map<String, Object> playersByName = (Map)this.playersByNameField.get(this.playerList);
            String lowerName = name.toLowerCase(Locale.ROOT);
            playersByName.remove(lowerName);
         }
      } catch (Exception e) {
         LOGGER.severe("Error removing from lists: " + e.getMessage());
         e.printStackTrace();
      }

   }

   public boolean isFakePlayer(UUID uuid) {
      return this.fakePlayers.containsKey(uuid);
   }

   public int getEntityId(UUID uuid) {
      return (Integer)this.fakeEntityIds.computeIfAbsent(uuid, (k) -> this.entityIdCounter++);
   }

   public Collection<UUID> getFakePlayerUUIDs() {
      return new ArrayList(this.fakePlayers.keySet());
   }

   public void cleanup() {
      try {
         for(UUID uuid : new ArrayList(this.fakePlayers.keySet())) {
            Object serverPlayer = this.fakePlayers.remove(uuid);
            if (serverPlayer != null) {
               this.removeFromLists(uuid, (String)this.fakePlayerNames.get(uuid), serverPlayer);
            }
         }
      } catch (Exception e) {
         LOGGER.severe("Error during cleanup: " + e.getMessage());
      }

   }

   public boolean isReady() {
      return this.playerList != null && this.playersField != null && this.playersByUUIDField != null && this.playersByNameField != null;
   }

   private static class PlayerInvocationHandler implements InvocationHandler {
      private final UUID uuid;
      private final String name;

      public PlayerInvocationHandler(UUID uuid, String name) {
         this.uuid = uuid;
         this.name = name;
      }

      public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
         String methodName = method.getName();

         try {
            switch (methodName) {
               case "getUniqueId":
                  return this.uuid;
               case "getName":
                  return this.name;
               case "getDisplayName":
               case "getPlayerListName":
               case "getCustomName":
                  return this.name;
               case "setCustomName":
               case "setPlayerListName":
               case "isOnline":
               case "isBanned":
               case "isWhitelisted":
               case "isOp":
               case "hasPermission":
               case "getLocation":
                  return null;
               case "getWorld":
                  return null;
               case "teleport":
                  return null;
               case "chat":
               case "performCommand":
               case "sendPluginMessage":
                  return null;
               case "isDead":
               case "getHealth":
                  return (double)20.0F;
               case "getMaxHealth":
                  return (double)20.0F;
               default:
                  Class<?> returnType = method.getReturnType();
                  if (returnType == Boolean.TYPE) {
                     return false;
                  } else if (returnType == Integer.TYPE) {
                     return 0;
                  } else {
                     return returnType == String.class ? "" : null;
                  }
            }
         } catch (Exception e) {
            PlayerListInjectorStandalone.LOGGER.warning("Error in Player proxy for method " + methodName + ": " + e.getMessage());
            return null;
         }
      }
   }
}
