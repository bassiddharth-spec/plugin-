package com.glidespoofer.nms;

import com.glidespoofer.fake.FakePlayer;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

public class NMSIntegration {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-NMSIntegration");
   private static NMSIntegration instance;
   private final Map<UUID, NMSEntityWrapper> entityWrappers = new ConcurrentHashMap();
   private NMSDamageHandler damageHandler;
   private final Plugin plugin;
   private boolean enabled = true;

   private NMSIntegration(Plugin plugin) {
      this.plugin = plugin;
      this.damageHandler = new NMSDamageHandler(plugin);
      if (SimpleNMSHandler.isDebugMode()) {
         LOGGER.info("[NMSIntegration] Initialized with full NMS support");
      }

   }

   public static NMSIntegration getInstance() {
      if (instance == null) {
         Plugin plugin = Bukkit.getPluginManager().getPlugin("GlideSpoofer");
         if (plugin != null) {
            instance = new NMSIntegration(plugin);
         } else {
            LOGGER.warning("[NMSIntegration] Could not find GlideSpoofer plugin");
            instance = new NMSIntegration((Plugin)null);
         }
      }

      return instance;
   }

   public static void initialize(Plugin plugin) {
      if (instance == null) {
         instance = new NMSIntegration(plugin);
      }

   }

   public void registerFakePlayer(UUID uuid, Player craftPlayer) {
      if (this.enabled && craftPlayer != null) {
         try {
            NMSEntityWrapper wrapper = new NMSEntityWrapper(craftPlayer);
            if (wrapper.isInitialized()) {
               this.entityWrappers.put(uuid, wrapper);
               this.damageHandler.initializeHealth(uuid, 20.0F);
               if (SimpleNMSHandler.isDebugMode()) {
                  LOGGER.info("[NMSIntegration] Registered fake player: " + String.valueOf(uuid));
               }
            }
         } catch (Exception var4) {
            LOGGER.log(Level.WARNING, "[NMSIntegration] Failed to register fake player", var4);
         }
      }

   }

   public void unregisterFakePlayer(UUID uuid) {
      this.entityWrappers.remove(uuid);
      if (SimpleNMSHandler.isDebugMode()) {
         LOGGER.info("[NMSIntegration] Unregistered fake player: " + String.valueOf(uuid));
      }

   }

   public NMSEntityWrapper getWrapper(UUID uuid) {
      return (NMSEntityWrapper)this.entityWrappers.get(uuid);
   }

   public boolean isRegistered(UUID uuid) {
      return this.entityWrappers.containsKey(uuid);
   }

   public boolean damage(FakePlayer fakePlayer, float amount, Player attacker, boolean isCritical) {
      return !this.enabled ? false : this.damageHandler.damage(fakePlayer, amount, attacker, isCritical);
   }

   public boolean damageWithKnockback(FakePlayer fakePlayer, float amount, Location attackLocation, double knockback) {
      return !this.enabled ? false : this.damageHandler.damageWithKnockback(fakePlayer, amount, attackLocation, knockback);
   }

   public void kill(FakePlayer fakePlayer, Player killer) {
      if (this.enabled) {
         this.damageHandler.kill(fakePlayer, killer);
      }

   }

   public void respawn(UUID uuid) {
      if (this.enabled) {
         this.damageHandler.respawn(uuid);
      }

   }

   public float getHealth(UUID uuid) {
      return this.damageHandler.getHealth(uuid);
   }

   public void setHealth(UUID uuid, float health) {
      this.damageHandler.setHealth(uuid, health);
   }

   public float getMaxHealth(UUID uuid) {
      return this.damageHandler.getMaxHealth(uuid);
   }

   public void setMaxHealth(UUID uuid, float maxHealth) {
      this.damageHandler.setMaxHealth(uuid, maxHealth);
   }

   public boolean isDead(UUID uuid) {
      return this.damageHandler.isDead(uuid);
   }

   public void triggerHurtAnimation(FakePlayer fakePlayer) {
      if (this.enabled) {
         this.damageHandler.triggerHurtAnimation(fakePlayer);
      }

   }

   public int getHurtTime(UUID uuid) {
      return this.damageHandler.getHurtTime(uuid);
   }

   public void tickHurtAnimation(UUID uuid) {
      if (this.enabled) {
         this.damageHandler.tickHurtAnimation(uuid);
      }

   }

   public void applyKnockback(FakePlayer fakePlayer, Vector direction, double strength) {
      if (this.enabled) {
         this.damageHandler.applyKnockback(fakePlayer, direction, strength);
      }

   }

   public void applyKnockbackFrom(FakePlayer fakePlayer, Location attackerLoc, double strength) {
      if (this.enabled && fakePlayer != null && attackerLoc != null) {
         Location fakeLoc = fakePlayer.getLocation();
         if (fakeLoc != null) {
            Vector direction = fakeLoc.toVector().subtract(attackerLoc.toVector()).normalize();
            this.applyKnockback(fakePlayer, direction, strength);
         }
      }

   }

   public boolean rayHitCheck(Location start, Location end, Player fakePlayer) {
      return !this.enabled ? false : NMSEntityTrackerManager.rayHitCheck(start, end, fakePlayer);
   }

   public Location getHitLocation(Location start, Location end, Player fakePlayer) {
      return !this.enabled ? null : NMSEntityTrackerManager.getHitLocation(start, end, fakePlayer);
   }

   public NMSEntityTrackerManager.HitResult preciseHitCheck(Player attacker, Player fakePlayer, double range) {
      return !this.enabled ? null : NMSEntityTrackerManager.preciseHitCheck(attacker, fakePlayer, range);
   }

   public boolean distanceHitCheck(Location attackerLoc, Location fakeLoc, double maxDistance) {
      return !this.enabled ? false : NMSEntityTrackerManager.distanceHitCheck(attackerLoc, fakeLoc, maxDistance);
   }

   public boolean checkCollision(Player realPlayer, Player fakePlayer) {
      return !this.enabled ? false : NMSEntityTrackerManager.checkCollision(realPlayer, fakePlayer);
   }

   public Set<Player> getTrackingPlayers(Player entity) {
      return (Set<Player>)(!this.enabled ? new HashSet() : NMSEntityTrackerManager.getTrackingPlayers(entity));
   }

   public boolean canSee(Player viewer, Player entity) {
      return !this.enabled ? false : NMSEntityTrackerManager.canSee(viewer, entity);
   }

   public boolean registerEntity(Object nmsEntity) {
      return !this.enabled ? false : NMSEntityTrackerManager.registerEntity(nmsEntity);
   }

   public boolean unregisterEntity(Object nmsEntity) {
      return !this.enabled ? false : NMSEntityTrackerManager.unregisterEntity(nmsEntity);
   }

   public int getEntityId(Object nmsEntity) {
      return NMSEntityTrackerManager.getEntityId(nmsEntity);
   }

   public Object getNMSEntity(Player player) {
      return NMSEntityTrackerManager.getNMSEntity(player);
   }

   public void tickAll() {
      if (this.enabled) {
         for(Map.Entry<UUID, NMSEntityWrapper> entry : this.entityWrappers.entrySet()) {
            UUID uuid = (UUID)entry.getKey();
            NMSEntityWrapper wrapper = (NMSEntityWrapper)entry.getValue();

            try {
               wrapper.tick();
               this.tickHurtAnimation(uuid);
            } catch (Exception var6) {
               LOGGER.log(Level.WARNING, "[NMSIntegration] Failed to tick entity: " + String.valueOf(uuid), var6);
            }
         }
      }

   }

   public void startTicker() {
      if (this.enabled && this.plugin != null) {
         try {
            Bukkit.getScheduler().runTaskTimer(this.plugin, this::tickAll, 1L, 1L);
            if (SimpleNMSHandler.isDebugMode()) {
               LOGGER.info("[NMSIntegration] Started automatic ticker");
            }
         } catch (Exception var2) {
            LOGGER.log(Level.WARNING, "[NMSIntegration] Failed to start ticker", var2);
         }
      }

   }

   public void setEnabled(boolean enabled) {
      this.enabled = enabled;
      if (SimpleNMSHandler.isDebugMode()) {
         LOGGER.info("[NMSIntegration] NMS integration " + (enabled ? "enabled" : "disabled"));
      }

   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void shutdown() {
      this.entityWrappers.clear();
      if (SimpleNMSHandler.isDebugMode()) {
         LOGGER.info("[NMSIntegration] Shut down");
      }

   }
}
