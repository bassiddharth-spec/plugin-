package com.glidespoofer.nms;

import io.netty.channel.Channel;
import io.netty.channel.ChannelPipeline;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;

public class FakeConnection {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer");

   public static Object create(InetAddress address) {
      try {
         Class<?> connectionClass = null;

         try {
            connectionClass = Class.forName("net.minecraft.network.Connection");
         } catch (ClassNotFoundException var15) {
            try {
               String nmsVersion = getNMSVersion();
               connectionClass = Class.forName("net.minecraft.server." + nmsVersion + ".NetworkManager");
            } catch (ClassNotFoundException var14) {
               LOGGER.warning("[FakeConnection] Could not find Connection class");
               return null;
            }
         }

         Object serverbound = getServerbound();
         if (serverbound == null) {
            LOGGER.warning("[FakeConnection] Could not get PacketFlow.SERVERBOUND");
            return null;
         } else {
            FakeChannelV2 fakeChannel = new FakeChannelV2((Channel)null, address);
            Object connection = null;

            try {
               Constructor<?> constructor = connectionClass.getDeclaredConstructor(serverbound.getClass());
               constructor.setAccessible(true);
               connection = constructor.newInstance(serverbound);
            } catch (Exception var131) {
               try {
                  Constructor<?> constructorx = connectionClass.getDeclaredConstructor();
                  constructorx.setAccessible(true);
                  connection = constructorx.newInstance();
               } catch (Exception var9) {
                  LOGGER.log(Level.WARNING, "[FakeConnection] Could not create Connection instance", var9);
                  return null;
               }
            }

            if (connection == null) {
               LOGGER.warning("[FakeConnection] Connection is null after creation");
               return null;
            } else {
               boolean channelSet = false;

               for(Field f : getAllFields(connectionClass)) {
                  if (Channel.class.isAssignableFrom(f.getType())) {
                     f.setAccessible(true);
                     f.set(connection, fakeChannel);
                     channelSet = true;
                     LOGGER.fine("[FakeConnection] Set channel on connection");
                     break;
                  }
               }

               if (!channelSet) {
                  LOGGER.warning("[FakeConnection] Could not set channel field");
               }

               boolean channelsInitialized = false;

               for(Field f : getAllFields(connectionClass)) {
                  if (f.getName().equals("channels") && Set.class.isAssignableFrom(f.getType())) {
                     f.setAccessible(true);
                     f.set(connection, new HashSet());
                     channelsInitialized = true;
                     LOGGER.fine("[FakeConnection] Initialized channels set for Paper compatibility");
                     break;
                  }
               }

               if (!channelsInitialized) {
                  for(Field f : getAllFields(connectionClass)) {
                     try {
                        if (Set.class.isAssignableFrom(f.getType())) {
                           f.setAccessible(true);
                           if (f.get(connection) == null) {
                              f.set(connection, new HashSet());
                              LOGGER.fine("[FakeConnection] Initialized null Set field '" + f.getName() + "' as channels fallback");
                           }
                        }
                     } catch (Exception var11) {
                     }
                  }
               }

               for(Field fx : getAllFields(connectionClass)) {
                  if (SocketAddress.class.isAssignableFrom(fx.getType())) {
                     fx.setAccessible(true);
                     fx.set(connection, new InetSocketAddress(address, 25565));
                     LOGGER.fine("[FakeConnection] Set address on connection");
                     break;
                  }
               }

               try {
                  Method configureSerialization = connectionClass.getMethod("configureSerialization", ChannelPipeline.class, serverbound.getClass(), Boolean.TYPE, Object.class);
                  configureSerialization.invoke((Object)null, fakeChannel.pipeline(), serverbound, false, null);
                  LOGGER.fine("[FakeConnection] Called configureSerialization");
               } catch (Exception var8) {
                  LOGGER.fine("[FakeConnection] configureSerialization not available: " + var8.getMessage());
               }

               LOGGER.info("[FakeConnection] Successfully created fake connection");
               return connection;
            }
         }
      } catch (Exception var13) {
         LOGGER.log(Level.WARNING, "[FakeConnection] Failed to create fake connection", var13);
         return null;
      }
   }

   private static Object getServerbound() {
      return null;
   }

   private static String getNMSVersion() {
      try {
         return Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
      } catch (Exception var1) {
         return "";
      }
   }

   private static List<Field> getAllFields(Class<?> clazz) {
      List<Field> fields;
      for(fields = new ArrayList(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
         for(Field f : clazz.getDeclaredFields()) {
            fields.add(f);
         }
      }

      return fields;
   }
}
