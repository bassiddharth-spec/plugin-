package com.glidespoofer.nms;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import io.netty.channel.Channel;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class RealFakePlayer {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-RealFakePlayer");
   private static Class<?> minecraftServerClass;
   private static Class<?> worldServerClass;
   private static Class<?> entityPlayerClass;
   private static Class<?> gameProfileClass;
   private static Class<?> propertyClass;
   private static Class<?> clientInformationClass;
   private static Class<?> playerConnectionClass;
   private static Class<?> serverGamePacketListenerClass;
   private static Class<?> serverCommonPacketListenerClass;
   private static Class<?> networkManagerClass;
   private static Class<?> packetFlowClass;
   private static Class<?> commonListenerCookieClass;
   private static Class<?> craftWorldClass;
   private static Class<?> craftServerClass;
   private static Class<?> craftPlayerClass;
   private static Field entityPlayerConnectionField;
   private static Field networkManagerChannelField;
   private static Field networkManagerAddressField;
   private static Field networkManagerPacketListenerField;
   private static Field networkManagerConnectedField;
   private static Field networkManagerDisconnectedField;
   private static Field commonListenerCookieCraftPlayerField;
   private static Field playerConnectionPingField;
   private final JavaPlugin plugin;
   private final String name;
   private final UUID uuid;
   private final String skinValue;
   private final String skinSignature;
   private final String ipAddress;
   private final int port;
   private Object entityPlayer;
   private Object networkManager;
   private Object playerConnection;
   private Object fakeChannel;
   private Object gameProfile;
   private Object craftPlayer;
   private int ping;
   private boolean registered = false;

   private static void cacheFields() {
      for(Field f : getAllFields(entityPlayerClass)) {
         if (f.getType().isAssignableFrom(playerConnectionClass) || f.getType().isAssignableFrom(serverGamePacketListenerClass)) {
            entityPlayerConnectionField = f;
            entityPlayerConnectionField.setAccessible(true);
            LOGGER.fine("[RealFakePlayer] Found EntityPlayer connection field: " + f.getName());
         }
      }

      for(Field f : getAllFields(networkManagerClass)) {
         String name = f.getName().toLowerCase();
         if (f.getType() != Channel.class && !name.contains("channel")) {
            if (f.getType() != SocketAddress.class && !name.contains("address")) {
               if (!name.contains("packetlistener") && !name.contains("listener")) {
                  if (f.getType() == Boolean.TYPE) {
                     if (name.contains("connected")) {
                        networkManagerConnectedField = f;
                        networkManagerConnectedField.setAccessible(true);
                     } else if (name.contains("disconnected")) {
                        networkManagerDisconnectedField = f;
                        networkManagerDisconnectedField.setAccessible(true);
                     }
                  }
               } else {
                  networkManagerPacketListenerField = f;
                  networkManagerPacketListenerField.setAccessible(true);
               }
            } else {
               networkManagerAddressField = f;
               networkManagerAddressField.setAccessible(true);
            }
         } else {
            networkManagerChannelField = f;
            networkManagerChannelField.setAccessible(true);
            LOGGER.fine("[RealFakePlayer] Found NetworkManager channel field: " + f.getName());
         }
      }

      for(Field f : getAllFields(serverCommonPacketListenerClass)) {
         if (f.getType() == Integer.TYPE) {
            String name = f.getName().toLowerCase();
            if (name.contains("ping") || name.equals("o") || name.equals("latency")) {
               playerConnectionPingField = f;
               playerConnectionPingField.setAccessible(true);
               LOGGER.fine("[RealFakePlayer] Found ping field: " + f.getName());
               break;
            }
         }
      }

      if (commonListenerCookieClass != null) {
         for(Field f : getAllFields(commonListenerCookieClass)) {
            if (f.getType().isAssignableFrom(craftPlayerClass)) {
               commonListenerCookieCraftPlayerField = f;
               commonListenerCookieCraftPlayerField.setAccessible(true);
               LOGGER.fine("[RealFakePlayer] Found CommonListenerCookie craftPlayer field");
               break;
            }
         }
      }

   }

   private static List<Field> getAllFields(Class<?> clazz) {
      List<Field> fields;
      for(fields = new ArrayList(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
         for(Field f : clazz.getDeclaredFields()) {
            fields.add(f);
         }
      }

      return fields;
   }

   public RealFakePlayer(JavaPlugin plugin, String name, UUID uuid, String skinValue, String skinSignature) {
      this.plugin = plugin;
      this.name = name.length() > 16 ? name.substring(0, 16) : name;
      this.uuid = uuid != null ? uuid : UUID.randomUUID();
      this.skinValue = skinValue;
      this.skinSignature = skinSignature;
      this.ipAddress = this.generateIP();
      this.port = ThreadLocalRandom.current().nextInt(40000, 60000);
      this.ping = this.generatePing();
   }

   public boolean create() {
      try {
         LOGGER.info("[RealFakePlayer] Creating fake player: " + this.name);
         this.gameProfile = this.createGameProfile();
         if (this.gameProfile == null) {
            LOGGER.severe("[RealFakePlayer] Failed to create GameProfile");
            return false;
         } else {
            LOGGER.info("[RealFakePlayer] GameProfile created");
            this.entityPlayer = this.createServerPlayer();
            if (this.entityPlayer == null) {
               LOGGER.severe("[RealFakePlayer] Failed to create ServerPlayer");
               return false;
            } else {
               LOGGER.info("[RealFakePlayer] ServerPlayer created");
               this.fakeChannel = this.createFakeChannel();
               if (this.fakeChannel == null) {
                  LOGGER.severe("[RealFakePlayer] Failed to create FakeChannel");
                  return false;
               } else {
                  LOGGER.info("[RealFakePlayer] FakeChannel created");
                  this.networkManager = this.createNetworkManager();
                  if (this.networkManager == null) {
                     LOGGER.severe("[RealFakePlayer] Failed to create NetworkManager");
                     return false;
                  } else {
                     LOGGER.info("[RealFakePlayer] NetworkManager created");
                     this.playerConnection = this.createPlayerConnection();
                     if (this.playerConnection == null) {
                        LOGGER.severe("[RealFakePlayer] Failed to create PlayerConnection");
                        return false;
                     } else {
                        LOGGER.info("[RealFakePlayer] PlayerConnection created");
                        this.wireConnectionToNetworkManager();
                        LOGGER.info("[RealFakePlayer] PlayerConnection wired to NetworkManager");
                        this.wireConnectionToPlayer();
                        LOGGER.info("[RealFakePlayer] PlayerConnection wired to ServerPlayer");
                        this.setPing(this.ping);
                        LOGGER.info("[RealFakePlayer] Ping set to: " + this.ping);
                        this.craftPlayer = this.retrieveCraftPlayer();
                        if (this.craftPlayer == null) {
                           LOGGER.warning("[RealFakePlayer] Failed to get CraftPlayer, but continuing");
                        } else {
                           LOGGER.info("[RealFakePlayer] CraftPlayer obtained: " + ((Player)this.craftPlayer).getName());
                        }

                        LOGGER.info("[RealFakePlayer] Successfully created fake player: " + this.name);
                        return true;
                     }
                  }
               }
            }
         }
      } catch (Exception e) {
         LOGGER.log(Level.SEVERE, "[RealFakePlayer] Error creating fake player", e);
         return false;
      }
   }

   private GameProfile createGameProfile() {
      try {
         GameProfile profile = new GameProfile(this.uuid, this.name);
         if (this.skinValue != null && !this.skinValue.isEmpty()) {
            profile.getProperties().put("textures", new Property("textures", this.skinValue, this.skinSignature));
            LOGGER.fine("[RealFakePlayer] Added skin to GameProfile");
         }

         return profile;
      } catch (Exception e) {
         LOGGER.log(Level.WARNING, "[RealFakePlayer] Error creating GameProfile", e);
         return null;
      }
   }

   private Object createServerPlayer() {
      try {
         Object minecraftServer = this.getMinecraftServer();
         Object worldServer = this.getDefaultWorldServer();
         Object clientInfo = this.createClientInformation();

         try {
            Constructor<?> constructor = entityPlayerClass.getConstructor(minecraftServerClass, worldServerClass, gameProfileClass, clientInformationClass);
            return constructor.newInstance(minecraftServer, worldServer, this.gameProfile, clientInfo);
         } catch (Exception e) {
            LOGGER.fine("[RealFakePlayer] 1.21+ constructor failed: " + e.getMessage());

            for(Constructor<?> constructor : entityPlayerClass.getConstructors()) {
               Class<?>[] params = constructor.getParameterTypes();
               if (params.length == 4 && params[0].isAssignableFrom(minecraftServerClass) && params[1].isAssignableFrom(worldServerClass) && gameProfileClass.isAssignableFrom(params[2]) && (clientInformationClass == null || clientInformationClass.isAssignableFrom(params[3]))) {
                  constructor.setAccessible(true);
                  return constructor.newInstance(minecraftServer, worldServer, this.gameProfile, clientInfo);
               }
            }

            LOGGER.warning("[RealFakePlayer] No suitable ServerPlayer constructor found");
            return null;
         }
      } catch (Exception e) {
         LOGGER.log(Level.WARNING, "[RealFakePlayer] Error creating ServerPlayer", e);
         return null;
      }
   }

   private Object createFakeChannel() {
      try {
         InetAddress address = InetAddress.getByName(this.ipAddress);
         FakeChannelV2 channel = new FakeChannelV2((Channel)null, address);
         channel.pipeline().fireChannelRegistered();
         channel.pipeline().fireChannelActive();
         return channel;
      } catch (Exception e) {
         LOGGER.log(Level.WARNING, "[RealFakePlayer] Error creating FakeChannel", e);
         return null;
      }
   }

   private Object createNetworkManager() {
      try {
         Object serverbound = null;

         for(Object constant : packetFlowClass.getEnumConstants()) {
            if (constant.toString().equals("SERVERBOUND")) {
               serverbound = constant;
               break;
            }
         }

         if (serverbound == null) {
            LOGGER.severe("[RealFakePlayer] Could not find SERVERBOUND enum");
            return null;
         } else {
            Constructor<?> constructor = networkManagerClass.getConstructor(packetFlowClass);
            Object connection = constructor.newInstance(serverbound);
            if (networkManagerChannelField != null) {
               networkManagerChannelField.set(connection, this.fakeChannel);
               LOGGER.fine("[RealFakePlayer] Set channel on NetworkManager");
            }

            if (networkManagerAddressField != null) {
               networkManagerAddressField.set(connection, new InetSocketAddress(this.ipAddress, this.port));
               LOGGER.fine("[RealFakePlayer] Set address on NetworkManager");
            }

            if (networkManagerConnectedField != null) {
               networkManagerConnectedField.setBoolean(connection, true);
            }

            return connection;
         }
      } catch (Exception e) {
         LOGGER.log(Level.WARNING, "[RealFakePlayer] Error creating NetworkManager", e);
         return null;
      }
   }

   private Object createPlayerConnection() {
      try {
         Object minecraftServer = this.getMinecraftServer();
         Object cookie = this.createCommonListenerCookie();

         try {
            Constructor<?> constructor = playerConnectionClass.getConstructor(minecraftServerClass, networkManagerClass, entityPlayerClass, commonListenerCookieClass);
            return constructor.newInstance(minecraftServer, this.networkManager, this.entityPlayer, cookie);
         } catch (Exception e) {
            LOGGER.fine("[RealFakePlayer] 1.21+ PlayerConnection constructor failed: " + e.getMessage());

            try {
               Constructor<?> constructor = playerConnectionClass.getConstructor(minecraftServerClass, networkManagerClass, entityPlayerClass);
               return constructor.newInstance(minecraftServer, this.networkManager, this.entityPlayer);
            } catch (Exception e) {
               LOGGER.fine("[RealFakePlayer] 3-param PlayerConnection constructor failed: " + e.getMessage());
               LOGGER.warning("[RealFakePlayer] No suitable PlayerConnection constructor found");
               return null;
            }
         }
      } catch (Exception e) {
         LOGGER.log(Level.WARNING, "[RealFakePlayer] Error creating PlayerConnection", e);
         return null;
      }
   }

   private Object createCommonListenerCookie() {
      try {
         if (commonListenerCookieClass == null) {
            return null;
         } else {
            try {
               Method createDefault = commonListenerCookieClass.getMethod("a");
               return createDefault.invoke((Object)null);
            } catch (Exception var2) {
               if (this.craftPlayer != null && commonListenerCookieCraftPlayerField != null) {
                  Constructor<?> constructor = commonListenerCookieClass.getConstructor(craftPlayerClass);
                  return constructor.newInstance(this.craftPlayer);
               } else {
                  return null;
               }
            }
         }
      } catch (Exception e) {
         LOGGER.fine("[RealFakePlayer] Error creating CommonListenerCookie: " + e.getMessage());
         return null;
      }
   }

   private void wireConnectionToNetworkManager() {
      try {
         if (networkManagerPacketListenerField != null && this.playerConnection != null) {
            networkManagerPacketListenerField.set(this.networkManager, this.playerConnection);
            LOGGER.fine("[RealFakePlayer] Wired PlayerConnection to NetworkManager");
         }
      } catch (Exception e) {
         LOGGER.warning("[RealFakePlayer] Error wiring connection to NetworkManager: " + e.getMessage());
      }

   }

   private void wireConnectionToPlayer() {
      try {
         if (entityPlayerConnectionField != null && this.playerConnection != null) {
            entityPlayerConnectionField.set(this.entityPlayer, this.playerConnection);
            LOGGER.fine("[RealFakePlayer] Wired PlayerConnection to ServerPlayer");
         }
      } catch (Exception e) {
         LOGGER.warning("[RealFakePlayer] Error wiring connection to ServerPlayer: " + e.getMessage());
      }

   }

   private Object getMinecraftServer() throws Exception {
      Object craftServer = craftServerClass.cast(Bukkit.getServer());
      Method getServerMethod = craftServerClass.getMethod("getServer");
      return getServerMethod.invoke(craftServer);
   }

   private Object getDefaultWorldServer() throws Exception {
      World world = (World)Bukkit.getWorlds().get(0);
      Object craftWorld = craftWorldClass.cast(world);
      Method getHandleMethod = craftWorldClass.getMethod("getHandle");
      return getHandleMethod.invoke(craftWorld);
   }

   private Object createClientInformation() {
      try {
         if (clientInformationClass == null) {
            return null;
         } else {
            Method createDefault = clientInformationClass.getMethod("a");
            return createDefault.invoke((Object)null);
         }
      } catch (Exception e) {
         LOGGER.fine("[RealFakePlayer] Error creating ClientInformation: " + e.getMessage());
         return null;
      }
   }

   private Object retrieveCraftPlayer() {
      try {
         Method getBukkitEntity = entityPlayerClass.getMethod("getBukkitEntity");
         return getBukkitEntity.invoke(this.entityPlayer);
      } catch (Exception e) {
         LOGGER.warning("[RealFakePlayer] Error getting CraftPlayer: " + e.getMessage());
         return null;
      }
   }

   public boolean registerWithServer() {
      if (this.registered) {
         LOGGER.warning("[RealFakePlayer] Player already registered");
         return true;
      } else {
         try {
            Object minecraftServer = this.getMinecraftPlayerList();
            if (minecraftServer == null) {
               LOGGER.severe("[RealFakePlayer] Could not get PlayerList");
               return false;
            } else {
               Method getPlayerListMethod = minecraftServerClass.getMethod("getPlayerList");
               Object playerList = getPlayerListMethod.invoke(minecraftServer);
               Field playersField = playerList.getClass().getDeclaredField("players");
               playersField.setAccessible(true);
               Collection<Object> players = (Collection)playersField.get(playerList);
               Field playersByUUIDField = playerList.getClass().getDeclaredField("playersByUUID");
               playersByUUIDField.setAccessible(true);
               Map<UUID, Object> playersByUUID = (Map)playersByUUIDField.get(playerList);
               Field playersByNameField = playerList.getClass().getDeclaredField("playersByName");
               playersByNameField.setAccessible(true);
               Map<String, Object> playersByName = (Map)playersByNameField.get(playerList);
               players.add(this.entityPlayer);
               playersByUUID.put(this.uuid, this.entityPlayer);
               playersByName.put(this.name.toLowerCase(Locale.ROOT), this.entityPlayer);
               this.registered = true;
               LOGGER.info("[RealFakePlayer] Registered " + this.name + " with server player list");
               return true;
            }
         } catch (Exception e) {
            LOGGER.log(Level.WARNING, "[RealFakePlayer] Error registering with server", e);
            return false;
         }
      }
   }

   public void fireJoinEvent() {
      if (this.craftPlayer instanceof Player) {
         PlayerJoinEvent event = new PlayerJoinEvent((Player)this.craftPlayer, "§e" + this.name + " joined the game");
         Bukkit.getPluginManager().callEvent(event);
         if (event.getJoinMessage() != null && !event.getJoinMessage().isEmpty()) {
            Bukkit.broadcastMessage(event.getJoinMessage());
         }

         LOGGER.info("[RealFakePlayer] Fired PlayerJoinEvent for " + this.name);
      }

   }

   public void unregister() {
      if (this.registered) {
         try {
            if (this.craftPlayer instanceof Player) {
               PlayerQuitEvent event = new PlayerQuitEvent((Player)this.craftPlayer, "§e" + this.name + " left the game");
               Bukkit.getPluginManager().callEvent(event);
            }

            Object minecraftServer = this.getMinecraftPlayerList();
            Method getPlayerListMethod = minecraftServerClass.getMethod("getPlayerList");
            Object playerList = getPlayerListMethod.invoke(minecraftServer);
            Field playersField = playerList.getClass().getDeclaredField("players");
            playersField.setAccessible(true);
            Collection<Object> players = (Collection)playersField.get(playerList);
            Field playersByUUIDField = playerList.getClass().getDeclaredField("playersByUUID");
            playersByUUIDField.setAccessible(true);
            Map<UUID, Object> playersByUUID = (Map)playersByUUIDField.get(playerList);
            Field playersByNameField = playerList.getClass().getDeclaredField("playersByName");
            playersByNameField.setAccessible(true);
            Map<String, Object> playersByName = (Map)playersByNameField.get(playerList);
            players.remove(this.entityPlayer);
            playersByUUID.remove(this.uuid);
            playersByName.remove(this.name.toLowerCase(Locale.ROOT));
            this.registered = false;
            LOGGER.info("[RealFakePlayer] Unregistered " + this.name);
         } catch (Exception e) {
            LOGGER.log(Level.WARNING, "[RealFakePlayer] Error unregistering", e);
         }

      }
   }

   private Object getMinecraftPlayerList() {
      try {
         return this.getMinecraftServer();
      } catch (Exception var2) {
         return null;
      }
   }

   public void setPing(int ping) {
      this.ping = ping;

      try {
         if (playerConnectionPingField != null && this.playerConnection != null) {
            playerConnectionPingField.setInt(this.playerConnection, ping);
         }
      } catch (Exception e) {
         LOGGER.fine("[RealFakePlayer] Error setting ping: " + e.getMessage());
      }

   }

   public void updatePing() {
      int variance = ThreadLocalRandom.current().nextInt(15) - 7;
      this.setPing(Math.max(10, Math.min(400, this.ping + variance)));
   }

   private String generateIP() {
      int[] firstOctets = new int[]{24, 31, 45, 64, 68, 71, 72, 74, 75, 76, 98, 99, 107, 108, 134, 173, 174, 184};
      int first = firstOctets[ThreadLocalRandom.current().nextInt(firstOctets.length)];
      return first + "." + ThreadLocalRandom.current().nextInt(256) + "." + ThreadLocalRandom.current().nextInt(256) + "." + (1 + ThreadLocalRandom.current().nextInt(254));
   }

   private int generatePing() {
      double r = Math.random();
      if (r < 0.4) {
         return 15 + ThreadLocalRandom.current().nextInt(50);
      } else if (r < (double)0.75F) {
         return 65 + ThreadLocalRandom.current().nextInt(80);
      } else {
         return r < 0.92 ? 145 + ThreadLocalRandom.current().nextInt(100) : 245 + ThreadLocalRandom.current().nextInt(150);
      }
   }

   public String getName() {
      return this.name;
   }

   public UUID getUUID() {
      return this.uuid;
   }

   public Object getEntityPlayer() {
      return this.entityPlayer;
   }

   public Object getNetworkManager() {
      return this.networkManager;
   }

   public Object getPlayerConnection() {
      return this.playerConnection;
   }

   public Object getCraftPlayer() {
      return this.craftPlayer;
   }

   public GameProfile getGameProfile() {
      return (GameProfile)this.gameProfile;
   }

   public int getPing() {
      return this.ping;
   }

   public String getIPAddress() {
      return this.ipAddress;
   }

   public int getPort() {
      return this.port;
   }

   public boolean isRegistered() {
      return this.registered;
   }

   public static boolean isRealFakePlayer(UUID uuid) {
      return false;
   }

   static {
      try {
         minecraftServerClass = Class.forName("net.minecraft.server.MinecraftServer");
         worldServerClass = Class.forName("net.minecraft.server.level.WorldServer");
         entityPlayerClass = Class.forName("net.minecraft.server.level.EntityPlayer");
         gameProfileClass = Class.forName("com.mojang.authlib.GameProfile");
         propertyClass = Class.forName("com.mojang.authlib.properties.Property");
         clientInformationClass = Class.forName("net.minecraft.server.level.ClientInformation");
         playerConnectionClass = Class.forName("net.minecraft.server.network.PlayerConnection");
         serverGamePacketListenerClass = Class.forName("net.minecraft.server.network.ServerGamePacketListenerImpl");
         serverCommonPacketListenerClass = Class.forName("net.minecraft.server.network.ServerCommonPacketListenerImpl");
         networkManagerClass = Class.forName("net.minecraft.network.Connection");
         packetFlowClass = Class.forName("net.minecraft.network.protocol.PacketFlow");
         commonListenerCookieClass = Class.forName("net.minecraft.server.network.CommonListenerCookie");
         String[] versions = new String[]{"v1_21_R4", "v1_21_R3", "v1_21_R2", "v1_21_R1", "v1_20_R4", "v1_20_R3", "v1_20_R2", "v1_20_R1"};

         for(String version : versions) {
            try {
               craftWorldClass = Class.forName("org.bukkit.craftbukkit." + version + ".CraftWorld");
               craftServerClass = Class.forName("org.bukkit.craftbukkit." + version + ".CraftServer");
               craftPlayerClass = Class.forName("org.bukkit.craftbukkit." + version + ".entity.CraftPlayer");
               break;
            } catch (ClassNotFoundException var6) {
            }
         }

         cacheFields();
         LOGGER.info("[RealFakePlayer] Initialized NMS classes successfully");
      } catch (Exception e) {
         LOGGER.log(Level.SEVERE, "[RealFakePlayer] Failed to initialize NMS classes", e);
      }

   }
}
