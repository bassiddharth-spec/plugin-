package com.glidespoofer.nms.network;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.logging.Logger;
import org.bukkit.Bukkit;

public class FakeServerGamePacketListenerImpl {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-FakePacketListener");
   private static Class<?> serverGamePacketListenerImplClass;
   private static Class<?> minecraftServerClass;
   private static Constructor<?> listenerConstructor;
   private static Field playerField;
   private static Field connectionField;
   private static boolean initialized = false;
   private Object listener;
   private final FakeConnection fakeConnection;
   private final Object serverPlayer;
   private final Object minecraftServer;

   private static Class<?> getNMSClass(String name) {
      try {
         return Class.forName(name);
      } catch (ClassNotFoundException var2) {
         return null;
      }
   }

   public FakeServerGamePacketListenerImpl(Object minecraftServer, FakeConnection fakeConnection, Object serverPlayer) {
      this.fakeConnection = fakeConnection;
      this.serverPlayer = serverPlayer;
      this.minecraftServer = minecraftServer;
      this.initializeStatic();
      this.listener = this.createPacketListener();
      if (this.listener != null) {
         this.setupListenerFields();
         if (fakeConnection != null) {
            fakeConnection.setPacketListener(this.listener);
         }
      } else {
         LOGGER.warning("[FakePacketListener] Could not create NMS packet listener, using stub");
         this.listener = this.createStubListener();
      }

   }

   private synchronized void initializeStatic() {
      if (!initialized) {
         try {
            String[] listenerClassNames = new String[]{"net.minecraft.server.network.ServerGamePacketListenerImpl", "net.minecraft.server.network.PlayerConnection", "net.minecraft.server.level.ServerPlayerConnection"};

            for(String className : listenerClassNames) {
               serverGamePacketListenerImplClass = getNMSClass(className);
               if (serverGamePacketListenerImplClass != null) {
                  LOGGER.info("[FakePacketListener] Found class: " + className);
                  break;
               }
            }

            minecraftServerClass = getNMSClass("net.minecraft.server.MinecraftServer");
            if (minecraftServerClass == null) {
               String nmsVersion = this.getNMSVersion();
               minecraftServerClass = getNMSClass("net.minecraft.server." + nmsVersion + ".MinecraftServer");
            }

            if (serverGamePacketListenerImplClass != null) {
               playerField = this.findField(serverGamePacketListenerImplClass, "player", "f", "c");
               connectionField = this.findField(serverGamePacketListenerImplClass, "connection", "e", "d", "b");
            }

            initialized = true;
            LOGGER.info("[FakePacketListener] Initialized successfully");
         } catch (Exception e) {
            LOGGER.warning("[FakePacketListener] Failed to initialize: " + e.getMessage());
         }

      }
   }

   private Object createPacketListener() {
      if (serverGamePacketListenerImplClass == null) {
         return null;
      } else {
         Object nmsConnection = this.fakeConnection != null ? this.fakeConnection.getConnection() : null;
         if (nmsConnection == null) {
            LOGGER.warning("[FakePacketListener] No NMS connection available");
            return null;
         } else {
            for(Constructor<?> constructor : serverGamePacketListenerImplClass.getDeclaredConstructors()) {
               constructor.setAccessible(true);
               Class<?>[] params = constructor.getParameterTypes();

               try {
                  Object[] args = this.buildConstructorArgs(params, nmsConnection);
                  Object instance = constructor.newInstance(args);
                  LOGGER.info("[FakePacketListener] Created listener via constructor with " + params.length + " params");
                  return instance;
               } catch (Exception var10) {
               }
            }

            try {
               Object instance = this.allocateInstance(serverGamePacketListenerImplClass);
               if (instance != null) {
                  LOGGER.info("[FakePacketListener] Created listener via Unsafe allocation");
                  return instance;
               }
            } catch (Exception e) {
               LOGGER.warning("[FakePacketListener] Unsafe allocation failed: " + e.getMessage());
            }

            return null;
         }
      }
   }

   private Object[] buildConstructorArgs(Class<?>[] params, Object nmsConnection) {
      Object[] args = new Object[params.length];

      for(int i = 0; i < params.length; ++i) {
         Class<?> paramType = params[i];
         if (paramType.isInstance(this.minecraftServer)) {
            args[i] = this.minecraftServer;
         } else if (paramType.isInstance(nmsConnection)) {
            args[i] = nmsConnection;
         } else if (paramType.isInstance(this.serverPlayer)) {
            args[i] = this.serverPlayer;
         } else if (paramType != Boolean.TYPE && paramType != Boolean.class) {
            if (paramType != Integer.TYPE && paramType != Integer.class) {
               if (paramType != Long.TYPE && paramType != Long.class) {
                  if (paramType != Float.TYPE && paramType != Float.class) {
                     if (paramType != Double.TYPE && paramType != Double.class) {
                        args[i] = this.getDefaultValue(paramType);
                     } else {
                        args[i] = (double)0.0F;
                     }
                  } else {
                     args[i] = 0.0F;
                  }
               } else {
                  args[i] = 0L;
               }
            } else {
               args[i] = 0;
            }
         } else {
            args[i] = Boolean.TRUE;
         }
      }

      return args;
   }

   private void setupListenerFields() {
      if (this.listener != null) {
         Object nmsConnection = this.fakeConnection != null ? this.fakeConnection.getConnection() : null;
         if (playerField != null) {
            try {
               playerField.set(this.listener, this.serverPlayer);
               LOGGER.fine("[FakePacketListener] Set player field");
            } catch (Exception var4) {
               this.setFieldByType(this.listener, this.serverPlayer, this.serverPlayer.getClass());
            }
         }

         if (connectionField != null && nmsConnection != null) {
            try {
               connectionField.set(this.listener, nmsConnection);
               LOGGER.fine("[FakePacketListener] Set connection field");
            } catch (Exception var5) {
               if (nmsConnection != null) {
                  this.setFieldByType(this.listener, nmsConnection, nmsConnection.getClass());
               }
            }
         }

         try {
            Field serverField = this.findField(this.listener.getClass(), "server", "c", "b");
            if (serverField != null && serverField.getType().isInstance(this.minecraftServer)) {
               serverField.set(this.listener, this.minecraftServer);
               LOGGER.fine("[FakePacketListener] Set server field");
            }
         } catch (Exception var3) {
         }

         this.initializeKeepAlive();
      }
   }

   private void setFieldByType(Object target, Object value, Class<?> valueType) {
      for(Field field : target.getClass().getDeclaredFields()) {
         if (field.getType().isInstance(value) || valueType.isInstance(field.getType())) {
            try {
               field.setAccessible(true);
               field.set(target, value);
               LOGGER.fine("[FakePacketListener] Set field by type: " + field.getName());
               return;
            } catch (Exception var9) {
            }
         }
      }

   }

   private void initializeKeepAlive() {
      if (this.listener != null) {
         try {
            for(Field field : this.listener.getClass().getDeclaredFields()) {
               String name = field.getName().toLowerCase();
               if ((name.contains("keepalive") || name.contains("keep_alive") || name.equals("e") || name.equals("f")) && (field.getType() == Long.TYPE || field.getType() == Integer.TYPE)) {
                  field.setAccessible(true);
                  if (field.getType() == Long.TYPE) {
                     field.setLong(this.listener, System.currentTimeMillis());
                  } else {
                     field.setInt(this.listener, 0);
                  }
               }
            }
         } catch (Exception var6) {
         }

      }
   }

   private Object createStubListener() {
      final Object connection = this.fakeConnection != null ? this.fakeConnection.getConnection() : null;
      return new Object() {
         public final Object player;
         public final Object connectionRef;
         public final boolean isConnected;

         {
            this.player = FakeServerGamePacketListenerImpl.this.serverPlayer;
            this.connectionRef = connection;
            this.isConnected = true;
         }

         public void send(Object packet) {
         }

         public void tick() {
         }
      };
   }

   public Object getListener() {
      return this.listener;
   }

   public FakeConnection getFakeConnection() {
      return this.fakeConnection;
   }

   public Object getServerPlayer() {
      return this.serverPlayer;
   }

   public void handlePacket(Object packet) {
      if (packet != null) {
         try {
            String packetClassName = packet.getClass().getSimpleName();
            if (packetClassName.contains("SetEntityMotion")) {
               this.handleMotionPacket(packet);
            }
         } catch (Exception var3) {
         }

      }
   }

   private void handleMotionPacket(Object packet) {
      try {
         Method getIdMethod = packet.getClass().getMethod("getId");
         int packetId = (Integer)getIdMethod.invoke(packet);
         if (this.serverPlayer != null) {
            Method getEntityIdMethod = this.serverPlayer.getClass().getMethod("getId");
            int playerId = (Integer)getEntityIdMethod.invoke(this.serverPlayer);
            if (packetId == playerId) {
               double xa = (double)0.0F;
               double ya = (double)0.0F;
               double za = (double)0.0F;

               try {
                  Method getXMethod = packet.getClass().getMethod("getXa");
                  Method getYMethod = packet.getClass().getMethod("getYa");
                  Method getZMethod = packet.getClass().getMethod("getZa");
                  xa = (Double)getXMethod.invoke(packet);
                  ya = (Double)getYMethod.invoke(packet);
                  za = (Double)getZMethod.invoke(packet);
               } catch (Exception var19) {
               }

               try {
                  Method lerpMotionMethod = this.serverPlayer.getClass().getMethod("lerpMotion", Double.TYPE, Double.TYPE, Double.TYPE);
                  lerpMotionMethod.invoke(this.serverPlayer, xa, ya, za);
               } catch (Exception var18) {
                  try {
                     Class<?> vec3Class = Class.forName("net.minecraft.world.phys.Vec3");
                     Constructor<?> vec3Constructor = vec3Class.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE);
                     Object vec3 = vec3Constructor.newInstance(xa, ya, za);
                     Method setDeltaMethod = this.serverPlayer.getClass().getMethod("setDeltaMovement", vec3Class);
                     setDeltaMethod.invoke(this.serverPlayer, vec3);
                  } catch (Exception var17) {
                  }
               }
            }
         }
      } catch (Exception e) {
         LOGGER.warning("[FakePacketListener] Failed to handle motion packet: " + e.getMessage());
      }

   }

   public void send(Object packet) {
      this.handlePacket(packet);
   }

   public void tick() {
   }

   private String getNMSVersion() {
      try {
         String packageName = Bukkit.getServer().getClass().getPackage().getName();
         String[] parts = packageName.split("\\.");
         if (parts.length >= 4) {
            return parts[3];
         }
      } catch (Exception var3) {
      }

      return "";
   }

   private Field findField(Class<?> clazz, String... names) {
      for(String name : names) {
         try {
            Field field = clazz.getDeclaredField(name);
            field.setAccessible(true);
            return field;
         } catch (NoSuchFieldException var8) {
         }
      }

      return null;
   }

   private Object getDefaultValue(Class<?> type) {
      if (type == Boolean.TYPE) {
         return false;
      } else if (type == Byte.TYPE) {
         return 0;
      } else if (type == Short.TYPE) {
         return 0;
      } else if (type == Integer.TYPE) {
         return 0;
      } else if (type == Long.TYPE) {
         return 0L;
      } else if (type == Float.TYPE) {
         return 0.0F;
      } else if (type == Double.TYPE) {
         return (double)0.0F;
      } else {
         return type == Character.TYPE ? '\u0000' : null;
      }
   }

   private Object allocateInstance(Class<?> clazz) {
      try {
         Class<?> unsafeClass = Class.forName("sun.misc.Unsafe");
         Field unsafeField = unsafeClass.getDeclaredField("theUnsafe");
         unsafeField.setAccessible(true);
         Object unsafe = unsafeField.get((Object)null);
         Method allocate = unsafeClass.getMethod("allocateInstance", Class.class);
         return allocate.invoke(unsafe, clazz);
      } catch (Exception var6) {
         return null;
      }
   }
}
