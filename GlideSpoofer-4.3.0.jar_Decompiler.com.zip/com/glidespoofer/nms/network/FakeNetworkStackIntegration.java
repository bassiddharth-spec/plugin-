package com.glidespoofer.nms.network;

import com.glidespoofer.nms.FakeChannelV2;
import java.lang.reflect.Field;
import java.net.InetAddress;
import java.util.logging.Logger;

public class FakeNetworkStackIntegration {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-NetworkStack");

   public static FakeNetworkStack setupNetworkStack(Object minecraftServer, Object serverPlayer, int ping, InetAddress address) {
      LOGGER.info("[Integration] Setting up fake network stack...");
      FakeNetworkStack.Builder builder = FakeNetworkStack.builder().minecraftServer(minecraftServer).serverPlayer(serverPlayer).ping(ping);
      if (address != null) {
         builder.address(address);
      }

      FakeNetworkStack stack = builder.build();
      if (!stack.verify()) {
         LOGGER.warning("[Integration] Network stack verification failed!");
         return null;
      } else if (!stack.applyToPlayer()) {
         LOGGER.warning("[Integration] Failed to apply network stack to player!");
         return null;
      } else {
         setConnectionLatency(stack.getNMSConnection(), ping);
         LOGGER.info("[Integration] Network stack setup complete!");
         return stack;
      }
   }

   private static void setConnectionLatency(Object connection, int ping) {
      if (connection != null) {
         try {
            String[] latencyFields = new String[]{"latency", "ping", "e", "f", "connectionLatency"};

            for(String fieldName : latencyFields) {
               try {
                  Field field = connection.getClass().getDeclaredField(fieldName);
                  if (field != null && (field.getType() == Integer.TYPE || field.getType() == Long.TYPE)) {
                     field.setAccessible(true);
                     if (field.getType() == Integer.TYPE) {
                        field.setInt(connection, ping);
                     } else {
                        field.setLong(connection, (long)ping);
                     }

                     LOGGER.fine("[Integration] Set latency via field: " + fieldName);
                     return;
                  }
               } catch (NoSuchFieldException var8) {
               }
            }
         } catch (Exception e) {
            LOGGER.warning("[Integration] Could not set latency: " + e.getMessage());
         }

      }
   }

   public static void debugConnectionChain(Object serverPlayer) {
      if (serverPlayer == null) {
         LOGGER.info("[Debug] ServerPlayer is null");
      } else {
         try {
            Object packetListener = null;

            for(String field : new String[]{"connection", "c", "b", "playerConnection"}) {
               try {
                  Field f = serverPlayer.getClass().getDeclaredField(field);
                  f.setAccessible(true);
                  packetListener = f.get(serverPlayer);
                  if (packetListener != null) {
                     break;
                  }
               } catch (Exception var11) {
               }
            }

            LOGGER.info("[Debug] ServerPlayer: " + serverPlayer.getClass().getSimpleName());
            String var10001 = packetListener != null ? packetListener.getClass().getSimpleName() : "NULL";
            LOGGER.info("[Debug] └── PacketListener: " + var10001);
            if (packetListener != null) {
               Object connection = null;

               for(String field : new String[]{"connection", "e", "d", "b"}) {
                  try {
                     Field f = packetListener.getClass().getDeclaredField(field);
                     f.setAccessible(true);
                     connection = f.get(packetListener);
                     if (connection != null) {
                        break;
                     }
                  } catch (Exception var10) {
                  }
               }

               var10001 = connection != null ? connection.getClass().getSimpleName() : "NULL";
               LOGGER.info("[Debug]     └── Connection: " + var10001);
               if (connection != null) {
                  Object channel = null;

                  for(String field : new String[]{"channel", "n", "m"}) {
                     try {
                        Field f = connection.getClass().getDeclaredField(field);
                        f.setAccessible(true);
                        channel = f.get(connection);
                        if (channel != null) {
                           break;
                        }
                     } catch (Exception var9) {
                     }
                  }

                  String channelType = channel != null ? channel.getClass().getSimpleName() : "NULL";
                  boolean isFakeChannel = channel instanceof FakeChannelV2;
                  LOGGER.info("[Debug]         └── Channel: " + channelType + (isFakeChannel ? " (FAKE)" : ""));
               }
            }
         } catch (Exception e) {
            LOGGER.warning("[Debug] Error tracing connection chain: " + e.getMessage());
         }

      }
   }
}
