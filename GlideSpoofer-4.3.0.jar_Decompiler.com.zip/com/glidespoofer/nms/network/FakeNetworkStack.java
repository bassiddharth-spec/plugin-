package com.glidespoofer.nms.network;

import com.glidespoofer.nms.FakeChannelV2;
import io.netty.channel.Channel;
import java.lang.reflect.Field;
import java.net.InetAddress;
import java.util.logging.Logger;

public class FakeNetworkStack {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-FakeNetworkStack");
   private final FakeChannelV2 channel;
   private final FakeConnection connection;
   private final FakeServerGamePacketListenerImpl packetListener;
   private final Object serverPlayer;
   private final int ping;

   private FakeNetworkStack(Builder builder) {
      this.channel = builder.channel;
      this.connection = builder.connection;
      this.packetListener = builder.packetListener;
      this.serverPlayer = builder.serverPlayer;
      this.ping = builder.ping;
   }

   public FakeChannelV2 getChannel() {
      return this.channel;
   }

   public FakeConnection getConnection() {
      return this.connection;
   }

   public Object getNMSConnection() {
      return this.connection != null ? this.connection.getConnection() : null;
   }

   public FakeServerGamePacketListenerImpl getPacketListener() {
      return this.packetListener;
   }

   public Object getNMSPacketListener() {
      return this.packetListener != null ? this.packetListener.getListener() : null;
   }

   public Object getServerPlayer() {
      return this.serverPlayer;
   }

   public int getPing() {
      return this.ping;
   }

   public boolean applyToPlayer() {
      if (this.serverPlayer == null) {
         LOGGER.warning("[FakeNetworkStack] Cannot apply: serverPlayer is null");
         return false;
      } else if (this.packetListener != null && this.packetListener.getListener() != null) {
         try {
            Object nmsPacketListener = this.packetListener.getListener();
            boolean listenerSet = this.setPacketListenerOnPlayer(this.serverPlayer, nmsPacketListener);
            if (!listenerSet) {
               LOGGER.warning("[FakeNetworkStack] Failed to set packet listener on ServerPlayer");
               return false;
            } else {
               LOGGER.info("[FakeNetworkStack] Successfully applied network stack to ServerPlayer");
               return true;
            }
         } catch (Exception e) {
            LOGGER.warning("[FakeNetworkStack] Failed to apply: " + e.getMessage());
            e.printStackTrace();
            return false;
         }
      } else {
         LOGGER.warning("[FakeNetworkStack] Cannot apply: packetListener is null");
         return false;
      }
   }

   public boolean verify() {
      StringBuilder issues = new StringBuilder();
      if (this.channel == null) {
         issues.append("channel is null; ");
      }

      if (this.connection == null) {
         issues.append("connection wrapper is null; ");
      } else if (this.connection.getConnection() == null) {
         issues.append("NMS connection is null; ");
      }

      if (this.packetListener == null) {
         issues.append("packetListener wrapper is null; ");
      } else if (this.packetListener.getListener() == null) {
         issues.append("NMS packetListener is null; ");
      }

      if (this.serverPlayer == null) {
         issues.append("serverPlayer is null; ");
      }

      if (issues.length() > 0) {
         LOGGER.warning("[FakeNetworkStack] Verification failed: " + issues.toString());
         return false;
      } else {
         LOGGER.info("[FakeNetworkStack] Verification passed - all components connected");
         return true;
      }
   }

   private boolean setPacketListenerOnPlayer(Object player, Object listener) {
      if (player != null && listener != null) {
         String[] fieldNames = new String[]{"connection", "playerConnection", "c", "b", "f", "d"};

         for(String fieldName : fieldNames) {
            try {
               Field field = this.findField(player.getClass(), fieldName);
               if (field != null && field.getType().isInstance(listener)) {
                  field.setAccessible(true);
                  field.set(player, listener);
                  LOGGER.info("[FakeNetworkStack] Set packet listener via field: " + fieldName);
                  return true;
               }
            } catch (Exception var9) {
            }
         }

         try {
            for(Field field : player.getClass().getDeclaredFields()) {
               if (field.getType().isInstance(listener)) {
                  field.setAccessible(true);
                  field.set(player, listener);
                  LOGGER.info("[FakeNetworkStack] Set packet listener via type match: " + field.getName());
                  return true;
               }
            }
         } catch (Exception var10) {
         }

         return false;
      } else {
         return false;
      }
   }

   private Field findField(Class<?> clazz, String name) {
      try {
         Field field = clazz.getDeclaredField(name);
         field.setAccessible(true);
         return field;
      } catch (NoSuchFieldException var5) {
         Class<?> superClass = clazz.getSuperclass();
         return superClass != null && superClass != Object.class ? this.findField(superClass, name) : null;
      }
   }

   public static Builder builder() {
      return new Builder();
   }

   public static FakeNetworkStack create(Object minecraftServer, Object serverPlayer, int ping) {
      return builder().minecraftServer(minecraftServer).serverPlayer(serverPlayer).ping(ping).build();
   }

   public static FakeNetworkStack createAndApply(Object minecraftServer, Object serverPlayer, int ping) {
      FakeNetworkStack stack = create(minecraftServer, serverPlayer, ping);
      if (stack != null) {
         stack.applyToPlayer();
      }

      return stack;
   }

   public static class Builder {
      private InetAddress address;
      private FakeChannelV2 channel;
      private FakeConnection connection;
      private FakeServerGamePacketListenerImpl packetListener;
      private Object serverPlayer;
      private Object minecraftServer;
      private int ping = 50;

      public Builder address(InetAddress address) {
         this.address = address;
         return this;
      }

      public Builder serverPlayer(Object serverPlayer) {
         this.serverPlayer = serverPlayer;
         return this;
      }

      public Builder minecraftServer(Object minecraftServer) {
         this.minecraftServer = minecraftServer;
         return this;
      }

      public Builder ping(int ping) {
         this.ping = ping;
         return this;
      }

      public FakeNetworkStack build() {
         if (this.address == null) {
            this.address = InetAddress.getLoopbackAddress();
         }

         this.channel = new FakeChannelV2((Channel)null, this.address);
         FakeNetworkStack.LOGGER.info("[FakeNetworkStack] Created FakeChannelV2");
         this.connection = new FakeConnection(this.address, this.channel);
         FakeNetworkStack.LOGGER.info("[FakeNetworkStack] Created FakeConnection");
         if (this.minecraftServer != null && this.connection != null && this.serverPlayer != null) {
            this.packetListener = new FakeServerGamePacketListenerImpl(this.minecraftServer, this.connection, this.serverPlayer);
            FakeNetworkStack.LOGGER.info("[FakeNetworkStack] Created FakeServerGamePacketListenerImpl");
         }

         return new FakeNetworkStack(this);
      }

      public FakeNetworkStack buildAndApply() {
         FakeNetworkStack stack = this.build();
         if (stack != null) {
            stack.applyToPlayer();
         }

         return stack;
      }
   }
}
