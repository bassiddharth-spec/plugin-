package com.glidespoofer.nms.network;

import com.glidespoofer.nms.FakeChannelV2;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.Logger;
import org.bukkit.Bukkit;

public class FakeConnection {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-FakeConnection");
   private static Class<?> connectionClass;
   private static Class<?> packetFlowClass;
   private static Constructor<?> connectionConstructor;
   private static Field addressField;
   private static Field channelField;
   private static boolean initialized = false;
   private Object connection;
   private final InetAddress address;
   private final InetSocketAddress socketAddress;
   private FakeChannelV2 fakeChannel;

   private static Class<?> getNMSClass(String name) {
      try {
         return Class.forName(name);
      } catch (ClassNotFoundException var2) {
         return null;
      }
   }

   public FakeConnection() {
      this(InetAddress.getLoopbackAddress());
   }

   public FakeConnection(InetAddress address) {
      this.address = address;
      this.socketAddress = new InetSocketAddress(address, 0);
      this.initializeStatic();
      this.connection = this.createNMSConnection();
      if (this.connection != null) {
         this.setupConnectionFields();
      }

   }

   public FakeConnection(InetAddress address, FakeChannelV2 channel) {
      this.address = address;
      this.socketAddress = new InetSocketAddress(address, 0);
      this.fakeChannel = channel;
      this.initializeStatic();
      this.connection = this.createNMSConnection();
      if (this.connection != null) {
         this.setupConnectionFields();
         this.setChannel(channel);
      }

   }

   private synchronized void initializeStatic() {
      if (!initialized) {
         try {
            connectionClass = getNMSClass("net.minecraft.network.Connection");
            packetFlowClass = getNMSClass("net.minecraft.network.protocol.PacketFlow");
            if (connectionClass == null) {
               String nmsVersion = this.getNMSVersion();
               connectionClass = getNMSClass("net.minecraft.server." + nmsVersion + ".NetworkManager");
               packetFlowClass = getNMSClass("net.minecraft.server." + nmsVersion + ".EnumProtocolDirection");
            }

            if (connectionClass != null && packetFlowClass != null) {
               Object serverbound = null;

               for(Object constant : packetFlowClass.getEnumConstants()) {
                  if (constant.toString().equals("SERVERBOUND")) {
                     serverbound = constant;
                     break;
                  }
               }

               if (serverbound != null) {
                  connectionConstructor = connectionClass.getDeclaredConstructor(packetFlowClass);
                  connectionConstructor.setAccessible(true);
               }
            }

            if (connectionClass != null) {
               addressField = this.findField(connectionClass, "address", "socketAddress");
               channelField = this.findField(connectionClass, "channel", "n");
            }

            initialized = true;
            LOGGER.info("[FakeConnection] Initialized successfully");
         } catch (Exception e) {
            LOGGER.warning("[FakeConnection] Failed to initialize: " + e.getMessage());
         }

      }
   }

   private Object createNMSConnection() {
      if (connectionConstructor != null && packetFlowClass != null) {
         try {
            for(Object constant : packetFlowClass.getEnumConstants()) {
               if (constant.toString().equals("SERVERBOUND")) {
                  return connectionConstructor.newInstance(constant);
               }
            }
         } catch (Exception e) {
            LOGGER.warning("[FakeConnection] Failed to create NMS connection: " + e.getMessage());
         }

         return null;
      } else {
         return null;
      }
   }

   private void setupConnectionFields() {
      if (this.connection != null) {
         if (addressField != null) {
            try {
               addressField.set(this.connection, this.socketAddress);
            } catch (Exception var2) {
            }
         }

         this.initializeSendQueue();
         this.setConnectionActive();
      }
   }

   private void initializeSendQueue() {
      if (this.connection != null) {
         try {
            for(String fieldName : new String[]{"m", "sendQueue", "packetQueue", "queue", "outboundQueue"}) {
               Field field = this.findField(this.connection.getClass(), fieldName);
               if (field != null) {
                  Class<?> fieldType = field.getType();
                  if (Queue.class.isAssignableFrom(fieldType) || fieldType.getName().contains("Queue")) {
                     field.setAccessible(true);
                     Object queue = this.createQueueForType(fieldType);
                     if (queue != null) {
                        field.set(this.connection, queue);
                        LOGGER.fine("[FakeConnection] Initialized send queue: " + fieldName);
                        return;
                     }
                  }
               }
            }
         } catch (Exception e) {
            LOGGER.warning("[FakeConnection] Could not initialize send queue: " + e.getMessage());
         }

      }
   }

   private Object createQueueForType(Class<?> queueType) {
      try {
         return !queueType.isInterface() && !Modifier.isAbstract(queueType.getModifiers()) ? queueType.getDeclaredConstructor().newInstance() : new ConcurrentLinkedQueue();
      } catch (Exception var3) {
         return new ConcurrentLinkedQueue();
      }
   }

   private void setConnectionActive() {
      if (this.connection != null) {
         try {
            for(Field f : this.connection.getClass().getDeclaredFields()) {
               if (f.getType() == Boolean.TYPE) {
                  String name = f.getName().toLowerCase();
                  if (name.contains("connected") || name.contains("active") || name.equals("m")) {
                     f.setAccessible(true);
                     f.setBoolean(this.connection, true);
                  }
               }
            }
         } catch (Exception var6) {
         }

      }
   }

   public void setChannel(FakeChannelV2 channel) {
      this.fakeChannel = channel;
      if (this.connection != null && channelField != null) {
         try {
            channelField.set(this.connection, channel);
            LOGGER.fine("[FakeConnection] Set channel on connection");
         } catch (Exception e) {
            LOGGER.warning("[FakeConnection] Failed to set channel: " + e.getMessage());
         }
      }

   }

   public Object getConnection() {
      return this.connection;
   }

   public FakeChannelV2 getFakeChannel() {
      return this.fakeChannel;
   }

   public InetSocketAddress getRemoteAddress() {
      return this.socketAddress;
   }

   public InetAddress getAddress() {
      return this.address;
   }

   public boolean isConnected() {
      return true;
   }

   public void setPacketListener(Object packetListener) {
      if (this.connection != null && packetListener != null) {
         try {
            Field listenerField = this.findField(this.connection.getClass(), "packetListener", "o", "q", "listener");
            if (listenerField != null) {
               listenerField.setAccessible(true);
               listenerField.set(this.connection, packetListener);
               LOGGER.fine("[FakeConnection] Set packet listener");
            }
         } catch (Exception e) {
            LOGGER.warning("[FakeConnection] Failed to set packet listener: " + e.getMessage());
         }

      }
   }

   public void tick() {
   }

   private String getNMSVersion() {
      try {
         String packageName = Bukkit.getServer().getClass().getPackage().getName();
         String[] parts = packageName.split("\\.");
         if (parts.length >= 4) {
            return parts[3];
         }
      } catch (Exception var3) {
      }

      return "";
   }

   private Field findField(Class<?> clazz, String... names) {
      for(String name : names) {
         try {
            Field field = clazz.getDeclaredField(name);
            field.setAccessible(true);
            return field;
         } catch (NoSuchFieldException var11) {
         }
      }

      for(Field field : clazz.getDeclaredFields()) {
         for(String name : names) {
            if (field.getName().equals(name)) {
               field.setAccessible(true);
               return field;
            }
         }
      }

      return null;
   }
}
