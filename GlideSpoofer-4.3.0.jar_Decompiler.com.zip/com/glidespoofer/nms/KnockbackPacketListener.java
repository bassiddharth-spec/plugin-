package com.glidespoofer.nms;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class KnockbackPacketListener {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-Knockback");
   private final Plugin plugin;
   private Class<?> serverGamePacketListenerImplClass;
   private Class<?> clientboundSetEntityMotionPacketClass;
   private Class<?> vec3Class;
   private Method lerpMotionMethod;
   private Method getMovementMethod;
   private Method getIdMethod;
   private Field hurtMarkedField;

   public KnockbackPacketListener(Plugin plugin) {
      this.plugin = plugin;
      this.initializeReflection();
   }

   private void initializeReflection() {
      try {
         String version = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
         String nmsPackage = "net.minecraft.server." + version;

         try {
            this.clientboundSetEntityMotionPacketClass = Class.forName("net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket");
            this.vec3Class = Class.forName("net.minecraft.world.phys.Vec3");
            this.serverGamePacketListenerImplClass = Class.forName("net.minecraft.server.network.ServerGamePacketListenerImpl");
         } catch (ClassNotFoundException var11) {
            this.clientboundSetEntityMotionPacketClass = Class.forName(nmsPackage + ".PacketPlayOutEntityVelocity");
            this.vec3Class = Class.forName(nmsPackage + ".Vec3D");
            this.serverGamePacketListenerImplClass = Class.forName(nmsPackage + ".PlayerConnection");
         }

         try {
            this.lerpMotionMethod = Class.forName("net.minecraft.world.entity.Entity").getDeclaredMethod("lerpMotion", Double.TYPE, Double.TYPE, Double.TYPE);
            this.lerpMotionMethod.setAccessible(true);
         } catch (NoSuchMethodException var10) {
            try {
               this.lerpMotionMethod = Class.forName("net.minecraft.world.entity.Entity").getDeclaredMethod("b", Double.TYPE, Double.TYPE, Double.TYPE);
               this.lerpMotionMethod.setAccessible(true);
            } catch (NoSuchMethodException var9) {
               LOGGER.fine("[KnockbackPacketListener] Could not find lerpMotion method");
            }
         }

         try {
            this.getMovementMethod = this.clientboundSetEntityMotionPacketClass.getDeclaredMethod("getMovement");
            this.getMovementMethod.setAccessible(true);
         } catch (NoSuchMethodException var8) {
            try {
               this.getMovementMethod = this.clientboundSetEntityMotionPacketClass.getDeclaredMethod("b");
               this.getMovementMethod.setAccessible(true);
            } catch (NoSuchMethodException var7) {
               LOGGER.fine("[KnockbackPacketListener] Could not find getMovement method");
            }
         }

         try {
            this.getIdMethod = Class.forName("net.minecraft.world.entity.Entity").getDeclaredMethod("getId");
            this.getIdMethod.setAccessible(true);
         } catch (NoSuchMethodException var6) {
            LOGGER.fine("[KnockbackPacketListener] Could not find getId method");
         }

         try {
            this.hurtMarkedField = Class.forName("net.minecraft.world.entity.Entity").getDeclaredField("hurtMarked");
            this.hurtMarkedField.setAccessible(true);
         } catch (NoSuchFieldException var5) {
            LOGGER.fine("[KnockbackPacketListener] Could not find hurtMarked field");
         }

         LOGGER.fine("[KnockbackPacketListener] Reflection initialized successfully");
      } catch (Exception var12) {
         LOGGER.fine("[KnockbackPacketListener] Failed to initialize reflection: " + var12.getMessage());
      }

   }

   public void handleKnockbackPacket(Player fakePlayer, Object packet) {
      if (fakePlayer != null && packet != null) {
         try {
            Object serverPlayer = this.getServerPlayer(fakePlayer);
            if (serverPlayer == null) {
               return;
            }

            int packetEntityId = this.getPacketEntityId(packet);
            int playerEntityId = (Integer)this.getIdMethod.invoke(serverPlayer);
            if (packetEntityId != playerEntityId) {
               return;
            }

            boolean hurtMarked = this.isHurtMarked(serverPlayer);
            if (!hurtMarked) {
               LOGGER.fine("[KnockbackPacketListener] hurtMarked is false, skipping knockback");
               return;
            }

            Object movement = this.getMovementFromPacket(packet);
            if (movement == null) {
               LOGGER.fine("[KnockbackPacketListener] Could not get movement from packet");
               return;
            }

            this.applyKnockback(serverPlayer, movement);
            LOGGER.fine("[KnockbackPacketListener] Applied knockback to " + fakePlayer.getName());
         } catch (Exception var8) {
            LOGGER.fine("[KnockbackPacketListener] Error handling knockback: " + var8.getMessage());
            var8.printStackTrace();
         }
      }

   }

   private void applyKnockback(Object serverPlayer, Object movementVec3) {
      try {
         if (this.lerpMotionMethod == null || movementVec3 == null) {
            LOGGER.fine("[KnockbackPacketListener] lerpMotion method or movement is null");
            return;
         }

         double x = (double)0.0F;
         double y = (double)0.0F;
         double z = (double)0.0F;

         try {
            Method xMethod = this.vec3Class.getMethod("x");
            Method yMethod = this.vec3Class.getMethod("y");
            Method zMethod = this.vec3Class.getMethod("z");
            x = (Double)xMethod.invoke(movementVec3);
            y = (Double)yMethod.invoke(movementVec3);
            z = (Double)zMethod.invoke(movementVec3);
         } catch (Exception var12) {
            LOGGER.fine("[KnockbackPacketListener] Could not extract Vec3 components");
            return;
         }

         if (this.hurtMarkedField != null) {
            this.hurtMarkedField.setBoolean(serverPlayer, true);
         }

         this.lerpMotionMethod.invoke(serverPlayer, x, y, z);
         LOGGER.fine("[KnockbackPacketListener] Applied lerpMotion: x=" + x + ", y=" + y + ", z=" + z);
      } catch (Exception var13) {
         LOGGER.fine("[KnockbackPacketListener] Error applying knockback: " + var13.getMessage());
      }

   }

   public void applyKnockback(Player fakePlayer, double velocityX, double velocityY, double velocityZ) {
      try {
         Object serverPlayer = this.getServerPlayer(fakePlayer);
         if (serverPlayer == null) {
            return;
         }

         if (this.hurtMarkedField != null) {
            this.hurtMarkedField.setBoolean(serverPlayer, true);
         }

         if (this.lerpMotionMethod != null) {
            this.lerpMotionMethod.invoke(serverPlayer, velocityX, velocityY, velocityZ);
            LOGGER.fine("[KnockbackPacketListener] Applied direct knockback to " + fakePlayer.getName());
         }
      } catch (Exception var9) {
         LOGGER.fine("[KnockbackPacketListener] Error applying direct knockback: " + var9.getMessage());
      }

   }

   public void setHurtMarked(Player fakePlayer, boolean value) {
      try {
         Object serverPlayer = this.getServerPlayer(fakePlayer);
         if (serverPlayer != null && this.hurtMarkedField != null) {
            this.hurtMarkedField.setBoolean(serverPlayer, value);
            LOGGER.fine("[KnockbackPacketListener] Set hurtMarked=" + value + " for " + fakePlayer.getName());
         }
      } catch (Exception var4) {
         LOGGER.fine("[KnockbackPacketListener] Error setting hurtMarked: " + var4.getMessage());
      }

   }

   public boolean isHurtMarked(Object serverPlayer) {
      try {
         if (this.hurtMarkedField != null) {
            return this.hurtMarkedField.getBoolean(serverPlayer);
         }
      } catch (Exception var3) {
         LOGGER.fine("[KnockbackPacketListener] Error checking hurtMarked: " + var3.getMessage());
      }

      return false;
   }

   private Object getServerPlayer(Player player) {
      try {
         Method getHandle = player.getClass().getMethod("getHandle");
         return getHandle.invoke(player);
      } catch (Exception var3) {
         LOGGER.fine("[KnockbackPacketListener] Could not get ServerPlayer: " + var3.getMessage());
         return null;
      }
   }

   private int getPacketEntityId(Object packet) {
      try {
         Method getIdMethod = this.clientboundSetEntityMotionPacketClass.getDeclaredMethod("getId");
         getIdMethod.setAccessible(true);
         return (Integer)getIdMethod.invoke(packet);
      } catch (Exception var3) {
         LOGGER.fine("[KnockbackPacketListener] Could not get packet entity ID: " + var3.getMessage());
         return -1;
      }
   }

   private Object getMovementFromPacket(Object packet) {
      try {
         if (this.getMovementMethod != null) {
            return this.getMovementMethod.invoke(packet);
         }
      } catch (Exception var3) {
         LOGGER.fine("[KnockbackPacketListener] Could not get movement from packet: " + var3.getMessage());
      }

      return null;
   }
}
