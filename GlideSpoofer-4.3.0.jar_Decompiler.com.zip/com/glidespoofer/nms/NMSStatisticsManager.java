package com.glidespoofer.nms;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.entity.Player;

public class NMSStatisticsManager {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer");
   private final Map<UUID, Object> statsManagers = new ConcurrentHashMap();
   private final Map<UUID, Map<String, Long>> customStats = new ConcurrentHashMap();
   private final boolean useModernNMS;
   private final String nmsPackage;
   private Method getStatsMethod;
   private Method incrementStatMethod;
   private Method setValueMethod;
   private Field statsField;
   private Class<?> statClass;
   private Class<?> statTypeClass;

   public NMSStatisticsManager(boolean useModernNMS, String nmsPackage) {
      this.useModernNMS = useModernNMS;
      this.nmsPackage = nmsPackage;
      this.initializeReflection();
   }

   private void initializeReflection() {
      try {
         Class<?> serverPlayerClass;
         if (this.useModernNMS) {
            serverPlayerClass = Class.forName("net.minecraft.server.level.ServerPlayer");
         } else {
            serverPlayerClass = Class.forName(this.nmsPackage + ".EntityPlayer");
         }

         try {
            this.getStatsMethod = serverPlayerClass.getMethod("getStats");
            LOGGER.info("[NMSStats] Found getStats() method");
         } catch (NoSuchMethodException var10) {
            for(Field f : serverPlayerClass.getDeclaredFields()) {
               if (f.getName().equalsIgnoreCase("stats") || f.getType().getSimpleName().contains("Stats") || f.getType().getSimpleName().contains("Statistic")) {
                  this.statsField = f;
                  this.statsField.setAccessible(true);
                  LOGGER.info("[NMSStats] Found stats field: " + f.getName());
                  break;
               }
            }
         }

         try {
            this.statClass = Class.forName("net.minecraft.world.level.block.state.Block" + (this.useModernNMS ? "Base" : "") + "$BlockData");
         } catch (ClassNotFoundException var9) {
            this.statClass = null;
         }

         try {
            this.statTypeClass = Class.forName("net.minecraft.stats.StatType");
         } catch (ClassNotFoundException var8) {
            try {
               this.statTypeClass = Class.forName(this.nmsPackage + ".Statistic");
            } catch (ClassNotFoundException var7) {
               this.statTypeClass = null;
            }
         }
      } catch (Exception var11) {
         LOGGER.warning("[NMSStats] Failed to initialize reflection: " + var11.getMessage());
      }

   }

   public void initializeStats(Player player, Object serverPlayer) {
      if (player != null && serverPlayer != null) {
         UUID uuid = player.getUniqueId();

         try {
            Object statsManager = null;
            if (this.getStatsMethod != null) {
               statsManager = this.getStatsMethod.invoke(serverPlayer);
            } else if (this.statsField != null) {
               statsManager = this.statsField.get(serverPlayer);
            }

            if (statsManager != null) {
               this.statsManagers.put(uuid, statsManager);
            }

            this.customStats.put(uuid, new ConcurrentHashMap());
         } catch (Exception var5) {
            Logger var10000 = LOGGER;
            String var10001 = player.getName();
            var10000.warning("[NMSStats] Failed to initialize stats for " + var10001 + ": " + var5.getMessage());
         }
      }

   }

   public void incrementStat(Player player, String category, String id, int amount) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         Map<String, Long> stats = (Map)this.customStats.get(uuid);
         if (stats != null) {
            String key = category + "." + id;
            stats.merge(key, (long)amount, Long::sum);
         }

         try {
            Object statsManager = this.statsManagers.get(uuid);
            if (statsManager == null) {
               return;
            }

            if (this.incrementStatMethod == null) {
               try {
                  this.incrementStatMethod = statsManager.getClass().getMethod("incrementStat", Class.forName("net.minecraft.server.level.ServerPlayer"), Class.forName("net.minecraft.stats.Stat"), Integer.TYPE);
               } catch (NoSuchMethodException var11) {
                  try {
                     this.incrementStatMethod = statsManager.getClass().getMethod("a", Class.forName("net.minecraft.server.level.EntityHuman"), Class.forName("net.minecraft.server.world.Statistic"), Integer.TYPE);
                  } catch (Exception var10) {
                     return;
                  }
               }
            }
         } catch (Exception var12) {
         }
      }

   }

   public void setStat(Player player, String category, String id, long value) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         Map<String, Long> stats = (Map)this.customStats.get(uuid);
         if (stats != null) {
            stats.put(category + "." + id, value);
         }
      }

   }

   public long getStat(Player player, String category, String id) {
      if (player == null) {
         return 0L;
      } else {
         UUID uuid = player.getUniqueId();
         Map<String, Long> stats = (Map)this.customStats.get(uuid);
         return stats != null ? (Long)stats.getOrDefault(category + "." + id, 0L) : 0L;
      }
   }

   public Map<String, Long> getAllStats(Player player) {
      return player == null ? new ConcurrentHashMap() : new ConcurrentHashMap((Map)this.customStats.getOrDefault(player.getUniqueId(), new ConcurrentHashMap()));
   }

   public void blockMined(Player player, String blockType, int amount) {
      this.incrementStat(player, "mineBlock", blockType, amount);
   }

   public void blockPlaced(Player player, String blockType, int amount) {
      this.incrementStat(player, "useItem", blockType, amount);
   }

   public void distanceTraveled(Player player, String type, double distance) {
      int cm = (int)(distance * (double)100.0F);
      this.incrementStat(player, "walkOneCm", type, cm);
   }

   public void itemCrafted(Player player, String itemType, int amount) {
      this.incrementStat(player, "craftItem", itemType, amount);
   }

   public void mobKilled(Player player, String entityType, int amount) {
      this.incrementStat(player, "killEntity", entityType, amount);
   }

   public void damageDealt(Player player, double damage) {
      long amount = (long)(damage * (double)10.0F);
      this.incrementStat(player, "damageDealt", "", (int)amount);
   }

   public void damageTaken(Player player, double damage) {
      long amount = (long)(damage * (double)10.0F);
      this.incrementStat(player, "damageTaken", "", (int)amount);
   }

   public void incrementDeaths(Player player) {
      this.incrementStat(player, "deaths", "", 1);
   }

   public void incrementJumps(Player player) {
      this.incrementStat(player, "jump", "", 1);
   }

   public void timePlayed(Player player, int ticks) {
      this.incrementStat(player, "playOneMinute", "", ticks);
   }

   public String getStatsDisplay(Player player) {
      Map<String, Long> stats = this.getAllStats(player);
      if (stats.isEmpty()) {
         return "No statistics yet";
      } else {
         StringBuilder sb = new StringBuilder("\n§e=== Statistics for " + player.getName() + " ===\n");

         for(Map.Entry<String, Long> entry : stats.entrySet()) {
            String[] parts = ((String)entry.getKey()).split("\\.", 2);
            String category = parts[0];
            String item = parts.length > 1 ? parts[1] : "";
            long value = (Long)entry.getValue();
            if (value > 0L) {
               sb.append(String.format("§7%s: §f%d\n", this.formatStatName(category, item), value));
            }
         }

         return sb.toString();
      }
   }

   private String formatStatName(String category, String item) {
      switch (category) {
         case "mineBlock" -> {
            return "Mined " + item;
         }
         case "craftItem" -> {
            return "Crafted " + item;
         }
         case "useItem" -> {
            return "Used " + item;
         }
         case "breakItem" -> {
            return "Broken " + item;
         }
         case "killEntity" -> {
            return "Killed " + item;
         }
         case "walkOneCm" -> {
            return "Distance walked";
         }
         case "damageDealt" -> {
            return "Damage dealt";
         }
         case "damageTaken" -> {
            return "Damage taken";
         }
         case "deaths" -> {
            return "Deaths";
         }
         case "jump" -> {
            return "Jumps";
         }
         case "playOneMinute" -> {
            return "Time played";
         }
         default -> {
            return category + (item.isEmpty() ? "" : " " + item);
         }
      }
   }

   public void removeStats(Player player) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         this.statsManagers.remove(uuid);
         this.customStats.remove(uuid);
      }

   }

   public void saveStats(Player player) {
   }

   public void loadStats(Player player, Map<String, Object> data) {
      if (player != null && data != null) {
         UUID uuid = player.getUniqueId();
         Map<String, Long> stats = (Map)this.customStats.computeIfAbsent(uuid, (k) -> new ConcurrentHashMap());

         for(Map.Entry<String, Object> entry : data.entrySet()) {
            if (entry.getValue() instanceof Number) {
               stats.put((String)entry.getKey(), ((Number)entry.getValue()).longValue());
            }
         }
      }

   }

   public Object getStatsManager(Player player) {
      return player == null ? null : this.statsManagers.get(player.getUniqueId());
   }
}
