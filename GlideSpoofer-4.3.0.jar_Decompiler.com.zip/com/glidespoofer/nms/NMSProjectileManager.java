package com.glidespoofer.nms;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.SimpleFakePlayerManager;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class NMSProjectileManager implements Listener {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer");
   private final Set<UUID> hittableFakePlayers = ConcurrentHashMap.newKeySet();
   private final Map<UUID, List<UUID>> projectileTargets = new ConcurrentHashMap();
   private final Map<UUID, Double> pendingDamage = new ConcurrentHashMap();
   private boolean enableProjectileHits = true;
   private boolean enableMobTargeting = true;
   private boolean trackProjectiles = true;
   private final boolean useModernNMS;
   private final String nmsPackage;
   private final Object plugin;
   private SimpleNMSHandler nmsHandler;
   private Method getBoundingBoxMethod;
   private Method intersectsMethod;
   private Field boundingBoxField;
   private BukkitTask targetingTask;

   public NMSProjectileManager(boolean useModernNMS, String nmsPackage, Object plugin) {
      this.useModernNMS = useModernNMS;
      this.nmsPackage = nmsPackage;
      this.plugin = plugin;
      this.initializeReflection();
   }

   public void setNmsHandler(SimpleNMSHandler handler) {
      this.nmsHandler = handler;
   }

   private void initializeReflection() {
      try {
         Class<?> entityClass;
         if (this.useModernNMS) {
            entityClass = Class.forName("net.minecraft.world.entity.Entity");
         } else {
            entityClass = Class.forName(this.nmsPackage + ".Entity");
         }

         try {
            this.getBoundingBoxMethod = entityClass.getMethod("getBoundingBox");
         } catch (NoSuchMethodException var7) {
            for(Method m : entityClass.getDeclaredMethods()) {
               if (m.getName().toLowerCase().contains("bounds") || m.getName().toLowerCase().contains("aabb")) {
                  this.getBoundingBoxMethod = m;
                  this.getBoundingBoxMethod.setAccessible(true);
                  break;
               }
            }
         }

         if (SimpleNMSHandler.isDebugMode()) {
            LOGGER.info("[NMSProjectile] Projectile manager initialized");
         }
      } catch (Exception var8) {
         LOGGER.warning("[NMSProjectile] Failed to initialize reflection: " + var8.getMessage());
      }

   }

   public void registerHittable(Player fakePlayer) {
      if (fakePlayer != null) {
         UUID uuid = fakePlayer.getUniqueId();
         this.hittableFakePlayers.add(uuid);
         this.projectileTargets.put(uuid, new ArrayList());
         if (SimpleNMSHandler.isDebugMode()) {
            LOGGER.info("[NMSProjectile] Registered " + fakePlayer.getName() + " as hittable");
         }
      }

   }

   public void unregisterHittable(Player fakePlayer) {
      if (fakePlayer != null) {
         UUID uuid = fakePlayer.getUniqueId();
         this.hittableFakePlayers.remove(uuid);
         this.projectileTargets.remove(uuid);
         this.pendingDamage.remove(uuid);
         if (SimpleNMSHandler.isDebugMode()) {
            LOGGER.info("[NMSProjectile] Unregistered " + fakePlayer.getName());
         }
      }

   }

   public boolean isHittable(Player player) {
      return player == null ? false : this.hittableFakePlayers.contains(player.getUniqueId());
   }

   public boolean isHittable(UUID uuid) {
      return this.hittableFakePlayers.contains(uuid);
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onProjectileHit(ProjectileHitEvent event) {
      if (this.enableProjectileHits) {
         Projectile projectile = event.getEntity();
         if (projectile != null) {
            Entity hitEntity = event.getHitEntity();
            if (hitEntity == null && event.getHitBlock() != null) {
               this.handleNearbyFakePlayerHit(event);
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
      if (this.enableProjectileHits) {
         Entity damager = event.getDamager();
         Entity victim = event.getEntity();
         if (damager instanceof Projectile && victim instanceof Player && this.isHittable((Player)victim)) {
            Projectile projectile = (Projectile)damager;
            if (SimpleNMSHandler.isDebugMode()) {
               Logger var10000 = LOGGER;
               String var10001 = victim.getName();
               var10000.info("[NMSProjectile] Projectile hit fake player " + var10001 + " from " + (projectile.getShooter() != null ? projectile.getShooter().toString() : "unknown") + " damage: " + event.getFinalDamage());
            }
         }
      }

   }

   private void handleNearbyFakePlayerHit(ProjectileHitEvent event) {
   }

   private boolean wouldHitPlayer(Projectile projectile, Player player) {
      Location playerLoc = player.getLocation();
      Location projectileLoc = projectile.getLocation();
      double dx = Math.abs(playerLoc.getX() - projectileLoc.getX());
      double dy = Math.abs(playerLoc.getY() + 0.9 - projectileLoc.getY());
      double dz = Math.abs(playerLoc.getZ() - projectileLoc.getZ());
      return dx < 0.4 && dy < (double)1.0F && dz < 0.4;
   }

   private double calculateProjectileDamage(Projectile projectile) {
      switch (projectile.getType().name()) {
         case "ARROW":
         case "SPECTRAL_ARROW":
            return (double)2.0F + projectile.getVelocity().length() * (double)2.0F;
         case "TIPPED_ARROW":
            return (double)1.5F;
         case "SHULKER_BULLET":
            return (double)4.0F;
         case "SMALL_FIREBALL":
            return (double)1.0F;
         case "FIREBALL":
            return (double)6.0F + projectile.getVelocity().length();
         case "SPLASH_POTION":
         case "LINGERING_POTION":
            return (double)1.5F;
         case "TRIDENT":
            return (double)8.0F;
         case "LLAMA_SPIT":
            return (double)1.5F;
         case "EGG":
            return (double)0.0F;
         case "SNOWBALL":
            return (double)0.0F;
         default:
            return (double)2.0F;
      }
   }

   private void handleProjectileDamage(Player fakePlayer, Projectile projectile, double damage) {
      if (projectile.getShooter() instanceof Entity) {
         this.applyDamage(fakePlayer, damage, (Entity)projectile.getShooter());
      } else {
         this.applyDamage(fakePlayer, damage, (Entity)null);
      }

      this.applyProjectileEffects(fakePlayer, projectile);
   }

   private void applyProjectileEffects(Player fakePlayer, Projectile projectile) {
      String type = projectile.getType().name();

      try {
         switch (type) {
            case "SMALL_FIREBALL":
            case "FIREBALL":
               fakePlayer.setFireTicks(100);
            case "SPLASH_POTION":
            case "LINGERING_POTION":
            case "SHULKER_BULLET":
            case "TIPPED_ARROW":
         }
      } catch (Exception var6) {
      }

   }

   public void applyDamage(Player fakePlayer, double damage, Entity source) {
      if (fakePlayer != null && !(damage <= (double)0.0F)) {
         UUID uuid = fakePlayer.getUniqueId();
         this.pendingDamage.put(uuid, damage);
         double currentHealth = fakePlayer.getHealth();
         double newHealth = Math.max((double)0.0F, currentHealth - damage);
         if (source != null && damage > (double)0.0F) {
            this.applyKnockback(fakePlayer, source, damage);
         }

         this.broadcastHurtAnimation(fakePlayer);
         fakePlayer.setHealth(newHealth);
         this.playHurtSound(fakePlayer.getLocation());
         if (newHealth <= (double)0.0F) {
            this.handleDeath(fakePlayer, source);
         }

         if (SimpleNMSHandler.isDebugMode()) {
            Logger var10000 = LOGGER;
            String var10001 = fakePlayer.getName();
            var10000.info("[NMSProjectile] " + var10001 + " took " + damage + " damage from " + (source != null ? source.getName() : "unknown") + " (health: " + newHealth + ")");
         }
      }

   }

   private void applyKnockback(Player fakePlayer, Entity source, double damage) {
      try {
         Location fakeLoc = fakePlayer.getLocation();
         Location sourceLoc = source.getLocation();
         double dx = fakeLoc.getX() - sourceLoc.getX();
         double dz = fakeLoc.getZ() - sourceLoc.getZ();
         double length = Math.sqrt(dx * dx + dz * dz);
         double kbX = (double)0.0F;
         double kbY = 0.08;
         double kbZ = (double)0.0F;
         if (length > (double)0.0F) {
            dx /= length;
            dz /= length;
            double strength = 0.4 + damage * 0.1;
            kbX = dx * strength * 0.6;
            kbZ = dz * strength * 0.6;
            Location newLoc = fakeLoc.clone().add(kbX, kbY, kbZ);
            if (!newLoc.getBlock().getType().isSolid()) {
               fakePlayer.teleport(newLoc);
            }

            this.broadcastVelocityPacket(fakePlayer, kbX, kbY, kbZ);
         }
      } catch (Exception var22) {
         LOGGER.fine("[NMSProjectile] Failed to apply knockback: " + var22.getMessage());
      }

   }

   private void broadcastHurtAnimation(Player fakePlayer) {
      if (this.nmsHandler != null) {
         try {
            Object serverPlayer = this.getServerPlayer(fakePlayer);
            if (serverPlayer != null) {
               this.nmsHandler.broadcastDamageAnimation(serverPlayer);
               return;
            }
         } catch (Exception var4) {
         }
      }

      Object var3 = this.plugin;
      if (var3 instanceof GlideSpoofer glideSpoofer) {
         SimpleFakePlayerManager manager = glideSpoofer.getSimpleFakePlayerManager();
         if (manager != null && manager.getNMSHandler() != null) {
            manager.getNMSHandler().performAction(fakePlayer, NMSHandler.FakePlayerAction.DAMAGE_ANIMATION);
         }
      }

   }

   private void broadcastVelocityPacket(Player fakePlayer, double vx, double vy, double vz) {
      if (this.nmsHandler != null) {
         try {
            Location loc = fakePlayer.getLocation();

            for(Player viewer : Bukkit.getOnlinePlayers()) {
               if (viewer.getWorld() == loc.getWorld() && viewer.getLocation().distance(loc) < (double)64.0F && !viewer.getUniqueId().equals(fakePlayer.getUniqueId())) {
                  this.nmsHandler.sendEntityVelocity(viewer, fakePlayer, vx, vy, vz);
               }
            }

            return;
         } catch (Exception var14) {
            LOGGER.warning("[NMSProjectile] Failed to send velocity via handler: " + var14.getMessage());
         }
      }

      Object var9 = this.plugin;
      if (var9 instanceof GlideSpoofer glideSpoofer) {
         SimpleFakePlayerManager manager = glideSpoofer.getSimpleFakePlayerManager();
         if (manager != null && manager.getNMSHandler() != null) {
            try {
               Location loc = fakePlayer.getLocation();

               for(Player viewerx : Bukkit.getOnlinePlayers()) {
                  if (viewerx.getWorld() == loc.getWorld() && viewerx.getLocation().distance(loc) < (double)64.0F && !viewerx.getUniqueId().equals(fakePlayer.getUniqueId())) {
                     manager.getNMSHandler().sendEntityVelocity(viewerx, fakePlayer, vx, vy, vz);
                  }
               }
            } catch (Exception var13) {
            }
         }
      }

   }

   private void playHurtSound(Location loc) {
      if (loc != null) {
         try {
            loc.getWorld().playSound(loc, Sound.ENTITY_PLAYER_HURT, SoundCategory.PLAYERS, 1.0F, 1.0F);
         } catch (Exception var3) {
         }
      }

   }

   private void playHurtEffect(Player fakePlayer) {
      try {
         Object serverPlayer = this.getServerPlayer(fakePlayer);
         if (serverPlayer != null) {
         }
      } catch (Exception var3) {
      }

   }

   private void updateHealthAfterDamage(Player fakePlayer, double damage) {
   }

   private void handleDeath(Player fakePlayer, Entity killer) {
      if (SimpleNMSHandler.isDebugMode()) {
         LOGGER.info("[NMSProjectile] " + fakePlayer.getName() + " died from projectile hit");
      }

   }

   private Object getServerPlayer(Player player) {
      try {
         Method getHandle = player.getClass().getMethod("getHandle");
         return getHandle.invoke(player);
      } catch (Exception var3) {
         return null;
      }
   }

   public void enableMobTargeting(Player fakePlayer) {
      if (this.enableMobTargeting) {
         try {
            Object serverPlayer = this.getServerPlayer(fakePlayer);
            if (serverPlayer == null) {
               return;
            }

            if (SimpleNMSHandler.isDebugMode()) {
               LOGGER.info("[NMSProjectile] Enabled mob targeting for " + fakePlayer.getName());
            }
         } catch (Exception var3) {
            LOGGER.warning("[NMSProjectile] Failed to enable mob targeting: " + var3.getMessage());
         }
      }

   }

   public void startTargetingTask() {
      if (this.targetingTask == null) {
         this.targetingTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::updateMobTargeting, 20L, 20L);
         if (SimpleNMSHandler.isDebugMode()) {
            LOGGER.info("[NMSProjectile] Started mob targeting task");
         }
      }

   }

   public void stopTargetingTask() {
      if (this.targetingTask != null) {
         this.targetingTask.cancel();
         this.targetingTask = null;
      }

   }

   private void updateMobTargeting() {
      if (this.enableMobTargeting) {
      }

   }

   public void setEnableProjectileHits(boolean enable) {
      this.enableProjectileHits = enable;
   }

   public void setEnableMobTargeting(boolean enable) {
      this.enableMobTargeting = enable;
   }

   public void setTrackProjectiles(boolean enable) {
      this.trackProjectiles = enable;
   }

   public boolean isEnableProjectileHits() {
      return this.enableProjectileHits;
   }

   public boolean isEnableMobTargeting() {
      return this.enableMobTargeting;
   }

   public Set<UUID> getHittablePlayers() {
      return new HashSet(this.hittableFakePlayers);
   }

   public Double getPendingDamage(UUID uuid) {
      return (Double)this.pendingDamage.get(uuid);
   }

   public void clearPendingDamage(UUID uuid) {
      this.pendingDamage.remove(uuid);
   }

   public void shutdown() {
      this.stopTargetingTask();
      this.hittableFakePlayers.clear();
      this.projectileTargets.clear();
      this.pendingDamage.clear();
   }
}
