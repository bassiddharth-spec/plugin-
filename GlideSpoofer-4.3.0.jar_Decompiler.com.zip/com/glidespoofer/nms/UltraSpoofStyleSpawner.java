package com.glidespoofer.nms;

import com.glidespoofer.nms.connection.FakeChannel;
import com.google.common.collect.Queues;
import io.netty.channel.Channel;
import io.netty.channel.nio.NioEventLoopGroup;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent.Result;
import org.bukkit.plugin.Plugin;

public class UltraSpoofStyleSpawner {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-UltraSpoofSpawner");
   private static NioEventLoopGroup EVENT_EXECUTORS = new NioEventLoopGroup(5);
   private static Class<?> minecraftServerClass;
   private static Class<?> playerListClass;
   private static Class<?> worldServerClass;
   private static Class<?> entityPlayerClass;
   private static Class<?> gameProfileClass;
   private static Class<?> connectionClass;
   private static Class<?> serverGamePacketListenerClass;
   private static Class<?> commonListenerCookieClass;
   private static Class<?> clientInformationClass;
   private static Class<?> craftServerClass;
   private static Class<?> craftWorldClass;
   private static Class<?> craftPlayerClass;
   private static Class<?> packetClass;
   private static Class<?> playerInfoPacketClass;
   private static Class<?> packetFlowClass;
   private static Method getServerMethod;
   private static Method getPlayerListMethod;
   private static Method placeNewPlayerMethod;
   private static Method getWorldHandleMethod;
   private static Method getCraftPlayerHandleMethod;
   private static Method getBukkitEntityMethod;
   private static Method getGameProfileMethod;
   private static Method getPlayersMethod;
   private static Constructor<?> gameProfileConstructor;
   private static Constructor<?> clientInfoDefaultConstructor;
   private static Constructor<?> entityPlayerConstructor;
   private static boolean initialized = false;
   private final Map<UUID, Player> spawnedPlayers = new ConcurrentHashMap();
   private final Plugin plugin;
   private final Object minecraftServer;
   private final Object playerList;
   private final List<String> permissionList;
   private int portStart = 40000;
   private int portEnd = 60000;

   public UltraSpoofStyleSpawner(Plugin plugin, List<String> permissionList) {
      if (!initialized) {
         throw new IllegalStateException("UltraSpoofStyleSpawner not initialized - NMS classes not available");
      } else {
         this.plugin = plugin;
         this.permissionList = permissionList != null ? permissionList : List.of();

         try {
            Object craftServer = craftServerClass.cast(Bukkit.getServer());
            getServerMethod = craftServerClass.getMethod("getServer");
            this.minecraftServer = getServerMethod.invoke(craftServer);
            getPlayerListMethod = minecraftServerClass.getMethod("getPlayerList");
            this.playerList = getPlayerListMethod.invoke(this.minecraftServer);
            if (this.playerList == null) {
               throw new IllegalStateException("PlayerList is null");
            } else {
               for(Method m : playerListClass.getMethods()) {
                  if (m.getName().equals("placeNewPlayer")) {
                     placeNewPlayerMethod = m;
                     break;
                  }
               }

               if (placeNewPlayerMethod == null) {
                  for(Method m : playerListClass.getDeclaredMethods()) {
                     Class<?>[] params = m.getParameterTypes();
                     if (params.length >= 2 && connectionClass.isAssignableFrom(params[0]) && entityPlayerClass.isAssignableFrom(params[1])) {
                        placeNewPlayerMethod = m;
                        placeNewPlayerMethod.setAccessible(true);
                        break;
                     }
                  }
               }

               getWorldHandleMethod = craftWorldClass.getMethod("getHandle");
               getCraftPlayerHandleMethod = craftPlayerClass.getMethod("getHandle");
               getBukkitEntityMethod = entityPlayerClass.getMethod("getBukkitEntity");
               getGameProfileMethod = entityPlayerClass.getMethod("getGameProfile");
               getPlayersMethod = playerListClass.getMethod("getPlayers");
               LOGGER.info("[UltraSpoofSpawner] Initialized successfully");
            }
         } catch (Exception e) {
            throw new RuntimeException("Failed to initialize UltraSpoofStyleSpawner", e);
         }
      }
   }

   public Player spawnFakePlayer(String name, UUID uuid, Location location) {
      try {
         LOGGER.info("[UltraSpoofSpawner] Starting spawn for: " + name);
         World world = location != null ? location.getWorld() : (World)Bukkit.getWorlds().get(0);
         Object craftWorld = craftWorldClass.cast(world);
         Object worldServer = getWorldHandleMethod.invoke(craftWorld);
         Object gameProfile = gameProfileConstructor.newInstance(uuid, name);
         Object serverPlayer = this.createServerPlayer(worldServer, gameProfile);
         if (location != null) {
            this.setPlayerPosition(serverPlayer, location);
         }

         String ipAddress = this.generateFakeIP();
         int port = ThreadLocalRandom.current().nextInt(this.portStart, this.portEnd + 1);
         LOGGER.info("[UltraSpoofSpawner] Created ServerPlayer for " + name + " at " + ipAddress + ":" + port);
         this.fireAsyncPreLoginEvent(name, uuid, ipAddress).thenAccept((success) -> {
            if (!success) {
               LOGGER.warning("[UltraSpoofSpawner] AsyncPlayerPreLoginEvent was cancelled for " + name);
            } else {
               Bukkit.getScheduler().runTask(this.plugin, () -> {
                  try {
                     this.completeSpawnOnMainThread(serverPlayer, gameProfile, ipAddress, port);
                  } catch (Exception e) {
                     LOGGER.log(Level.SEVERE, "[UltraSpoofSpawner] Error completing spawn for " + name, e);
                  }

               });
            }
         });
         return (Player)getBukkitEntityMethod.invoke(serverPlayer);
      } catch (Exception e) {
         LOGGER.log(Level.SEVERE, "[UltraSpoofSpawner] Error spawning fake player: " + name, e);
         return null;
      }
   }

   private Object createServerPlayer(Object worldServer, Object gameProfile) throws Exception {
      Object clientInfo = this.createDefaultClientInformation();

      try {
         Constructor<?> constructor = entityPlayerClass.getConstructor(minecraftServerClass, worldServerClass, gameProfileClass, clientInformationClass);
         return constructor.newInstance(this.minecraftServer, worldServer, gameProfile, clientInfo);
      } catch (NoSuchMethodException var16) {
         LOGGER.fine("[UltraSpoofSpawner] 4-param constructor not found, trying alternatives");

         for(Constructor<?> constructor : entityPlayerClass.getConstructors()) {
            Class<?>[] params = constructor.getParameterTypes();
            if (params.length >= 3) {
               boolean hasMcServer = false;
               boolean hasWorldServer = false;
               boolean hasGameProfile = false;

               for(Class<?> p : params) {
                  if (minecraftServerClass.isAssignableFrom(p)) {
                     hasMcServer = true;
                  }

                  if (worldServerClass.isAssignableFrom(p)) {
                     hasWorldServer = true;
                  }

                  if (gameProfileClass.isAssignableFrom(p)) {
                     hasGameProfile = true;
                  }
               }

               if (hasMcServer && hasWorldServer && hasGameProfile) {
                  constructor.setAccessible(true);
                  Object[] args = new Object[params.length];

                  for(int i = 0; i < params.length; ++i) {
                     if (minecraftServerClass.isAssignableFrom(params[i])) {
                        args[i] = this.minecraftServer;
                     } else if (worldServerClass.isAssignableFrom(params[i])) {
                        args[i] = worldServer;
                     } else if (gameProfileClass.isAssignableFrom(params[i])) {
                        args[i] = gameProfile;
                     } else if (clientInformationClass.isAssignableFrom(params[i])) {
                        args[i] = clientInfo;
                     } else {
                        args[i] = this.getDefaultValue(params[i]);
                     }
                  }

                  return constructor.newInstance(args);
               }
            }
         }

         throw new RuntimeException("Could not find suitable ServerPlayer constructor");
      }
   }

   private Object createDefaultClientInformation() throws Exception {
      for(Method m : clientInformationClass.getMethods()) {
         if (m.getName().equals("a") && m.getParameterCount() == 0 && Modifier.isStatic(m.getModifiers())) {
            return m.invoke((Object)null);
         }
      }

      for(Method m : clientInformationClass.getMethods()) {
         if (m.getName().equals("createDefault")) {
            return m.invoke((Object)null);
         }
      }

      return clientInformationClass.getConstructor().newInstance();
   }

   private void setPlayerPosition(Object serverPlayer, Location location) throws Exception {
      for(String methodName : new String[]{"b", "moveTo", "snapTo", "setPos"}) {
         try {
            Method method = serverPlayer.getClass().getMethod(methodName, Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
            method.invoke(serverPlayer, location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
            return;
         } catch (NoSuchMethodException var9) {
         }
      }

      for(String methodName : new String[]{"setPos", "b"}) {
         try {
            Method method = serverPlayer.getClass().getMethod(methodName, Double.TYPE, Double.TYPE, Double.TYPE);
            method.invoke(serverPlayer, location.getX(), location.getY(), location.getZ());
            return;
         } catch (NoSuchMethodException var8) {
         }
      }

   }

   private CompletableFuture<Boolean> fireAsyncPreLoginEvent(String name, UUID uuid, String ipAddress) {
      return CompletableFuture.supplyAsync(() -> {
         try {
            AsyncPlayerPreLoginEvent event = new AsyncPlayerPreLoginEvent(name, InetAddress.getByName(ipAddress), uuid);
            Bukkit.getPluginManager().callEvent(event);
            return event.getLoginResult() == Result.ALLOWED;
         } catch (UnknownHostException e) {
            LOGGER.warning("[UltraSpoofSpawner] Failed to create InetAddress: " + e.getMessage());
            return true;
         }
      });
   }

   private void completeSpawnOnMainThread(Object serverPlayer, Object gameProfile, String ipAddress, int port) {
      String name = null;

      try {
         name = (String)gameProfileClass.getMethod("getName").invoke(gameProfile);
         Object fakeNetworkManager = this.createFakeNetworkManager(ipAddress, port);
         if (fakeNetworkManager == null) {
            LOGGER.warning("[UltraSpoofSpawner] Failed to create FakeNetworkManager");
            return;
         }

         Object channel = this.getChannelFromConnection(fakeNetworkManager);
         if (channel != null) {
            EVENT_EXECUTORS.register((Channel)channel);
         }

         LOGGER.info("[UltraSpoofSpawner] Created FakeNetworkManager for " + name);

         try {
            UUID playerUuid = (UUID)gameProfileClass.getMethod("getId").invoke(gameProfile);
            this.registerChannelWithPacketEvents(playerUuid, channel);
         } catch (Exception e) {
            LOGGER.warning("[UltraSpoofSpawner] Failed to register channel with PacketEvents: " + e.getMessage());
         }

         Player craftPlayer = (Player)getBukkitEntityMethod.invoke(serverPlayer);
         PlayerLoginEvent loginEvent = new PlayerLoginEvent(craftPlayer, ipAddress, InetAddress.getByName(ipAddress));
         Bukkit.getPluginManager().callEvent(loginEvent);
         if (loginEvent.getResult() != org.bukkit.event.player.PlayerLoginEvent.Result.ALLOWED) {
            LOGGER.warning("[UltraSpoofSpawner] PlayerLoginEvent denied for " + name);
            return;
         }

         Object cookie = this.createCommonListenerCookie(gameProfile);
         if (cookie == null) {
            LOGGER.warning("[UltraSpoofSpawner] Failed to create CommonListenerCookie");
            return;
         }

         LOGGER.info("[UltraSpoofSpawner] Created CommonListenerCookie for " + name);
         if (placeNewPlayerMethod != null) {
            placeNewPlayerMethod.invoke(this.playerList, fakeNetworkManager, serverPlayer, cookie);
            LOGGER.info("[UltraSpoofSpawner] Called placeNewPlayer for " + name);
         } else {
            LOGGER.warning("[UltraSpoofSpawner] placeNewPlayer method not found!");
         }

         this.addToPlayerListMaps(serverPlayer);
         this.broadcastPlayerInfo(serverPlayer);
         String joinMessage = name + " joined the game";
         PlayerJoinEvent joinEvent = new PlayerJoinEvent(craftPlayer, joinMessage);
         Bukkit.getPluginManager().callEvent(joinEvent);
         UUID uuid = (UUID)gameProfileClass.getMethod("getId").invoke(gameProfile);
         this.spawnedPlayers.put(uuid, craftPlayer);
         LOGGER.info("[UltraSpoofSpawner] Successfully spawned: " + name + " (Online players: " + Bukkit.getOnlinePlayers().size() + ")");
      } catch (Exception e) {
         LOGGER.log(Level.SEVERE, "[UltraSpoofSpawner] Error in completeSpawnOnMainThread for " + name, e);
      }

   }

   private Object createFakeNetworkManager(String ipAddress, int port) {
      try {
         Object serverbound = null;

         for(Object constant : packetFlowClass.getEnumConstants()) {
            if (constant.toString().equals("SERVERBOUND")) {
               serverbound = constant;
               break;
            }
         }

         if (serverbound == null && packetFlowClass.getEnumConstants().length >= 2) {
            serverbound = packetFlowClass.getEnumConstants()[1];
         }

         Object connection;
         try {
            Constructor<?> constructor = connectionClass.getConstructor(packetFlowClass);
            connection = constructor.newInstance(serverbound);
         } catch (NoSuchMethodException var8) {
            connection = connectionClass.getConstructor().newInstance();
         }

         Channel fakeChannel = this.createFakeChannel(connection, ipAddress, port);
         this.setChannelField(connection, fakeChannel);
         this.setAddressField(connection, ipAddress, port);
         this.setConnectedField(connection, true);
         this.setQueueField(connection);
         return connection;
      } catch (Exception e) {
         LOGGER.log(Level.WARNING, "[UltraSpoofSpawner] Error creating FakeNetworkManager", e);
         return null;
      }
   }

   private Channel createFakeChannel(Object connection, String ipAddress, int port) {
      try {
         return new FakeChannel(new InetSocketAddress(ipAddress, port));
      } catch (Exception ex) {
         LOGGER.warning("[UltraSpoofSpawner] Could not create fake channel: " + ex.getMessage());
         return null;
      }
   }

   private void setChannelField(Object connection, Channel channel) {
      for(Field f : this.getAllFields(connectionClass)) {
         if (Channel.class.isAssignableFrom(f.getType())) {
            f.setAccessible(true);

            try {
               f.set(connection, channel);
               return;
            } catch (IllegalAccessException var6) {
            }
         }
      }

   }

   private void setAddressField(Object connection, String ipAddress, int port) {
      for(Field f : this.getAllFields(connectionClass)) {
         if (SocketAddress.class.isAssignableFrom(f.getType())) {
            f.setAccessible(true);

            try {
               f.set(connection, new InetSocketAddress(ipAddress, port));
               return;
            } catch (IllegalAccessException var7) {
            }
         }
      }

   }

   private void setConnectedField(Object connection, boolean connected) {
      for(Field f : this.getAllFields(connectionClass)) {
         if (f.getType() == Boolean.TYPE) {
            f.setAccessible(true);

            try {
               f.setBoolean(connection, connected);
            } catch (IllegalAccessException var6) {
            }
         }
      }

   }

   private void setQueueField(Object connection) {
      for(Field f : this.getAllFields(connectionClass)) {
         if (Queue.class.isAssignableFrom(f.getType())) {
            f.setAccessible(true);

            try {
               f.set(connection, Queues.newConcurrentLinkedQueue());
               return;
            } catch (IllegalAccessException var5) {
            }
         }
      }

   }

   private Object getChannelFromConnection(Object connection) {
      for(Field f : this.getAllFields(connectionClass)) {
         if (Channel.class.isAssignableFrom(f.getType())) {
            f.setAccessible(true);

            try {
               return f.get(connection);
            } catch (IllegalAccessException var5) {
            }
         }
      }

      return null;
   }

   private void registerChannelWithPacketEvents(UUID uuid, Object channel) {
      try {
         Class<?> pmClass = Class.forName("com.github.retrooper.packetevents.manager.protocol.ProtocolManager");
         Field channelsField = pmClass.getDeclaredField("CHANNELS");
         channelsField.setAccessible(true);
         Map<UUID, Object> channels = (Map)channelsField.get((Object)null);
         channels.put(uuid, channel);
         LOGGER.info("[UltraSpoofSpawner] Registered channel with PacketEvents for " + String.valueOf(uuid));
      } catch (ClassNotFoundException var6) {
         LOGGER.fine("[UltraSpoofSpawner] PacketEvents not present, skipping channel registration");
      } catch (Exception e) {
         LOGGER.warning("[UltraSpoofSpawner] Failed to register channel with PacketEvents: " + e.getMessage());
      }

   }

   private Object createCommonListenerCookie(Object gameProfile) {
      try {
         for(Method m : commonListenerCookieClass.getMethods()) {
            if ((m.getName().equals("a") || m.getName().equals("create")) && m.getParameterCount() == 2 && gameProfileClass.isAssignableFrom(m.getParameterTypes()[0])) {
               return m.invoke((Object)null, gameProfile, true);
            }
         }

         for(Constructor<?> c : commonListenerCookieClass.getConstructors()) {
            Class<?>[] params = c.getParameterTypes();
            if (params.length >= 1 && gameProfileClass.isAssignableFrom(params[0])) {
               c.setAccessible(true);
               Object[] args = new Object[params.length];
               args[0] = gameProfile;

               for(int i = 1; i < params.length; ++i) {
                  args[i] = this.getDefaultValue(params[i]);
               }

               return c.newInstance(args);
            }
         }

         return null;
      } catch (Exception e) {
         LOGGER.warning("[UltraSpoofSpawner] Error creating CommonListenerCookie: " + e.getMessage());
         return null;
      }
   }

   private void addToPlayerListMaps(Object serverPlayer) {
      try {
         Object profile = getGameProfileMethod.invoke(serverPlayer);
         String name = (String)gameProfileClass.getMethod("getName").invoke(profile);
         UUID uuid = (UUID)gameProfileClass.getMethod("getId").invoke(profile);
         String nameLower = name.toLowerCase(Locale.ROOT);

         for(Field f : this.getAllFields(playerListClass)) {
            if (Map.class.isAssignableFrom(f.getType())) {
               f.setAccessible(true);
               Map<Object, Object> map = (Map)f.get(this.playerList);
               if (map != null && !map.isEmpty()) {
                  Object firstKey = map.keySet().iterator().next();
                  if (firstKey instanceof String) {
                     map.put(nameLower, serverPlayer);
                     LOGGER.fine("[UltraSpoofSpawner] Added to string-keyed map");
                  } else if (firstKey instanceof UUID) {
                     map.put(uuid, serverPlayer);
                     LOGGER.fine("[UltraSpoofSpawner] Added to UUID-keyed map");
                  }
               }
            }

            if (List.class.isAssignableFrom(f.getType())) {
               f.setAccessible(true);
               List<Object> list = (List)f.get(this.playerList);
               if (list != null && !list.contains(serverPlayer)) {
                  Object first = list.isEmpty() ? null : list.get(0);
                  if (first == null || entityPlayerClass.isInstance(first)) {
                     list.add(serverPlayer);
                     LOGGER.fine("[UltraSpoofSpawner] Added to player list");
                  }
               }
            }
         }
      } catch (Exception e) {
         LOGGER.warning("[UltraSpoofSpawner] Error adding to PlayerList maps: " + e.getMessage());
      }

   }

   private void broadcastPlayerInfo(Object newPlayer) {
      try {
         Method createPacketMethod = null;

         for(Method m : playerInfoPacketClass.getMethods()) {
            if ((m.getName().equals("a") || m.getName().contains("create")) && m.getParameterCount() == 1 && List.class.isAssignableFrom(m.getParameterTypes()[0])) {
               createPacketMethod = m;
               break;
            }
         }

         if (createPacketMethod != null) {
            Object packet = createPacketMethod.invoke((Object)null, List.of(newPlayer));

            for(Player online : Bukkit.getOnlinePlayers()) {
               Object craftPlayer = craftPlayerClass.cast(online);
               Object handle = getCraftPlayerHandleMethod.invoke(craftPlayer);

               for(Field f : this.getAllFields(entityPlayerClass)) {
                  if (serverGamePacketListenerClass.isAssignableFrom(f.getType())) {
                     f.setAccessible(true);
                     Object connection = f.get(handle);
                     if (connection != null) {
                        Method sendMethod = connection.getClass().getMethod("send", packetClass);
                        sendMethod.invoke(connection, packet);
                     }
                     break;
                  }
               }
            }
         }

         LOGGER.fine("[UltraSpoofSpawner] Broadcast player info");
      } catch (Exception e) {
         LOGGER.warning("[UltraSpoofSpawner] Error broadcasting player info: " + e.getMessage());
      }

   }

   private Object getDefaultValue(Class<?> type) {
      if (type == Boolean.TYPE) {
         return false;
      } else if (type == Integer.TYPE) {
         return 0;
      } else if (type == Long.TYPE) {
         return 0L;
      } else if (type == Float.TYPE) {
         return 0.0F;
      } else if (type == Double.TYPE) {
         return (double)0.0F;
      } else {
         return type == String.class ? "" : null;
      }
   }

   private List<Field> getAllFields(Class<?> clazz) {
      List<Field> fields;
      for(fields = new ArrayList(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
         for(Field f : clazz.getDeclaredFields()) {
            fields.add(f);
         }
      }

      return fields;
   }

   private String generateFakeIP() {
      int[] firstOctets = new int[]{24, 31, 45, 64, 68, 71, 72, 74, 75, 76, 98, 99, 107, 108, 134, 173, 174, 184};
      int first = firstOctets[ThreadLocalRandom.current().nextInt(firstOctets.length)];
      return first + "." + ThreadLocalRandom.current().nextInt(256) + "." + ThreadLocalRandom.current().nextInt(256) + "." + (1 + ThreadLocalRandom.current().nextInt(254));
   }

   public void removeFakePlayer(UUID uuid) {
      Player player = (Player)this.spawnedPlayers.remove(uuid);
      if (player != null) {
         try {
            player.kickPlayer("Removing fake player");
            LOGGER.info("[UltraSpoofSpawner] Removed fake player: " + player.getName());
         } catch (Exception e) {
            LOGGER.warning("[UltraSpoofSpawner] Error removing fake player: " + e.getMessage());
         }
      }

   }

   public boolean isFakePlayer(UUID uuid) {
      return this.spawnedPlayers.containsKey(uuid);
   }

   public Map<UUID, Player> getSpawnedPlayers() {
      return new ConcurrentHashMap(this.spawnedPlayers);
   }

   public static boolean isAvailable() {
      return initialized;
   }

   public int getFakePlayerCount() {
      return this.spawnedPlayers.size();
   }

   static {
      try {
         LOGGER.info("[UltraSpoofSpawner] Loading NMS classes via reflection...");
         minecraftServerClass = Class.forName("net.minecraft.server.MinecraftServer");
         playerListClass = Class.forName("net.minecraft.server.players.PlayerList");
         worldServerClass = Class.forName("net.minecraft.server.level.WorldServer");
         entityPlayerClass = Class.forName("net.minecraft.server.level.EntityPlayer");
         gameProfileClass = Class.forName("com.mojang.authlib.GameProfile");
         connectionClass = Class.forName("net.minecraft.network.Connection");
         serverGamePacketListenerClass = Class.forName("net.minecraft.server.network.ServerGamePacketListenerImpl");
         commonListenerCookieClass = Class.forName("net.minecraft.server.network.CommonListenerCookie");
         clientInformationClass = Class.forName("net.minecraft.server.level.ClientInformation");
         packetClass = Class.forName("net.minecraft.network.protocol.Packet");
         playerInfoPacketClass = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket");
         packetFlowClass = Class.forName("net.minecraft.network.protocol.PacketFlow");
         String[] versions = new String[]{"v1_21_R7", "v1_21_R6", "v1_21_R5", "v1_21_R4", "v1_21_R3", "v1_21_R2", "v1_21_R1", "v1_20_R4", "v1_20_R3", "v1_20_R2", "v1_20_R1", ""};

         for(String version : versions) {
            try {
               String pkg = version.isEmpty() ? "" : "." + version;
               craftServerClass = Class.forName("org.bukkit.craftbukkit" + pkg + ".CraftServer");
               craftWorldClass = Class.forName("org.bukkit.craftbukkit" + pkg + ".CraftWorld");
               craftPlayerClass = Class.forName("org.bukkit.craftbukkit" + pkg + ".entity.CraftPlayer");
               LOGGER.info("[UltraSpoofSpawner] Found CraftBukkit version: " + (version.isEmpty() ? "modern" : version));
               break;
            } catch (ClassNotFoundException var6) {
            }
         }

         gameProfileConstructor = gameProfileClass.getConstructor(UUID.class, String.class);

         for(Method m : clientInformationClass.getMethods()) {
            if (m.getName().equals("a") && m.getParameterCount() == 0 && Modifier.isStatic(m.getModifiers())) {
               clientInfoDefaultConstructor = null;
               break;
            }
         }

         initialized = true;
         LOGGER.info("[UltraSpoofSpawner] NMS classes loaded successfully - READY!");
      } catch (Throwable e) {
         Logger var10000 = LOGGER;
         String var10001 = e.getClass().getName();
         var10000.warning("[UltraSpoofSpawner] Failed to load NMS classes: " + var10001 + " - " + e.getMessage());
         e.printStackTrace();
      }

   }
}
