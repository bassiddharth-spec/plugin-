package com.glidespoofer.nms;

import java.util.logging.Logger;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

public class NMSPlayerFeatures {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer");
   private final SimpleNMSHandler nmsHandler;

   public NMSPlayerFeatures(SimpleNMSHandler nmsHandler) {
      this.nmsHandler = nmsHandler;
   }

   public void trackBlockMined(Player fakePlayer, String blockType) {
      this.nmsHandler.getStatisticsManager().blockMined(fakePlayer, blockType, 1);
   }

   public void trackDistanceWalked(Player fakePlayer, double blocks) {
      this.nmsHandler.getStatisticsManager().distanceTraveled(fakePlayer, "walk", blocks);
   }

   public void trackMobKill(Player fakePlayer, String mobType) {
      this.nmsHandler.getStatisticsManager().mobKilled(fakePlayer, mobType, 1);
   }

   public String getStatistics(Player fakePlayer) {
      return this.nmsHandler.getStatisticsManager().getStatsDisplay(fakePlayer);
   }

   public int grantAllAdvancements(Player fakePlayer) {
      return this.nmsHandler.getAdvancementManager().grantAllAdvancements(fakePlayer);
   }

   public boolean grantAdvancement(Player fakePlayer, String advancementKey) {
      return this.nmsHandler.getAdvancementManager().grantAdvancement(fakePlayer, advancementKey);
   }

   public int grantStoryAdvancements(Player fakePlayer) {
      return this.nmsHandler.getAdvancementManager().grantStoryAdvancements(fakePlayer);
   }

   public int grantNetherAdvancements(Player fakePlayer) {
      return this.nmsHandler.getAdvancementManager().grantNetherAdvancements(fakePlayer);
   }

   public int grantEndAdvancements(Player fakePlayer) {
      return this.nmsHandler.getAdvancementManager().grantEndAdvancements(fakePlayer);
   }

   public boolean hasAdvancement(Player fakePlayer, String advancementKey) {
      NamespacedKey key = this.parseKey(advancementKey);
      return this.nmsHandler.getAdvancementManager().hasCompletedAdvancement(fakePlayer, key);
   }

   public String getAdvancementDisplay(Player fakePlayer) {
      return this.nmsHandler.getAdvancementManager().getAdvancementDisplay(fakePlayer);
   }

   public void eatFood(Player fakePlayer, String foodType) {
      NMSFoodManager.FoodData foodData = this.nmsHandler.getFoodManager().getFoodData(fakePlayer);
      if (foodData != null) {
         int hunger = this.getHungerValue(foodType);
         float saturation = this.getSaturationValue(foodType);
         this.nmsHandler.getFoodManager().eat(fakePlayer, hunger, saturation);
      }

   }

   public void addExhaustion(Player fakePlayer, float amount) {
      this.nmsHandler.getFoodManager().addExhaustion(fakePlayer, amount);
   }

   public void exhaustFromWalk(Player fakePlayer, double distance) {
      this.nmsHandler.getFoodManager().addExhaustion(fakePlayer, (float)(distance * 0.01));
   }

   public void exhaustFromSprint(Player fakePlayer, double distance) {
      this.nmsHandler.getFoodManager().addExhaustion(fakePlayer, (float)(distance * 0.1));
   }

   public void exhaustFromJump(Player fakePlayer) {
      this.nmsHandler.getFoodManager().addExhaustion(fakePlayer, 0.05F);
   }

   public void exhaustFromCombat(Player fakePlayer) {
      this.nmsHandler.getFoodManager().addExhaustion(fakePlayer, 0.1F);
   }

   public boolean canRegenerate(Player fakePlayer) {
      return this.nmsHandler.getFoodManager().canRegenerate(fakePlayer);
   }

   public String getHungerBar(Player fakePlayer) {
      NMSFoodManager.FoodData foodData = this.nmsHandler.getFoodManager().getFoodData(fakePlayer);
      return foodData != null ? foodData.getHungerBar() : "No food data";
   }

   public int unlockAllRecipes(Player fakePlayer) {
      return this.nmsHandler.getRecipeManager().unlockAllRecipes(fakePlayer);
   }

   public boolean unlockRecipe(Player fakePlayer, String recipeKey) {
      return this.nmsHandler.getRecipeManager().unlockRecipe(fakePlayer, recipeKey);
   }

   public int unlockBasicRecipes(Player fakePlayer) {
      return this.nmsHandler.getRecipeManager().unlockBasicRecipes(fakePlayer);
   }

   public int unlockCraftingRecipes(Player fakePlayer) {
      return this.nmsHandler.getRecipeManager().unlockCraftingRecipes(fakePlayer);
   }

   public String getRecipeDisplay(Player fakePlayer) {
      return this.nmsHandler.getRecipeManager().getRecipeDisplay(fakePlayer);
   }

   public void killPlayer(Player fakePlayer) {
      this.nmsHandler.getDeathManager().killPlayer(fakePlayer, (String)null);
   }

   public void killPlayerBy(Player fakePlayer, String damageSource, Entity killer) {
      this.nmsHandler.getDeathManager().killPlayerByDamage(fakePlayer, damageSource, killer);
   }

   public void killByFire(Player fakePlayer) {
      this.killPlayerBy(fakePlayer, "fire", (Entity)null);
   }

   public void killByLava(Player fakePlayer) {
      this.killPlayerBy(fakePlayer, "lava", (Entity)null);
   }

   public void killByDrowning(Player fakePlayer) {
      this.killPlayerBy(fakePlayer, "drown", (Entity)null);
   }

   public void killByStarvation(Player fakePlayer) {
      this.killPlayerBy(fakePlayer, "starve", (Entity)null);
   }

   public void killByFall(Player fakePlayer) {
      this.killPlayerBy(fakePlayer, "fall", (Entity)null);
   }

   public void killByPlayer(Player fakePlayer, Player killer) {
      this.killPlayerBy(fakePlayer, "attack", killer);
   }

   public void respawnPlayer(Player fakePlayer, Location spawnLoc) {
      this.nmsHandler.getDeathManager().respawnPlayer(fakePlayer, spawnLoc);
   }

   public void respawnPlayer(Player fakePlayer) {
      this.respawnPlayer(fakePlayer, fakePlayer.getWorld().getSpawnLocation());
   }

   public void setDropItemsOnDeath(boolean drop) {
      this.nmsHandler.getDeathManager().setDropItems(drop);
   }

   public void setDropXpOnDeath(boolean drop) {
      this.nmsHandler.getDeathManager().setDropXp(drop);
   }

   public void setKeepInventoryOnDeath(boolean keep) {
      this.nmsHandler.getDeathManager().setKeepInventory(keep);
   }

   private NamespacedKey parseKey(String key) {
      if (key == null) {
         return null;
      } else {
         String namespace = "minecraft";
         String value = key;
         if (key.contains(":")) {
            String[] parts = key.split(":", 2);
            namespace = parts[0];
            value = parts[1];
         }

         return new NamespacedKey(namespace, value);
      }
   }

   private int getHungerValue(String foodType) {
      String type = foodType.toLowerCase();
      if (type.contains("apple") && !type.contains("golden")) {
         return 4;
      } else if (type.contains("golden_apple")) {
         return 4;
      } else if (type.contains("bread")) {
         return 5;
      } else if (!type.contains("cooked_meat") && !type.contains("steak")) {
         if (type.contains("cooked_chicken")) {
            return 6;
         } else if (!type.contains("cooked_fish") && !type.contains("salmon")) {
            if (type.contains("cooked_cod")) {
               return 5;
            } else if (type.contains("carrot")) {
               return 3;
            } else if (type.contains("baked_potato")) {
               return 5;
            } else if (type.contains("potato") && !type.contains("baked")) {
               return 1;
            } else if (type.contains("cookie")) {
               return 2;
            } else if (type.contains("melon")) {
               return 2;
            } else if (!type.contains("sweet_berries") && !type.contains("glow_berries")) {
               if (type.contains("honey_bottle")) {
                  return 6;
               } else if (type.contains("pumpkin_pie")) {
                  return 8;
               } else if (!type.contains("rabbit_stew") && !type.contains("mushroom_stew") && !type.contains("beetroot_soup") && !type.contains("suspicious_stew")) {
                  if (type.contains("cake")) {
                     return 14;
                  } else if (type.contains("chorus")) {
                     return 4;
                  } else if (type.contains("kelp")) {
                     return 1;
                  } else if (type.contains("rotten_flesh")) {
                     return 4;
                  } else {
                     return type.contains("spider_eye") ? 2 : 0;
                  }
               } else {
                  return 6;
               }
            } else {
               return 2;
            }
         } else {
            return 6;
         }
      } else {
         return 8;
      }
   }

   private float getSaturationValue(String foodType) {
      String type = foodType.toLowerCase();
      if (type.contains("apple") && !type.contains("golden")) {
         return 2.4F;
      } else if (type.contains("golden_apple")) {
         return 9.6F;
      } else if (type.contains("bread")) {
         return 6.0F;
      } else if (!type.contains("cooked_meat") && !type.contains("steak")) {
         if (type.contains("cooked_chicken")) {
            return 7.2F;
         } else if (!type.contains("cooked_fish") && !type.contains("salmon")) {
            if (type.contains("cooked_cod")) {
               return 6.0F;
            } else if (type.contains("carrot")) {
               return 3.6F;
            } else if (type.contains("baked_potato")) {
               return 6.0F;
            } else if (type.contains("cookie")) {
               return 0.4F;
            } else if (type.contains("melon")) {
               return 1.2F;
            } else if (!type.contains("sweet_berries") && !type.contains("glow_berries")) {
               if (type.contains("honey_bottle")) {
                  return 1.2F;
               } else if (type.contains("pumpkin_pie")) {
                  return 4.8F;
               } else if (type.contains("rabbit_stew")) {
                  return 12.0F;
               } else if (type.contains("mushroom_stew")) {
                  return 7.2F;
               } else if (type.contains("beetroot_soup")) {
                  return 7.2F;
               } else if (type.contains("suspicious_stew")) {
                  return 7.2F;
               } else if (type.contains("cake")) {
                  return 0.4F;
               } else if (type.contains("chorus")) {
                  return 2.4F;
               } else if (type.contains("kelp")) {
                  return 0.6F;
               } else if (type.contains("rotten_flesh")) {
                  return 0.8F;
               } else {
                  return type.contains("spider_eye") ? 3.2F : 0.0F;
               }
            } else {
               return 0.4F;
            }
         } else {
            return 9.6F;
         }
      } else {
         return 12.8F;
      }
   }

   public void setupRealisticPlayer(Player fakePlayer) {
      this.unlockBasicRecipes(fakePlayer);
      this.grantAdvancement(fakePlayer, "minecraft:story/root");
      this.grantAdvancement(fakePlayer, "minecraft:adventure/root");
      this.grantAdvancement(fakePlayer, "minecraft:husbandry/root");
      this.nmsHandler.getFoodManager().setFoodLevel(fakePlayer, 20);
      this.nmsHandler.getFoodManager().setSaturation(fakePlayer, 5.0F);
      LOGGER.info("[NMSFeatures] Set up realistic player " + fakePlayer.getName());
   }

   public void setupExperiencedPlayer(Player fakePlayer) {
      this.grantAllAdvancements(fakePlayer);
      this.unlockAllRecipes(fakePlayer);
      this.nmsHandler.getStatisticsManager().setStat(fakePlayer, "playOneMinute", "", 72000L);
      this.nmsHandler.getStatisticsManager().setStat(fakePlayer, "walkOneCm", "walking", 500000L);
      this.nmsHandler.getStatisticsManager().setStat(fakePlayer, "jump", "", 1000L);
      this.nmsHandler.getStatisticsManager().incrementDeaths(fakePlayer);
      LOGGER.info("[NMSFeatures] Set up experienced player " + fakePlayer.getName());
   }

   public String getPlayerSummary(Player fakePlayer) {
      StringBuilder sb = new StringBuilder();
      sb.append("\n§e===== Fake Player Summary: ").append(fakePlayer.getName()).append(" =====\n");
      sb.append("§7Statistics:\n").append(this.getStatistics(fakePlayer)).append("\n");
      sb.append("§7Advancements:\n").append(this.getAdvancementDisplay(fakePlayer)).append("\n");
      sb.append("§7Recipes:\n").append(this.getRecipeDisplay(fakePlayer)).append("\n");
      sb.append("§7Hunger:\n").append(this.getHungerBar(fakePlayer)).append("\n");
      sb.append("§e====================================================\n");
      return sb.toString();
   }
}
