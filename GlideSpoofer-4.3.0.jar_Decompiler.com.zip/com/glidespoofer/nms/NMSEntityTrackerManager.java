package com.glidespoofer.nms;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

public class NMSEntityTrackerManager {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-EntityTracker");
   private static final double PLAYER_WIDTH = 0.6;
   private static final double PLAYER_HEIGHT = 1.8;
   private static boolean is1_20Plus = false;
   private static boolean isFolia = false;
   private static Method trackMethod;
   private static Method untrackMethod;

   private static void initializeReflection() {
      try {
         String mcVersion = getMinecraftVersion();
         is1_20Plus = compareVersions(mcVersion, "1.20") >= 0;

         try {
            Class.forName("io.papermc.paper.threadedregions.RegionizedServer");
            isFolia = true;
         } catch (ClassNotFoundException var31) {
            isFolia = false;
         }

         LOGGER.info("[NMSEntityTracker] Version: " + mcVersion + ", Folia: " + isFolia);
         if (is1_20Plus) {
            try {
               Class<?> chunkMapClass = Class.forName("net.minecraft.server.level.ChunkMap");
               trackMethod = chunkMapClass.getDeclaredMethod("a", Class.forName("net.minecraft.world.entity.Entity"));
               trackMethod.setAccessible(true);
               untrackMethod = chunkMapClass.getDeclaredMethod("b", Class.forName("net.minecraft.world.entity.Entity"));
               untrackMethod.setAccessible(true);
            } catch (Exception var2) {
               LOGGER.warning("[NMSEntityTracker] Could not find track/untrack methods");
            }
         }

         LOGGER.info("[NMSEntityTracker] Reflection initialized");
      } catch (Exception var4) {
         LOGGER.log(Level.SEVERE, "[NMSEntityTracker] Failed to initialize reflection", var4);
      }

   }

   private static String getMinecraftVersion() {
      try {
         Method method = Bukkit.class.getMethod("getMinecraftVersion");
         return (String)method.invoke((Object)null);
      } catch (Exception var1) {
         return "1.8.8";
      }
   }

   private static int compareVersions(String v1, String v2) {
      String[] p1 = v1.split("\\.");
      String[] p2 = v2.split("\\.");

      for(int i = 0; i < Math.max(p1.length, p2.length); ++i) {
         int n1 = i < p1.length ? Integer.parseInt(p1[i]) : 0;
         int n2 = i < p2.length ? Integer.parseInt(p2[i]) : 0;
         if (n1 != n2) {
            return n1 - n2;
         }
      }

      return 0;
   }

   public static boolean registerEntity(Object nmsEntity) {
      if (nmsEntity == null) {
         return false;
      } else {
         try {
            Object level = getEntityLevel(nmsEntity);
            if (level == null) {
               return false;
            }

            Object tracker = getEntityTracker(level);
            if (tracker == null) {
               return false;
            }

            if (trackMethod != null) {
               trackMethod.invoke(tracker, nmsEntity);
               LOGGER.info("[NMSEntityTracker] Registered entity: " + nmsEntity.getClass().getSimpleName());
               return true;
            }
         } catch (Exception var3) {
            LOGGER.log(Level.WARNING, "[NMSEntityTracker] Failed to register entity", var3);
         }

         return false;
      }
   }

   public static boolean unregisterEntity(Object nmsEntity) {
      if (nmsEntity == null) {
         return false;
      } else {
         try {
            Object level = getEntityLevel(nmsEntity);
            if (level == null) {
               return false;
            }

            Object tracker = getEntityTracker(level);
            if (tracker == null) {
               return false;
            }

            if (untrackMethod != null) {
               untrackMethod.invoke(tracker, nmsEntity);
               LOGGER.info("[NMSEntityTracker] Unregistered entity");
               return true;
            }
         } catch (Exception var3) {
            LOGGER.log(Level.WARNING, "[NMSEntityTracker] Failed to unregister entity", var3);
         }

         return false;
      }
   }

   private static Object getEntityLevel(Object nmsEntity) {
      try {
         Method levelMethod = nmsEntity.getClass().getMethod("level");
         return levelMethod.invoke(nmsEntity);
      } catch (Exception var4) {
         try {
            Method worldMethod = nmsEntity.getClass().getMethod("getWorld");
            return worldMethod.invoke(nmsEntity);
         } catch (Exception var3) {
            return null;
         }
      }
   }

   private static Object getEntityTracker(Object level) {
      try {
         Method getChunkMap = level.getClass().getMethod("getChunkMap");
         return getChunkMap.invoke(level);
      } catch (Exception var4) {
         try {
            Method getTracker = level.getClass().getMethod("getTracker");
            return getTracker.invoke(level);
         } catch (Exception var3) {
            return null;
         }
      }
   }

   public static boolean rayHitCheck(Location start, Location end, Player fakePlayer) {
      if (fakePlayer != null && fakePlayer.isOnline()) {
         Location fakeLoc = fakePlayer.getLocation();
         if (fakeLoc == null) {
            return false;
         } else {
            AABB box = NMSEntityTrackerManager.AABB.ofPlayer(fakeLoc);
            Vector dir = end.toVector().subtract(start.toVector());
            return box.rayIntersects(start.toVector(), dir);
         }
      } else {
         return false;
      }
   }

   public static Location getHitLocation(Location start, Location end, Player fakePlayer) {
      if (fakePlayer != null && fakePlayer.isOnline()) {
         Location fakeLoc = fakePlayer.getLocation();
         if (fakeLoc == null) {
            return null;
         } else {
            AABB box = NMSEntityTrackerManager.AABB.ofPlayer(fakeLoc);
            Vector dir = end.toVector().subtract(start.toVector());
            return box.rayIntersects(start.toVector(), dir) ? fakeLoc.clone() : null;
         }
      } else {
         return null;
      }
   }

   public static HitResult preciseHitCheck(Player attacker, Player fakePlayer, double range) {
      if (attacker != null && fakePlayer != null) {
         Location attackerLoc = attacker.getEyeLocation();
         Location fakeLoc = fakePlayer.getLocation();
         if (attackerLoc.distance(fakeLoc) > range) {
            return null;
         } else {
            Vector dir = attackerLoc.getDirection().clone();
            AABB box = NMSEntityTrackerManager.AABB.ofPlayer(fakeLoc);
            if (box.rayIntersects(attackerLoc.toVector(), dir)) {
               Vector hitDir = fakeLoc.toVector().subtract(attackerLoc.toVector()).normalize();
               return new HitResult(fakeLoc.clone(), hitDir, (BlockFace)null);
            } else {
               return null;
            }
         }
      } else {
         return null;
      }
   }

   public static boolean distanceHitCheck(Location attackerLoc, Location fakeLoc, double maxDistance) {
      if (attackerLoc != null && fakeLoc != null) {
         double dx = attackerLoc.getX() - fakeLoc.getX();
         double dy = attackerLoc.getY() - fakeLoc.getY();
         double dz = attackerLoc.getZ() - fakeLoc.getZ();
         double horizontalDist = Math.sqrt(dx * dx + dz * dz);
         if (horizontalDist > 0.3 + maxDistance) {
            return false;
         } else {
            double verticalDist = Math.abs(dy - 1.62);
            return verticalDist <= 0.9;
         }
      } else {
         return false;
      }
   }

   public static boolean checkCollision(Player realPlayer, Player fakePlayer) {
      if (realPlayer != null && fakePlayer != null) {
         if (!realPlayer.getWorld().equals(fakePlayer.getWorld())) {
            return false;
         } else {
            Location realLoc = realPlayer.getLocation();
            Location fakeLoc = fakePlayer.getLocation();
            double dx = Math.abs(realLoc.getX() - fakeLoc.getX());
            double dz = Math.abs(realLoc.getZ() - fakeLoc.getZ());
            double dy = Math.abs(realLoc.getY() - fakeLoc.getY());
            return dx < 0.6 && dz < 0.6 && dy < 1.8;
         }
      } else {
         return false;
      }
   }

   public static Set<Player> getTrackingPlayers(Player entity) {
      Set<Player> viewers = new HashSet();
      if (entity != null && entity.isOnline()) {
         Location loc = entity.getLocation();
         if (loc == null) {
            return viewers;
         } else {
            double range = (double)64.0F;

            for(Player player : Bukkit.getOnlinePlayers()) {
               if (player.getWorld().equals(entity.getWorld()) && player.getLocation().distance(loc) <= range) {
                  viewers.add(player);
               }
            }

            return viewers;
         }
      } else {
         return viewers;
      }
   }

   public static boolean canSee(Player viewer, Player entity) {
      if (viewer != null && entity != null) {
         if (!entity.isOnline()) {
            return false;
         } else if (!viewer.getWorld().equals(entity.getWorld())) {
            return false;
         } else {
            double distance = viewer.getLocation().distance(entity.getLocation());
            return distance <= (double)64.0F;
         }
      } else {
         return false;
      }
   }

   public static int getEntityId(Object nmsEntity) {
      if (nmsEntity == null) {
         return -1;
      } else {
         try {
            Field idField = nmsEntity.getClass().getDeclaredField("id");
            idField.setAccessible(true);
            return idField.getInt(nmsEntity);
         } catch (Exception var4) {
            try {
               Method getIdMethod = nmsEntity.getClass().getMethod("getId");
               return (Integer)getIdMethod.invoke(nmsEntity);
            } catch (Exception var3) {
               return -1;
            }
         }
      }
   }

   public static Object getNMSEntity(Player player) {
      if (player == null) {
         return null;
      } else {
         try {
            Method getHandle = player.getClass().getMethod("getHandle");
            return getHandle.invoke(player);
         } catch (Exception var2) {
            LOGGER.log(Level.WARNING, "[NMSEntityTracker] Failed to get NMS entity", var2);
            return null;
         }
      }
   }

   static {
      initializeReflection();
   }

   private static class AABB {
      double minX;
      double minY;
      double minZ;
      double maxX;
      double maxY;
      double maxZ;

      AABB(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
         this.minX = minX;
         this.minY = minY;
         this.minZ = minZ;
         this.maxX = maxX;
         this.maxY = maxY;
         this.maxZ = maxZ;
      }

      static AABB ofPlayer(Location loc) {
         return new AABB(loc.getX() - 0.3, loc.getY(), loc.getZ() - 0.3, loc.getX() + 0.3, loc.getY() + 1.8, loc.getZ() + 0.3);
      }

      boolean rayIntersects(Vector origin, Vector direction) {
         double tMin = Double.NEGATIVE_INFINITY;
         double tMax = Double.POSITIVE_INFINITY;
         if (Math.abs(direction.getX()) < 1.0E-9) {
            if (origin.getX() < this.minX || origin.getX() > this.maxX) {
               return false;
            }
         } else {
            double t1 = (this.minX - origin.getX()) / direction.getX();
            double t2 = (this.maxX - origin.getX()) / direction.getX();
            if (t1 > t2) {
               double temp = t1;
               t1 = t2;
               t2 = temp;
            }

            if (t1 > tMin) {
               tMin = t1;
            }

            if (t2 < tMax) {
               tMax = t2;
            }

            if (tMin > tMax) {
               return false;
            }
         }

         if (Math.abs(direction.getY()) < 1.0E-9) {
            if (origin.getY() < this.minY || origin.getY() > this.maxY) {
               return false;
            }
         } else {
            double t1x = (this.minY - origin.getY()) / direction.getY();
            double t2x = (this.maxY - origin.getY()) / direction.getY();
            if (t1x > t2x) {
               double temp = t1x;
               t1x = t2x;
               t2x = temp;
            }

            if (t1x > tMin) {
               tMin = t1x;
            }

            if (t2x < tMax) {
               tMax = t2x;
            }

            if (tMin > tMax) {
               return false;
            }
         }

         if (Math.abs(direction.getZ()) < 1.0E-9) {
            if (origin.getZ() < this.minZ || origin.getZ() > this.maxZ) {
               return false;
            }
         } else {
            double t1xx = (this.minZ - origin.getZ()) / direction.getZ();
            double t2xx = (this.maxZ - origin.getZ()) / direction.getZ();
            if (t1xx > t2xx) {
               double temp = t1xx;
               t1xx = t2xx;
               t2xx = temp;
            }

            if (t1xx > tMin) {
               tMin = t1xx;
            }

            if (t2xx < tMax) {
               tMax = t2xx;
            }

            if (tMin > tMax) {
               return false;
            }
         }

         return tMin >= (double)0.0F && tMax >= (double)0.0F;
      }

      Location rayTrace(Vector origin, Vector direction) {
         return this.rayIntersects(origin, direction) ? new Location((World)null, (this.minX + this.maxX) / (double)2.0F, (this.minY + this.maxY) / (double)2.0F, (this.minZ + this.maxZ) / (double)2.0F) : null;
      }
   }

   public static class HitResult {
      private final Location hitLocation;
      private final Vector hitDirection;
      private final BlockFace hitFace;

      public HitResult(Location hitLocation, Vector hitDirection, BlockFace hitFace) {
         this.hitLocation = hitLocation;
         this.hitDirection = hitDirection;
         this.hitFace = hitFace;
      }

      public Location getHitLocation() {
         return this.hitLocation;
      }

      public Vector getHitDirection() {
         return this.hitDirection;
      }

      public BlockFace getHitFace() {
         return this.hitFace;
      }

      public boolean hasHit() {
         return this.hitLocation != null;
      }
   }
}
