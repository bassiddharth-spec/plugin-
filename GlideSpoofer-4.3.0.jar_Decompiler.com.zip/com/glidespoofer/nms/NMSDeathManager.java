package com.glidespoofer.nms;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ExperienceOrb;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class NMSDeathManager {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer");
   private final Map<UUID, DeathInfo> deathInfoMap = new ConcurrentHashMap();
   private final Map<UUID, Long> deathTimeMap = new ConcurrentHashMap();
   private boolean dropItems = true;
   private boolean dropXp = true;
   private boolean keepInventory = false;
   private boolean keepLevel = false;
   private boolean broadcastDeathMessages = true;
   private final boolean useModernNMS;
   private final String nmsPackage;
   private Method dieMethod;
   private Method dropAllMethod;
   private Method dropEquipmentMethod;
   private Method getInventoryMethod;
   private Method createExperienceOrbMethod;
   private Field xpField;
   private Class<?> damageSourceClass;
   private Class<?> entityClass;
   private Class<?> entityPlayerClass;

   public NMSDeathManager(boolean useModernNMS, String nmsPackage) {
      this.useModernNMS = useModernNMS;
      this.nmsPackage = nmsPackage;
      this.initializeReflection();
   }

   private void initializeReflection() {
      try {
         if (this.useModernNMS) {
            this.damageSourceClass = Class.forName("net.minecraft.world.damagesource.DamageSource");
            this.entityClass = Class.forName("net.minecraft.world.entity.Entity");
            this.entityPlayerClass = Class.forName("net.minecraft.server.level.ServerPlayer");
         } else {
            this.damageSourceClass = Class.forName(this.nmsPackage + ".DamageSource");
            this.entityClass = Class.forName(this.nmsPackage + ".Entity");
            this.entityPlayerClass = Class.forName(this.nmsPackage + ".EntityPlayer");
         }

         try {
            this.dieMethod = this.entityClass.getMethod("die", this.damageSourceClass);
            LOGGER.info("[NMSDeath] Found die() method");
         } catch (NoSuchMethodException var8) {
            for(Method m : this.entityClass.getDeclaredMethods()) {
               if (m.getName().equals("die") && m.getParameterCount() == 1) {
                  this.dieMethod = m;
                  this.dieMethod.setAccessible(true);
                  break;
               }
            }
         }

         try {
            this.dropAllMethod = this.entityPlayerClass.getMethod("dropAll");
         } catch (NoSuchMethodException var7) {
            for(Method mx : this.entityPlayerClass.getDeclaredMethods()) {
               if (mx.getName().toLowerCase().contains("drop") && mx.getName().toLowerCase().contains("all")) {
                  this.dropAllMethod = mx;
                  this.dropAllMethod.setAccessible(true);
                  break;
               }
            }
         }

         try {
            this.dropEquipmentMethod = this.entityClass.getMethod("dropEquipment");
         } catch (NoSuchMethodException var6) {
            for(Method mxx : this.entityClass.getDeclaredMethods()) {
               if (mxx.getName().toLowerCase().contains("drop") && mxx.getName().toLowerCase().contains("equip")) {
                  this.dropEquipmentMethod = mxx;
                  this.dropEquipmentMethod.setAccessible(true);
                  break;
               }
            }
         }

         LOGGER.info("[NMSDeath] Death manager initialized");
      } catch (Exception var9) {
         LOGGER.warning("[NMSDeath] Failed to initialize reflection: " + var9.getMessage());
      }

   }

   public List<ItemStack> killPlayer(Player player, String deathMessage) {
      if (player == null) {
         return new ArrayList();
      } else {
         Location loc = player.getLocation();
         UUID uuid = player.getUniqueId();
         List<ItemStack> droppedItems = new ArrayList();
         if (this.dropItems && !this.keepInventory) {
            droppedItems.addAll(Arrays.asList(player.getInventory().getContents()));
            droppedItems.addAll(Arrays.asList(player.getInventory().getArmorContents()));
            ItemStack offhand = player.getInventory().getItemInOffHand();
            if (offhand != null && !offhand.getType().isAir()) {
               droppedItems.add(offhand);
            }
         }

         if (!this.keepInventory) {
            player.getInventory().clear();
         }

         player.setHealth((double)0.0F);
         this.playDeathSound(loc);
         if (this.broadcastDeathMessages) {
            String message = deathMessage != null ? deathMessage : this.getDefaultDeathMessage(player);
            Bukkit.getOnlinePlayers().forEach((p) -> p.sendMessage(message));
         }

         if (this.dropXp && !this.keepLevel) {
            this.dropExperienceOrbs(loc, this.getTotalExperience(player));
         }

         if (!this.keepLevel) {
            player.setTotalExperience(0);
            player.setLevel(0);
            player.setExp(0.0F);
         }

         DeathInfo deathInfo = new DeathInfo();
         deathInfo.player = player;
         deathInfo.location = loc;
         deathInfo.deathTime = System.currentTimeMillis();
         deathInfo.deathMessage = deathMessage;
         deathInfo.droppedItems = droppedItems;
         this.deathInfoMap.put(uuid, deathInfo);
         this.deathTimeMap.put(uuid, deathInfo.deathTime);
         Logger var10000 = LOGGER;
         String var10001 = player.getName();
         var10000.info("[NMSDeath] Killed " + var10001 + " at " + String.valueOf(loc));
         return droppedItems;
      }
   }

   public List<ItemStack> killPlayerByDamage(Player player, String damageSource, Entity killer) {
      String deathMessage = this.getDamageDeathMessage(player, damageSource, killer);
      return this.killPlayer(player, deathMessage);
   }

   public void dropItems(Location loc, Collection<ItemStack> items) {
      if (loc != null && items != null) {
         for(ItemStack item : items) {
            if (item != null && !item.getType().isAir()) {
               loc.getWorld().dropItemNaturally(loc, item);
            }
         }
      }

   }

   public void dropExperienceOrbs(Location loc, int totalXp) {
      int orbSize;
      if (loc != null && totalXp > 0) {
         for(int remaining = totalXp; remaining > 0; remaining -= orbSize) {
            orbSize = Math.min(remaining, 10 + (int)(Math.random() * (double)10.0F));
            ((ExperienceOrb)loc.getWorld().spawn(loc, ExperienceOrb.class)).setExperience(orbSize);
         }
      }

   }

   private void playDeathSound(Location loc) {
      if (loc != null) {
         try {
            try {
               Sound sound = Sound.valueOf("ENTITY_PLAYER_DEATH");
               loc.getWorld().playSound(loc, sound, SoundCategory.PLAYERS, 1.0F, 1.0F);
            } catch (IllegalArgumentException var3) {
               loc.getWorld().playSound(loc, Sound.ENTITY_PLAYER_HURT, SoundCategory.PLAYERS, 1.0F, 0.5F);
            }
         } catch (Exception var4) {
         }
      }

   }

   private String getDefaultDeathMessage(Player player) {
      List<String> messages = Arrays.asList("§e" + player.getName() + " died", "§e" + player.getName() + " fell out of the world", "§e" + player.getName() + " went up in flames", "§e" + player.getName() + " was pricked to death", "§e" + player.getName() + " drowned", "§e" + player.getName() + " starved to death", "§e" + player.getName() + " hit the ground too hard", "§e" + player.getName() + " blew up");
      return (String)messages.get((int)(Math.random() * (double)messages.size()));
   }

   private String getDamageDeathMessage(Player player, String source, Entity killer) {
      String name = player.getName();
      String killerName = killer != null ? killer.getName() : "Unknown";
      switch (source.toLowerCase()) {
         case "fire":
         case "lava":
            return "§e" + name + " went up in flames";
         case "drown":
            return "§e" + name + " drowned";
         case "starve":
            return "§e" + name + " starved to death";
         case "fall":
            return "§e" + name + " hit the ground too hard";
         case "attack":
         case "player":
            if (killer instanceof Player) {
               return "§e" + name + " was slain by " + killerName;
            }

            return "§e" + name + " was killed by " + killerName;
         case "void":
            return "§e" + name + " fell out of the world";
         case "explosion":
            return "§e" + name + " blew up";
         case "suffocate":
            return "§e" + name + " suffocated in a wall";
         case "poison":
         case "magic":
            return "§e" + name + " withered away";
         case "thorns":
            return "§e" + name + " was killed trying to hurt " + killerName;
         case "firework":
            return "§e" + name + " went off with a bang";
         case "falling_block":
            return "§e" + name + " was squashed by a falling anvil";
         case "temperature":
            return "§e" + name + " froze to death";
         case "sonic_boom":
            return "§e" + name + " was shattered by sound";
         case "generic":
            return "§e" + name + " died";
         default:
            return "§e" + name + " died";
      }
   }

   private int getTotalExperience(Player player) {
      int level = player.getLevel();
      float exp = player.getExp();
      int total = 0;
      if (level <= 16) {
         total = level * level + 6 * level;
      } else if (level <= 31) {
         total = (int)((double)2.5F * (double)level * (double)level - (double)40.5F * (double)level + (double)360.0F);
      } else {
         total = (int)((double)4.5F * (double)level * (double)level - (double)162.5F * (double)level + (double)2220.0F);
      }

      int nextLevelXp;
      if (level <= 16) {
         nextLevelXp = 2 * level + 7;
      } else if (level <= 31) {
         nextLevelXp = 5 * level - 38;
      } else {
         nextLevelXp = 9 * level - 158;
      }

      return total + (int)(exp * (float)nextLevelXp);
   }

   public DeathInfo getDeathInfo(Player player) {
      return player == null ? null : (DeathInfo)this.deathInfoMap.get(player.getUniqueId());
   }

   public long getTimeSinceDeath(Player player) {
      if (player == null) {
         return -1L;
      } else {
         Long deathTime = (Long)this.deathTimeMap.get(player.getUniqueId());
         return deathTime == null ? -1L : System.currentTimeMillis() - deathTime;
      }
   }

   public boolean isDead(Player player) {
      return player != null && player.getHealth() <= (double)0.0F;
   }

   public void respawnPlayer(Player player, Location spawnLoc) {
      if (player != null) {
         Location loc = spawnLoc != null ? spawnLoc : player.getWorld().getSpawnLocation();
         double maxHealth = (double)20.0F;

         try {
            AttributeInstance attr = player.getAttribute(Attribute.MAX_HEALTH);
            if (attr != null) {
               maxHealth = attr.getValue();
            }
         } catch (Exception var8) {
         }

         player.setHealth(maxHealth);
         player.setFoodLevel(20);
         player.setSaturation(5.0F);
         player.teleport(loc);

         try {
            loc.getWorld().playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.0F, 1.0F);
         } catch (Exception var7) {
         }

         UUID uuid = player.getUniqueId();
         this.deathInfoMap.remove(uuid);
         this.deathTimeMap.remove(uuid);
         Logger var10000 = LOGGER;
         String var10001 = player.getName();
         var10000.info("[NMSDeath] Respawned " + var10001 + " at " + String.valueOf(loc));
      }

   }

   public void setDropItems(boolean dropItems) {
      this.dropItems = dropItems;
   }

   public void setDropXp(boolean dropXp) {
      this.dropXp = dropXp;
   }

   public void setKeepInventory(boolean keepInventory) {
      this.keepInventory = keepInventory;
   }

   public void setKeepLevel(boolean keepLevel) {
      this.keepLevel = keepLevel;
   }

   public void setBroadcastDeathMessages(boolean broadcast) {
      this.broadcastDeathMessages = broadcast;
   }

   public void removeDeathInfo(Player player) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         this.deathInfoMap.remove(uuid);
         this.deathTimeMap.remove(uuid);
      }

   }

   public void playDeathAnimation(Player player) {
      if (player != null) {
         Location loc = player.getLocation();
         this.playDeathSound(loc);
      }

   }

   public static class DamageSources {
      public static final String FIRE = "fire";
      public static final String LAVA = "lava";
      public static final String DROWN = "drown";
      public static final String STARVE = "starve";
      public static final String FALL = "fall";
      public static final String ATTACK = "attack";
      public static final String VOID = "void";
      public static final String EXPLOSION = "explosion";
      public static final String SUFFOCATE = "suffocate";
      public static final String POISON = "poison";
      public static final String MAGIC = "magic";
      public static final String THORNS = "thorns";
      public static final String FIREWORK = "firework";
      public static final String FALLING_BLOCK = "falling_block";
      public static final String TEMPERATURE = "temperature";
      public static final String SONIC_BOOM = "sonic_boom";
      public static final String GENERIC = "generic";
   }

   public static class DeathInfo {
      public Player player;
      public Location location;
      public long deathTime;
      public String deathMessage;
      public List<ItemStack> droppedItems = new ArrayList();

      public List<ItemStack> getDroppedItems() {
         return new ArrayList(this.droppedItems);
      }

      public long getTimeSinceDeath() {
         return System.currentTimeMillis() - this.deathTime;
      }

      public boolean hasDroppedItems() {
         return !this.droppedItems.isEmpty();
      }
   }
}
