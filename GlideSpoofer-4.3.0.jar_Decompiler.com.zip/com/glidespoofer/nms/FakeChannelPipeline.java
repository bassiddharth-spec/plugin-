package com.glidespoofer.nms;

import io.netty.buffer.ByteBufAllocator;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandler;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelOutboundHandlerAdapter;
import io.netty.channel.ChannelOutboundInvoker;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.ChannelProgressivePromise;
import io.netty.channel.ChannelPromise;
import io.netty.channel.DefaultChannelPromise;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.util.Attribute;
import io.netty.util.AttributeKey;
import io.netty.util.ReferenceCountUtil;
import io.netty.util.concurrent.EventExecutor;
import io.netty.util.concurrent.EventExecutorGroup;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

public class FakeChannelPipeline implements ChannelPipeline {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer");
   private final Channel channel;
   private final Map<String, ChannelHandler> handlers = new ConcurrentHashMap();
   private final List<FakeChannelHandlerContext> contexts = new ArrayList();
   private boolean initializing = true;

   public FakeChannelPipeline(Channel channel) {
      this.channel = channel;
      this.addLastInternal("timeout", new ChannelInboundHandlerAdapter());
      this.addLastInternal("encoder", new ChannelOutboundHandlerAdapter() {
         public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {
            ReferenceCountUtil.release(msg);
            promise.setSuccess();
         }
      });
      this.addLastInternal("decoder", new ChannelInboundHandlerAdapter() {
         public void channelRead(ChannelHandlerContext ctx, Object msg) {
            ReferenceCountUtil.release(msg);
         }
      });
      this.addLastInternal("prepender", new ChannelOutboundHandlerAdapter());
      this.addLastInternal("splitter", new ChannelInboundHandlerAdapter());
      this.initializing = false;
      LOGGER.fine("[FakeChannelPipeline] Initialized with default handlers: timeout, encoder, decoder, prepender, splitter");
   }

   private void addLastInternal(String name, ChannelHandler handler) {
      this.handlers.put(name, handler);
      this.contexts.add(new FakeChannelHandlerContext(this.channel, name, handler));
   }

   public ChannelPipeline addFirst(String name, ChannelHandler handler) {
      if (handler instanceof ReadTimeoutHandler) {
         return this;
      } else {
         this.handlers.put(name, handler);
         FakeChannelHandlerContext ctx = new FakeChannelHandlerContext(this.channel, name, handler);
         this.contexts.add(0, ctx);
         LOGGER.fine("[FakeChannelPipeline] Added handler: " + name + " (" + handler.getClass().getSimpleName() + ")");
         if (!this.initializing) {
            this.callHandlerAddedAndFireEvents(ctx);
         }

         return this;
      }
   }

   public ChannelPipeline addFirst(EventExecutorGroup group, String name, ChannelHandler handler) {
      return this.addFirst(name, handler);
   }

   public ChannelPipeline addLast(String name, ChannelHandler handler) {
      if (handler instanceof ReadTimeoutHandler) {
         return this;
      } else {
         this.handlers.put(name, handler);
         FakeChannelHandlerContext ctx = new FakeChannelHandlerContext(this.channel, name, handler);
         this.contexts.add(ctx);
         LOGGER.fine("[FakeChannelPipeline] Added handler: " + name + " (" + handler.getClass().getSimpleName() + ")");
         if (!this.initializing) {
            this.callHandlerAddedAndFireEvents(ctx);
         }

         return this;
      }
   }

   public ChannelPipeline addLast(EventExecutorGroup group, String name, ChannelHandler handler) {
      return this.addLast(name, handler);
   }

   public ChannelPipeline addBefore(String baseName, String name, ChannelHandler handler) {
      if (handler instanceof ReadTimeoutHandler) {
         return this;
      } else {
         this.handlers.put(name, handler);
         FakeChannelHandlerContext ctx = new FakeChannelHandlerContext(this.channel, name, handler);
         int index = this.findContextIndex(baseName);
         if (index >= 0) {
            this.contexts.add(index, ctx);
         } else {
            this.contexts.add(ctx);
         }

         if (!this.initializing) {
            this.callHandlerAddedAndFireEvents(ctx);
         }

         return this;
      }
   }

   public ChannelPipeline addBefore(EventExecutorGroup group, String baseName, String name, ChannelHandler handler) {
      return this.addBefore(baseName, name, handler);
   }

   public ChannelPipeline addAfter(String baseName, String name, ChannelHandler handler) {
      if (handler instanceof ReadTimeoutHandler) {
         return this;
      } else {
         this.handlers.put(name, handler);
         FakeChannelHandlerContext ctx = new FakeChannelHandlerContext(this.channel, name, handler);
         int index = this.findContextIndex(baseName);
         if (index >= 0) {
            this.contexts.add(index + 1, ctx);
         } else {
            this.contexts.add(ctx);
         }

         if (!this.initializing) {
            this.callHandlerAddedAndFireEvents(ctx);
         }

         return this;
      }
   }

   public ChannelPipeline addAfter(EventExecutorGroup group, String baseName, String name, ChannelHandler handler) {
      return this.addAfter(baseName, name, handler);
   }

   public ChannelPipeline addFirst(ChannelHandler... handlers) {
      for(int i = 0; i < handlers.length; ++i) {
         this.addFirst("handler" + i, handlers[i]);
      }

      return this;
   }

   public ChannelPipeline addFirst(EventExecutorGroup group, ChannelHandler... handlers) {
      return this.addFirst(handlers);
   }

   public ChannelPipeline addLast(ChannelHandler... handlers) {
      for(int i = 0; i < handlers.length; ++i) {
         this.addLast("handler" + System.nanoTime() + "_" + i, handlers[i]);
      }

      return this;
   }

   public ChannelPipeline addLast(EventExecutorGroup group, ChannelHandler... handlers) {
      return this.addLast(handlers);
   }

   private void callHandlerAddedAndFireEvents(FakeChannelHandlerContext ctx) {
      try {
         ChannelHandler handler = ctx.getHandler();

         try {
            handler.handlerAdded(ctx);
            LOGGER.fine("[FakeChannelPipeline] Called handlerAdded on: " + ctx.getName());
         } catch (Exception e) {
            LOGGER.fine("[FakeChannelPipeline] handlerAdded threw exception (may be expected): " + e.getMessage());
         }

         if (this.channel.isRegistered()) {
            try {
               if (handler instanceof ChannelInboundHandler) {
                  ((ChannelInboundHandler)handler).channelRegistered(ctx);
                  LOGGER.fine("[FakeChannelPipeline] Fired channelRegistered to: " + ctx.getName());
               }
            } catch (Exception e) {
               LOGGER.fine("[FakeChannelPipeline] channelRegistered threw exception: " + e.getMessage());
            }
         }

         if (this.channel.isActive()) {
            try {
               if (handler instanceof ChannelInboundHandler) {
                  ((ChannelInboundHandler)handler).channelActive(ctx);
                  LOGGER.fine("[FakeChannelPipeline] Fired channelActive to: " + ctx.getName());
               }
            } catch (Exception e) {
               LOGGER.fine("[FakeChannelPipeline] channelActive threw exception: " + e.getMessage());
            }
         }
      } catch (Exception e) {
         LOGGER.fine("[FakeChannelPipeline] Error in callHandlerAddedAndFireEvents: " + e.getMessage());
      }

   }

   private int findContextIndex(String name) {
      for(int i = 0; i < this.contexts.size(); ++i) {
         if (((FakeChannelHandlerContext)this.contexts.get(i)).getName().equals(name)) {
            return i;
         }
      }

      return -1;
   }

   public ChannelPipeline remove(ChannelHandler handler) {
      String nameToRemove = null;

      for(Map.Entry<String, ChannelHandler> entry : this.handlers.entrySet()) {
         if (entry.getValue() == handler) {
            nameToRemove = (String)entry.getKey();
            break;
         }
      }

      if (nameToRemove != null) {
         this.handlers.remove(nameToRemove);
         this.contexts.removeIf((ctx) -> ctx.getName().equals(nameToRemove));
      }

      return this;
   }

   public ChannelHandler remove(String name) {
      ChannelHandler handler = (ChannelHandler)this.handlers.remove(name);
      this.contexts.removeIf((ctx) -> ctx.getName().equals(name));
      return handler;
   }

   public <T extends ChannelHandler> T remove(Class<T> handlerType) {
      String nameToRemove = null;
      T handlerToRemove = null;

      for(Map.Entry<String, ChannelHandler> entry : this.handlers.entrySet()) {
         if (handlerType.isInstance(entry.getValue())) {
            nameToRemove = (String)entry.getKey();
            handlerToRemove = (T)(handlerType.cast(entry.getValue()));
            break;
         }
      }

      if (nameToRemove != null) {
         this.handlers.remove(nameToRemove);
         this.contexts.removeIf((ctx) -> ctx.getName().equals(nameToRemove));
      }

      return handlerToRemove;
   }

   public ChannelHandler removeFirst() {
      if (!this.contexts.isEmpty()) {
         FakeChannelHandlerContext ctx = (FakeChannelHandlerContext)this.contexts.remove(0);
         return (ChannelHandler)this.handlers.remove(ctx.getName());
      } else {
         return null;
      }
   }

   public ChannelHandler removeLast() {
      if (!this.contexts.isEmpty()) {
         FakeChannelHandlerContext ctx = (FakeChannelHandlerContext)this.contexts.remove(this.contexts.size() - 1);
         return (ChannelHandler)this.handlers.remove(ctx.getName());
      } else {
         return null;
      }
   }

   public ChannelPipeline replace(ChannelHandler oldHandler, String newName, ChannelHandler newHandler) {
      this.remove(oldHandler);
      return this.addLast(newName, newHandler);
   }

   public ChannelHandler replace(String oldName, String newName, ChannelHandler newHandler) {
      ChannelHandler old = this.remove(oldName);
      this.addLast(newName, newHandler);
      return old;
   }

   public <T extends ChannelHandler> T replace(Class<T> oldHandlerType, String newName, ChannelHandler newHandler) {
      T old = this.remove(oldHandlerType);
      this.addLast(newName, newHandler);
      return old;
   }

   public ChannelHandler first() {
      return !this.contexts.isEmpty() ? ((FakeChannelHandlerContext)this.contexts.get(0)).getHandler() : null;
   }

   public ChannelHandlerContext firstContext() {
      return !this.contexts.isEmpty() ? (ChannelHandlerContext)this.contexts.get(0) : null;
   }

   public ChannelHandler last() {
      return !this.contexts.isEmpty() ? ((FakeChannelHandlerContext)this.contexts.get(this.contexts.size() - 1)).getHandler() : null;
   }

   public ChannelHandlerContext lastContext() {
      return !this.contexts.isEmpty() ? (ChannelHandlerContext)this.contexts.get(this.contexts.size() - 1) : null;
   }

   public ChannelHandler get(String name) {
      return (ChannelHandler)this.handlers.get(name);
   }

   public <T extends ChannelHandler> T get(Class<T> handlerType) {
      for(ChannelHandler handler : this.handlers.values()) {
         if (handlerType.isInstance(handler)) {
            return (T)(handlerType.cast(handler));
         }
      }

      return null;
   }

   public ChannelHandlerContext context(ChannelHandler handler) {
      for(FakeChannelHandlerContext ctx : this.contexts) {
         if (ctx.getHandler() == handler) {
            return ctx;
         }
      }

      return null;
   }

   public ChannelHandlerContext context(String name) {
      for(FakeChannelHandlerContext ctx : this.contexts) {
         if (ctx.getName().equals(name)) {
            return ctx;
         }
      }

      return null;
   }

   public ChannelHandlerContext context(Class<? extends ChannelHandler> handlerType) {
      for(FakeChannelHandlerContext ctx : this.contexts) {
         if (handlerType.isInstance(ctx.getHandler())) {
            return ctx;
         }
      }

      return null;
   }

   public Channel channel() {
      return this.channel;
   }

   public List<String> names() {
      return new ArrayList(this.handlers.keySet());
   }

   public Map<String, ChannelHandler> toMap() {
      return new LinkedHashMap(this.handlers);
   }

   public ChannelPipeline fireChannelRegistered() {
      for(FakeChannelHandlerContext ctx : this.contexts) {
         try {
            if (ctx.getHandler() instanceof ChannelInboundHandler) {
               ((ChannelInboundHandler)ctx.getHandler()).channelRegistered(ctx);
            }
         } catch (Exception var4) {
         }
      }

      return this;
   }

   public ChannelPipeline fireChannelUnregistered() {
      for(FakeChannelHandlerContext ctx : this.contexts) {
         try {
            if (ctx.getHandler() instanceof ChannelInboundHandler) {
               ((ChannelInboundHandler)ctx.getHandler()).channelUnregistered(ctx);
            }
         } catch (Exception var4) {
         }
      }

      return this;
   }

   public ChannelPipeline fireChannelActive() {
      for(FakeChannelHandlerContext ctx : this.contexts) {
         try {
            if (ctx.getHandler() instanceof ChannelInboundHandler) {
               ((ChannelInboundHandler)ctx.getHandler()).channelActive(ctx);
            }
         } catch (Exception var4) {
         }
      }

      return this;
   }

   public ChannelPipeline fireChannelInactive() {
      for(FakeChannelHandlerContext ctx : this.contexts) {
         try {
            if (ctx.getHandler() instanceof ChannelInboundHandler) {
               ((ChannelInboundHandler)ctx.getHandler()).channelInactive(ctx);
            }
         } catch (Exception var4) {
         }
      }

      return this;
   }

   public ChannelPipeline fireExceptionCaught(Throwable cause) {
      for(FakeChannelHandlerContext ctx : this.contexts) {
         try {
            if (ctx.getHandler() instanceof ChannelInboundHandler) {
               ((ChannelInboundHandler)ctx.getHandler()).exceptionCaught(ctx, cause);
            }
         } catch (Exception var5) {
         }
      }

      return this;
   }

   public ChannelPipeline fireUserEventTriggered(Object event) {
      for(FakeChannelHandlerContext ctx : this.contexts) {
         try {
            if (ctx.getHandler() instanceof ChannelInboundHandler) {
               ((ChannelInboundHandler)ctx.getHandler()).userEventTriggered(ctx, event);
            }
         } catch (Exception var5) {
         }
      }

      return this;
   }

   public ChannelPipeline fireChannelRead(Object msg) {
      for(FakeChannelHandlerContext ctx : this.contexts) {
         try {
            if (ctx.getHandler() instanceof ChannelInboundHandler) {
               ((ChannelInboundHandler)ctx.getHandler()).channelRead(ctx, msg);
            }
         } catch (Exception var5) {
         }
      }

      ReferenceCountUtil.release(msg);
      return this;
   }

   public ChannelPipeline fireChannelReadComplete() {
      for(FakeChannelHandlerContext ctx : this.contexts) {
         try {
            if (ctx.getHandler() instanceof ChannelInboundHandler) {
               ((ChannelInboundHandler)ctx.getHandler()).channelReadComplete(ctx);
            }
         } catch (Exception var4) {
         }
      }

      return this;
   }

   public ChannelPipeline fireChannelWritabilityChanged() {
      for(FakeChannelHandlerContext ctx : this.contexts) {
         try {
            if (ctx.getHandler() instanceof ChannelInboundHandler) {
               ((ChannelInboundHandler)ctx.getHandler()).channelWritabilityChanged(ctx);
            }
         } catch (Exception var4) {
         }
      }

      return this;
   }

   public ChannelFuture bind(SocketAddress localAddress) {
      return this.newSucceededFuture();
   }

   public ChannelFuture connect(SocketAddress remoteAddress) {
      return this.newSucceededFuture();
   }

   public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress) {
      return this.newSucceededFuture();
   }

   public ChannelFuture disconnect() {
      return this.newSucceededFuture();
   }

   public ChannelFuture close() {
      return this.newSucceededFuture();
   }

   public ChannelFuture deregister() {
      return this.newSucceededFuture();
   }

   public ChannelFuture bind(SocketAddress localAddress, ChannelPromise promise) {
      promise.setSuccess();
      return promise;
   }

   public ChannelFuture connect(SocketAddress remoteAddress, ChannelPromise promise) {
      promise.setSuccess();
      return promise;
   }

   public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) {
      promise.setSuccess();
      return promise;
   }

   public ChannelFuture disconnect(ChannelPromise promise) {
      promise.setSuccess();
      return promise;
   }

   public ChannelFuture close(ChannelPromise promise) {
      promise.setSuccess();
      return promise;
   }

   public ChannelFuture deregister(ChannelPromise promise) {
      promise.setSuccess();
      return promise;
   }

   public ChannelOutboundInvoker read() {
      return this;
   }

   public ChannelFuture write(Object msg) {
      ReferenceCountUtil.release(msg);
      return this.newSucceededFuture();
   }

   public ChannelFuture write(Object msg, ChannelPromise promise) {
      ReferenceCountUtil.release(msg);
      promise.setSuccess();
      return promise;
   }

   public ChannelPipeline flush() {
      return this;
   }

   public ChannelFuture writeAndFlush(Object msg, ChannelPromise promise) {
      ReferenceCountUtil.release(msg);
      promise.setSuccess();
      return promise;
   }

   public ChannelFuture writeAndFlush(Object msg) {
      ReferenceCountUtil.release(msg);
      return this.newSucceededFuture();
   }

   public ChannelPromise newPromise() {
      return new DefaultChannelPromise(this.channel);
   }

   public ChannelProgressivePromise newProgressivePromise() {
      return null;
   }

   public ChannelFuture newSucceededFuture() {
      DefaultChannelPromise promise = new DefaultChannelPromise(this.channel);
      promise.setSuccess((Void)null);
      return promise;
   }

   public ChannelFuture newFailedFuture(Throwable cause) {
      DefaultChannelPromise promise = new DefaultChannelPromise(this.channel);
      promise.setFailure(cause);
      return promise;
   }

   public ChannelPromise voidPromise() {
      DefaultChannelPromise promise = new DefaultChannelPromise(this.channel);
      promise.setSuccess((Void)null);
      return promise;
   }

   public Iterator<Map.Entry<String, ChannelHandler>> iterator() {
      return this.handlers.entrySet().iterator();
   }

   private static class FakeChannelHandlerContext implements ChannelHandlerContext {
      private final Channel channel;
      private final String handlerName;
      private final ChannelHandler handler;

      FakeChannelHandlerContext(Channel channel, String name, ChannelHandler handler) {
         this.channel = channel;
         this.handlerName = name;
         this.handler = handler;
      }

      public String getName() {
         return this.handlerName;
      }

      public ChannelHandler getHandler() {
         return this.handler;
      }

      public Channel channel() {
         return this.channel;
      }

      public EventExecutor executor() {
         return null;
      }

      public String name() {
         return this.handlerName;
      }

      public ChannelHandler handler() {
         return this.handler;
      }

      public boolean isRemoved() {
         return false;
      }

      public ChannelHandlerContext fireChannelRegistered() {
         return this;
      }

      public ChannelHandlerContext fireChannelUnregistered() {
         return this;
      }

      public ChannelHandlerContext fireChannelActive() {
         return this;
      }

      public ChannelHandlerContext fireChannelInactive() {
         return this;
      }

      public ChannelHandlerContext fireExceptionCaught(Throwable cause) {
         return this;
      }

      public ChannelHandlerContext fireUserEventTriggered(Object event) {
         return this;
      }

      public ChannelHandlerContext fireChannelRead(Object msg) {
         ReferenceCountUtil.release(msg);
         return this;
      }

      public ChannelHandlerContext fireChannelReadComplete() {
         return this;
      }

      public ChannelHandlerContext fireChannelWritabilityChanged() {
         return this;
      }

      public ChannelFuture bind(SocketAddress localAddress) {
         return this.newSucceededFuture();
      }

      public ChannelFuture connect(SocketAddress remoteAddress) {
         return this.newSucceededFuture();
      }

      public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress) {
         return this.newSucceededFuture();
      }

      public ChannelFuture disconnect() {
         return this.newSucceededFuture();
      }

      public ChannelFuture close() {
         return this.newSucceededFuture();
      }

      public ChannelFuture deregister() {
         return this.newSucceededFuture();
      }

      public ChannelFuture bind(SocketAddress localAddress, ChannelPromise promise) {
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture connect(SocketAddress remoteAddress, ChannelPromise promise) {
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) {
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture disconnect(ChannelPromise promise) {
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture close(ChannelPromise promise) {
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture deregister(ChannelPromise promise) {
         promise.setSuccess();
         return promise;
      }

      public ChannelHandlerContext read() {
         return this;
      }

      public ChannelFuture write(Object msg) {
         ReferenceCountUtil.release(msg);
         return this.newSucceededFuture();
      }

      public ChannelFuture write(Object msg, ChannelPromise promise) {
         ReferenceCountUtil.release(msg);
         promise.setSuccess();
         return promise;
      }

      public ChannelHandlerContext flush() {
         return this;
      }

      public ChannelFuture writeAndFlush(Object msg, ChannelPromise promise) {
         ReferenceCountUtil.release(msg);
         promise.setSuccess();
         return promise;
      }

      public ChannelFuture writeAndFlush(Object msg) {
         ReferenceCountUtil.release(msg);
         return this.newSucceededFuture();
      }

      public ChannelPipeline pipeline() {
         return this.channel.pipeline();
      }

      public ByteBufAllocator alloc() {
         return this.channel.alloc();
      }

      public ChannelPromise newPromise() {
         return new DefaultChannelPromise(this.channel);
      }

      public ChannelProgressivePromise newProgressivePromise() {
         return null;
      }

      public ChannelFuture newSucceededFuture() {
         DefaultChannelPromise p = new DefaultChannelPromise(this.channel);
         p.setSuccess((Void)null);
         return p;
      }

      public ChannelFuture newFailedFuture(Throwable cause) {
         DefaultChannelPromise p = new DefaultChannelPromise(this.channel);
         p.setFailure(cause);
         return p;
      }

      public ChannelPromise voidPromise() {
         DefaultChannelPromise p = new DefaultChannelPromise(this.channel);
         p.setSuccess((Void)null);
         return p;
      }

      public <T> Attribute<T> attr(AttributeKey<T> key) {
         return this.channel.attr(key);
      }

      public <T> boolean hasAttr(AttributeKey<T> key) {
         return this.channel.hasAttr(key);
      }
   }
}
