package com.glidespoofer.nms;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Keyed;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.BlastingRecipe;
import org.bukkit.inventory.CampfireRecipe;
import org.bukkit.inventory.FurnaceRecipe;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.inventory.SmithingRecipe;
import org.bukkit.inventory.SmokingRecipe;
import org.bukkit.inventory.StonecuttingRecipe;

public class NMSRecipeManager {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer");
   private final Map<UUID, Set<NamespacedKey>> unlockedRecipes = new ConcurrentHashMap();
   private final Map<UUID, Set<String>> recipeCategories = new ConcurrentHashMap();
   private final boolean useModernNMS;
   private final String nmsPackage;
   private Method unlockRecipesMethod;
   private Method lockRecipesMethod;
   private Method getRecipeBookMethod;
   private Method awardMethod;
   private Field recipesField;
   private Class<?> recipeBookClass;
   private Class<?> recipeClass;

   public NMSRecipeManager(boolean useModernNMS, String nmsPackage) {
      this.useModernNMS = useModernNMS;
      this.nmsPackage = nmsPackage;
      this.initializeReflection();
   }

   private void initializeReflection() {
      try {
         Class<?> serverPlayerClass;
         if (this.useModernNMS) {
            serverPlayerClass = Class.forName("net.minecraft.server.level.ServerPlayer");
            this.recipeBookClass = Class.forName("net.minecraft.server.RecipeBook");
            this.recipeClass = Class.forName("net.minecraft.world.item.crafting.Recipe");
         } else {
            serverPlayerClass = Class.forName(this.nmsPackage + ".EntityPlayer");

            try {
               this.recipeBookClass = Class.forName(this.nmsPackage + ".RecipeBookServer");
               this.recipeClass = Class.forName(this.nmsPackage + ".Recipe");
            } catch (ClassNotFoundException var7) {
            }
         }

         try {
            Class<?> recipeClassArg = Class.forName("[Lnet.minecraft.resources.ResourceLocation;");
            this.unlockRecipesMethod = serverPlayerClass.getMethod("unlockRecipes", recipeClassArg);
            this.unlockRecipesMethod.setAccessible(true);
            LOGGER.info("[NMSRecipe] Found unlockRecipes method");
         } catch (NoSuchMethodException var9) {
            for(Method m : serverPlayerClass.getDeclaredMethods()) {
               if (m.getName().toLowerCase().contains("unlock") && m.getName().toLowerCase().contains("recipe")) {
                  this.unlockRecipesMethod = m;
                  this.unlockRecipesMethod.setAccessible(true);
                  LOGGER.info("[NMSRecipe] Found unlock method: " + m.getName());
                  break;
               }
            }
         }

         try {
            this.getRecipeBookMethod = serverPlayerClass.getMethod("getRecipeBook");
         } catch (NoSuchMethodException var8) {
            for(Method mx : serverPlayerClass.getDeclaredMethods()) {
               if (mx.getName().toLowerCase().contains("recipe") && mx.getName().toLowerCase().contains("book")) {
                  this.getRecipeBookMethod = mx;
                  this.getRecipeBookMethod.setAccessible(true);
                  break;
               }
            }
         }
      } catch (Exception var10) {
         LOGGER.warning("[NMSRecipe] Failed to initialize reflection: " + var10.getMessage());
      }

   }

   public void initializeRecipeBook(Player player, Object serverPlayer) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         this.unlockedRecipes.put(uuid, new HashSet());
         this.recipeCategories.put(uuid, new HashSet());
      }

   }

   public boolean unlockRecipe(Player player, NamespacedKey key) {
      if (player != null && key != null) {
         try {
            Recipe recipe = Bukkit.getRecipe(key);
            if (recipe == null) {
               LOGGER.warning("[NMSRecipe] Recipe not found: " + String.valueOf(key));
               return false;
            } else {
               try {
                  Method discoverRecipe = player.getClass().getMethod("discoverRecipe", NamespacedKey.class);
                  discoverRecipe.invoke(player, key);
               } catch (NoSuchMethodException var6) {
               }

               UUID uuid = player.getUniqueId();
               Set<NamespacedKey> unlocked = (Set)this.unlockedRecipes.get(uuid);
               if (unlocked != null) {
                  unlocked.add(key);
               }

               Logger var9 = LOGGER;
               String var10 = String.valueOf(key);
               var9.info("[NMSRecipe] Unlocked recipe " + var10 + " for " + player.getName());
               return true;
            }
         } catch (Exception var7) {
            Logger var10000 = LOGGER;
            String var10001 = String.valueOf(key);
            var10000.warning("[NMSRecipe] Failed to unlock recipe " + var10001 + ": " + var7.getMessage());
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean unlockRecipe(Player player, String key) {
      if (key == null) {
         return false;
      } else {
         String namespace = "minecraft";
         String value = key;
         if (key.contains(":")) {
            String[] parts = key.split(":", 2);
            namespace = parts[0];
            value = parts[1];
         }

         NamespacedKey namespacedKey = new NamespacedKey(namespace, value);
         return this.unlockRecipe(player, namespacedKey);
      }
   }

   public int unlockRecipes(Player player, Collection<NamespacedKey> recipes) {
      if (player != null && recipes != null) {
         int count = 0;

         for(NamespacedKey key : recipes) {
            if (this.unlockRecipe(player, key)) {
               ++count;
            }
         }

         return count;
      } else {
         return 0;
      }
   }

   public int unlockAllRecipes(Player player) {
      if (player == null) {
         return 0;
      } else {
         int count = 0;

         try {
            Iterator<Recipe> iterator = Bukkit.recipeIterator();

            while(iterator.hasNext()) {
               Recipe recipe = (Recipe)iterator.next();
               if (recipe instanceof Keyed) {
                  NamespacedKey key = ((Keyed)recipe).getKey();
                  if (this.unlockRecipe(player, key)) {
                     ++count;
                  }
               }
            }

            LOGGER.info("[NMSRecipe] Unlocked " + count + " recipes for " + player.getName());
            return count;
         } catch (Exception var6) {
            LOGGER.warning("[NMSRecipe] Failed to unlock all recipes: " + var6.getMessage());
            return count;
         }
      }
   }

   public boolean lockRecipe(Player player, NamespacedKey key) {
      if (player != null && key != null) {
         try {
            try {
               Method undiscoverRecipe = player.getClass().getMethod("undiscoverRecipe", NamespacedKey.class);
               undiscoverRecipe.invoke(player, key);
            } catch (NoSuchMethodException var5) {
            }

            UUID uuid = player.getUniqueId();
            Set<NamespacedKey> unlocked = (Set)this.unlockedRecipes.get(uuid);
            if (unlocked != null) {
               unlocked.remove(key);
            }

            return true;
         } catch (Exception var6) {
            LOGGER.warning("[NMSRecipe] Failed to lock recipe: " + var6.getMessage());
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean isUnlocked(Player player, NamespacedKey key) {
      if (player != null && key != null) {
         UUID uuid = player.getUniqueId();
         Set<NamespacedKey> unlocked = (Set)this.unlockedRecipes.get(uuid);
         return unlocked != null ? unlocked.contains(key) : false;
      } else {
         return false;
      }
   }

   public Set<NamespacedKey> getUnlockedRecipes(Player player) {
      if (player == null) {
         return new HashSet();
      } else {
         Set<NamespacedKey> unlocked = (Set)this.unlockedRecipes.get(player.getUniqueId());
         return unlocked != null ? new HashSet(unlocked) : new HashSet();
      }
   }

   public int unlockCategory(Player player, String category) {
      if (player != null && category != null) {
         int count = 0;

         for(NamespacedKey key : this.getRecipesByCategory(category)) {
            if (this.unlockRecipe(player, key)) {
               ++count;
            }
         }

         UUID uuid = player.getUniqueId();
         Set<String> categories = (Set)this.recipeCategories.get(uuid);
         if (categories != null) {
            categories.add(category);
         }

         LOGGER.info("[NMSRecipe] Unlocked " + count + " recipes in category " + category);
         return count;
      } else {
         return 0;
      }
   }

   private Set<NamespacedKey> getRecipesByCategory(String category) {
      Set<NamespacedKey> recipes = new HashSet();

      try {
         Iterator<Recipe> iterator = Bukkit.recipeIterator();

         while(iterator.hasNext()) {
            Recipe recipe = (Recipe)iterator.next();
            if (recipe instanceof Keyed) {
               NamespacedKey key = ((Keyed)recipe).getKey();
               if (key.getKey().contains(category)) {
                  recipes.add(key);
               }
            }
         }
      } catch (Exception var6) {
      }

      return recipes;
   }

   public int unlockCraftingRecipes(Player player) {
      int count = 0;
      String[] woods = new String[]{"oak", "birch", "spruce", "jungle", "acacia", "dark_oak", "mangrove", "cherry", "bamboo", "crimson", "warped"};

      for(String wood : woods) {
         count += this.unlockCategory(player, wood + "_planks");
         count += this.unlockCategory(player, wood + "_stairs");
         count += this.unlockCategory(player, wood + "_slab");
         count += this.unlockCategory(player, wood + "_fence");
         count += this.unlockCategory(player, wood + "_door");
         count += this.unlockCategory(player, wood + "_trapdoor");
         count += this.unlockCategory(player, wood + "_pressure_plate");
         count += this.unlockCategory(player, wood + "_button");
      }

      return count;
   }

   public int unlockSmeltingRecipes(Player player) {
      return this.unlockCategory(player, "smelting");
   }

   public int autoUnlockRecipes(Player player, Collection<ItemStack> items) {
      if (player != null && items != null) {
         int count = 0;

         try {
            Iterator<Recipe> iterator = Bukkit.recipeIterator();

            while(iterator.hasNext()) {
               Recipe recipe = (Recipe)iterator.next();
               if (this.canCraft(recipe, items) && recipe instanceof Keyed && this.unlockRecipe(player, ((Keyed)recipe).getKey())) {
                  ++count;
               }
            }
         } catch (Exception var6) {
         }

         return count;
      } else {
         return 0;
      }
   }

   private boolean canCraft(Recipe recipe, Collection<ItemStack> items) {
      try {
         if (recipe instanceof ShapedRecipe) {
            return !((ShapedRecipe)recipe).getChoiceMap().isEmpty();
         } else if (recipe instanceof ShapelessRecipe) {
            return !((ShapelessRecipe)recipe).getChoiceList().isEmpty();
         } else {
            return !(recipe instanceof SmokingRecipe) && !(recipe instanceof FurnaceRecipe) && !(recipe instanceof BlastingRecipe) && !(recipe instanceof CampfireRecipe) && !(recipe instanceof StonecuttingRecipe) && !(recipe instanceof SmithingRecipe) ? true : recipe.getResult() != null;
         }
      } catch (Exception var4) {
         return true;
      }
   }

   public void showRecipeNotification(Player player, NamespacedKey recipe) {
      if (player != null && recipe != null) {
         try {
            LOGGER.info("[NMSRecipe] Would show recipe notification for " + String.valueOf(recipe));
         } catch (Exception var4) {
         }
      }

   }

   public void removeRecipeBook(Player player) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         this.unlockedRecipes.remove(uuid);
         this.recipeCategories.remove(uuid);
      }

   }

   public String getRecipeDisplay(Player player) {
      Set<NamespacedKey> unlocked = this.getUnlockedRecipes(player);
      if (unlocked.isEmpty()) {
         return "No recipes unlocked";
      } else {
         StringBuilder sb = new StringBuilder("\n§e=== Recipe Book for " + player.getName() + " ===\n");
         sb.append("§7Total: §f").append(unlocked.size()).append("\n");
         Map<String, Integer> byType = new HashMap();

         for(NamespacedKey key : unlocked) {
            String type = key.getNamespace();
            byType.merge(type, 1, Integer::sum);
         }

         for(Map.Entry<String, Integer> entry : byType.entrySet()) {
            sb.append("§7").append((String)entry.getKey()).append(": §f").append(entry.getValue()).append("\n");
         }

         return sb.toString();
      }
   }

   public int unlockBasicRecipes(Player player) {
      int count = 0;
      count += this.unlockRecipe(player, "minecraft:oak_planks") ? 1 : 0;
      count += this.unlockRecipe(player, "minecraft:oak_stairs") ? 1 : 0;
      count += this.unlockRecipe(player, "minecraft:oak_slab") ? 1 : 0;
      count += this.unlockRecipe(player, "minecraft:crafting_table") ? 1 : 0;
      count += this.unlockRecipe(player, "minecraft:stick") ? 1 : 0;
      count += this.unlockRecipe(player, "minecraft:chest") ? 1 : 0;
      count += this.unlockRecipe(player, "minecraft:furnace") ? 1 : 0;
      count += this.unlockRecipe(player, "minecraft:torch") ? 1 : 0;
      count += this.unlockRecipe(player, "minecraft:wooden_pickaxe") ? 1 : 0;
      count += this.unlockRecipe(player, "minecraft:stone_pickaxe") ? 1 : 0;
      count += this.unlockRecipe(player, "minecraft:bread") ? 1 : 0;
      return count + (this.unlockRecipe(player, "minecraft:cake") ? 1 : 0);
   }

   public static class CommonRecipes {
      public static final String OAK_PLANKS = "minecraft:oak_planks";
      public static final String OAK_STAIRS = "minecraft:oak_stairs";
      public static final String OAK_SLAB = "minecraft:oak_slab";
      public static final String CRAFTING_TABLE = "minecraft:crafting_table";
      public static final String STICK = "minecraft:stick";
      public static final String CHEST = "minecraft:chest";
      public static final String TRAPPED_CHEST = "minecraft:trapped_chest";
      public static final String FURNACE = "minecraft:furnace";
      public static final String TORCH = "minecraft:torch";
      public static final String STONE_STAIRS = "minecraft:stone_stairs";
      public static final String STONE_SLAB = "minecraft:stone_slab";
      public static final String COBBLESTONE_STAIRS = "minecraft:cobblestone_stairs";
      public static final String COBBLESTONE_SLAB = "minecraft:cobblestone_slab";
      public static final String WOOD_PICKAXE = "minecraft:wooden_pickaxe";
      public static final String STONE_PICKAXE = "minecraft:stone_pickaxe";
      public static final String IRON_PICKAXE = "minecraft:iron_pickaxe";
      public static final String GOLD_PICKAXE = "minecraft:golden_pickaxe";
      public static final String DIAMOND_PICKAXE = "minecraft:diamond_pickaxe";
      public static final String LEATHER_HELMET = "minecraft:leather_helmet";
      public static final String IRON_HELMET = "minecraft:iron_helmet";
      public static final String GOLD_HELMET = "minecraft:golden_helmet";
      public static final String DIAMOND_HELMET = "minecraft:diamond_helmet";
      public static final String BREAD = "minecraft:bread";
      public static final String GOLDEN_APPLE = "minecraft:golden_apple";
      public static final String CAKE = "minecraft:cake";
      public static final String MUSHROOM_STEW = "minecraft:mushroom_stew";
      public static final String REDSTONE_TORCH = "minecraft:redstone_torch";
      public static final String PISTON = "minecraft:piston";
      public static final String STICKY_PISTON = "minecraft:sticky_piston";
      public static final String DISPENSER = "minecraft:dispenser";
      public static final String DROPPER = "minecraft:dropper";
      public static final String RED_BED = "minecraft:red_bed";
      public static final String ORANGE_BED = "minecraft:orange_bed";
      public static final String YELLOW_BED = "minecraft:yellow_bed";
      public static final String GREEN_BED = "minecraft:green_bed";
      public static final String BLUE_BED = "minecraft:blue_bed";
      public static final String BLACK_BED = "minecraft:black_bed";
      public static final String WHITE_BED = "minecraft:white_bed";
      public static final String ENCHANTING_TABLE = "minecraft:enchanting_table";
      public static final String BOOKSHELF = "minecraft:bookshelf";
      public static final String ANVIL = "minecraft:anvil";
   }

   public static class RecipeCategories {
      public static final String WOOD = "wood";
      public static final String STONE = "stone";
      public static final String IRON = "iron";
      public static final String GOLD = "gold";
      public static final String DIAMOND = "diamond";
      public static final String NETHER = "nether";
      public static final String REDSTONE = "redstone";
      public static final String FOOD = "food";
      public static final String ARMOR = "armor";
      public static final String TOOLS = "tools";
      public static final String DECORATIONS = "decorations";
   }
}
