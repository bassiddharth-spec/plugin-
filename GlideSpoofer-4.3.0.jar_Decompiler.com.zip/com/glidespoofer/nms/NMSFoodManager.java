package com.glidespoofer.nms;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class NMSFoodManager {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer");
   public static final int MAX_FOOD_LEVEL = 20;
   public static final float MAX_SATURATION = 20.0F;
   public static final float MAX_EXHAUSTION = 4.0F;
   public static final float EXHAUSTION_THRESHOLD = 4.0F;
   public static final float EXHAUSTION_BREAK = 0.005F;
   public static final float EXHAUSTION_WALK = 0.01F;
   public static final float EXHAUSTION_SPRINT = 0.1F;
   public static final float EXHAUSTION_COMBAT = 0.1F;
   public static final float EXHAUSTION_SWIM = 0.01F;
   public static final float EXHAUSTION_JUMP = 0.05F;
   public static final float EXHAUSTION_ATTACK = 0.1F;
   public static final float EXHAUSTION_DAMAGE = 0.1F;
   private final Map<UUID, FoodData> foodDataMap = new ConcurrentHashMap();
   private final boolean useModernNMS;
   private final String nmsPackage;
   private Field foodLevelField;
   private Field saturationField;
   private Field exhaustionField;
   private Method getFoodDataMethod;
   private Method setFoodLevelMethod;
   private Method setSaturationMethod;
   private Method eatMethod;
   private Class<?> foodDataClass;

   public NMSFoodManager(boolean useModernNMS, String nmsPackage) {
      this.useModernNMS = useModernNMS;
      this.nmsPackage = nmsPackage;
      this.initializeReflection();
   }

   private void initializeReflection() {
      try {
         try {
            if (this.useModernNMS) {
               this.foodDataClass = Class.forName("net.minecraft.world.food.FoodData");
            } else {
               try {
                  this.foodDataClass = Class.forName(this.nmsPackage + ".FoodMetaData");
               } catch (ClassNotFoundException var101) {
                  this.foodDataClass = null;
               }
            }

            if (this.foodDataClass != null) {
               try {
                  this.foodLevelField = this.foodDataClass.getDeclaredField("foodLevel");
                  this.foodLevelField.setAccessible(true);
               } catch (NoSuchFieldException var13) {
                  for(Field f : this.foodDataClass.getDeclaredFields()) {
                     if (f.getType() == Integer.TYPE) {
                        this.foodLevelField = f;
                        this.foodLevelField.setAccessible(true);
                        break;
                     }
                  }
               }

               try {
                  this.saturationField = this.foodDataClass.getDeclaredField("saturationLevel");
                  this.saturationField.setAccessible(true);
               } catch (NoSuchFieldException var12) {
                  for(Field fx : this.foodDataClass.getDeclaredFields()) {
                     if (fx.getType() == Float.TYPE) {
                        this.saturationField = fx;
                        this.saturationField.setAccessible(true);
                        break;
                     }
                  }
               }

               try {
                  this.exhaustionField = this.foodDataClass.getDeclaredField("exhaustionLevel");
                  this.exhaustionField.setAccessible(true);
               } catch (NoSuchFieldException var9) {
                  try {
                     this.exhaustionField = this.foodDataClass.getDeclaredField("exhaustion");
                     this.exhaustionField.setAccessible(true);
                  } catch (NoSuchFieldException var8) {
                  }
               }

               try {
                  this.setFoodLevelMethod = this.foodDataClass.getMethod("setFoodLevel", Integer.TYPE);
                  this.setSaturationMethod = this.foodDataClass.getMethod("setSaturation", Float.TYPE);
                  this.eatMethod = this.foodDataClass.getMethod("eat", Integer.TYPE, Float.TYPE);
               } catch (NoSuchMethodException var7) {
               }
            }
         } catch (Exception var14) {
            LOGGER.warning("[NMSFood] Failed to initialize FoodData reflection: " + var14.getMessage());
         }

         Class<?> serverPlayerClass;
         if (this.useModernNMS) {
            serverPlayerClass = Class.forName("net.minecraft.server.level.ServerPlayer");
         } else {
            serverPlayerClass = Class.forName(this.nmsPackage + ".EntityPlayer");
         }

         try {
            this.getFoodDataMethod = serverPlayerClass.getMethod("getFoodData");
         } catch (NoSuchMethodException var11) {
            for(Method m : serverPlayerClass.getDeclaredMethods()) {
               if (m.getName().toLowerCase().contains("food") || m.getName().toLowerCase().contains("hunger")) {
                  this.getFoodDataMethod = m;
                  this.getFoodDataMethod.setAccessible(true);
                  break;
               }
            }
         }
      } catch (Exception var15) {
         LOGGER.warning("[NMSFood] Failed to initialize reflection: " + var15.getMessage());
      }

   }

   public void initializeFoodData(Player player, Object serverPlayer) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         FoodData foodData = new FoodData();
         foodData.foodLevel = 20;
         foodData.saturationLevel = 5.0F;
         foodData.exhaustionLevel = 0.0F;

         try {
            if (this.getFoodDataMethod != null) {
               Object nmsFoodData = this.getFoodDataMethod.invoke(serverPlayer);
               if (nmsFoodData != null) {
                  foodData.nmsFoodData = nmsFoodData;
                  if (this.foodLevelField != null) {
                     foodData.foodLevel = this.foodLevelField.getInt(nmsFoodData);
                  }

                  if (this.saturationField != null) {
                     foodData.saturationLevel = this.saturationField.getFloat(nmsFoodData);
                  }

                  if (this.exhaustionField != null) {
                     foodData.exhaustionLevel = this.exhaustionField.getFloat(nmsFoodData);
                  }
               }
            }
         } catch (Exception var6) {
         }

         this.foodDataMap.put(uuid, foodData);
      }

   }

   public FoodData getFoodData(Player player) {
      return player == null ? null : (FoodData)this.foodDataMap.get(player.getUniqueId());
   }

   public int getFoodLevel(Player player) {
      FoodData data = this.getFoodData(player);
      return data != null ? data.foodLevel : 20;
   }

   public void setFoodLevel(Player player, int level) {
      if (player != null) {
         FoodData data = this.getFoodData(player);
         if (data != null) {
            data.foodLevel = Math.max(0, Math.min(20, level));
            this.syncFoodData(player, data);
         }
      }

   }

   public float getSaturation(Player player) {
      FoodData data = this.getFoodData(player);
      return data != null ? data.saturationLevel : 0.0F;
   }

   public void setSaturation(Player player, float saturation) {
      if (player != null) {
         FoodData data = this.getFoodData(player);
         if (data != null) {
            data.saturationLevel = Math.max(0.0F, Math.min(20.0F, saturation));
            this.syncFoodData(player, data);
         }
      }

   }

   public float getExhaustion(Player player) {
      FoodData data = this.getFoodData(player);
      return data != null ? data.exhaustionLevel : 0.0F;
   }

   public void addExhaustion(Player player, float amount) {
      if (player != null) {
         FoodData data = this.getFoodData(player);
         if (data != null) {
            data.exhaustionLevel += amount;
            if (data.exhaustionLevel >= 4.0F) {
               data.exhaustionLevel -= 4.0F;
               if (data.saturationLevel > 0.0F) {
                  data.saturationLevel = Math.max(0.0F, data.saturationLevel - 1.0F);
               } else if ((float)data.foodLevel > 0.0F) {
                  data.foodLevel = Math.max(0, data.foodLevel - 1);
               }
            }

            this.syncFoodData(player, data);
         }
      }

   }

   public void eat(Player player, int hunger, float saturation) {
      if (player != null) {
         FoodData data = this.getFoodData(player);
         if (data != null) {
            data.foodLevel = Math.min(20, data.foodLevel + hunger);
            data.saturationLevel = Math.min((float)data.foodLevel, data.saturationLevel + saturation);
            this.syncFoodData(player, data);
         }
      }

   }

   public void eat(Player player, ItemStack food) {
      if (player != null && food != null) {
         try {
            Material material = food.getType();
            int hunger = this.getHungerValue(material);
            float saturation = this.getSaturationValue(material);
            this.eat(player, hunger, saturation);
         } catch (Exception var6) {
            LOGGER.warning("[NMSFood] Failed to eat food: " + var6.getMessage());
         }
      }

   }

   public void starve(Player player, int amount) {
      if (player != null) {
         this.setFoodLevel(player, this.getFoodLevel(player) - amount);
      }

   }

   public boolean isStarving(Player player) {
      return this.getFoodLevel(player) <= 0;
   }

   public boolean canRegenerate(Player player) {
      FoodData data = this.getFoodData(player);
      return data == null ? false : data.foodLevel >= 18 && data.saturationLevel > 0.0F;
   }

   public boolean tickRegeneration(Player player) {
      if (!this.canRegenerate(player)) {
         return false;
      } else {
         FoodData data = this.getFoodData(player);
         data.saturationLevel = Math.max(0.0F, data.saturationLevel - 3.0F);
         if (data.saturationLevel <= 0.0F) {
            data.foodLevel = Math.max(0, data.foodLevel - 1);
         }

         this.syncFoodData(player, data);
         return true;
      }
   }

   private void syncFoodData(Player player, FoodData data) {
      if (data.nmsFoodData != null) {
         try {
            if (this.setFoodLevelMethod != null) {
               this.setFoodLevelMethod.invoke(data.nmsFoodData, data.foodLevel);
            } else if (this.foodLevelField != null) {
               this.foodLevelField.setInt(data.nmsFoodData, data.foodLevel);
            }

            if (this.setSaturationMethod != null) {
               this.setSaturationMethod.invoke(data.nmsFoodData, data.saturationLevel);
            } else if (this.saturationField != null) {
               this.saturationField.setFloat(data.nmsFoodData, data.saturationLevel);
            }

            if (this.exhaustionField != null) {
               this.exhaustionField.setFloat(data.nmsFoodData, data.exhaustionLevel);
            }
         } catch (Exception var4) {
         }
      }

   }

   private int getHungerValue(Material material) {
      String name = material.name().toLowerCase();
      if (name.contains("apple") && !name.contains("golden")) {
         return 4;
      } else if (name.contains("golden_apple")) {
         return 4;
      } else if (name.contains("bread")) {
         return 5;
      } else if (!name.contains("cooked_meat") && !name.contains("steak") && !name.contains("porkchop")) {
         if (name.contains("cooked_chicken")) {
            return 6;
         } else if (!name.contains("cooked_fish") && !name.contains("cooked_salmon")) {
            if (name.contains("cooked_cod")) {
               return 5;
            } else if (name.contains("cooked_rabbit")) {
               return 5;
            } else if (name.contains("mutton")) {
               return 6;
            } else if (name.contains("carrot")) {
               return 3;
            } else if (name.contains("potato") && !name.contains("baked")) {
               return 1;
            } else if (name.contains("baked_potato")) {
               return 5;
            } else if (name.contains("beetroot")) {
               return 1;
            } else if (name.contains("cookie")) {
               return 2;
            } else if (name.contains("melon")) {
               return 2;
            } else if (name.contains("sweet_berries")) {
               return 2;
            } else if (name.contains("glow_berries")) {
               return 2;
            } else if (name.contains("honey_bottle")) {
               return 6;
            } else if (name.contains("pumpkin_pie")) {
               return 8;
            } else if (name.contains("rabbit_stew")) {
               return 10;
            } else if (name.contains("mushroom_stew")) {
               return 6;
            } else if (name.contains("beetroot_soup")) {
               return 6;
            } else if (name.contains("suspicious_stew")) {
               return 6;
            } else if (name.contains("cake")) {
               return 14;
            } else if (name.contains("chorus")) {
               return 4;
            } else if (name.contains("kelp")) {
               return 1;
            } else if (name.contains("dried_kelp")) {
               return 1;
            } else if (name.contains("rotten_flesh")) {
               return 4;
            } else if (name.contains("spider_eye")) {
               return 2;
            } else {
               return name.contains("tropical_fish") ? 1 : 0;
            }
         } else {
            return 6;
         }
      } else {
         return 8;
      }
   }

   private float getSaturationValue(Material material) {
      String name = material.name().toLowerCase();
      if (name.contains("apple") && !name.contains("golden")) {
         return 2.4F;
      } else if (name.contains("golden_apple")) {
         return 9.6F;
      } else if (name.contains("bread")) {
         return 6.0F;
      } else if (!name.contains("cooked_meat") && !name.contains("steak") && !name.contains("porkchop")) {
         if (name.contains("cooked_chicken")) {
            return 7.2F;
         } else if (!name.contains("cooked_fish") && !name.contains("cooked_salmon")) {
            if (name.contains("cooked_cod")) {
               return 6.0F;
            } else if (name.contains("cooked_rabbit")) {
               return 6.0F;
            } else if (name.contains("mutton")) {
               return 9.6F;
            } else if (name.contains("carrot")) {
               return 3.6F;
            } else if (name.contains("baked_potato")) {
               return 6.0F;
            } else if (name.contains("beetroot")) {
               return 1.2F;
            } else if (name.contains("cookie")) {
               return 0.4F;
            } else if (name.contains("melon")) {
               return 1.2F;
            } else if (name.contains("sweet_berries")) {
               return 0.4F;
            } else if (name.contains("glow_berries")) {
               return 0.4F;
            } else if (name.contains("honey_bottle")) {
               return 1.2F;
            } else if (name.contains("pumpkin_pie")) {
               return 4.8F;
            } else if (name.contains("rabbit_stew")) {
               return 12.0F;
            } else if (name.contains("mushroom_stew")) {
               return 7.2F;
            } else if (name.contains("beetroot_soup")) {
               return 7.2F;
            } else if (name.contains("suspicious_stew")) {
               return 7.2F;
            } else if (name.contains("cake")) {
               return 0.4F;
            } else if (name.contains("chorus")) {
               return 2.4F;
            } else if (name.contains("kelp")) {
               return 0.6F;
            } else if (name.contains("dried_kelp")) {
               return 0.6F;
            } else if (name.contains("rotten_flesh")) {
               return 0.8F;
            } else if (name.contains("spider_eye")) {
               return 3.2F;
            } else {
               return name.contains("tropical_fish") ? 0.1F : 0.0F;
            }
         } else {
            return 9.6F;
         }
      } else {
         return 12.8F;
      }
   }

   public void removeFoodData(Player player) {
      if (player != null) {
         this.foodDataMap.remove(player.getUniqueId());
      }

   }

   public static class FoodData {
      public int foodLevel = 20;
      public float saturationLevel = 5.0F;
      public float exhaustionLevel = 0.0F;
      public Object nmsFoodData;

      public FoodData() {
      }

      public FoodData(int foodLevel, float saturationLevel, float exhaustionLevel) {
         this.foodLevel = foodLevel;
         this.saturationLevel = saturationLevel;
         this.exhaustionLevel = exhaustionLevel;
      }

      public String getHungerBar() {
         StringBuilder bar = new StringBuilder();
         int fullBars = this.foodLevel / 2;
         int halfBar = this.foodLevel % 2;

         for(int i = 0; i < fullBars; ++i) {
            bar.append("§c");
         }

         if (halfBar > 0) {
            bar.append("§c§7");
         }

         for(int i = 0; i < 10 - fullBars - halfBar; ++i) {
            bar.append("§7");
         }

         String var10000 = bar.toString();
         return var10000 + " §f" + this.foodLevel + "/20";
      }

      public boolean isFull() {
         return this.foodLevel >= 20;
      }

      public boolean isHungry() {
         return this.foodLevel <= 6;
      }
   }
}
