package com.glidespoofer.nms;

import com.glidespoofer.events.PlayerDamageFakeEntityEvent;
import com.glidespoofer.fake.FakePlayer;
import com.glidespoofer.tasks.DeathManager;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

public class NMSDamageHandler {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-Damage");
   private static final double DEFAULT_KNOCKBACK_STRENGTH = (double)3.5F;
   private static final double CRITICAL_HIT_MULTIPLIER = (double)1.5F;
   private static final int HURT_ANIMATION_TICKS = 10;
   private static boolean is1_19Plus = false;
   private static boolean is1_18Plus = false;
   private static boolean is1_17Plus = false;
   private static Class<?> damageSourceClass;
   private static Class<?> entityClass;
   private static Class<?> livingEntityClass;
   private static Method hurtMethod;
   private static Method knockbackMethod;
   private static Method dieMethod;
   private static Field deadField;
   private static Field hurtTimeField;
   private static Field hurtDurationField;
   private static Field hurtDirectionField;
   private static Field healthField;
   private static Field maxHealthField;
   private static Field absorptionField;
   private final Map<UUID, Float> healthMap = new ConcurrentHashMap();
   private final Map<UUID, Float> maxHealthMap = new ConcurrentHashMap();
   private final Map<UUID, Integer> hurtTimeMap = new ConcurrentHashMap();
   private final Map<UUID, Long> lastDamageTimeMap = new ConcurrentHashMap();
   private final Set<UUID> deadPlayers = ConcurrentHashMap.newKeySet();
   private final Plugin plugin;

   private static void initializeReflection() {
      try {
         String mcVersion = getMinecraftVersion();
         is1_17Plus = compareVersions(mcVersion, "1.17") >= 0;
         is1_18Plus = compareVersions(mcVersion, "1.18") >= 0;
         is1_19Plus = compareVersions(mcVersion, "1.19") >= 0;
         if (SimpleNMSHandler.isDebugMode()) {
            LOGGER.info("[NMSDamageHandler] Detected version: " + mcVersion);
         }

         if (is1_19Plus) {
            damageSourceClass = Class.forName("net.minecraft.world.damagesource.DamageSource");
            entityClass = Class.forName("net.minecraft.world.entity.Entity");
            livingEntityClass = Class.forName("net.minecraft.world.entity.LivingEntity");
         } else if (is1_18Plus) {
            damageSourceClass = Class.forName("net.minecraft.world.damagesources.DamageSource");
            entityClass = Class.forName("net.minecraft.world.entity.Entity");
            livingEntityClass = Class.forName("net.minecraft.world.entity.LivingEntity");
         } else if (is1_17Plus) {
            damageSourceClass = Class.forName("net.minecraft.world.damagesource.DamageSource");
            entityClass = Class.forName("net.minecraft.world.entity.Entity");
            livingEntityClass = Class.forName("net.minecraft.world.entity.LivingEntity");
         } else {
            damageSourceClass = Class.forName("net.minecraft.util.DamageSource");
            entityClass = Class.forName("net.minecraft.server." + getNmsVersion() + ".Entity");
            livingEntityClass = Class.forName("net.minecraft.server." + getNmsVersion() + ".EntityLiving");
         }

         boolean hurtMethodFound = false;
         if (!hurtMethodFound) {
            try {
               hurtMethod = livingEntityClass.getDeclaredMethod("hurt", damageSourceClass, Float.TYPE);
               hurtMethod.setAccessible(true);
               hurtMethodFound = true;
               if (SimpleNMSHandler.isDebugMode()) {
                  LOGGER.info("[NMSDamageHandler] Found hurt(DamageSource, float) method");
               }
            } catch (NoSuchMethodException var20) {
            }
         }

         if (!hurtMethodFound) {
            try {
               hurtMethod = livingEntityClass.getDeclaredMethod("hurt", Class.forName("net.minecraft.world.damagesource.DamageSource"), Float.TYPE, Float.TYPE);
               hurtMethod.setAccessible(true);
               hurtMethodFound = true;
               if (SimpleNMSHandler.isDebugMode()) {
                  LOGGER.info("[NMSDamageHandler] Found hurt(DamageSource, float, float) method");
               }
            } catch (NoSuchMethodException var19) {
            }
         }

         if (!hurtMethodFound) {
            try {
               Class<?> dsClass = Class.forName("net.minecraft.world.damagesource.DamageSource");
               hurtMethod = livingEntityClass.getDeclaredMethod("hurt", dsClass, Float.TYPE);
               hurtMethod.setAccessible(true);
               hurtMethodFound = true;
               if (SimpleNMSHandler.isDebugMode()) {
                  LOGGER.info("[NMSDamageHandler] Found hurt method with generic DamageSource");
               }
            } catch (NoSuchMethodException var18) {
            }
         }

         if (!hurtMethodFound) {
            try {
               hurtMethod = livingEntityClass.getDeclaredMethod("damageEntity", damageSourceClass, Float.TYPE);
               hurtMethod.setAccessible(true);
               hurtMethodFound = true;
               if (SimpleNMSHandler.isDebugMode()) {
                  LOGGER.info("[NMSDamageHandler] Found damageEntity method");
               }
            } catch (NoSuchMethodException var17) {
            }
         }

         if (!hurtMethodFound) {
            try {
               hurtMethod = livingEntityClass.getDeclaredMethod("damageEntity0", damageSourceClass, Float.TYPE);
               hurtMethod.setAccessible(true);
               hurtMethodFound = true;
               if (SimpleNMSHandler.isDebugMode()) {
                  LOGGER.info("[NMSDamageHandler] Found damageEntity0 method");
               }
            } catch (NoSuchMethodException var16) {
            }
         }

         if (!hurtMethodFound) {
            try {
               for(Method m : livingEntityClass.getDeclaredMethods()) {
                  if (m.getName().equals("hurt")) {
                     if (SimpleNMSHandler.isDebugMode()) {
                        LOGGER.info("[NMSDamageHandler] Found hurt method with signature: " + String.valueOf(m));
                     }

                     hurtMethod = m;
                     hurtMethod.setAccessible(true);
                     hurtMethodFound = true;
                     break;
                  }
               }

               if (!hurtMethodFound && livingEntityClass.getSuperclass() != null) {
                  for(Method mx : livingEntityClass.getSuperclass().getDeclaredMethods()) {
                     if (mx.getName().equals("hurt")) {
                        if (SimpleNMSHandler.isDebugMode()) {
                           LOGGER.info("[NMSDamageHandler] Found hurt method in superclass: " + String.valueOf(mx));
                        }

                        hurtMethod = mx;
                        hurtMethod.setAccessible(true);
                        hurtMethodFound = true;
                        break;
                     }
                  }
               }
            } catch (Exception var21) {
            }
         }

         if (!hurtMethodFound) {
            LOGGER.warning("[NMSDamageHandler] Could not find hurt/damageEntity method - will use fallback");
            hurtMethod = null;
         }

         try {
            knockbackMethod = livingEntityClass.getDeclaredMethod("knockback", Double.TYPE, Double.TYPE, Double.TYPE);
            knockbackMethod.setAccessible(true);
         } catch (NoSuchMethodException var15) {
            LOGGER.fine("[NMSDamageHandler] Could not find knockback method");
         }

         try {
            dieMethod = livingEntityClass.getDeclaredMethod("die", damageSourceClass);
            dieMethod.setAccessible(true);
         } catch (NoSuchMethodException var14) {
            LOGGER.warning("[NMSDamageHandler] Could not find die method");
         }

         try {
            deadField = livingEntityClass.getDeclaredField("dead");
            deadField.setAccessible(true);
         } catch (NoSuchFieldException var13) {
         }

         try {
            hurtTimeField = livingEntityClass.getDeclaredField("hurtTime");
            hurtTimeField.setAccessible(true);
         } catch (NoSuchFieldException var12) {
         }

         try {
            hurtDurationField = livingEntityClass.getDeclaredField("hurtDuration");
            hurtDurationField.setAccessible(true);
         } catch (NoSuchFieldException var11) {
         }

         try {
            hurtDirectionField = livingEntityClass.getDeclaredField("hurtDir");
            hurtDirectionField.setAccessible(true);
         } catch (NoSuchFieldException var10) {
            try {
               hurtDirectionField = livingEntityClass.getDeclaredField("hurtDirection");
               hurtDirectionField.setAccessible(true);
            } catch (Exception var9) {
            }
         }

         try {
            healthField = livingEntityClass.getDeclaredField("health");
            healthField.setAccessible(true);
         } catch (NoSuchFieldException var8) {
         }

         try {
            maxHealthField = livingEntityClass.getDeclaredField("maxHealth");
            maxHealthField.setAccessible(true);
         } catch (NoSuchFieldException var7) {
         }

         try {
            absorptionField = livingEntityClass.getDeclaredField("absorptionAmount");
            absorptionField.setAccessible(true);
         } catch (NoSuchFieldException var6) {
         }

         if (SimpleNMSHandler.isDebugMode()) {
            LOGGER.info("[NMSDamageHandler] Reflection initialized successfully");
         }
      } catch (Exception var22) {
         LOGGER.log(Level.SEVERE, "[NMSDamageHandler] Failed to initialize reflection", var22);
      }

   }

   private static String getMinecraftVersion() {
      try {
         Method method = Bukkit.class.getMethod("getMinecraftVersion");
         return (String)method.invoke((Object)null);
      } catch (Exception var1) {
         return "1.8.8";
      }
   }

   private static String getNmsVersion() {
      try {
         String[] parts = Bukkit.getServer().getClass().getPackage().getName().split("\\.");
         return parts.length > 3 ? parts[3] : "";
      } catch (Exception var1) {
         return "";
      }
   }

   private static int compareVersions(String v1, String v2) {
      String[] p1 = v1.split("\\.");
      String[] p2 = v2.split("\\.");

      for(int i = 0; i < Math.max(p1.length, p2.length); ++i) {
         int n1 = i < p1.length ? Integer.parseInt(p1[i]) : 0;
         int n2 = i < p2.length ? Integer.parseInt(p2[i]) : 0;
         if (n1 != n2) {
            return n1 - n2;
         }
      }

      return 0;
   }

   public NMSDamageHandler(Plugin plugin) {
      this.plugin = plugin;
   }

   public boolean damage(FakePlayer fakePlayer, float amount, Player attacker, boolean isCritical) {
      if (fakePlayer != null && !this.isDead(fakePlayer.getUuid())) {
         UUID uuid = fakePlayer.getUuid();
         long now = System.currentTimeMillis();
         Long lastDamage = (Long)this.lastDamageTimeMap.get(uuid);
         if (lastDamage != null && now - lastDamage < 500L) {
            return false;
         } else {
            this.lastDamageTimeMap.put(uuid, now);
            float finalDamage = amount;
            if (isCritical) {
               finalDamage = (float)((double)amount * (double)1.5F);
            }

            float currentHealth = this.getHealth(uuid);
            this.getMaxHealth(uuid);
            float newHealth = Math.max(0.0F, currentHealth - finalDamage);
            this.setHealth(uuid, newHealth);
            this.triggerHurtAnimation(fakePlayer);
            this.playHurtSound(fakePlayer);
            if (attacker != null) {
               Location attackerLoc = attacker.getLocation();
               Location fakeLoc = fakePlayer.getLocation();
               Vector knockbackDir = fakeLoc.toVector().subtract(attackerLoc.toVector()).normalize();
               this.applyKnockback(fakePlayer, knockbackDir, (double)3.5F);
            }

            PlayerDamageFakeEntityEvent event = new PlayerDamageFakeEntityEvent(attacker, fakePlayer, (int)finalDamage);
            Bukkit.getPluginManager().callEvent(event);
            if (newHealth <= 0.0F) {
               this.kill(fakePlayer, attacker);
            }

            return true;
         }
      } else {
         return false;
      }
   }

   public boolean damageWithKnockback(FakePlayer fakePlayer, float amount, Location attackLocation, double knockbackStrength) {
      if (fakePlayer != null && !this.isDead(fakePlayer.getUuid())) {
         boolean result = this.damage(fakePlayer, amount, (Player)null, false);
         if (result && attackLocation != null) {
            Location fakeLoc = fakePlayer.getLocation();
            Vector knockbackDir = fakeLoc.toVector().subtract(attackLocation.toVector()).normalize();
            this.applyKnockback(fakePlayer, knockbackDir, knockbackStrength);
         }

         return result;
      } else {
         return false;
      }
   }

   public void kill(FakePlayer fakePlayer, Player killer) {
      if (fakePlayer != null) {
         UUID uuid = fakePlayer.getUuid();
         this.deadPlayers.add(uuid);
         this.setHealth(uuid, 0.0F);
         this.playDeathSound(fakePlayer);

         try {
            DeathManager deathManager = (DeathManager)Bukkit.getPluginManager().getPlugin("GlideSpoofer");
            if (deathManager != null) {
            }
         } catch (Exception var5) {
         }

         if (SimpleNMSHandler.isDebugMode()) {
            LOGGER.info("[NMSDamageHandler] Fake player died: " + fakePlayer.getName());
         }
      }

   }

   public void respawn(UUID uuid) {
      this.deadPlayers.remove(uuid);
      this.setHealth(uuid, this.getMaxHealth(uuid));
      this.setHurtTime(uuid, 0);
      if (SimpleNMSHandler.isDebugMode()) {
         LOGGER.info("[NMSDamageHandler] Fake player respawned: " + String.valueOf(uuid));
      }

   }

   public void applyKnockback(FakePlayer fakePlayer, Vector direction, double strength) {
      if (fakePlayer != null && direction != null) {
         try {
            Player craftPlayer = this.getCraftPlayer(fakePlayer);
            if (craftPlayer == null) {
               return;
            }

            Object nmsEntity = this.getNMSEntity(craftPlayer);
            if (nmsEntity == null) {
               return;
            }

            if (!livingEntityClass.isInstance(nmsEntity)) {
               LOGGER.warning("[NMSDamageHandler] NMS entity is not a LivingEntity");
               return;
            }

            double dx = direction.getX();
            double dz = direction.getZ();
            double length = Math.sqrt(dx * dx + dz * dz);
            if (length > (double)0.0F) {
               dx /= length;
               dz /= length;
            }

            if (knockbackMethod != null) {
               knockbackMethod.invoke(nmsEntity, strength, dx, dz);
               LOGGER.log(Level.FINE, "[NMSDamageHandler] Applied native knockback: strength=" + strength + ", dx=" + dx + ", dz=" + dz);
            } else {
               try {
                  Method kbMethod = livingEntityClass.getDeclaredMethod("knockback", Double.TYPE, Double.TYPE, Double.TYPE);
                  kbMethod.setAccessible(true);
                  kbMethod.invoke(nmsEntity, strength, dx, dz);
                  knockbackMethod = kbMethod;
                  LOGGER.log(Level.FINE, "[NMSDamageHandler] Applied native knockback (found at runtime)");
               } catch (NoSuchMethodException var18) {
                  for(Method m : livingEntityClass.getDeclaredMethods()) {
                     if (m.getParameterCount() == 3 && m.getParameterTypes()[0] == Double.TYPE && m.getParameterTypes()[1] == Double.TYPE && m.getParameterTypes()[2] == Double.TYPE) {
                        m.setAccessible(true);
                        m.invoke(nmsEntity, strength, dx, dz);
                        knockbackMethod = m;
                        LOGGER.log(Level.FINE, "[NMSDamageHandler] Applied knockback via obfuscated method: " + m.getName());
                        return;
                     }
                  }

                  LOGGER.fine("[NMSDamageHandler] Could not find knockback method - no knockback applied");
               }
            }
         } catch (Exception var19) {
            LOGGER.fine("[NMSDamageHandler] Failed to apply native knockback: " + var19.getMessage());
         }
      }

   }

   public void triggerHurtAnimation(FakePlayer fakePlayer) {
      if (fakePlayer != null) {
         UUID uuid = fakePlayer.getUuid();
         this.setHurtTime(uuid, 10);

         try {
            Player craftPlayer = this.getCraftPlayer(fakePlayer);
            if (craftPlayer != null) {
               Object nmsEntity = this.getNMSEntity(craftPlayer);
               if (nmsEntity != null && hurtTimeField != null) {
                  hurtTimeField.setInt(nmsEntity, 10);
               }

               if (nmsEntity != null && hurtDurationField != null) {
                  hurtDurationField.setInt(nmsEntity, 10);
               }
            }
         } catch (Exception var5) {
         }
      }

   }

   public int getHurtTime(UUID uuid) {
      return (Integer)this.hurtTimeMap.getOrDefault(uuid, 0);
   }

   private void setHurtTime(UUID uuid, int ticks) {
      this.hurtTimeMap.put(uuid, ticks);
   }

   public void tickHurtAnimation(UUID uuid) {
      int current = this.getHurtTime(uuid);
      if (current > 0) {
         this.setHurtTime(uuid, current - 1);
      }

   }

   public float getHealth(UUID uuid) {
      return (Float)this.healthMap.getOrDefault(uuid, 20.0F);
   }

   public void setHealth(UUID uuid, float health) {
      this.healthMap.put(uuid, health);

      try {
         Object nmsEntity = this.getNMSEntityByUUID(uuid);
         if (nmsEntity != null && healthField != null) {
            healthField.setFloat(nmsEntity, health);
         }
      } catch (Exception var4) {
      }

   }

   public float getMaxHealth(UUID uuid) {
      return (Float)this.maxHealthMap.getOrDefault(uuid, 20.0F);
   }

   public void setMaxHealth(UUID uuid, float maxHealth) {
      this.maxHealthMap.put(uuid, maxHealth);

      try {
         Object nmsEntity = this.getNMSEntityByUUID(uuid);
         if (nmsEntity != null && maxHealthField != null) {
            maxHealthField.setFloat(nmsEntity, maxHealth);
         }
      } catch (Exception var4) {
      }

   }

   public boolean isDead(UUID uuid) {
      return this.deadPlayers.contains(uuid);
   }

   public void initializeHealth(UUID uuid, float maxHealth) {
      this.maxHealthMap.put(uuid, maxHealth);
      this.healthMap.put(uuid, maxHealth);
      this.deadPlayers.remove(uuid);
      this.hurtTimeMap.remove(uuid);
      this.lastDamageTimeMap.remove(uuid);
   }

   private void playHurtSound(FakePlayer fakePlayer) {
      Location loc = fakePlayer.getLocation();
      if (loc != null) {
         try {
            Sound sound;
            try {
               sound = Sound.valueOf("ENTITY_PLAYER_HURT");
            } catch (IllegalArgumentException var7) {
               try {
                  sound = Sound.valueOf("HURT_FLESH");
               } catch (IllegalArgumentException var6) {
                  return;
               }
            }

            loc.getWorld().playSound(loc, sound, 1.0F, 1.0F);
         } catch (Exception var8) {
         }
      }

   }

   private void playDeathSound(FakePlayer fakePlayer) {
      Location loc = fakePlayer.getLocation();
      if (loc != null) {
         try {
            Sound sound;
            try {
               sound = Sound.valueOf("ENTITY_PLAYER_DEATH");
            } catch (IllegalArgumentException var7) {
               try {
                  sound = Sound.valueOf("HURT_FLESH");
               } catch (IllegalArgumentException var6) {
                  return;
               }
            }

            loc.getWorld().playSound(loc, sound, 1.0F, 1.0F);
         } catch (Exception var8) {
         }
      }

   }

   private Player getCraftPlayer(FakePlayer fakePlayer) {
      try {
         Class<?> handlerClass = Class.forName("com.glidespoofer.nms.SimpleNMSHandler");
         Object handler = handlerClass.getField("instance").get((Object)null);
         if (handler != null) {
            Method getFakePlayer = handlerClass.getMethod("getFakePlayer", UUID.class);
            return (Player)getFakePlayer.invoke(handler, fakePlayer.getUuid());
         }
      } catch (Exception var5) {
      }

      return null;
   }

   private Object getNMSEntity(Player player) {
      if (player == null) {
         return null;
      } else {
         try {
            Method getHandle = player.getClass().getMethod("getHandle");
            return getHandle.invoke(player);
         } catch (Exception var3) {
            return null;
         }
      }
   }

   private Object getNMSEntityByUUID(UUID uuid) {
      return null;
   }

   private static Object createPlayerDamageSource(Player attacker) {
      try {
         Method playerAttack = damageSourceClass.getMethod("playerAttack", entityClass);
         Object nmsAttacker = getNMSEntityStatic(attacker);
         return playerAttack.invoke((Object)null, nmsAttacker);
      } catch (Exception var3) {
         return null;
      }
   }

   private static Object createGenericDamageSource() {
      return null;
   }

   private static Object getNMSEntityStatic(Player player) {
      if (player == null) {
         return null;
      } else {
         try {
            Method getHandle = player.getClass().getMethod("getHandle");
            return getHandle.invoke(player);
         } catch (Exception var2) {
            return null;
         }
      }
   }

   static {
      initializeReflection();
   }
}
