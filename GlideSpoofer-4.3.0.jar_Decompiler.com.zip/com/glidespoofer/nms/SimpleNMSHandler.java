package com.glidespoofer.nms;

import com.glidespoofer.core.GlideSpoofer;
import com.glidespoofer.fake.FakePlayer;
import com.glidespoofer.fake.SkinFetcher;
import com.glidespoofer.hooks.LoginEventManager;
import com.glidespoofer.listener.FakePlayerDamageListener;
import com.glidespoofer.nms.connection.FakeNetworkManager;
import com.glidespoofer.pathfinding.FollowModeManager;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.properties.PropertyMap;
import io.netty.channel.Channel;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.file.Path;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class SimpleNMSHandler implements NMSHandler {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-SimpleNMS");
   private static boolean debugMode = false;
   private final GlideSpoofer plugin;
   private final LoginEventManager loginEventManager;
   private final Map<UUID, Player> fakePlayers = new ConcurrentHashMap();
   private final Map<UUID, Integer> fakePlayerPings = new ConcurrentHashMap();
   private final Map<UUID, Boolean> lookAtPlayers = new ConcurrentHashMap();
   private final Map<UUID, Boolean> banned = new ConcurrentHashMap();
   private final Map<UUID, Boolean> muted = new ConcurrentHashMap();
   private final Set<UUID> swingArmEnabled = ConcurrentHashMap.newKeySet();
   private final Set<UUID> headMovementEnabled = ConcurrentHashMap.newKeySet();
   private final Map<UUID, Object> playerTickers = new ConcurrentHashMap();
   private final Map<UUID, FakePlayerTickerRunnable> tickerInstances = new ConcurrentHashMap();
   private volatile boolean doTickInitialized = false;
   private Method doTickMethod = null;
   private boolean usingTickFallback = false;
   private boolean moveMethodsInit = false;
   private Method entityMoveRelativeMethod = null;
   private Method entityMoveMethod = null;
   private Object moverTypeSelf = null;
   private Constructor<?> vec3Constructor = null;
   private Class<?> vec3Class = null;
   private Method getDeltaMovementMethod = null;
   private Method setDeltaMovementMethod = null;
   private Field zzaField = null;
   private Field xxaField = null;
   private Field lastActionTimeField = null;
   private Method resetLastActionTimeMethod = null;
   private final boolean useModernNMS;
   private final String nmsPackage;
   private static final String[] SKIN_POOL = new String[]{"Notch", "jeb_", "Dinnerbone", "Grumm", "Marc_IRL", "Mojang", "Searge", "ExcitedZe", "KnightMiner", "kingbdogz", "Agnes", "MHF_Steve", "MHF_Alex", "MHF_Blaze", "MHF_Golem", "MHF_Pig", "MHF_Villager", "MHF_Zombie", "MHF_Skeleton", "MHF_Creeper", "MHF_Spider", "MHF_Enderman", "MHF_Ghast", "MHF_Herobrine", "Dream", "Technoblade", "TommyInnit", "GeorgeNotFound", "Sapnap", "Ph1LzA", "WilburSoot", "Tubbo", "Ranboo", "KarlJacobs", "Nihachu", "Quackity", "Fundy", "Punz", "Ponk", "Awesamdude", "Antfrost", "HBomb94", "Vikkstar123", "LazarBeam", "Grian", "MumboJumbo", "iskall85", "Stressmonster101", "FalseSymmetry", "TangoTek", "ImpulseSV", "GoodTimesWithScar", "BdoubleO100", "Keralis", "Etho", "Docm77", "xBCrafted", "rendog", "Welsknight", "cubfan135", "Xisuma", "hypnotizd", "joehillssays", "Zedaph", "Tinfoilchef", "VintageBeef", "Bdubs", "PearlescentMoon", "GeminiTay", "fWhip", "Shrub", "Skizzleman", "SolidarityGaming", "CaptainSparklez", "DanTDM", "PopularMMOs", "PewDiePie", "MrBeast", "Jacksepticeye", "Markiplier", "SSundee", "Lachlan", "PrestonPlayz", "Bajan_Canadian", "JeromeASF", "Crainer", "xNestorio", "Vikkstar123", "HuoBi", "solllunaa", "Minikloon", "Trydar", "SkiKora", "Cxlour", "yZumbi", "Pulous", "SoLLoX", "Petom", "Tonkaaj", "ItsPavi", "kystevey", "Albyumps", "BazzaFcm", "TinyTanj", "ChefMmm", "Stretserayy", "Wienteey", "Incontroll", "ThqZnn", "Astronix", "MysticMamba", "BlindJasmine", "RuneTiger", "Feinberg", "Couriway", "a_Statler", "Zumplet", "K4yfour", "Cheese", "brea", "Swordself", "Furthest", "RyanTheInventor", "DaphneElma", "WealthyPuppy", "Snowylilies", "Nubiaa", "OkPurple", "DangerousBacon", "ItsTAFU", "RedShulker", "Jannine", "Blockworks", "Darastlix", "Naomi", "Philza", "FitMC", "Skeppy", "BadBoyHalo", "A6D", "Spifey", "Tubbo_", "Foolish_Gamers", "Eret", "Sapnap_", "Caitibugzz", "BeePee", "Shubble", "VoiceoverPete", "Sandiction", "TheJogMan", "WoogieGriefer", "SpaceTimeMonkey", "cohhcarnage", "Captaan", "TapL", "Fruitberries", "IlluminaHD", "avghardy", "Boz", "zelk", "Wisp"};
   private static final Random RANDOM = new Random();
   private static Class<?> minecraftServerClass;
   private static Class<?> worldServerClass;
   private static Class<?> entityPlayerClass;
   private static Class<?> gameProfileClass;
   private static Class<?> craftServerClass;
   private static Class<?> craftWorldClass;
   private static Class<?> craftPlayerClass;
   private static Class<?> clientInformationClass;
   private NMSAdvancementManager advancementManager;
   private NMSFoodManager foodManager;
   private NMSRecipeManager recipeManager;
   private NMSDeathManager deathManager;
   private NMSStatisticsManager statisticsManager;

   public SimpleNMSHandler(GlideSpoofer plugin) {
      this.plugin = plugin;
      this.loginEventManager = new LoginEventManager(plugin);
      this.nmsPackage = this.detectNmsPackage();
      this.useModernNMS = this.nmsPackage != null && !this.nmsPackage.isEmpty();
      this.registerKickPrevention();
   }

   private void registerKickPrevention() {
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler(
            priority = EventPriority.LOWEST
         )
         public void onPlayerKick(PlayerKickEvent event) {
            if (SimpleNMSHandler.this.isFakePlayer(event.getPlayer())) {
               event.setCancelled(true);
            }
         }
      }, this.plugin);
   }

   private String detectNmsPackage() {
      if (craftServerClass != null) {
         String className = craftServerClass.getName();
         int idx = className.indexOf(".craftbukkit.");
         if (idx > 0) {
            int start = idx + 13;
            int end = className.indexOf(".", start);
            if (end > start) {
               return className.substring(start, end);
            }

            return "";
         }
      }

      return "";
   }

   public static void setDebugMode(boolean enabled) {
      debugMode = enabled;
   }

   public static boolean isDebugMode() {
      return debugMode;
   }

   private static void debug(String message) {
      if (debugMode) {
         LOGGER.info(message);
      }

   }

   public Player spawnFakePlayer(String name, UUID uuid, Location location) {
      return this.spawnFakePlayer(name, uuid, location, this.getRandomSkinName());
   }

   public Player spawnFakePlayer(String name, UUID uuid, Location location, String skinName) {
      try {
         debug("[SimpleNMSHandler] Spawning fake player: " + name + " with skin: " + skinName);
         Object minecraftServer = this.getMinecraftServer();
         Object worldServer = this.getWorldServer(location.getWorld());
         if (minecraftServer != null && worldServer != null) {
            if (skinName == null || skinName.isEmpty()) {
               skinName = SKIN_POOL[RANDOM.nextInt(SKIN_POOL.length)];
            }

            Object gameProfile = this.createGameProfileWithSkin(uuid, name, skinName);
            Object clientInfo = this.createDefaultClientInformation();
            Object entityPlayer = entityPlayerClass.getConstructor(minecraftServerClass, worldServerClass, gameProfileClass, clientInformationClass).newInstance(minecraftServer, worldServer, gameProfile, clientInfo);
            this.setLocation(entityPlayer, location);
            Player craftPlayer = this.getCraftPlayer(entityPlayer);
            if (craftPlayer == null) {
               LOGGER.warning("[SimpleNMSHandler] Could not get CraftPlayer from EntityPlayer");
               return null;
            } else {
               try {
                  InetAddress fakeAddr = InetAddress.getByName("127.0.0.1");
                  this.loginEventManager.fireAsyncPreLoginEvent(name, fakeAddr, uuid);
                  this.loginEventManager.firePlayerLoginEvent(craftPlayer, fakeAddr);
               } catch (Exception e) {
                  LOGGER.fine("[SimpleNMSHandler] Login event chain failed for " + name + ": " + e.getMessage());
               }

               this.registerWithPlayerList(minecraftServer, entityPlayer, gameProfile, uuid, name);
               this.setupPostSpawn(entityPlayer);
               this.fakePlayers.put(uuid, craftPlayer);
               int ping = this.generateRandomPing();
               this.fakePlayerPings.put(uuid, ping);
               this.setPingField(entityPlayer, ping);
               Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                  try {
                     Object handle = craftPlayerClass.getMethod("getHandle").invoke(craftPlayerClass.cast(craftPlayer));
                     if (handle != null) {
                        this.setPingField(handle, ping);
                        this.broadcastPingUpdate(handle);
                        debug("[SimpleNMSHandler] Delayed ping broadcast for " + name + ": " + ping + "ms");
                     }
                  } catch (Exception e) {
                     LOGGER.warning("[SimpleNMSHandler] Delayed ping broadcast failed for " + name + ": " + e.getMessage());
                  }

               }, 10L);
               this.startPlayerTicker(uuid, craftPlayer);
               debug("[SimpleNMSHandler] Spawned fake player: " + name);
               return craftPlayer;
            }
         } else {
            LOGGER.warning("[SimpleNMSHandler] Could not get MinecraftServer or WorldServer");
            return null;
         }
      } catch (Exception e) {
         LOGGER.warning("[SimpleNMSHandler] Failed to spawn fake player: " + e.getMessage());
         e.printStackTrace();
         return null;
      }
   }

   private void registerWithPlayerList(Object minecraftServer, Object entityPlayer, Object gameProfile, UUID uuid, String name) {
      try {
         Method getPlayerListMethod = minecraftServerClass.getMethod("getPlayerList");
         Object playerList = getPlayerListMethod.invoke(minecraftServer);
         if (playerList == null) {
            LOGGER.warning("[SimpleNMSHandler] Could not get PlayerList");
            return;
         }

         Player craftPlayer = this.getCraftPlayer(entityPlayer);
         if (craftPlayer == null) {
            LOGGER.warning("[SimpleNMSHandler] Could not get CraftPlayer");
            return;
         }

         try {
            FakeNetworkManager fakeNetworkManager = new FakeNetworkManager(this.generateFakeIP(), '鱀' + RANDOM.nextInt(20000));
            fakeNetworkManager.initialize();
            Object connection = fakeNetworkManager.getNetworkManager();
            if (connection == null) {
               LOGGER.warning("[SimpleNMSHandler] Failed to create NetworkManager");
               return;
            }

            Object cookie = this.createCommonListenerCookie(gameProfile);
            if (cookie == null) {
               LOGGER.warning("[SimpleNMSHandler] Failed to create CommonListenerCookie");
               return;
            }

            Method placeNewPlayerMethod = null;

            for(Method m : playerList.getClass().getMethods()) {
               if (m.getName().equals("placeNewPlayer")) {
                  placeNewPlayerMethod = m;
                  break;
               }
            }

            if (placeNewPlayerMethod == null) {
               Class<?> connectionClass = Class.forName("net.minecraft.network.Connection");
               Class<?> cookieClass = Class.forName("net.minecraft.server.network.CommonListenerCookie");

               for(Method m : playerList.getClass().getDeclaredMethods()) {
                  Class<?>[] params = m.getParameterTypes();
                  if (params.length >= 2 && connectionClass.isAssignableFrom(params[0]) && entityPlayerClass.isAssignableFrom(params[1])) {
                     placeNewPlayerMethod = m;
                     m.setAccessible(true);
                     break;
                  }
               }
            }

            if (placeNewPlayerMethod != null) {
               try {
                  Channel fakeChannel = fakeNetworkManager.getFakeChannel();
                  this.registerWithPacketEvents(uuid, fakeChannel, name);
               } catch (Exception ex) {
                  LOGGER.warning("[SimpleNMSHandler] Failed to register with PacketEvents: " + ex.getMessage());
               }

               placeNewPlayerMethod.invoke(playerList, connection, entityPlayer, cookie);
               debug("[SimpleNMSHandler] Called placeNewPlayer for " + name);

               try {
                  this.savePlayerData(playerList, entityPlayer);
                  LOGGER.fine("[SimpleNMSHandler] Saved playerdata for " + name);
               } catch (Exception spdEx) {
                  LOGGER.fine("[SimpleNMSHandler] Could not save playerdata for " + name + ": " + spdEx.getMessage());
               }

               try {
                  Object api = Class.forName("com.github.retrooper.packetevents.PacketEvents").getMethod("getAPI").invoke((Object)null);
                  Method diagGetPM = api.getClass().getMethod("getProtocolManager");
                  diagGetPM.setAccessible(true);
                  Object pm = diagGetPM.invoke(api);
                  Class<?> pmIface = null;

                  for(Class<?> iface : pm.getClass().getInterfaces()) {
                     if (iface.getSimpleName().equals("ProtocolManager")) {
                        pmIface = iface;
                        break;
                     }
                  }

                  Field chField = pmIface.getDeclaredField("CHANNELS");
                  chField.setAccessible(true);
                  Field uField = pmIface.getDeclaredField("USERS");
                  uField.setAccessible(true);
                  Map<UUID, Object> channels = (Map)chField.get((Object)null);
                  Map<Object, Object> users = (Map)uField.get((Object)null);
                  Object ch = channels.get(uuid);
                  Object pipeline = ch != null ? ((Channel)ch).pipeline() : null;
                  Object user = pipeline != null ? users.get(pipeline) : null;
                  String var10000 = String.valueOf(uuid);
                  debug("[SimpleNMSHandler] DIAG POST-placeNewPlayer: uuid=" + var10000 + ", channel=" + (ch != null ? ch.getClass().getSimpleName() : "null") + ", user=" + (user != null ? "found" : "null") + ", CHANNELS size=" + channels.size() + " contains uuid=" + channels.containsKey(uuid) + ", USERS size=" + users.size() + " contains pipeline=" + (pipeline != null && users.containsKey(pipeline)));
                  ClassLoader ourLoader = this.getClass().getClassLoader();
                  ClassLoader peLoader = pmIface.getClassLoader();
                  var10000 = String.valueOf(ourLoader);
                  debug("[SimpleNMSHandler] DIAG ClassLoader: our=" + var10000 + ", pe=" + String.valueOf(peLoader) + ", same=" + (ourLoader == peLoader));
               } catch (Exception diagEx) {
                  debug("[SimpleNMSHandler] DIAG failed: " + String.valueOf(diagEx));
               }
            } else {
               LOGGER.warning("[SimpleNMSHandler] placeNewPlayer method not found, falling back to manual registration");
               this.manualRegisterWithPlayerList(playerList, entityPlayer, craftPlayer, uuid, name);
            }
         } catch (Exception e) {
            LOGGER.warning("[SimpleNMSHandler] UltraSpoof approach failed: " + e.getMessage() + ", trying manual registration");
            e.printStackTrace();
            this.manualRegisterWithPlayerList(playerList, entityPlayer, craftPlayer, uuid, name);
         }
      } catch (Exception e) {
         LOGGER.warning("[SimpleNMSHandler] Failed to register with player list: " + e.getMessage());
         e.printStackTrace();
      }

   }

   private void manualRegisterWithPlayerList(Object playerList, Object entityPlayer, Player craftPlayer, UUID uuid, String name) {
      try {
         for(Field f : playerList.getClass().getDeclaredFields()) {
            if (Map.class.isAssignableFrom(f.getType())) {
               f.setAccessible(true);
               Map<Object, Object> map = (Map)f.get(playerList);
               if (map != null && !map.isEmpty()) {
                  Object firstKey = map.keySet().iterator().next();
                  if (firstKey instanceof UUID) {
                     map.put(uuid, entityPlayer);
                     debug("[SimpleNMSHandler] Added to UUID map in PlayerList");
                  } else if (firstKey instanceof String) {
                     map.put(name, entityPlayer);
                     map.put(name.toLowerCase(), entityPlayer);
                     debug("[SimpleNMSHandler] Added to name map in PlayerList");
                  }
               }
            }
         }

         for(Field f : playerList.getClass().getDeclaredFields()) {
            if (List.class.isAssignableFrom(f.getType())) {
               f.setAccessible(true);
               List<Object> list = (List)f.get(playerList);
               if (list != null && !list.contains(entityPlayer) && (list.isEmpty() || entityPlayerClass.isInstance(list.get(0)))) {
                  list.add(entityPlayer);
                  debug("[SimpleNMSHandler] Added to players list in PlayerList");
                  break;
               }
            }
         }

         try {
            Object craftServer = craftServerClass.cast(Bukkit.getServer());

            for(Field f : craftServerClass.getDeclaredFields()) {
               if (List.class.isAssignableFrom(f.getType())) {
                  f.setAccessible(true);
                  Object fieldValue = f.get(craftServer);
                  if (fieldValue instanceof List) {
                     List<Object> list = (List)fieldValue;
                     if ((list.isEmpty() || list.get(0) instanceof Player) && !list.contains(craftPlayer)) {
                        list.add(craftPlayer);
                        debug("[SimpleNMSHandler] Added to Bukkit player list: " + f.getName());
                     }
                  }
               } else if (Set.class.isAssignableFrom(f.getType())) {
                  f.setAccessible(true);
                  Object fieldValue = f.get(craftServer);
                  if (fieldValue instanceof Set) {
                     Set<Object> set = (Set)fieldValue;
                     if (set.isEmpty()) {
                        set.add(craftPlayer);
                        debug("[SimpleNMSHandler] Added to empty Bukkit player set: " + f.getName());
                     } else {
                        Object first = set.iterator().next();
                        if (first instanceof Player) {
                           set.add(craftPlayer);
                           debug("[SimpleNMSHandler] Added to Bukkit player set: " + f.getName());
                        }
                     }
                  }
               } else if (Map.class.isAssignableFrom(f.getType())) {
                  f.setAccessible(true);
                  Object fieldValue = f.get(craftServer);
                  if (fieldValue instanceof Map) {
                     Map<Object, Object> map = (Map)fieldValue;
                     if (!map.isEmpty()) {
                        Object firstKey = map.keySet().iterator().next();
                        Object firstValue = map.values().iterator().next();
                        if (firstValue instanceof Player) {
                           if (firstKey instanceof UUID) {
                              map.put(uuid, craftPlayer);
                              debug("[SimpleNMSHandler] Added to Bukkit UUID map: " + f.getName());
                           } else if (firstKey instanceof String) {
                              map.put(name, craftPlayer);
                              map.put(name.toLowerCase(), craftPlayer);
                              debug("[SimpleNMSHandler] Added to Bukkit name map: " + f.getName());
                           }
                        }
                     }
                  }
               }
            }
         } catch (Exception e) {
            debug("[SimpleNMSHandler] Could not add to Bukkit player list: " + e.getMessage());
         }
      } catch (Exception e) {
         LOGGER.warning("[SimpleNMSHandler] Manual registration failed: " + e.getMessage());
      }

   }

   private Object createCommonListenerCookie(Object gameProfile) {
      try {
         Class<?> cookieClass = Class.forName("net.minecraft.server.network.CommonListenerCookie");

         for(Method m : cookieClass.getMethods()) {
            if ((m.getName().equals("a") || m.getName().equals("create")) && m.getParameterCount() == 2 && m.getParameterTypes()[0].getName().contains("GameProfile")) {
               return m.invoke((Object)null, gameProfile, true);
            }
         }

         for(Constructor<?> c : cookieClass.getConstructors()) {
            Class<?>[] params = c.getParameterTypes();
            if (params.length >= 1 && params[0].getName().contains("GameProfile")) {
               c.setAccessible(true);
               Object[] args = new Object[params.length];
               args[0] = gameProfile;

               for(int i = 1; i < params.length; ++i) {
                  args[i] = this.getDefaultValue(params[i]);
               }

               return c.newInstance(args);
            }
         }

         return null;
      } catch (Exception e) {
         debug("[SimpleNMSHandler] Could not create CommonListenerCookie: " + e.getMessage());
         return null;
      }
   }

   private Object getDefaultValue(Class<?> type) {
      if (type == Boolean.TYPE) {
         return false;
      } else if (type == Integer.TYPE) {
         return 0;
      } else if (type == Long.TYPE) {
         return 0L;
      } else if (type == Float.TYPE) {
         return 0.0F;
      } else if (type == Double.TYPE) {
         return (double)0.0F;
      } else {
         return type == String.class ? "" : null;
      }
   }

   private void registerWithPacketEvents(UUID uuid, Object channel, String playerName) {
      try {
         Object api = Class.forName("com.github.retrooper.packetevents.PacketEvents").getMethod("getAPI").invoke((Object)null);
         Method getPM = api.getClass().getMethod("getProtocolManager");
         getPM.setAccessible(true);
         Object pm = getPM.invoke(api);
         Class<?> pmIface = null;

         for(Class<?> iface : pm.getClass().getInterfaces()) {
            if (iface.getSimpleName().equals("ProtocolManager")) {
               pmIface = iface;
               break;
            }
         }

         if (pmIface == null) {
            LOGGER.warning("[SimpleNMSHandler] Could not find ProtocolManager interface on " + pm.getClass().getName());
            return;
         }

         Field channelsField = pmIface.getDeclaredField("CHANNELS");
         channelsField.setAccessible(true);
         Map<UUID, Object> channels = (Map)channelsField.get((Object)null);
         channels.put(uuid, channel);

         try {
            Class<?> userClass = null;
            Class<?> connStateClass = null;
            Class<?> clientVersionClass = null;
            Class<?> userProfileClass = null;
            ClassLoader peLoader = pmIface.getClassLoader();
            userClass = Class.forName("com.github.retrooper.packetevents.protocol.player.User", true, peLoader);
            connStateClass = Class.forName("com.github.retrooper.packetevents.protocol.ConnectionState", true, peLoader);
            clientVersionClass = Class.forName("com.github.retrooper.packetevents.protocol.player.ClientVersion", true, peLoader);
            userProfileClass = Class.forName("com.github.retrooper.packetevents.protocol.player.UserProfile", true, peLoader);
            Object playState = Enum.valueOf(connStateClass, "PLAY");
            Object latestVersion = clientVersionClass.getMethod("getLatest").invoke((Object)null);
            Object userProfile = userProfileClass.getConstructor(UUID.class, String.class).newInstance(uuid, playerName);
            Object user = userClass.getConstructor(Object.class, connStateClass, clientVersionClass, userProfileClass).newInstance(channel, playState, latestVersion, userProfile);
            Object pipeline = ((Channel)channel).pipeline();
            Field usersField = pmIface.getDeclaredField("USERS");
            usersField.setAccessible(true);
            Map<Object, Object> users = (Map)usersField.get((Object)null);
            users.put(pipeline, user);
            debug("[SimpleNMSHandler] Registered User+Channel with PacketEvents for " + playerName + " (" + String.valueOf(uuid) + ") [channels=" + channels.size() + ", users=" + users.size() + "]");
         } catch (Exception e) {
            LOGGER.warning("[SimpleNMSHandler] Failed to create PacketEvents User for " + playerName + ": " + e.getMessage());
         }
      } catch (ClassNotFoundException var23) {
         LOGGER.fine("[SimpleNMSHandler] PacketEvents not present, skipping registration");
      } catch (Exception e) {
         LOGGER.warning("[SimpleNMSHandler] Failed to register with PacketEvents: " + e.getMessage());
      }

   }

   private String generateFakeIP() {
      int[] firstOctets = new int[]{24, 31, 45, 64, 68, 71, 72, 74, 75, 76, 98, 99, 107, 108, 134, 173, 174, 184};
      int first = firstOctets[RANDOM.nextInt(firstOctets.length)];
      return first + "." + RANDOM.nextInt(256) + "." + RANDOM.nextInt(256) + "." + (1 + RANDOM.nextInt(254));
   }

   private void broadcastPlayerInfo(Object entityPlayer, boolean add) {
      try {
         Object gameProfile = entityPlayerClass.getMethod("getGameProfile").invoke(entityPlayer);
         String playerName = this.getProfileName(gameProfile);
         UUID uuid = this.getProfileUUID(gameProfile);
         if (!add) {
            try {
               Class<?> removePacketClass = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket");
               Constructor<?> removeConstructor = removePacketClass.getConstructor(List.class);
               Object packet = removeConstructor.newInstance(Collections.singletonList(uuid));
               this.broadcastPacketToAll(packet);
               debug("[SimpleNMSHandler] Broadcast PlayerInfo REMOVE for " + playerName);
               return;
            } catch (ClassNotFoundException var18) {
               debug("[SimpleNMSHandler] RemovePacket class not found, trying update packet");
            } catch (Exception e) {
               debug("[SimpleNMSHandler] RemovePacket failed: " + e.getMessage());
            }
         }

         try {
            Class<?> packetClass = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket");
            Class<?> actionClass = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket$Action");
            if (add) {
               try {
                  Method createMethod = packetClass.getMethod("createPlayerInitializing", Collection.class);
                  Object packet = createMethod.invoke((Object)null, Collections.singletonList(entityPlayer));
                  this.broadcastPacketToAll(packet);
                  debug("[SimpleNMSHandler] Broadcast PlayerInfo ADD via createPlayerInitializing for " + playerName);
                  return;
               } catch (NoSuchMethodException var16) {
                  debug("[SimpleNMSHandler] createPlayerInitializing not found, trying constructor approach");
               } catch (Exception e) {
                  debug("[SimpleNMSHandler] createPlayerInitializing failed: " + e.getMessage());
               }

               try {
                  EnumSet actions = EnumSet.allOf(actionClass);
                  actions.clear();

                  for(Object action : actionClass.getEnumConstants()) {
                     String actionName = action.toString();
                     if (actionName.contains("ADD") || actionName.contains("INITIALIZING") || actionName.contains("LISTED") || actionName.contains("LATENCY") || actionName.contains("DISPLAY") || actionName.contains("NAME") || actionName.contains("GAME_MODE") || actionName.contains("MODEL") || actionName.contains("CHAT") || actionName.contains("UPDATE")) {
                        try {
                           actions.add(action);
                        } catch (Exception var15) {
                        }
                     }
                  }

                  if (actions.isEmpty()) {
                     actions = EnumSet.allOf(actionClass);
                  }

                  Constructor<?> packetConstructor = packetClass.getConstructor(EnumSet.class, Collection.class);
                  Object packet = packetConstructor.newInstance(actions, Collections.singletonList(entityPlayer));
                  this.broadcastPacketToAll(packet);
                  debug("[SimpleNMSHandler] Broadcast PlayerInfo ADD via constructor for " + playerName);
                  return;
               } catch (Exception e) {
                  debug("[SimpleNMSHandler] Constructor approach failed: " + e.getMessage());
               }
            } else {
               try {
                  Constructor<?> removeConstructor = packetClass.getConstructor(List.class);
                  Object packet = removeConstructor.newInstance(Collections.singletonList(uuid));
                  this.broadcastPacketToAll(packet);
                  debug("[SimpleNMSHandler] Broadcast PlayerInfo REMOVE via update packet for " + playerName);
                  return;
               } catch (Exception e) {
                  debug("[SimpleNMSHandler] Update packet removal failed: " + e.getMessage());
               }
            }
         } catch (ClassNotFoundException modernEx) {
            debug("[SimpleNMSHandler] Modern class not found: " + modernEx.getMessage());
         } catch (Exception modernEx) {
            Logger var10000 = LOGGER;
            String var10001 = modernEx.getClass().getSimpleName();
            var10000.warning("[SimpleNMSHandler] Modern approach failed: " + var10001 + " - " + modernEx.getMessage());
         }

         try {
            Class<?> playerInfoPacketClass = Class.forName("net.minecraft.network.protocol.game.PacketPlayOutPlayerInfo");
            Class<?> playerInfoActionClass = Class.forName("net.minecraft.network.protocol.game.PacketPlayOutPlayerInfo$EnumPlayerInfoAction");
            Object legacyAction = null;

            for(Object constant : playerInfoActionClass.getEnumConstants()) {
               if (constant.toString().equals(add ? "ADD_PLAYER" : "REMOVE_PLAYER")) {
                  legacyAction = constant;
                  break;
               }
            }

            Constructor<?> packetConstructor = playerInfoPacketClass.getConstructor(playerInfoActionClass, Collection.class);
            List<Object> players = Collections.singletonList(entityPlayer);
            Object packet = packetConstructor.newInstance(legacyAction, players);
            this.broadcastPacketToAll(packet);
            debug("[SimpleNMSHandler] Broadcast PlayerInfo (legacy) for " + playerName);
         } catch (ClassNotFoundException var20) {
            LOGGER.warning("[SimpleNMSHandler] Legacy PlayerInfo class not found");
         } catch (Exception legacyEx) {
            LOGGER.warning("[SimpleNMSHandler] Failed to broadcast PlayerInfo (legacy): " + legacyEx.getMessage());
         }
      } catch (Exception e) {
         LOGGER.warning("[SimpleNMSHandler] Failed to broadcast player info: " + e.getMessage());
      }

   }

   private void broadcastPingUpdate(Object entityPlayer) {
      try {
         Class<?> packetClass = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket");
         Class<?> actionClass = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket$Action");
         Object latencyAction = null;

         for(Object constant : actionClass.getEnumConstants()) {
            String name = constant.toString();
            debug("[SimpleNMSHandler] Action enum: " + name);
            if (name.contains("LATENCY") || name.contains("PING")) {
               latencyAction = constant;
               break;
            }
         }

         if (latencyAction == null) {
            LOGGER.warning("[SimpleNMSHandler] UPDATE_LATENCY action not found!");
            return;
         }

         debug("[SimpleNMSHandler] Found latency action: " + String.valueOf(latencyAction));
         EnumSet actions = EnumSet.of((Enum)latencyAction);
         Constructor<?> ctor = packetClass.getConstructor(EnumSet.class, Collection.class);
         Object packet = ctor.newInstance(actions, Collections.singletonList(entityPlayer));
         this.broadcastPacketToAll(packet);
         debug("[SimpleNMSHandler] Broadcast UPDATE_LATENCY packet to all players");
      } catch (Exception e) {
         LOGGER.warning("[SimpleNMSHandler] Could not broadcast ping update: " + e.getMessage());
         e.printStackTrace();
      }

   }

   private void broadcastPacketToAll(Object packet) {
      for(Player player : Bukkit.getOnlinePlayers()) {
         try {
            this.sendPacketToPlayer(player, packet);
         } catch (Exception var5) {
         }
      }

   }

   private void sendPacketToPlayer(Player player, Object packet) {
      try {
         Object craftPlayer = craftPlayerClass.cast(player);
         Method getHandleMethod = craftPlayerClass.getMethod("getHandle");
         Object entityPlayer = getHandleMethod.invoke(craftPlayer);
         Field connectionField = null;

         for(Field f : entityPlayer.getClass().getDeclaredFields()) {
            if (f.getType().getName().contains("ServerGamePacketListenerImpl") || f.getType().getName().contains("PlayerConnection")) {
               connectionField = f;
               break;
            }
         }

         if (connectionField == null) {
            connectionField = entityPlayer.getClass().getDeclaredField("c");
         }

         connectionField.setAccessible(true);
         Object connection = connectionField.get(entityPlayer);
         if (connection != null) {
            Method sendMethod = connection.getClass().getMethod("send", Class.forName("net.minecraft.network.protocol.Packet"));
            sendMethod.invoke(connection, packet);
         }
      } catch (Exception var11) {
      }

   }

   public void setupClientOptions(Player player) {
      try {
         player.setFlySpeed(0.1F);
         player.setWalkSpeed(0.2F);
      } catch (Exception e) {
         debug("[SimpleNMSHandler] Could not setup client options: " + e.getMessage());
      }

   }

   private void savePlayerData(Object playerList, Object entityPlayer) throws Exception {
      Object playerIo = null;

      for(Field f : playerList.getClass().getDeclaredFields()) {
         if (f.getType().getName().contains("PlayerDataStorage") || f.getType().getName().contains("ServerPlayerFileData")) {
            f.setAccessible(true);
            playerIo = f.get(playerList);
            break;
         }
      }

      if (playerIo == null) {
         LOGGER.fine("[SimpleNMSHandler] PlayerDataStorage field not found in PlayerList");
      } else {
         for(Method m : playerIo.getClass().getDeclaredMethods()) {
            if (m.getName().equals("save") && m.getParameterCount() == 1 && entityPlayerClass.isAssignableFrom(m.getParameterTypes()[0])) {
               m.setAccessible(true);
               m.invoke(playerIo, entityPlayer);
               return;
            }
         }

         LOGGER.fine("[SimpleNMSHandler] save(ServerPlayer) method not found on PlayerDataStorage");
      }
   }

   private void setupPostSpawn(Object entityPlayer) {
      this.setHasPlayedBefore(entityPlayer);
      this.setSleepingIgnored(entityPlayer);
      this.suppressAdvancements(entityPlayer);
   }

   private void setHasPlayedBefore(Object entityPlayer) {
      try {
         Method m = entityPlayer.getClass().getMethod("setHasPlayedBefore", Boolean.TYPE);
         m.invoke(entityPlayer, true);
      } catch (Exception var8) {
         try {
            for(Field f : entityPlayer.getClass().getDeclaredFields()) {
               if (f.getType() == Boolean.TYPE && !Modifier.isStatic(f.getModifiers())) {
                  String name = f.getName();
                  if (name.equals("hasPlayedBefore")) {
                     f.setAccessible(true);
                     f.setBoolean(entityPlayer, true);
                     debug("[SimpleNMSHandler] Set hasPlayedBefore = true");
                     return;
                  }
               }
            }
         } catch (Exception e) {
            debug("[SimpleNMSHandler] setHasPlayedBefore failed: " + e.getMessage());
         }

      }
   }

   private void setSleepingIgnored(Object entityPlayer) {
      try {
         Method m = entityPlayer.getClass().getMethod("setSleepingIgnored", Boolean.TYPE);
         m.invoke(entityPlayer, true);
         debug("[SimpleNMSHandler] Set sleepingIgnored = true");
      } catch (Exception var5) {
         try {
            Field f = entityPlayer.getClass().getDeclaredField("sleepingIgnored");
            f.setAccessible(true);
            f.setBoolean(entityPlayer, true);
            debug("[SimpleNMSHandler] Set sleepingIgnored field = true");
         } catch (Exception var4) {
            debug("[SimpleNMSHandler] sleepingIgnored not found");
         }
      }

   }

   private void suppressAdvancements(Object entityPlayer) {
      try {
         Class<?> playerAdvancementsClass = Class.forName("net.minecraft.server.PlayerAdvancements");
         Field advancementsField = null;

         for(Field f : entityPlayer.getClass().getDeclaredFields()) {
            if (playerAdvancementsClass.isAssignableFrom(f.getType()) && !Modifier.isStatic(f.getModifiers())) {
               advancementsField = f;
               f.setAccessible(true);
               break;
            }
         }

         if (advancementsField == null) {
            debug("[SimpleNMSHandler] advancements field not found on EntityPlayer");
            return;
         }

         Object server = this.getMinecraftServer();
         Method getFixerUpper = server.getClass().getMethod("getFixerUpper");
         Object datafixer = getFixerUpper.invoke(server);
         Method getPlayerList = server.getClass().getMethod("getPlayerList");
         Object playerList = getPlayerList.invoke(server);
         Method getAdvancements = server.getClass().getMethod("getAdvancements");
         Object advManager = getAdvancements.invoke(server);
         Path dataPath = this.plugin.getDataFolder().getParentFile().toPath();
         Constructor<?> ctor = playerAdvancementsClass.getDeclaredConstructor(Class.forName("com.mojang.datafixers.DataFixer"), playerList.getClass(), advManager.getClass(), Path.class, entityPlayer.getClass());
         ctor.setAccessible(true);
         Object advancements = ctor.newInstance(datafixer, playerList, advManager, dataPath, entityPlayer);
         Class<?>[] interfaces = playerAdvancementsClass.getInterfaces();
         if (interfaces.length > 0) {
            Object proxy = Proxy.newProxyInstance(playerAdvancementsClass.getClassLoader(), interfaces, (proxyObj, method, args) -> {
               String methodName = method.getName();
               return !"save".equals(methodName) && !"flushDirty".equals(methodName) ? method.invoke(advancements, args) : null;
            });
            advancementsField.set(entityPlayer, proxy);
         } else {
            advancementsField.set(entityPlayer, advancements);
         }

         debug("[SimpleNMSHandler] Replaced PlayerAdvancements with no-op");
      } catch (Exception e) {
         debug("[SimpleNMSHandler] Advancement suppression failed: " + e.getMessage());
      }

   }

   public void removeFakePlayer(UUID uuid) {
      Player craftPlayer = (Player)this.fakePlayers.get(uuid);
      if (craftPlayer != null) {
         this.removeFakePlayer(craftPlayer);
      } else {
         this.stopPlayerTicker(uuid);
         this.fakePlayerPings.remove(uuid);
         this.lookAtPlayers.remove(uuid);
         this.banned.remove(uuid);
         this.muted.remove(uuid);
         this.swingArmEnabled.remove(uuid);
         this.headMovementEnabled.remove(uuid);
      }

   }

   public void removeFakePlayer(Player player) {
      if (player != null) {
         UUID uuid = player.getUniqueId();

         try {
            Object entityPlayer = craftPlayerClass.getMethod("getHandle").invoke(craftPlayerClass.cast(player));
            if (entityPlayer != null) {
               this.broadcastPlayerInfo(entityPlayer, false);
               debug("[SimpleNMSHandler] Broadcast REMOVE packet for " + player.getName());
            }
         } catch (Exception e) {
            debug("[SimpleNMSHandler] Could not broadcast remove: " + e.getMessage());
         }

         try {
            Object minecraftServer = this.getMinecraftServer();
            Object playerList = minecraftServer.getClass().getMethod("getPlayerList").invoke(minecraftServer);
            if (playerList != null) {
               Object entityPlayer = craftPlayerClass.getMethod("getHandle").invoke(craftPlayerClass.cast(player));
               if (entityPlayer != null) {
                  playerList.getClass().getMethod("remove", entityPlayerClass).invoke(playerList, entityPlayer);
                  debug("[SimpleNMSHandler] Removed from server PlayerList");
               }
            }
         } catch (Exception e) {
            debug("[SimpleNMSHandler] Could not remove from PlayerList: " + e.getMessage());
         }

         this.stopPlayerTicker(uuid);
         this.fakePlayers.remove(uuid);
         this.fakePlayerPings.remove(uuid);
         this.lookAtPlayers.remove(uuid);
         this.banned.remove(uuid);
         this.muted.remove(uuid);
         this.swingArmEnabled.remove(uuid);
         this.headMovementEnabled.remove(uuid);
      }

   }

   public boolean isCompatible() {
      return minecraftServerClass != null && entityPlayerClass != null && craftPlayerClass != null;
   }

   public String getVersion() {
      if (craftServerClass != null) {
         String className = craftServerClass.getName();
         int idx = className.indexOf(".craftbukkit.");
         if (idx > 0) {
            return className.substring(idx + 12, className.indexOf(".", idx + 12));
         }
      }

      return "unknown";
   }

   public boolean isFakePlayer(Player player) {
      return player != null && this.fakePlayers.containsKey(player.getUniqueId());
   }

   public boolean isFakePlayer(UUID uuid) {
      return this.fakePlayers.containsKey(uuid);
   }

   public void performAction(Player player, NMSHandler.FakePlayerAction action) {
      if (action == NMSHandler.FakePlayerAction.DAMAGE_ANIMATION) {
         try {
            Object serverPlayer = this.getServerPlayer(player);
            if (serverPlayer != null) {
               this.setEntityHurtTime(serverPlayer, 10);
               this.sendHurtAnimationPacket(serverPlayer, player.getLocation().getYaw());
            }
         } catch (Exception e) {
            debug("[SimpleNMSHandler] DAMAGE_ANIMATION failed: " + e.getMessage());
         }
      }

   }

   public void updatePosition(Player player, Location location, boolean smooth) {
      if (player != null && location != null) {
         player.teleport(location);
      }

   }

   public void updateRotation(Player player, float yaw, float pitch) {
      if (player != null) {
         Location loc = player.getLocation();
         loc.setYaw(yaw);
         loc.setPitch(pitch);
         player.teleport(loc);
      }

   }

   public void registerWithPlugin(Plugin plugin) {
   }

   public Player getFakePlayer(UUID uuid) {
      return (Player)this.fakePlayers.get(uuid);
   }

   public Player getFakePlayer(String name) {
      for(Player player : this.fakePlayers.values()) {
         if (player.getName().equalsIgnoreCase(name)) {
            return player;
         }
      }

      return null;
   }

   public int getPing(UUID uuid) {
      return (Integer)this.fakePlayerPings.getOrDefault(uuid, 50);
   }

   public int getFakePlayerCount() {
      return this.fakePlayers.size();
   }

   public void setLookAtPlayers(UUID uuid, boolean enabled) {
      this.lookAtPlayers.put(uuid, enabled);
   }

   public boolean isLookingAtPlayers(UUID uuid) {
      return (Boolean)this.lookAtPlayers.getOrDefault(uuid, false);
   }

   public void setVisibleInWorld(UUID uuid, boolean visible) {
   }

   public boolean isVisibleInWorld(UUID uuid) {
      return true;
   }

   public void setVisibleInTab(UUID uuid, boolean visible) {
   }

   public void setVisibleInPing(UUID uuid, boolean visible) {
   }

   public void sendEntityMetadata(Player viewer, FakePlayer fake, int entityId, boolean isSprinting) {
   }

   public void sendEntityAnimation(Player viewer, int entityId, int animationId) {
   }

   public void sendEntityVelocity(Player viewer, Player entity, double vx, double vy, double vz) {
   }

   public String getRandomSkinName() {
      return SKIN_POOL[RANDOM.nextInt(SKIN_POOL.length)];
   }

   public void setSwingArmEnabled(UUID uuid, boolean enabled) {
      if (enabled) {
         this.swingArmEnabled.add(uuid);
      } else {
         this.swingArmEnabled.remove(uuid);
      }

   }

   public boolean isSwingArmEnabled(UUID uuid) {
      return this.swingArmEnabled.contains(uuid);
   }

   public void setHeadMovementEnabled(UUID uuid, boolean enabled) {
      if (enabled) {
         this.headMovementEnabled.add(uuid);
      } else {
         this.headMovementEnabled.remove(uuid);
      }

   }

   public boolean isHeadMovementEnabled(UUID uuid) {
      return this.headMovementEnabled.contains(uuid);
   }

   public void damageFakePlayer(UUID uuid, double damage, Object source) {
      Player player = (Player)this.fakePlayers.get(uuid);
      if (player != null) {
         try {
            player.damage(damage);
         } catch (Exception e) {
            debug("[SimpleNMSHandler] Could not damage fake player: " + e.getMessage());
         }
      }

   }

   public void killFakePlayer(UUID uuid, Object source) {
      Player player = (Player)this.fakePlayers.get(uuid);
      if (player != null) {
         try {
            player.setHealth((double)0.0F);
         } catch (Exception e) {
            debug("[SimpleNMSHandler] Could not kill fake player: " + e.getMessage());
         }
      }

   }

   public void setBanned(UUID uuid, boolean isBanned) {
      this.banned.put(uuid, isBanned);
   }

   public boolean isBanned(UUID uuid) {
      return (Boolean)this.banned.getOrDefault(uuid, false);
   }

   public void setMuted(UUID uuid, boolean isMuted) {
      this.muted.put(uuid, isMuted);
   }

   public boolean isMuted(UUID uuid) {
      return (Boolean)this.muted.getOrDefault(uuid, false);
   }

   public void updatePing(UUID uuid) {
      int currentPing = (Integer)this.fakePlayerPings.getOrDefault(uuid, 50);
      int variance = RANDOM.nextInt(15) - 7;
      int newPing = Math.max(10, Math.min(400, currentPing + variance));
      this.fakePlayerPings.put(uuid, newPing);
      Player craftPlayer = (Player)this.fakePlayers.get(uuid);
      if (craftPlayer != null) {
         try {
            Object handle = craftPlayerClass.getMethod("getHandle").invoke(craftPlayerClass.cast(craftPlayer));
            if (handle != null) {
               this.setPingField(handle, newPing);
               this.broadcastPingUpdate(handle);
            }
         } catch (Exception e) {
            debug("[SimpleNMSHandler] Could not update ping on EntityPlayer: " + e.getMessage());
         }
      }

   }

   public NMSAdvancementManager getAdvancementManager() {
      if (this.advancementManager == null) {
         this.advancementManager = new NMSAdvancementManager(this.useModernNMS, this.nmsPackage);
      }

      return this.advancementManager;
   }

   public NMSFoodManager getFoodManager() {
      if (this.foodManager == null) {
         this.foodManager = new NMSFoodManager(this.useModernNMS, this.nmsPackage);
      }

      return this.foodManager;
   }

   public NMSRecipeManager getRecipeManager() {
      if (this.recipeManager == null) {
         this.recipeManager = new NMSRecipeManager(this.useModernNMS, this.nmsPackage);
      }

      return this.recipeManager;
   }

   public NMSDeathManager getDeathManager() {
      if (this.deathManager == null) {
         this.deathManager = new NMSDeathManager(this.useModernNMS, this.nmsPackage);
      }

      return this.deathManager;
   }

   public NMSStatisticsManager getStatisticsManager() {
      if (this.statisticsManager == null) {
         this.statisticsManager = new NMSStatisticsManager(this.useModernNMS, this.nmsPackage);
      }

      return this.statisticsManager;
   }

   private UUID getProfileUUID(Object gameProfile) {
      try {
         Method m = gameProfile.getClass().getMethod("getId");
         return (UUID)m.invoke(gameProfile);
      } catch (Exception var5) {
         try {
            Method m = gameProfile.getClass().getMethod("id");
            return (UUID)m.invoke(gameProfile);
         } catch (Exception var4) {
            try {
               Field f = gameProfile.getClass().getDeclaredField("id");
               f.setAccessible(true);
               return (UUID)f.get(gameProfile);
            } catch (Exception var3) {
               return null;
            }
         }
      }
   }

   private String getProfileName(Object gameProfile) {
      try {
         Method m = gameProfile.getClass().getMethod("getName");
         return (String)m.invoke(gameProfile);
      } catch (Exception var5) {
         try {
            Method m = gameProfile.getClass().getMethod("name");
            return (String)m.invoke(gameProfile);
         } catch (Exception var4) {
            try {
               Field f = gameProfile.getClass().getDeclaredField("name");
               f.setAccessible(true);
               return (String)f.get(gameProfile);
            } catch (Exception var3) {
               return null;
            }
         }
      }
   }

   public void shutdown() {
      this.stopAllTickers();
      this.fakePlayers.clear();
      this.fakePlayerPings.clear();
      this.lookAtPlayers.clear();
      this.banned.clear();
      this.muted.clear();
      this.swingArmEnabled.clear();
      this.headMovementEnabled.clear();
   }

   private Object createGameProfileWithSkin(UUID uuid, String name, String skinName) {
      try {
         SkinFetcher.SkinData skinData = this.fetchSkinData(skinName);
         if (skinData == null) {
            LOGGER.warning("[SimpleNMSHandler] Could not fetch skin for: " + skinName + ", creating profile without skin");
            return new GameProfile(uuid, name);
         } else {
            debug("[SimpleNMSHandler] Got skin data for " + skinName + ", value length: " + skinData.value.length());
            Property textureProperty = skinData.signature != null && !skinData.signature.isEmpty() ? new Property("textures", skinData.value, skinData.signature) : new Property("textures", skinData.value);
            ImmutableMultimap<String, Property> multimap = ImmutableMultimap.builder().put("textures", textureProperty).build();
            PropertyMap propertyMap = this.createPropertyMap(multimap);
            if (propertyMap == null) {
               LOGGER.warning("[SimpleNMSHandler] Could not create PropertyMap, creating profile without skin");
               return new GameProfile(uuid, name);
            } else {
               GameProfile profile = this.createProfileWithProperties(uuid, name, propertyMap);
               debug("[SimpleNMSHandler] Successfully created GameProfile with skin " + skinName);
               return profile;
            }
         }
      } catch (Exception e) {
         LOGGER.warning("[SimpleNMSHandler] Failed to create GameProfile with skin: " + e.getMessage());
         e.printStackTrace();

         try {
            return new GameProfile(uuid, name);
         } catch (Exception var9) {
            return null;
         }
      }
   }

   private PropertyMap createPropertyMap(Multimap<String, Property> multimap) {
      try {
         Constructor<?> ctor = PropertyMap.class.getDeclaredConstructor(Multimap.class);
         ctor.setAccessible(true);
         return (PropertyMap)ctor.newInstance(multimap);
      } catch (Exception e) {
         debug("[SimpleNMSHandler] PropertyMap(Multimap) constructor failed: " + e.getMessage());

         for(Constructor<?> ctor : PropertyMap.class.getDeclaredConstructors()) {
            try {
               ctor.setAccessible(true);
               Class<?>[] params = ctor.getParameterTypes();
               Object[] args = new Object[params.length];

               for(int i = 0; i < params.length; ++i) {
                  if (Multimap.class.isAssignableFrom(params[i])) {
                     args[i] = multimap;
                  }
               }

               PropertyMap pm = (PropertyMap)ctor.newInstance(args);
               if (pm != null && !pm.isEmpty()) {
                  return pm;
               }
            } catch (Exception var10) {
            }
         }

         try {
            PropertyMap pm = new PropertyMap();

            for(Class<?> current = PropertyMap.class; current != null; current = current.getSuperclass()) {
               for(Field f : current.getDeclaredFields()) {
                  if (Multimap.class.isAssignableFrom(f.getType())) {
                     f.setAccessible(true);
                     f.set(pm, multimap);
                     return pm;
                  }
               }
            }
         } catch (Exception e) {
            debug("[SimpleNMSHandler] PropertyMap delegate injection failed: " + e.getMessage());
         }

         return null;
      }
   }

   private GameProfile createProfileWithProperties(UUID uuid, String name, PropertyMap propertyMap) {
      try {
         Constructor<?> ctor = GameProfile.class.getDeclaredConstructor(UUID.class, String.class, PropertyMap.class);
         ctor.setAccessible(true);
         return (GameProfile)ctor.newInstance(uuid, name, propertyMap);
      } catch (Exception e) {
         debug("[SimpleNMSHandler] 3-arg GameProfile constructor failed: " + e.getMessage());

         try {
            GameProfile profile = new GameProfile(uuid, name);

            for(Field f : GameProfile.class.getDeclaredFields()) {
               if (PropertyMap.class.isAssignableFrom(f.getType())) {
                  f.setAccessible(true);

                  try {
                     Field modifiersField = Field.class.getDeclaredField("modifiers");
                     modifiersField.setAccessible(true);
                     modifiersField.setInt(f, f.getModifiers() & -17);
                  } catch (Exception var10) {
                  }

                  f.set(profile, propertyMap);
                  debug("[SimpleNMSHandler] Replaced PropertyMap in GameProfile via field");
                  return profile;
               }
            }

            LOGGER.warning("[SimpleNMSHandler] Could not find PropertyMap field in GameProfile");
            return profile;
         } catch (Exception e) {
            LOGGER.warning("[SimpleNMSHandler] Profile creation fallback failed: " + e.getMessage());
            return new GameProfile(uuid, name);
         }
      }
   }

   private void setPingField(Object entityPlayer, int pingValue) {
      Object connection = this.getConnectionFromPlayer(entityPlayer);
      if (connection != null) {
         this.setConnectionLatency(connection, pingValue);
      } else {
         LOGGER.warning("[SimpleNMSHandler] Could not get connection from EntityPlayer for ping setting!");
      }

      for(String fieldName : new String[]{"f", "e", "d", "ping", "latency"}) {
         try {
            Field field = null;

            for(Class<?> clazz = entityPlayerClass; clazz != null; clazz = clazz.getSuperclass()) {
               try {
                  field = clazz.getDeclaredField(fieldName);
                  break;
               }
            }

            if (field != null && (field.getType() == Integer.TYPE || field.getType() == Integer.class) && (field.getModifiers() & 8) == 0) {
               field.setAccessible(true);
               field.setInt(entityPlayer, pingValue);
               debug("[SimpleNMSHandler] Set EntityPlayer ping field '" + fieldName + "' to " + pingValue);
               break;
            }
         } catch (Exception var12) {
         }
      }

   }

   private Object getConnectionFromPlayer(Object entityPlayer) {
      try {
         Method getConnection = entityPlayer.getClass().getMethod("getConnection");
         Object conn = getConnection.invoke(entityPlayer);
         if (conn != null) {
            debug("[SimpleNMSHandler] Got connection via getConnection() method: " + conn.getClass().getName());
            return conn;
         }
      } catch (Exception e) {
         debug("[SimpleNMSHandler] getConnection() method failed: " + e.getMessage());
      }

      for(String fieldName : new String[]{"connection", "c", "b", "h"}) {
         try {
            Field field = null;

            for(Class<?> clazz = entityPlayer.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
               try {
                  field = clazz.getDeclaredField(fieldName);
                  break;
               }
            }

            if (field != null) {
               field.setAccessible(true);
               Object conn = field.get(entityPlayer);
               if (conn != null) {
                  debug("[SimpleNMSHandler] Got connection via field '" + fieldName + "': " + conn.getClass().getName());
                  return conn;
               }
            }
         } catch (Exception var12) {
         }
      }

      for(Field f : entityPlayer.getClass().getDeclaredFields()) {
         String typeName = f.getType().getName();
         if (typeName.contains("ServerGamePacketListenerImpl") || typeName.contains("ServerCommonPacketListener") || typeName.contains("PlayerConnection")) {
            try {
               f.setAccessible(true);
               Object conn = f.get(entityPlayer);
               if (conn != null) {
                  String var10000 = f.getName();
                  debug("[SimpleNMSHandler] Got connection via field scan, field '" + var10000 + "': " + conn.getClass().getName());
                  return conn;
               }
            } catch (Exception var9) {
            }
         }
      }

      return null;
   }

   private void setConnectionLatency(Object connection, int pingValue) {
      try {
         Class<?> commonClass = Class.forName("net.minecraft.server.network.ServerCommonPacketListenerImpl");
         if (this.trySetLatencyField(connection, commonClass, pingValue)) {
            return;
         }
      } catch (ClassNotFoundException var5) {
      }

      try {
         Class<?> gameClass = Class.forName("net.minecraft.server.network.ServerGamePacketListenerImpl");
         if (this.trySetLatencyField(connection, gameClass, pingValue)) {
            return;
         }
      } catch (ClassNotFoundException var4) {
      }

      for(Class<?> connClass = connection.getClass(); connClass != null; connClass = connClass.getSuperclass()) {
         if (this.trySetLatencyField(connection, connClass, pingValue)) {
            return;
         }
      }

      LOGGER.warning("[SimpleNMSHandler] Could not find ANY instance latency field on connection!");
   }

   private boolean trySetLatencyField(Object connection, Class<?> clazz, int pingValue) {
      for(String fieldName : new String[]{"latency", "ping", "averagePing", "connectionLatency", "o", "h", "i", "j", "k", "l", "m", "n", "p", "q"}) {
         try {
            Field field = clazz.getDeclaredField(fieldName);
            if ((field.getModifiers() & 8) == 0 && (field.getType() == Integer.TYPE || field.getType() == Long.TYPE)) {
               field.setAccessible(true);
               if (field.getType() == Integer.TYPE) {
                  field.setInt(connection, pingValue);
               } else {
                  field.setLong(connection, (long)pingValue);
               }

               debug("[SimpleNMSHandler] Set latency field '" + fieldName + "' on " + clazz.getSimpleName() + " to " + pingValue);
               return true;
            }
         } catch (NoSuchFieldException var9) {
         } catch (Exception e) {
            debug("[SimpleNMSHandler] Skipped '" + fieldName + "' on " + clazz.getSimpleName() + ": " + e.getMessage());
         }
      }

      return false;
   }

   private SkinFetcher.SkinData fetchSkinData(String skinName) {
      try {
         String uuidUrl = "https://api.mojang.com/users/profiles/minecraft/" + skinName;
         debug("[SimpleNMSHandler] Fetching UUID from: " + uuidUrl);
         String uuidResponse = this.httpGet(uuidUrl);
         if (uuidResponse != null && !uuidResponse.isEmpty()) {
            debug("[SimpleNMSHandler] UUID response: " + uuidResponse);
            String uuidStr = this.parseJsonValue(uuidResponse, "id");
            if (uuidStr == null) {
               LOGGER.warning("[SimpleNMSHandler] Could not parse UUID from response");
               return null;
            } else {
               debug("[SimpleNMSHandler] Parsed UUID: " + uuidStr);
               UUID uuid = this.formatUUID(uuidStr);
               String var10000 = uuid.toString();
               String profileUrl = "https://sessionserver.mojang.com/session/minecraft/profile/" + var10000.replace("-", "") + "?unsigned=false";
               debug("[SimpleNMSHandler] Fetching profile from: " + profileUrl);
               String response = this.httpGet(profileUrl);
               if (response != null && !response.isEmpty()) {
                  debug("[SimpleNMSHandler] Profile response length: " + response.length());
                  int propsStart = response.indexOf("\"properties\"");
                  if (propsStart == -1) {
                     return null;
                  } else {
                     Matcher valueMatcher = Pattern.compile("\"value\"\\s*:\\s*\"([^\"]+)\"").matcher(response);
                     if (!valueMatcher.find(propsStart)) {
                        return null;
                     } else {
                        String value = valueMatcher.group(1);
                        String signature = "";
                        Matcher sigMatcher = Pattern.compile("\"signature\"\\s*:\\s*\"([^\"]+)\"").matcher(response);
                        if (sigMatcher.find(propsStart)) {
                           signature = sigMatcher.group(1);
                        }

                        return new SkinFetcher.SkinData(value, signature);
                     }
                  }
               } else {
                  LOGGER.warning("[SimpleNMSHandler] No profile response for UUID " + uuidStr);
                  return null;
               }
            }
         } else {
            LOGGER.warning("[SimpleNMSHandler] No UUID response for " + skinName);
            return null;
         }
      } catch (Exception e) {
         debug("[SimpleNMSHandler] Failed to fetch skin data for " + skinName + ": " + e.getMessage());
         return null;
      }
   }

   private String httpGet(String urlStr) {
      try {
         HttpURLConnection conn = (HttpURLConnection)(new URL(urlStr)).openConnection();
         conn.setRequestMethod("GET");
         conn.setRequestProperty("User-Agent", "GlideSpoofer/4.3");
         conn.setConnectTimeout(5000);
         conn.setReadTimeout(5000);
         if (conn.getResponseCode() != 200) {
            return null;
         } else {
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();

            String line;
            while((line = reader.readLine()) != null) {
               response.append(line);
            }

            reader.close();
            return response.toString();
         }
      } catch (Exception var6) {
         return null;
      }
   }

   private String parseJsonValue(String json, String key) {
      Pattern pattern = Pattern.compile("\"" + key + "\"\\s*:\\s*\"([^\"]+)\"");
      Matcher matcher = pattern.matcher(json);
      return matcher.find() ? matcher.group(1) : null;
   }

   private UUID formatUUID(String uuidStr) {
      if (uuidStr.contains("-")) {
         return UUID.fromString(uuidStr);
      } else {
         String var10000 = uuidStr.substring(0, 8);
         return UUID.fromString(var10000 + "-" + uuidStr.substring(8, 12) + "-" + uuidStr.substring(12, 16) + "-" + uuidStr.substring(16, 20) + "-" + uuidStr.substring(20));
      }
   }

   private Object getMinecraftServer() {
      try {
         Object craftServer = craftServerClass.cast(Bukkit.getServer());
         Method getServerMethod = craftServerClass.getMethod("getServer");
         return getServerMethod.invoke(craftServer);
      } catch (Exception var3) {
         return null;
      }
   }

   private Object getWorldServer(World world) {
      try {
         Object craftWorld = craftWorldClass.cast(world);
         Method getHandleMethod = craftWorldClass.getMethod("getHandle");
         return getHandleMethod.invoke(craftWorld);
      } catch (Exception var4) {
         return null;
      }
   }

   private Object createDefaultClientInformation() {
      try {
         Class<?> chatVisClass = Class.forName("net.minecraft.world.entity.player.ChatVisiblity");
         Class<?> armClass = Class.forName("net.minecraft.world.entity.player.HumanoidArm");
         Class<?> particleClass = Class.forName("net.minecraft.world.entity.player.ParticleStatus");
         Object systemChat = Enum.valueOf(chatVisClass, "SYSTEM");
         Object rightArm = Enum.valueOf(armClass, "RIGHT");
         Object minimalParticles = Enum.valueOf(particleClass, "MINIMAL");
         int viewDistance = Bukkit.getViewDistance();
         int modelCustomisation = 127;

         try {
            Constructor<?> ctor = clientInformationClass.getDeclaredConstructor(String.class, Integer.TYPE, chatVisClass, Boolean.TYPE, Integer.TYPE, armClass, Boolean.TYPE, Boolean.TYPE, particleClass);
            ctor.setAccessible(true);
            return ctor.newInstance("en_us", viewDistance, systemChat, false, modelCustomisation, rightArm, false, true, minimalParticles);
         } catch (NoSuchMethodException var15) {
            for(Method m : clientInformationClass.getDeclaredMethods()) {
               if (m.getReturnType() == clientInformationClass && m.getParameterCount() == 9) {
                  m.setAccessible(true);
                  return m.invoke((Object)null, "en_us", viewDistance, systemChat, false, modelCustomisation, rightArm, false, true, minimalParticles);
               }
            }
         }
      } catch (Exception e) {
         LOGGER.fine("[SimpleNMSHandler] Failed to create explicit ClientInformation: " + e.getMessage());
      }

      try {
         Method createDefault = clientInformationClass.getMethod("a");
         return createDefault.invoke((Object)null);
      } catch (Exception var14) {
         return null;
      }
   }

   private void setLocation(Object entityPlayer, Location location) {
      try {
         Method setPosMethod = entityPlayerClass.getMethod("b", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
         setPosMethod.invoke(entityPlayer, location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
      } catch (Exception e) {
         debug("[SimpleNMSHandler] Could not set location: " + e.getMessage());
      }

   }

   private Player getCraftPlayer(Object entityPlayer) {
      try {
         Method getBukkitEntityMethod = entityPlayerClass.getMethod("getBukkitEntity");
         return (Player)getBukkitEntityMethod.invoke(entityPlayer);
      } catch (Exception var3) {
         return null;
      }
   }

   private int generateRandomPing() {
      int maxPing = 200;
      if (this.plugin.getGuiListener() != null && this.plugin.getGuiListener().getGUI() != null) {
         maxPing = this.plugin.getGuiListener().getGUI().getMaxPing();
      }

      maxPing = Math.max(25, maxPing);
      double r = Math.random();
      if (r < 0.4) {
         return 5 + RANDOM.nextInt(Math.max(1, maxPing / 3));
      } else {
         return r < (double)0.75F ? maxPing / 3 + RANDOM.nextInt(maxPing / 3) : 2 * maxPing / 3 + RANDOM.nextInt(maxPing / 3 + 1);
      }
   }

   public void broadcastSittingPose(Object serverPlayer) {
      debug("[SimpleNMSHandler] broadcastSittingPose called (stub)");
   }

   public void setGuiMovementEnabled(UUID uuid, boolean enabled) {
      debug("[SimpleNMSHandler] setGuiMovementEnabled: " + enabled);
   }

   public boolean isGuiMovementEnabled(UUID uuid) {
      return false;
   }

   public void broadcastDamageAnimation(Object serverPlayer) {
      debug("[SimpleNMSHandler] broadcastDamageAnimation called (stub)");
   }

   public double getHealth(UUID uuid) {
      Player player = (Player)this.fakePlayers.get(uuid);
      return player != null ? player.getHealth() : (double)20.0F;
   }

   public Set<String> getFakePlayerNames() {
      Set<String> names = new HashSet();

      for(Player player : this.fakePlayers.values()) {
         names.add(player.getName());
      }

      return names;
   }

   public boolean isCurrentlySpawning(UUID uuid) {
      return false;
   }

   public Object getServerPlayer(Player player) {
      try {
         if (craftPlayerClass != null && craftPlayerClass.isInstance(player)) {
            Method getHandle = craftPlayerClass.getMethod("getHandle");
            return getHandle.invoke(player);
         }
      } catch (Exception e) {
         debug("[SimpleNMSHandler] Could not get server player: " + e.getMessage());
      }

      return null;
   }

   public void sendVelocityPacket(Object serverPlayer, double vx, double vy, double vz) {
      try {
         int entityId = (Integer)serverPlayer.getClass().getMethod("getId").invoke(serverPlayer);
         Class<?> packetClass = Class.forName("net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket");
         Constructor<?> ctor = packetClass.getConstructor(Integer.TYPE, Double.TYPE, Double.TYPE, Double.TYPE);
         Object packet = ctor.newInstance(entityId, vx, vy, vz);
         this.broadcastPacketToAll(packet);
      } catch (Exception e) {
         debug("[SimpleNMSHandler] sendVelocityPacket failed: " + e.getMessage());
      }

   }

   public void sendHurtAnimationPacket(Object serverPlayer, float yaw) {
      try {
         int entityId = (Integer)serverPlayer.getClass().getMethod("getId").invoke(serverPlayer);

         try {
            Class<?> packetClass = Class.forName("net.minecraft.network.protocol.game.ClientboundHurtAnimationPacket");
            Constructor<?> ctor = packetClass.getConstructor(Integer.TYPE, Float.TYPE);
            Object packet = ctor.newInstance(entityId, yaw);
            this.broadcastPacketToAll(packet);
         } catch (ClassNotFoundException var7) {
            this.setEntityHurtTime(serverPlayer, 10);
         }
      } catch (Exception e) {
         debug("[SimpleNMSHandler] sendHurtAnimationPacket failed: " + e.getMessage());
      }

   }

   private void setEntityHurtTime(Object serverPlayer, int ticks) {
      try {
         for(Class<?> c = serverPlayer.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            try {
               Field hurtTime = c.getDeclaredField("hurtTime");
               hurtTime.setAccessible(true);
               hurtTime.setInt(serverPlayer, ticks);
               break;
            }
         }

         for(Class<?> c = serverPlayer.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            try {
               Field hurtDuration = c.getDeclaredField("hurtDuration");
               hurtDuration.setAccessible(true);
               hurtDuration.setInt(serverPlayer, ticks);
               break;
            }
         }
      } catch (Exception var7) {
      }

   }

   public String getSkin(UUID uuid) {
      return this.getRandomSkinName();
   }

   private void initDoTickReflection(Object serverPlayer) {
      if (!this.doTickInitialized) {
         this.doTickInitialized = true;
         this.usingTickFallback = false;

         try {
            for(Class<?> clazz = serverPlayer.getClass(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
               try {
                  this.doTickMethod = clazz.getDeclaredMethod("doTick");
                  this.doTickMethod.setAccessible(true);
                  debug("[SimpleNMSHandler] Found doTick() on " + clazz.getSimpleName() + " — applyMovement will handle travel");
                  return;
               }
            }

            for(Class<?> clazz = serverPlayer.getClass(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
               try {
                  this.doTickMethod = clazz.getDeclaredMethod("tick");
                  this.doTickMethod.setAccessible(true);
                  this.usingTickFallback = true;
                  LOGGER.warning("[SimpleNMSHandler] Found tick() on " + clazz.getSimpleName() + " (fallback) — tick() includes travel, applyMovement will be SKIPPED to prevent double movement");
                  return;
               }
            }

            LOGGER.warning("[SimpleNMSHandler] Could not find doTick() or tick() method");
         } catch (Exception e) {
            LOGGER.warning("[SimpleNMSHandler] Failed to init doTick reflection: " + e.getMessage());
         }

         this.cacheLastActionTime(serverPlayer);
      }
   }

   private void cacheLastActionTime(Object serverPlayer) {
      try {
         this.resetLastActionTimeMethod = serverPlayer.getClass().getMethod("resetLastActionTime");
      } catch (NoSuchMethodException var7) {
         this.resetLastActionTimeMethod = null;
      }

      if (this.resetLastActionTimeMethod == null) {
         try {
            for(Field f : serverPlayer.getClass().getDeclaredFields()) {
               if (f.getType() == Long.TYPE && !Modifier.isStatic(f.getModifiers())) {
                  String name = f.getName();
                  if (name.equals("lastActionTime")) {
                     f.setAccessible(true);
                     this.lastActionTimeField = f;
                     return;
                  }
               }
            }
         } catch (Exception var8) {
         }

      }
   }

   private void resetLastActionTime(Object serverPlayer) {
      try {
         if (this.resetLastActionTimeMethod != null) {
            this.resetLastActionTimeMethod.invoke(serverPlayer);
         } else if (this.lastActionTimeField != null) {
            this.lastActionTimeField.setLong(serverPlayer, System.currentTimeMillis());
         }
      } catch (Exception var3) {
      }

   }

   private void initMoveReflection(Object serverPlayer) {
      if (!this.moveMethodsInit) {
         this.moveMethodsInit = true;

         try {
            Class<?> entityClass = Class.forName("net.minecraft.world.entity.Entity");
            Class<?> livingEntityClass = Class.forName("net.minecraft.world.entity.LivingEntity");
            this.vec3Class = Class.forName("net.minecraft.world.phys.Vec3");
            this.vec3Constructor = this.vec3Class.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE);

            try {
               this.getDeltaMovementMethod = entityClass.getMethod("getDeltaMovement");
               this.setDeltaMovementMethod = entityClass.getMethod("setDeltaMovement", this.vec3Class);
            } catch (Exception var9) {
            }

            for(Class<?> c = livingEntityClass; c != null && c != Object.class; c = c.getSuperclass()) {
               try {
                  if (this.zzaField == null) {
                     this.zzaField = c.getDeclaredField("zza");
                  }

                  if (this.xxaField == null) {
                     this.xxaField = c.getDeclaredField("xxa");
                  }
               } catch (NoSuchFieldException var8) {
               }
            }

            if (this.zzaField != null) {
               this.zzaField.setAccessible(true);
            }

            if (this.xxaField != null) {
               this.xxaField.setAccessible(true);
            }

            for(Class<?> c = entityClass; c != null && c != Object.class; c = c.getSuperclass()) {
               try {
                  this.entityMoveRelativeMethod = c.getDeclaredMethod("moveRelative", Float.TYPE, this.vec3Class);
                  this.entityMoveRelativeMethod.setAccessible(true);
                  break;
               }
            }

            Class<?> moverTypeClass = Class.forName("net.minecraft.world.entity.MoverType");
            Field selfField = moverTypeClass.getDeclaredField("SELF");
            selfField.setAccessible(true);
            this.moverTypeSelf = selfField.get((Object)null);

            for(Class<?> c = entityClass; c != null && c != Object.class; c = c.getSuperclass()) {
               try {
                  this.entityMoveMethod = c.getDeclaredMethod("move", moverTypeClass, this.vec3Class);
                  this.entityMoveMethod.setAccessible(true);
                  break;
               }
            }

            boolean var10000 = this.entityMoveRelativeMethod != null;
            debug("[SimpleNMSHandler] moveReflection: moveRelative=" + var10000 + " move=" + (this.entityMoveMethod != null) + " MoverType.SELF=" + (this.moverTypeSelf != null) + " zza=" + (this.zzaField != null) + " xxa=" + (this.xxaField != null));
         } catch (Exception e) {
            LOGGER.warning("[SimpleNMSHandler] Failed to init move reflection: " + e.getMessage());
         }

      }
   }

   public void applyMovement(Object serverPlayer) {
      if (this.moveMethodsInit && this.entityMoveRelativeMethod != null && this.entityMoveMethod != null) {
         try {
            float zza = 0.0F;
            float xxa = 0.0F;
            if (this.zzaField != null) {
               zza = this.zzaField.getFloat(serverPlayer);
            }

            if (this.xxaField != null) {
               xxa = this.xxaField.getFloat(serverPlayer);
            }

            float speed = 0.7F;

            try {
               Class<?> livingEntityClass = Class.forName("net.minecraft.world.entity.LivingEntity");
               Method getSpeedMethod = null;

               for(Class<?> c = serverPlayer.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                  try {
                     getSpeedMethod = c.getDeclaredMethod("getSpeed");
                     getSpeedMethod.setAccessible(true);
                     break;
                  }
               }

               if (getSpeedMethod != null) {
                  speed = (Float)getSpeedMethod.invoke(serverPlayer);
               }
            } catch (Exception var31) {
            }

            try {
               if ((Boolean)serverPlayer.getClass().getMethod("isSprinting").invoke(serverPlayer)) {
                  speed *= 1.3F;
               }
            } catch (Exception var27) {
            }

            try {
               if ((Boolean)serverPlayer.getClass().getMethod("isShiftKeyDown").invoke(serverPlayer)) {
                  speed *= 0.3F;
               }
            } catch (Exception var26) {
            }

            Object inputVec = this.vec3Constructor.newInstance((double)xxa, (double)0.0F, (double)zza);
            this.entityMoveRelativeMethod.invoke(serverPlayer, speed, inputVec);
            Object delta = null;

            try {
               if (this.getDeltaMovementMethod != null) {
                  delta = this.getDeltaMovementMethod.invoke(serverPlayer);
               }
            } catch (Exception var25) {
            }

            if (delta != null) {
               double dx = (Double)delta.getClass().getMethod("x").invoke(delta);
               double dy = (Double)delta.getClass().getMethod("y").invoke(delta);
               double dz = (Double)delta.getClass().getMethod("z").invoke(delta);
               if (Math.abs(dx) > 1.0E-7 || Math.abs(dy) > 1.0E-7 || Math.abs(dz) > 1.0E-7) {
                  double beforeY = (double)0.0F;

                  try {
                     beforeY = (Double)serverPlayer.getClass().getMethod("getY").invoke(serverPlayer);
                  } catch (Exception var24) {
                  }

                  this.entityMoveMethod.invoke(serverPlayer, this.moverTypeSelf, delta);
                  double afterY = (double)0.0F;

                  try {
                     afterY = (Double)serverPlayer.getClass().getMethod("getY").invoke(serverPlayer);
                  } catch (Exception var23) {
                  }

                  double actualDy = afterY - beforeY;
                  boolean onGround = false;

                  try {
                     for(Class<?> c = serverPlayer.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                        try {
                           Field ogf = c.getDeclaredField("onGround");
                           ogf.setAccessible(true);
                           onGround = ogf.getBoolean(serverPlayer);
                           break;
                        }
                     }
                  } catch (Exception var29) {
                  }

                  if (onGround) {
                     actualDy = (double)0.0F;
                  } else {
                     actualDy -= 0.04;
                  }

                  if (this.setDeltaMovementMethod != null && this.vec3Constructor != null) {
                     try {
                        this.setDeltaMovementMethod.invoke(serverPlayer, this.vec3Constructor.newInstance((double)0.0F, actualDy, (double)0.0F));
                     } catch (Exception var22) {
                     }
                  }
               }
            }
         } catch (Exception e) {
            debug("[FakePlayerTicker] applyMovement failed: " + e.getMessage());
         }

      }
   }

   private void startPlayerTicker(UUID uuid, Player player) {
      if (this.playerTickers.containsKey(uuid)) {
         debug("[SimpleNMSHandler] Ticker already exists for " + String.valueOf(uuid));
      } else {
         FakePlayerTickerRunnable ticker = new FakePlayerTickerRunnable(uuid, player);

         try {
            Object task = Bukkit.getScheduler().runTaskTimer(this.plugin, ticker, 1L, 1L);
            this.playerTickers.put(uuid, task);
            this.tickerInstances.put(uuid, ticker);
            debug("[SimpleNMSHandler] Started ticker for " + player.getName());
         } catch (Exception e) {
            Logger var10000 = LOGGER;
            String var10001 = player.getName();
            var10000.severe("[SimpleNMSHandler] Failed to start ticker for " + var10001 + ": " + e.getMessage());
         }

      }
   }

   private void stopPlayerTicker(UUID uuid) {
      Object task = this.playerTickers.remove(uuid);
      if (task != null) {
         try {
            Bukkit.getScheduler().cancelTask(((BukkitTask)task).getTaskId());
         } catch (Exception var4) {
         }
      }

      this.tickerInstances.remove(uuid);
   }

   private void stopAllTickers() {
      for(UUID uuid : this.playerTickers.keySet()) {
         this.stopPlayerTicker(uuid);
      }

   }

   static {
      try {
         minecraftServerClass = Class.forName("net.minecraft.server.MinecraftServer");
         worldServerClass = Class.forName("net.minecraft.server.level.WorldServer");
         entityPlayerClass = Class.forName("net.minecraft.server.level.EntityPlayer");
         gameProfileClass = Class.forName("com.mojang.authlib.GameProfile");
         clientInformationClass = Class.forName("net.minecraft.server.level.ClientInformation");
         String[] versions = new String[]{"v1_21_R7", "v1_21_R6", "v1_21_R5", "v1_21_R4", "v1_21_R3", "v1_21_R2", "v1_21_R1", "v1_20_R4", "v1_20_R3", "v1_20_R2", "v1_20_R1"};

         for(String version : versions) {
            try {
               craftServerClass = Class.forName("org.bukkit.craftbukkit." + version + ".CraftServer");
               craftWorldClass = Class.forName("org.bukkit.craftbukkit." + version + ".CraftWorld");
               craftPlayerClass = Class.forName("org.bukkit.craftbukkit." + version + ".entity.CraftPlayer");
               break;
            } catch (ClassNotFoundException var6) {
            }
         }
      } catch (ClassNotFoundException e) {
         LOGGER.warning("[SimpleNMSHandler] Failed to load NMS classes: " + e.getMessage());
      }

   }

   private class FakePlayerTickerRunnable implements Runnable {
      private final UUID uuid;
      private final Player player;
      private boolean firstTick = true;
      private boolean cancelled = false;

      FakePlayerTickerRunnable(UUID uuid, Player player) {
         this.uuid = uuid;
         this.player = player;
      }

      public void run() {
         if (!this.cancelled) {
            if (this.player.isOnline() && SimpleNMSHandler.this.fakePlayers.containsKey(this.uuid)) {
               try {
                  Object serverPlayer = SimpleNMSHandler.this.getServerPlayer(this.player);
                  if (serverPlayer == null) {
                     SimpleNMSHandler.debug("[FakePlayerTicker] serverPlayer is null for " + this.player.getName());
                     return;
                  }

                  if (!SimpleNMSHandler.this.doTickInitialized) {
                     SimpleNMSHandler.this.initDoTickReflection(serverPlayer);
                  }

                  if (!SimpleNMSHandler.this.moveMethodsInit) {
                     SimpleNMSHandler.this.initMoveReflection(serverPlayer);
                  }

                  if (SimpleNMSHandler.this.doTickMethod == null) {
                     SimpleNMSHandler.debug("[FakePlayerTicker] doTickMethod is null, skipping");
                     return;
                  }

                  if (this.firstTick) {
                     String var121 = this.player.getName();
                     SimpleNMSHandler.debug("[FakePlayerTicker] " + var121 + " using method=" + SimpleNMSHandler.this.doTickMethod.getName() + " on " + SimpleNMSHandler.this.doTickMethod.getDeclaringClass().getSimpleName() + " usingTickFallback=" + SimpleNMSHandler.this.usingTickFallback + " applyMovement=" + !SimpleNMSHandler.this.usingTickFallback);
                  }

                  if (this.firstTick) {
                     this.firstTick = false;

                     try {
                        double x = (double)0.0F;
                        double y = (double)0.0F;
                        double z = (double)0.0F;

                        try {
                           x = (Double)serverPlayer.getClass().getMethod("getX").invoke(serverPlayer);
                           y = (Double)serverPlayer.getClass().getMethod("getY").invoke(serverPlayer);
                           z = (Double)serverPlayer.getClass().getMethod("getZ").invoke(serverPlayer);
                        } catch (Exception var65) {
                        }

                        this.setPositionField(serverPlayer, "xo", x);
                        this.setPositionField(serverPlayer, "yo", y);
                        this.setPositionField(serverPlayer, "zo", z);
                        float savedZza = 0.0F;
                        float savedXxa = 0.0F;
                        if (SimpleNMSHandler.this.zzaField != null) {
                           savedZza = SimpleNMSHandler.this.zzaField.getFloat(serverPlayer);
                        }

                        if (SimpleNMSHandler.this.xxaField != null) {
                           savedXxa = SimpleNMSHandler.this.xxaField.getFloat(serverPlayer);
                        }

                        SimpleNMSHandler.this.doTickMethod.invoke(serverPlayer);
                        if (SimpleNMSHandler.this.zzaField != null) {
                           SimpleNMSHandler.this.zzaField.setFloat(serverPlayer, savedZza);
                        }

                        if (SimpleNMSHandler.this.xxaField != null) {
                           SimpleNMSHandler.this.xxaField.setFloat(serverPlayer, savedXxa);
                        }

                        try {
                           Location loc = this.player.getLocation();
                           Method absMoveTo = serverPlayer.getClass().getMethod("absMoveTo", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
                           absMoveTo.invoke(serverPlayer, x, y, z, loc.getYaw(), loc.getPitch());
                        } catch (NoSuchMethodException var64) {
                           try {
                              Method moveTo = serverPlayer.getClass().getMethod("absMoveTo", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
                              moveTo.invoke(serverPlayer, x, y, z, this.player.getLocation().getYaw(), this.player.getLocation().getPitch());
                           } catch (Exception var63) {
                           }
                        }

                        SimpleNMSHandler.debug("[FakePlayerTicker] First tick completed for " + this.player.getName());
                     } catch (Exception e) {
                        Logger var122 = SimpleNMSHandler.LOGGER;
                        String var10001 = this.player.getName();
                        var122.warning("[FakePlayerTicker] First tick failed for " + var10001 + ": " + e.getMessage());
                        this.runFallbackPhysics(serverPlayer);
                     }
                  } else {
                     Location bukkitPos = this.player.getLocation();
                     double bx = bukkitPos.getX();
                     double by = bukkitPos.getY();
                     double bz = bukkitPos.getZ();
                     float byaw = bukkitPos.getYaw();
                     float bpitch = bukkitPos.getPitch();

                     try {
                        double nx = (Double)serverPlayer.getClass().getMethod("getX").invoke(serverPlayer);
                        double ny = (Double)serverPlayer.getClass().getMethod("getY").invoke(serverPlayer);
                        double nz = (Double)serverPlayer.getClass().getMethod("getZ").invoke(serverPlayer);
                        double dist = Math.sqrt((bx - nx) * (bx - nx) + (by - ny) * (by - ny) + (bz - nz) * (bz - nz));
                        if (dist > 0.01) {
                           try {
                              Method absMoveTo = serverPlayer.getClass().getMethod("absMoveTo", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
                              absMoveTo.invoke(serverPlayer, bx, by, bz, byaw, bpitch);
                           } catch (NoSuchMethodException var61) {
                              Method setPos = serverPlayer.getClass().getMethod("setPos", Double.TYPE, Double.TYPE, Double.TYPE);
                              setPos.invoke(serverPlayer, bx, by, bz);
                           }
                        }
                     } catch (Exception var62) {
                     }

                     float savedZza = 0.0F;
                     float savedXxa = 0.0F;
                     if (SimpleNMSHandler.this.zzaField != null) {
                        try {
                           savedZza = SimpleNMSHandler.this.zzaField.getFloat(serverPlayer);
                        } catch (Exception var60) {
                        }
                     }

                     if (SimpleNMSHandler.this.xxaField != null) {
                        try {
                           savedXxa = SimpleNMSHandler.this.xxaField.getFloat(serverPlayer);
                        } catch (Exception var59) {
                        }
                     }

                     SimpleNMSHandler.this.doTickMethod.invoke(serverPlayer);
                     if (SimpleNMSHandler.this.zzaField != null) {
                        try {
                           SimpleNMSHandler.this.zzaField.setFloat(serverPlayer, savedZza);
                        } catch (Exception var58) {
                        }
                     }

                     if (SimpleNMSHandler.this.xxaField != null) {
                        try {
                           SimpleNMSHandler.this.xxaField.setFloat(serverPlayer, savedXxa);
                        } catch (Exception var57) {
                        }
                     }

                     FollowModeManager fmm = SimpleNMSHandler.this.plugin.getFollowModeManager();
                     if (fmm != null && fmm.isFollowing(this.uuid)) {
                        Player followTarget = fmm.getTarget(this.uuid);
                        if (followTarget != null && followTarget.isOnline() && followTarget.getWorld().equals(this.player.getWorld())) {
                           Location fakeLoc = this.player.getLocation();
                           Location targetLoc = followTarget.getLocation();
                           double dist = fakeLoc.distance(targetLoc);
                           if (dist >= (double)2.5F) {
                              double dx = targetLoc.getX() - fakeLoc.getX();
                              double dz = targetLoc.getZ() - fakeLoc.getZ();
                              float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));

                              try {
                                 serverPlayer.getClass().getMethod("setYRot", Float.TYPE).invoke(serverPlayer, yaw);
                              } catch (Exception var56) {
                              }

                              try {
                                 Method setYBodyRot = serverPlayer.getClass().getMethod("setYBodyRot", Float.TYPE);
                                 setYBodyRot.invoke(serverPlayer, yaw);
                              } catch (NoSuchMethodException var82) {
                                 try {
                                    for(Class<?> c = serverPlayer.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                                       try {
                                          Field ybr = c.getDeclaredField("yBodyRot");
                                          ybr.setAccessible(true);
                                          ybr.setFloat(serverPlayer, yaw);
                                          break;
                                       }
                                    }
                                 } catch (Exception var81) {
                                 }
                              }

                              if (SimpleNMSHandler.this.zzaField != null) {
                                 try {
                                    SimpleNMSHandler.this.zzaField.setFloat(serverPlayer, 1.0F);
                                 } catch (Exception var55) {
                                 }
                              }

                              this.player.setSprinting(dist > (double)8.0F);
                              double currentX = (double)0.0F;
                              double currentZ = (double)0.0F;

                              try {
                                 currentX = (Double)serverPlayer.getClass().getMethod("getX").invoke(serverPlayer);
                                 currentZ = (Double)serverPlayer.getClass().getMethod("getZ").invoke(serverPlayer);
                              } catch (Exception var54) {
                              }

                              double prevX = fmm.getPreviousX(this.uuid);
                              double prevZ = fmm.getPreviousZ(this.uuid);
                              double bdx = currentX - prevX;
                              double bdz = currentZ - prevZ;
                              boolean isBlocked = bdx * bdx + bdz * bdz < 0.001 && fmm.isFirstMoveDone(this.uuid);
                              boolean wallAhead = false;

                              try {
                                 World world = fakeLoc.getWorld();
                                 if (world != null) {
                                    double yawRad = Math.toRadians((double)(-fakeLoc.getYaw()));
                                    double dirX = -Math.sin(yawRad);
                                    double dirZ = Math.cos(yawRad);

                                    for(double d = (double)0.5F; d <= (double)1.5F; d += (double)0.5F) {
                                       int bx2 = (int)Math.floor(fakeLoc.getX() + dirX * d);
                                       int bz2 = (int)Math.floor(fakeLoc.getZ() + dirZ * d);
                                       int by2 = (int)Math.floor(fakeLoc.getY());
                                       if (world.getBlockAt(bx2, by2, bz2).getType().isSolid() && !world.getBlockAt(bx2, by2 + 1, bz2).getType().isSolid() && !world.getBlockAt(bx2, by2 + 2, bz2).getType().isSolid()) {
                                          wallAhead = true;
                                          break;
                                       }
                                    }
                                 }
                              } catch (Exception var79) {
                              }

                              if (isBlocked || wallAhead) {
                                 boolean onGround = false;

                                 try {
                                    for(Class<?> c = serverPlayer.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                                       try {
                                          Field ogf = c.getDeclaredField("onGround");
                                          ogf.setAccessible(true);
                                          onGround = ogf.getBoolean(serverPlayer);
                                          break;
                                       }
                                    }
                                 } catch (Exception var78) {
                                 }

                                 if (onGround && fmm.getJumpCooldown(this.uuid) <= 0) {
                                    try {
                                       Method jfg = null;

                                       for(Class<?> c = serverPlayer.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                                          try {
                                             jfg = c.getDeclaredMethod("jumpFromGround");
                                             jfg.setAccessible(true);
                                             break;
                                          }
                                       }

                                       if (jfg != null) {
                                          jfg.invoke(serverPlayer);
                                          String var123 = this.player.getName();
                                          SimpleNMSHandler.debug("[FakePlayerTicker] " + var123 + " jumped (" + (isBlocked ? "blocked" : "wall ahead") + ")");
                                       }
                                    } catch (Exception var76) {
                                    }

                                    fmm.setJumpCooldown(this.uuid, 5);
                                 }
                              }
                           } else {
                              if (SimpleNMSHandler.this.zzaField != null) {
                                 try {
                                    SimpleNMSHandler.this.zzaField.setFloat(serverPlayer, 0.0F);
                                 } catch (Exception var53) {
                                 }
                              }

                              this.player.setSprinting(false);
                           }

                           fmm.updateLastPos(this.uuid, serverPlayer);
                        }
                     }

                     FakePlayerDamageListener dl = SimpleNMSHandler.this.plugin.getDamageListener();
                     boolean knockedBack = dl != null && dl.isKnockedBack(this.player.getName());
                     if (knockedBack) {
                        try {
                           Object kbDelta = null;

                           try {
                              if (SimpleNMSHandler.this.getDeltaMovementMethod != null) {
                                 kbDelta = SimpleNMSHandler.this.getDeltaMovementMethod.invoke(serverPlayer);
                              }
                           } catch (Exception var52) {
                           }

                           if (kbDelta != null) {
                              double kdx = (Double)kbDelta.getClass().getMethod("x").invoke(kbDelta);
                              double kdy = (Double)kbDelta.getClass().getMethod("y").invoke(kbDelta);
                              double kdz = (Double)kbDelta.getClass().getMethod("z").invoke(kbDelta);
                              if (Math.abs(kdx) > 1.0E-7 || Math.abs(kdy) > 1.0E-7 || Math.abs(kdz) > 1.0E-7) {
                                 boolean kbOnGround = false;

                                 try {
                                    for(Class<?> c = serverPlayer.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                                       try {
                                          Field ogf = c.getDeclaredField("onGround");
                                          ogf.setAccessible(true);
                                          kbOnGround = ogf.getBoolean(serverPlayer);
                                          break;
                                       }
                                    }
                                 } catch (Exception var73) {
                                 }

                                 float friction = kbOnGround ? 0.6F : 0.98F;
                                 kdx *= (double)friction;
                                 kdz *= (double)friction;
                                 if (kbOnGround) {
                                    kdy = (double)0.0F;
                                 } else {
                                    kdy *= (double)0.98F;
                                 }

                                 if (kdy < (double)-3.0F) {
                                    kdy = (double)-3.0F;
                                 }

                                 Object newKbDelta = SimpleNMSHandler.this.vec3Constructor.newInstance(kdx, kdy, kdz);
                                 SimpleNMSHandler.this.entityMoveMethod.invoke(serverPlayer, SimpleNMSHandler.this.moverTypeSelf, newKbDelta);

                                 try {
                                    for(Class<?> c = serverPlayer.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                                       try {
                                          Field hm = c.getDeclaredField("hurtMarked");
                                          hm.setAccessible(true);
                                          hm.setBoolean(serverPlayer, true);
                                          break;
                                       }
                                    }
                                 } catch (Exception var71) {
                                 }
                              }
                           }
                        } catch (Exception var74) {
                        }
                     } else {
                        SimpleNMSHandler.this.applyMovement(serverPlayer);
                     }

                     if (fmm != null && fmm.isFollowing(this.uuid)) {
                        fmm.setFirstMoveDone(this.uuid);
                     }

                     try {
                        double fx = (Double)serverPlayer.getClass().getMethod("getX").invoke(serverPlayer);
                        double fy = (Double)serverPlayer.getClass().getMethod("getY").invoke(serverPlayer);
                        double fz = (Double)serverPlayer.getClass().getMethod("getZ").invoke(serverPlayer);
                        double driftDist = Math.sqrt((fx - bx) * (fx - bx) + (fy - by) * (fy - by) + (fz - bz) * (fz - bz));
                        if (driftDist > (double)5.0F) {
                           Logger var124 = SimpleNMSHandler.LOGGER;
                           String var125 = this.player.getName();
                           var124.warning("[Ticker-DRIFT] " + var125 + " drifted " + String.format("%.1f", driftDist) + " blocks: (" + (int)bx + "," + (int)by + "," + (int)bz + ") -> (" + (int)fx + "," + (int)fy + "," + (int)fz + ")");

                           try {
                              Method absMoveTo = serverPlayer.getClass().getMethod("absMoveTo", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
                              absMoveTo.invoke(serverPlayer, bx, by, bz, byaw, bpitch);
                           } catch (Exception var51) {
                           }
                        }

                        if (driftDist > 0.01) {
                           try {
                              for(Class<?> c = serverPlayer.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                                 try {
                                    Field hm = c.getDeclaredField("hurtMarked");
                                    hm.setAccessible(true);
                                    hm.setBoolean(serverPlayer, true);
                                    break;
                                 }
                              }
                           } catch (Exception var68) {
                           }
                        }
                     } catch (Exception var69) {
                     }

                     SimpleNMSHandler.this.resetLastActionTime(serverPlayer);
                  }
               } catch (Exception e) {
                  String var10000 = this.player.getName();
                  SimpleNMSHandler.debug("[FakePlayerTicker] doTick() failed for " + var10000 + ": " + e.getMessage());

                  try {
                     Object serverPlayer = SimpleNMSHandler.this.getServerPlayer(this.player);
                     if (serverPlayer != null) {
                        this.runFallbackPhysics(serverPlayer);
                     }
                  } catch (Exception var50) {
                  }
               }

            } else {
               this.cancelled = true;
            }
         }
      }

      private void setPositionField(Object obj, String fieldName, double value) {
         try {
            Field f = this.findFieldInHierarchy(obj.getClass(), fieldName);
            if (f != null) {
               f.setAccessible(true);
               f.setDouble(obj, value);
            }
         } catch (Exception var6) {
         }

      }

      private void runFallbackPhysics(Object serverPlayer) {
         try {
            double x = (Double)serverPlayer.getClass().getMethod("getX").invoke(serverPlayer);
            double y = (Double)serverPlayer.getClass().getMethod("getY").invoke(serverPlayer);
            double z = (Double)serverPlayer.getClass().getMethod("getZ").invoke(serverPlayer);
            boolean onGround = false;

            try {
               Method isOnGround = serverPlayer.getClass().getMethod("isOnGround");
               onGround = (Boolean)isOnGround.invoke(serverPlayer);
            } catch (Exception var17) {
            }

            double dy = (double)0.0F;
            if (!onGround) {
               dy -= 0.08;
               if (dy < (double)-3.0F) {
                  dy = (double)-3.0F;
               }
            }

            if (onGround) {
               dy = (double)0.0F;
            }

            if (Math.abs(dy) > 0.001 || Math.abs(x) > 0.001 || Math.abs(z) > 0.001) {
               try {
                  Method moveMethod = serverPlayer.getClass().getMethod("move", Double.TYPE, Double.TYPE, Double.TYPE);
                  moveMethod.invoke(serverPlayer, (double)0.0F, dy, (double)0.0F);
               } catch (NoSuchMethodException var16) {
                  try {
                     Class<?> vec3Class = Class.forName("net.minecraft.world.phys.Vec3");
                     Object vec3 = vec3Class.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE).newInstance((double)0.0F, dy, (double)0.0F);
                     Method moveMethod = serverPlayer.getClass().getMethod("move", vec3Class);
                     moveMethod.invoke(serverPlayer, vec3);
                  } catch (Exception e2) {
                     SimpleNMSHandler.debug("[FakePlayerTicker] Fallback move also failed: " + e2.getMessage());
                  }
               }
            }
         } catch (Exception e) {
            SimpleNMSHandler.debug("[FakePlayerTicker] Fallback physics failed: " + e.getMessage());
         }

      }

      private Field findFieldInHierarchy(Class<?> clazz, String name) {
         for(Class<?> c = clazz; c != null && c != Object.class; c = c.getSuperclass()) {
            try {
               return c.getDeclaredField(name);
            }
         }

         return null;
      }
   }
}
