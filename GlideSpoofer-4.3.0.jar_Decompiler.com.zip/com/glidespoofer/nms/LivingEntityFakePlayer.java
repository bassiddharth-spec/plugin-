package com.glidespoofer.nms;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Skeleton;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

public class LivingEntityFakePlayer {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer");
   private final UUID uuid;
   private final String name;
   private final Location spawnLocation;
   private Object entitySkeleton;
   private Entity bukkitEntity;
   private int fakePlayerEntityId;
   private String skinValue;
   private String skinSignature;
   private boolean useModernNMS;
   private String craftBukkitVersion;
   private Plugin plugin;
   private final Set<UUID> viewers = new HashSet();
   private Method entityTickMethod;
   private Class<?> packetSpawnPlayerClass;
   private Class<?> packetPlayerInfoClass;
   private Class<?> packetEntityMetadataClass;
   private Class<?> packetEntityDestroyClass;
   private Class<?> packetTeleportClass;
   private Class<?> packetMoveClass;
   private Class<?> gameProfileClass;
   private Location lastSentPosition;

   public LivingEntityFakePlayer(UUID uuid, String name, Location spawnLocation) {
      this.uuid = uuid;
      this.name = name;
      this.spawnLocation = spawnLocation;
      String version = Bukkit.getVersion();
      this.useModernNMS = version.contains("1.17") || version.contains("1.18") || version.contains("1.19") || version.contains("1.20") || version.contains("1.21");

      try {
         String packageName = Bukkit.getServer().getClass().getPackage().getName();
         String[] parts = packageName.split("\\.");
         if (parts.length >= 4 && parts[3].startsWith("v")) {
            this.craftBukkitVersion = parts[3];
         } else {
            this.craftBukkitVersion = "";
         }
      } catch (Exception var7) {
         this.craftBukkitVersion = "";
      }

      this.initializePacketClasses();
   }

   public boolean spawn() {
      try {
         Entity skeleton = this.spawnLocation.getWorld().spawn(this.spawnLocation, Skeleton.class);
         if (skeleton == null) {
            return false;
         } else {
            this.bukkitEntity = skeleton;
            if (skeleton instanceof Skeleton) {
               Skeleton skel = (Skeleton)skeleton;
               skel.setInvisible(true);
               skel.setSilent(true);
               skel.setCollidable(false);
               skel.setPersistent(false);
               skel.setRemoveWhenFarAway(false);
               EntityEquipment equipment = skel.getEquipment();
               if (equipment != null) {
                  equipment.clear();
               }

               try {
                  Method setInvisibleMethod = skeleton.getClass().getMethod("setInvisible", Boolean.TYPE);
                  setInvisibleMethod.invoke(skeleton, true);
               } catch (Exception var7) {
               }

               try {
                  Method setNoPhysicsMethod = skeleton.getClass().getMethod("setNoPhysics", Boolean.TYPE);
                  setNoPhysicsMethod.invoke(skeleton, false);
               } catch (Exception var6) {
               }

               try {
                  Method setGravityMethod = skeleton.getClass().getMethod("setGravity", Boolean.TYPE);
                  setGravityMethod.invoke(skeleton, true);
               } catch (Exception var5) {
               }
            }

            this.entitySkeleton = this.getHandle(skeleton);
            if (this.entitySkeleton == null) {
               return false;
            } else {
               this.initializeReflection();
               this.fakePlayerEntityId = this.generateFakeEntityId();
               return true;
            }
         }
      } catch (Exception var8) {
         var8.printStackTrace();
         return false;
      }
   }

   private Object getHandle(Entity entity) {
      try {
         Method getHandle = entity.getClass().getMethod("getHandle");
         return getHandle.invoke(entity);
      } catch (Exception var3) {
         return null;
      }
   }

   private void initializeReflection() {
      try {
         this.entityTickMethod = this.entitySkeleton.getClass().getMethod("tick");
      } catch (NoSuchMethodException var4) {
         try {
            this.entityTickMethod = this.entitySkeleton.getClass().getSuperclass().getMethod("tick");
         } catch (Exception var3) {
         }
      }

   }

   private void initializePacketClasses() {
      try {
         String nmsPackage = this.useModernNMS ? "net.minecraft.network.protocol.game" : "net.minecraft.server." + this.craftBukkitVersion;
         this.packetSpawnPlayerClass = this.getNMSClass(nmsPackage + ".PacketPlayOutNamedEntitySpawn", "net.minecraft.network.protocol.game.PacketPlayOutNamedEntitySpawn");
         this.packetPlayerInfoClass = this.getNMSClass(nmsPackage + ".PacketPlayOutPlayerInfo", "net.minecraft.network.protocol.game.PacketPlayOutPlayerInfo");
         this.packetEntityMetadataClass = this.getNMSClass(nmsPackage + ".PacketPlayOutEntityMetadata", "net.minecraft.network.protocol.game.PacketPlayOutEntityMetadata");
         this.packetEntityDestroyClass = this.getNMSClass(nmsPackage + ".PacketPlayOutEntityDestroy", "net.minecraft.network.protocol.game.PacketPlayOutEntityDestroy");
         this.packetTeleportClass = this.getNMSClass(nmsPackage + ".PacketPlayOutEntityTeleport", "net.minecraft.network.protocol.game.PacketPlayOutEntityTeleport");
         this.packetMoveClass = this.getNMSClass(nmsPackage + ".PacketPlayOutRelEntityMove", "net.minecraft.network.protocol.game.PacketPlayOutRelEntityMove");
         if (this.useModernNMS) {
            String var2 = "com.mojang.authlib";
         } else {
            String var4 = this.craftBukkitVersion.isEmpty() ? "com.mojang.authlib" : "net.minecraft.util.com.mojang.authlib";
         }

         this.gameProfileClass = this.getClassByName("com.mojang.authlib.GameProfile");
      } catch (Exception var3) {
      }

   }

   private Class<?> getNMSClass(String... names) {
      for(String name : names) {
         try {
            return Class.forName(name);
         } catch (ClassNotFoundException var7) {
         }
      }

      return null;
   }

   private Class<?> getClassByName(String name) {
      try {
         return Class.forName(name);
      } catch (ClassNotFoundException var3) {
         return null;
      }
   }

   public void setPlugin(Plugin plugin) {
      this.plugin = plugin;
   }

   public void tick() {
      if (this.entitySkeleton != null && this.entityTickMethod != null) {
         try {
            this.entityTickMethod.invoke(this.entitySkeleton);
         } catch (Exception var2) {
         }
      }

   }

   public void knockback(double strength, double dx, double dz) {
      if (this.entitySkeleton != null) {
         try {
            double length = Math.sqrt(dx * dx + dz * dz);
            if (length > (double)0.0F) {
               dx /= length;
               dz /= length;
            }

            try {
               for(Class<?> entityClass = this.entitySkeleton.getClass(); entityClass != null; entityClass = entityClass.getSuperclass()) {
                  try {
                     Method kbMethod = entityClass.getDeclaredMethod("knockback", Double.TYPE, Double.TYPE, Double.TYPE);
                     kbMethod.setAccessible(true);
                     kbMethod.invoke(this.entitySkeleton, strength, dx, dz);
                     return;
                  }
               }
            } catch (Exception var12) {
            }

            this.setDeltaMovement(dx * strength * 0.6, 0.08, dz * strength * 0.6);
         } catch (Exception var13) {
         }
      }

   }

   public void setDeltaMovement(double x, double y, double z) {
      if (this.entitySkeleton != null) {
         try {
            if (this.useModernNMS) {
               Class<?> vec3Class = Class.forName("net.minecraft.world.phys.Vec3");
               Constructor<?> vec3Constructor = vec3Class.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE);
               Object vec3 = vec3Constructor.newInstance(x, y, z);
               Method setDeltaMethod = this.entitySkeleton.getClass().getMethod("setDeltaMovement", vec3Class);
               setDeltaMethod.invoke(this.entitySkeleton, vec3);
            } else {
               try {
                  for(Class<?> entityClass = this.entitySkeleton.getClass(); entityClass != null; entityClass = entityClass.getSuperclass()) {
                     try {
                        Field motX = entityClass.getDeclaredField("motX");
                        Field motY = entityClass.getDeclaredField("motY");
                        Field motZ = entityClass.getDeclaredField("motZ");
                        motX.setAccessible(true);
                        motY.setAccessible(true);
                        motZ.setAccessible(true);
                        motX.set(this.entitySkeleton, x);
                        motY.set(this.entitySkeleton, y);
                        motZ.set(this.entitySkeleton, z);
                        return;
                     }
                  }
               } catch (Exception var12) {
               }
            }
         } catch (Exception var13) {
         }
      }

   }

   public Vector getDeltaMovement() {
      if (this.entitySkeleton == null) {
         return new Vector();
      } else {
         try {
            if (this.useModernNMS) {
               Method getDeltaMethod = this.entitySkeleton.getClass().getMethod("getDeltaMovement");
               Object vec3 = getDeltaMethod.invoke(this.entitySkeleton);
               Method xMethod = vec3.getClass().getMethod("x");
               Method yMethod = vec3.getClass().getMethod("y");
               Method zMethod = vec3.getClass().getMethod("z");
               return new Vector((Double)xMethod.invoke(vec3), (Double)yMethod.invoke(vec3), (Double)zMethod.invoke(vec3));
            }

            for(Class<?> entityClass = this.entitySkeleton.getClass(); entityClass != null; entityClass = entityClass.getSuperclass()) {
               try {
                  Field motX = entityClass.getDeclaredField("motX");
                  Field motY = entityClass.getDeclaredField("motY");
                  Field motZ = entityClass.getDeclaredField("motZ");
                  motX.setAccessible(true);
                  motY.setAccessible(true);
                  motZ.setAccessible(true);
                  return new Vector(motX.getDouble(this.entitySkeleton), motY.getDouble(this.entitySkeleton), motZ.getDouble(this.entitySkeleton));
               }
            }
         } catch (Exception var7) {
         }

         return new Vector();
      }
   }

   public Location getLocation() {
      if (this.bukkitEntity != null) {
         return this.bukkitEntity.getLocation();
      } else if (this.entitySkeleton == null) {
         return this.spawnLocation.clone();
      } else {
         try {
            Method getXMethod = this.entitySkeleton.getClass().getMethod("getX");
            Method getYMethod = this.entitySkeleton.getClass().getMethod("getY");
            Method getZMethod = this.entitySkeleton.getClass().getMethod("getZ");
            Method getYawMethod = this.entitySkeleton.getClass().getMethod("getYRot");
            Method getPitchMethod = this.entitySkeleton.getClass().getMethod("getXRot");
            return new Location(this.spawnLocation.getWorld(), (Double)getXMethod.invoke(this.entitySkeleton), (Double)getYMethod.invoke(this.entitySkeleton), (Double)getZMethod.invoke(this.entitySkeleton), (Float)getYawMethod.invoke(this.entitySkeleton), (Float)getPitchMethod.invoke(this.entitySkeleton));
         } catch (Exception var6) {
            return this.spawnLocation.clone();
         }
      }
   }

   public void remove() {
      for(UUID viewerUuid : new HashSet(this.viewers)) {
         Player viewer = Bukkit.getPlayer(viewerUuid);
         if (viewer != null && viewer.isOnline()) {
            this.hideFromViewer(viewer);
         }
      }

      this.viewers.clear();
      if (this.entitySkeleton != null) {
         try {
            Method removeMethod = this.entitySkeleton.getClass().getMethod("discard");
            removeMethod.invoke(this.entitySkeleton);
         } catch (Exception var5) {
            try {
               Method removeMethodx = this.entitySkeleton.getClass().getMethod("die");
               removeMethodx.invoke(this.entitySkeleton);
            } catch (Exception var4) {
            }
         }

         this.entitySkeleton = null;
         this.bukkitEntity = null;
         this.lastSentPosition = null;
      }

   }

   public boolean isOnGround() {
      if (this.entitySkeleton == null) {
         return false;
      } else {
         try {
            Method onGroundMethod = this.entitySkeleton.getClass().getMethod("isOnGround");
            return (Boolean)onGroundMethod.invoke(this.entitySkeleton);
         } catch (Exception var2) {
            return false;
         }
      }
   }

   public boolean isInWater() {
      if (this.entitySkeleton == null) {
         return false;
      } else {
         try {
            Method method = this.entitySkeleton.getClass().getMethod("isInWater");
            return (Boolean)method.invoke(this.entitySkeleton);
         } catch (Exception var2) {
            return false;
         }
      }
   }

   public UUID getUuid() {
      return this.uuid;
   }

   public String getName() {
      return this.name;
   }

   public Object getEntity() {
      return this.entitySkeleton;
   }

   public Entity getBukkitEntity() {
      return this.bukkitEntity;
   }

   public int getFakePlayerEntityId() {
      return this.fakePlayerEntityId;
   }

   public String getSkinValue() {
      return this.skinValue;
   }

   public void setSkinValue(String skinValue) {
      this.skinValue = skinValue;
   }

   public String getSkinSignature() {
      return this.skinSignature;
   }

   public void setSkinSignature(String skinSignature) {
      this.skinSignature = skinSignature;
   }

   public Set<UUID> getViewers() {
      return new HashSet(this.viewers);
   }

   public boolean hasViewer(UUID viewer) {
      return this.viewers.contains(viewer);
   }

   private int generateFakeEntityId() {
      return -Math.abs(UUID.randomUUID().hashCode());
   }

   public boolean showToViewer(Player viewer, String skinValue, String skinSignature) {
      if (this.entitySkeleton == null) {
         return false;
      } else if (this.viewers.contains(viewer.getUniqueId())) {
         return true;
      } else {
         try {
            this.hideSkeletonFromViewer(viewer);
            this.sendPlayerInfoAdd(viewer, skinValue, skinSignature);
            this.sendSpawnPlayer(viewer);
            this.sendEntityMetadata(viewer);
            this.viewers.add(viewer.getUniqueId());
            return true;
         } catch (Exception var5) {
            LOGGER.warning("[LivingEntityFakePlayer] Failed to show to viewer: " + var5.getMessage());
            return false;
         }
      }
   }

   public boolean hideFromViewer(Player viewer) {
      if (!this.viewers.contains(viewer.getUniqueId())) {
         return true;
      } else {
         try {
            this.sendDestroyEntity(viewer);
            this.sendPlayerInfoRemove(viewer);
            this.showSkeletonToViewer(viewer);
            this.viewers.remove(viewer.getUniqueId());
            return true;
         } catch (Exception var3) {
            LOGGER.warning("[LivingEntityFakePlayer] Failed to hide from viewer: " + var3.getMessage());
            return false;
         }
      }
   }

   public void syncPositionToViewers() {
      if (this.entitySkeleton != null && !this.viewers.isEmpty()) {
         Location currentLoc = this.getLocation();
         if (currentLoc != null) {
            if (this.lastSentPosition == null) {
               this.lastSentPosition = currentLoc.clone();
            } else {
               double deltaX = currentLoc.getX() - this.lastSentPosition.getX();
               double deltaY = currentLoc.getY() - this.lastSentPosition.getY();
               double deltaZ = currentLoc.getZ() - this.lastSentPosition.getZ();
               float deltaYaw = currentLoc.getYaw() - this.lastSentPosition.getYaw();
               float deltaPitch = currentLoc.getPitch() - this.lastSentPosition.getPitch();
               boolean positionChanged = Math.abs(deltaX) > 0.001 || Math.abs(deltaY) > 0.001 || Math.abs(deltaZ) > 0.001;
               boolean rotationChanged = Math.abs(deltaYaw) > 1.0F || Math.abs(deltaPitch) > 1.0F;
               if (positionChanged || rotationChanged) {
                  boolean onGround = this.isOnGround();

                  for(UUID viewerUuid : this.viewers) {
                     Player viewer = Bukkit.getPlayer(viewerUuid);
                     if (viewer != null && viewer.isOnline()) {
                        try {
                           if (!(Math.abs(deltaX) > (double)8.0F) && !(Math.abs(deltaY) > (double)8.0F) && !(Math.abs(deltaZ) > (double)8.0F)) {
                              if (!positionChanged && !rotationChanged) {
                                 if (rotationChanged) {
                                    this.sendRotation(viewer, currentLoc.getYaw(), currentLoc.getPitch());
                                 }
                              } else {
                                 this.sendRelativeMove(viewer, deltaX, deltaY, deltaZ, currentLoc.getYaw(), currentLoc.getPitch(), onGround);
                              }
                           } else {
                              this.sendTeleport(viewer, currentLoc);
                           }
                        } catch (Exception var17) {
                        }
                     }
                  }

                  this.lastSentPosition = currentLoc.clone();
               }
            }
         }
      }

   }

   private void hideSkeletonFromViewer(Player viewer) {
      if (this.bukkitEntity != null) {
         try {
            int skeletonEntityId = this.bukkitEntity.getEntityId();
            this.sendInvisibilityMetadata(viewer, skeletonEntityId);
         } catch (Exception var3) {
         }
      }

   }

   private void showSkeletonToViewer(Player viewer) {
      if (this.bukkitEntity != null) {
         try {
            int skeletonEntityId = this.bukkitEntity.getEntityId();
            this.sendVisibilityMetadata(viewer, skeletonEntityId);
         } catch (Exception var3) {
         }
      }

   }

   private void sendPlayerInfoAdd(Player viewer, String skinValue, String skinSignature) {
      try {
         if (this.gameProfileClass == null) {
            return;
         }

         Constructor<?> profileConstructor = this.gameProfileClass.getConstructor(UUID.class, String.class);
         Object profile = profileConstructor.newInstance(this.uuid, this.name);
         if (skinValue != null && !skinValue.isEmpty()) {
            try {
               Class<?> propertyClass = Class.forName("com.mojang.authlib.properties.Property");
               Constructor<?> propertyConstructor = propertyClass.getConstructor(String.class, String.class, String.class);
               Object property = propertyConstructor.newInstance("textures", skinValue, skinSignature);
               Method getPropertiesMethod = this.gameProfileClass.getMethod("getProperties");
               Object propertiesMap = getPropertiesMethod.invoke(profile);
               Method putMethod = propertiesMap.getClass().getMethod("put", Object.class, Object.class);
               putMethod.invoke(propertiesMap, "textures", property);
            } catch (Exception var12) {
            }
         }

         Object packet = this.createPlayerInfoPacket(profile, 0);
         this.sendPacket(viewer, packet);
      } catch (Exception var13) {
      }

   }

   private void sendPlayerInfoRemove(Player viewer) {
      try {
         Object packet = this.createPlayerInfoRemovePacket();
         this.sendPacket(viewer, packet);
      } catch (Exception var3) {
      }

   }

   private void sendSpawnPlayer(Player viewer) {
      try {
         Location loc = this.getLocation();
         if (loc == null) {
            return;
         }

         Object packet = this.createSpawnPlayerPacket(loc);
         this.sendPacket(viewer, packet);
      } catch (Exception var4) {
      }

   }

   private void sendEntityMetadata(Player viewer) {
      try {
         Object packet = this.createEntityMetadataPacket();
         this.sendPacket(viewer, packet);
      } catch (Exception var3) {
      }

   }

   private void sendDestroyEntity(Player viewer) {
      try {
         Object packet = this.createDestroyEntityPacket();
         this.sendPacket(viewer, packet);
      } catch (Exception var3) {
      }

   }

   private void sendTeleport(Player viewer, Location loc) {
      try {
         Object packet = this.createTeleportPacket(loc);
         this.sendPacket(viewer, packet);
      } catch (Exception var4) {
      }

   }

   private void sendRelativeMove(Player viewer, double dx, double dy, double dz, float yaw, float pitch, boolean onGround) {
      try {
         Object packet = this.createRelativeMovePacket(dx, dy, dz, yaw, pitch, onGround);
         this.sendPacket(viewer, packet);
      } catch (Exception var12) {
      }

   }

   private void sendRotation(Player viewer, float yaw, float pitch) {
      try {
         Object packet = this.createRotationPacket(yaw, pitch);
         this.sendPacket(viewer, packet);
      } catch (Exception var5) {
      }

   }

   private void sendInvisibilityMetadata(Player viewer, int entityId) {
      try {
         Object data = this.createMetadataByte((byte)32);
         Object packet = this.createEntityMetadataPacket(entityId, data);
         this.sendPacket(viewer, packet);
      } catch (Exception var5) {
      }

   }

   private void sendVisibilityMetadata(Player viewer, int entityId) {
      try {
         Object data = this.createMetadataByte((byte)0);
         Object packet = this.createEntityMetadataPacket(entityId, data);
         this.sendPacket(viewer, packet);
      } catch (Exception var5) {
      }

   }

   private Object createPlayerInfoPacket(Object profile, int action) {
      return null;
   }

   private Object createPlayerInfoRemovePacket() {
      return null;
   }

   private Object createSpawnPlayerPacket(Location loc) {
      try {
         String nmsPackage = this.useModernNMS ? "net.minecraft.network.protocol.game" : "net.minecraft.server." + this.craftBukkitVersion;
         Class<?> packetClass = Class.forName(nmsPackage + ".PacketPlayOutNamedEntitySpawn");

         try {
            Constructor<?> constructor = packetClass.getConstructor(Class.forName("net.minecraft.world.entity.Entity"));
            return constructor.newInstance(this.entitySkeleton);
         } catch (Exception var6) {
            Constructor<?> constructorx = packetClass.getConstructor(Integer.TYPE, UUID.class, Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
            return constructorx.newInstance(this.fakePlayerEntityId, this.uuid, loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch());
         }
      } catch (Exception var7) {
         return null;
      }
   }

   private Object createEntityMetadataPacket() {
      try {
         String nmsPackage = this.useModernNMS ? "net.minecraft.network.protocol.game" : "net.minecraft.server." + this.craftBukkitVersion;
         Class<?> packetClass = Class.forName(nmsPackage + ".PacketPlayOutEntityMetadata");
         Class<?> dataWatcherClass = Class.forName(nmsPackage.replace(".protocol.game", ".network.syncher.DataWatcher"));
         Class<?> dataWatcherItemClass = Class.forName(nmsPackage.replace(".protocol.game", ".network.syncher.DataWatcher$Item"));
         Class<?> dataWatcherRegistryClass = Class.forName(nmsPackage.replace(".protocol.game", ".network.syncher.DataWatcherRegistry"));
         Method getDataWatcherMethod = this.entitySkeleton.getClass().getMethod("getDataWatcher");
         Object dataWatcher = getDataWatcherMethod.invoke(this.entitySkeleton);
         Constructor<?> constructor = packetClass.getConstructor(Integer.TYPE, dataWatcherClass, Boolean.TYPE);
         return constructor.newInstance(this.fakePlayerEntityId, dataWatcher, true);
      } catch (Exception var9) {
         return null;
      }
   }

   private Object createEntityMetadataPacket(int entityId, Object data) {
      try {
         String nmsPackage = this.useModernNMS ? "net.minecraft.network.protocol.game" : "net.minecraft.server." + this.craftBukkitVersion;
         Class<?> packetClass = Class.forName(nmsPackage + ".PacketPlayOutEntityMetadata");
         Class<?> dataWatcherItemClass = Class.forName(nmsPackage.replace(".protocol.game", ".network.syncher.DataWatcher$Item"));
         List<Object> metadataList = new ArrayList();
         metadataList.add(data);
         Constructor<?> constructor = packetClass.getConstructor(Integer.TYPE, List.class);
         return constructor.newInstance(entityId, metadataList);
      } catch (Exception var8) {
         return null;
      }
   }

   private Object createMetadataByte(byte value) {
      try {
         String nmsPackage = this.useModernNMS ? "net.minecraft.network.protocol.game" : "net.minecraft.server." + this.craftBukkitVersion;
         Class<?> dataWatcherItemClass = Class.forName(nmsPackage.replace(".protocol.game", ".network.syncher.DataWatcher$Item"));
         Class<?> dataWatcherRegistryClass = Class.forName(nmsPackage.replace(".protocol.game", ".network.syncher.DataWatcherRegistry"));
         Object byteRegistry = dataWatcherRegistryClass.getField("a").get((Object)null);
         Constructor<?> constructor = dataWatcherItemClass.getConstructor(Integer.TYPE, Object.class, Object.class);
         return constructor.newInstance(0, byteRegistry, value);
      } catch (Exception var7) {
         return null;
      }
   }

   private Object createDestroyEntityPacket() {
      try {
         String nmsPackage = this.useModernNMS ? "net.minecraft.network.protocol.game" : "net.minecraft.server." + this.craftBukkitVersion;
         Class<?> packetClass = Class.forName(nmsPackage + ".PacketPlayOutEntityDestroy");
         Constructor<?> constructor = packetClass.getConstructor(int[].class);
         int[] ids = new int[]{this.fakePlayerEntityId};
         return constructor.newInstance(ids);
      } catch (Exception var5) {
         return null;
      }
   }

   private Object createTeleportPacket(Location loc) {
      try {
         String nmsPackage = this.useModernNMS ? "net.minecraft.network.protocol.game" : "net.minecraft.server." + this.craftBukkitVersion;
         Class<?> packetClass = Class.forName(nmsPackage + ".PacketPlayOutEntityTeleport");
         Constructor<?> constructor = packetClass.getConstructor(Integer.TYPE, Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE, Boolean.TYPE);
         return constructor.newInstance(this.fakePlayerEntityId, loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch(), this.isOnGround());
      } catch (Exception var5) {
         return null;
      }
   }

   private Object createRelativeMovePacket(double dx, double dy, double dz, float yaw, float pitch, boolean onGround) {
      try {
         String nmsPackage = this.useModernNMS ? "net.minecraft.network.protocol.game" : "net.minecraft.server." + this.craftBukkitVersion;
         int fixedDx = (int)(dx * (double)4096.0F);
         int fixedDy = (int)(dy * (double)4096.0F);
         int fixedDz = (int)(dz * (double)4096.0F);
         Class<?> packetClass = Class.forName(nmsPackage + ".PacketPlayOutRelEntityMoveLook");
         Constructor<?> constructor = packetClass.getConstructor(Integer.TYPE, Short.TYPE, Short.TYPE, Short.TYPE, Float.TYPE, Float.TYPE, Boolean.TYPE);
         return constructor.newInstance(this.fakePlayerEntityId, (short)fixedDx, (short)fixedDy, (short)fixedDz, yaw, pitch, onGround);
      } catch (Exception var16) {
         return this.createTeleportPacket(this.getLocation());
      }
   }

   private Object createRotationPacket(float yaw, float pitch) {
      try {
         String nmsPackage = this.useModernNMS ? "net.minecraft.network.protocol.game" : "net.minecraft.server." + this.craftBukkitVersion;
         Class<?> packetClass = Class.forName(nmsPackage + ".PacketPlayOutEntityLook");
         Constructor<?> constructor = packetClass.getConstructor(Integer.TYPE, Float.TYPE, Float.TYPE, Boolean.TYPE);
         return constructor.newInstance(this.fakePlayerEntityId, yaw, pitch, this.isOnGround());
      } catch (Exception var6) {
         return null;
      }
   }

   private void sendPacket(Player player, Object packet) {
      if (packet != null) {
         try {
            Method getHandleMethod = player.getClass().getMethod("getHandle");
            Object craftPlayer = getHandleMethod.invoke(player);
            Field connectionField = craftPlayer.getClass().getDeclaredField("connection");
            connectionField.setAccessible(true);
            Object playerConnection = connectionField.get(craftPlayer);
            Method sendMethod = playerConnection.getClass().getMethod("sendPacket", Class.forName("net.minecraft.network.protocol.Packet"));
            sendMethod.invoke(playerConnection, packet);
         } catch (Exception var10) {
            try {
               Method getHandleMethodx = player.getClass().getMethod("getHandle");
               Object craftPlayerx = getHandleMethodx.invoke(player);
               Field playerConnectionField = craftPlayerx.getClass().getDeclaredField("playerConnection");
               playerConnectionField.setAccessible(true);
               Object playerConnectionx = playerConnectionField.get(craftPlayerx);
               Method sendMethodx = playerConnectionx.getClass().getMethod("sendPacket", Class.forName(this.useModernNMS ? "net.minecraft.network.protocol.Packet" : "net.minecraft.server." + this.craftBukkitVersion + ".Packet"));
               sendMethodx.invoke(playerConnectionx, packet);
            } catch (Exception var9) {
            }
         }
      }

   }
}
