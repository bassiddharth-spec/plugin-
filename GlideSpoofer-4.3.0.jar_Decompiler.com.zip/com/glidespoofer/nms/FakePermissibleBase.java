package com.glidespoofer.nms;

import com.glidespoofer.core.GlideSpoofer;
import java.util.List;
import net.luckperms.api.model.user.User;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissibleBase;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.plugin.Plugin;

public class FakePermissibleBase extends PermissibleBase {
   private final List<String> permList;
   private final Player craftPlayer;
   private final GlideSpoofer plugin;

   public FakePermissibleBase(List<String> permList, Player craftPlayer) {
      super(craftPlayer);
      this.permList = permList;
      this.craftPlayer = craftPlayer;
      this.plugin = (GlideSpoofer)Bukkit.getPluginManager().getPlugin("GlideSpoofer");
   }

   public boolean isPermissionSet(String name) {
      return this.checkPermission(name);
   }

   public boolean isPermissionSet(Permission perm) {
      return this.checkPermission(perm.getName());
   }

   public boolean hasPermission(String name) {
      return this.checkPermission(name);
   }

   public boolean hasPermission(Permission perm) {
      return this.checkPermission(perm.getName());
   }

   private boolean checkPermission(String permission) {
      if (this.plugin != null && this.plugin.getLuckPermsHook() != null && this.plugin.getLuckPermsHook().isEnabled()) {
         try {
            User user = this.plugin.getLuckPermsHook().getUserByUuid(this.craftPlayer.getUniqueId());
            if (user != null) {
               Boolean result = user.getCachedData().getPermissionData().checkPermission(permission).asBoolean();
               if (result) {
                  return true;
               }
            }
         } catch (Exception var4) {
         }
      }

      return this.permList != null && this.permList.contains(permission);
   }

   public PermissionAttachment addAttachment(Plugin plugin) {
      throw new UnsupportedOperationException("Cannot add attachments to fake players");
   }

   public PermissionAttachment addAttachment(Plugin plugin, String name, boolean value) {
      throw new UnsupportedOperationException("Cannot add attachments to fake players");
   }

   public PermissionAttachment addAttachment(Plugin plugin, String name, boolean value, int ticks) {
      throw new UnsupportedOperationException("Cannot add attachments to fake players");
   }

   public void removeAttachment(PermissionAttachment attachment) {
   }

   public void recalculatePermissions() {
   }

   public synchronized void clearPermissions() {
   }
}
