package com.glidespoofer.nms;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.advancement.Advancement;
import org.bukkit.advancement.AdvancementProgress;
import org.bukkit.entity.Player;

public class NMSAdvancementManager {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer");
   private final Map<UUID, Set<NamespacedKey>> completedAdvancements = new ConcurrentHashMap();
   private final Map<UUID, Set<String>> completedNMSAdvancements = new ConcurrentHashMap();
   private final boolean useModernNMS;
   private final String nmsPackage;
   private Method getAdvancementProgressMethod;
   private Method grantCriteriaMethod;
   private Method awardMethod;
   private Method getAdvancementsMethod;
   private Class<?> advancementClass;
   private Class<?> advancementProgressClass;
   private Class<?> advancementDataClass;

   public NMSAdvancementManager(boolean useModernNMS, String nmsPackage) {
      this.useModernNMS = useModernNMS;
      this.nmsPackage = nmsPackage;
      this.initializeReflection();
   }

   private void initializeReflection() {
      try {
         Class<?> serverPlayerClass;
         if (this.useModernNMS) {
            serverPlayerClass = Class.forName("net.minecraft.server.level.ServerPlayer");
            this.advancementClass = Class.forName("net.minecraft.advancements.Advancement");
            this.advancementProgressClass = Class.forName("net.minecraft.advancements.AdvancementProgress");
         } else {
            serverPlayerClass = Class.forName(this.nmsPackage + ".EntityPlayer");

            try {
               this.advancementClass = Class.forName(this.nmsPackage + ".Advancement");
               this.advancementProgressClass = Class.forName(this.nmsPackage + ".AdvancementProgress");
            } catch (ClassNotFoundException var9) {
            }
         }

         try {
            this.getAdvancementProgressMethod = serverPlayerClass.getMethod("getAdvancementProgress", this.advancementClass);
         } catch (NoSuchMethodException var13) {
            for(Method m : serverPlayerClass.getDeclaredMethods()) {
               if (m.getName().toLowerCase().contains("advancement") && m.getName().toLowerCase().contains("progress")) {
                  this.getAdvancementProgressMethod = m;
                  this.getAdvancementProgressMethod.setAccessible(true);
                  break;
               }
            }
         }

         if (this.advancementProgressClass != null) {
            try {
               this.grantCriteriaMethod = this.advancementProgressClass.getMethod("award", String.class);
            } catch (NoSuchMethodException var12) {
               try {
                  this.grantCriteriaMethod = this.advancementProgressClass.getMethod("grantCriteria", String.class);
               } catch (NoSuchMethodException var11) {
                  try {
                     this.grantCriteriaMethod = this.advancementProgressClass.getMethod("a", String.class);
                  } catch (NoSuchMethodException var10) {
                     for(Method mx : this.advancementProgressClass.getDeclaredMethods()) {
                        if ((mx.getName().toLowerCase().contains("award") || mx.getName().toLowerCase().contains("grant") || mx.getName().equals("a")) && mx.getParameterCount() == 1 && mx.getParameterTypes()[0] == String.class) {
                           this.grantCriteriaMethod = mx;
                           this.grantCriteriaMethod.setAccessible(true);
                           break;
                        }
                     }
                  }
               }
            }
         }
      } catch (Exception var14) {
         LOGGER.warning("[NMSAdvancement] Failed to initialize reflection: " + var14.getMessage());
      }

   }

   public void initializeAdvancements(Player player, Object serverPlayer) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         this.completedAdvancements.put(uuid, new HashSet());
         this.completedNMSAdvancements.put(uuid, new HashSet());
      }

   }

   public boolean grantAdvancement(Player player, NamespacedKey key) {
      if (player != null && key != null) {
         try {
            Advancement advancement = Bukkit.getAdvancement(key);
            if (advancement == null) {
               LOGGER.warning("[NMSAdvancement] Advancement not found: " + String.valueOf(key));
               return false;
            } else {
               AdvancementProgress progress = player.getAdvancementProgress(advancement);

               for(String criterion : progress.getRemainingCriteria()) {
                  progress.awardCriteria(criterion);
               }

               UUID uuid = player.getUniqueId();
               Set<NamespacedKey> completed = (Set)this.completedAdvancements.get(uuid);
               if (completed != null) {
                  completed.add(key);
               }

               Logger var10 = LOGGER;
               String var11 = String.valueOf(key);
               var10.info("[NMSAdvancement] Granted " + var11 + " to " + player.getName());
               return true;
            }
         } catch (Exception var7) {
            Logger var10000 = LOGGER;
            String var10001 = String.valueOf(key);
            var10000.warning("[NMSAdvancement] Failed to grant advancement " + var10001 + ": " + var7.getMessage());
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean grantAdvancement(Player player, String key) {
      if (key == null) {
         return false;
      } else {
         String namespace = "minecraft";
         String value = key;
         if (key.contains(":")) {
            String[] parts = key.split(":", 2);
            namespace = parts[0];
            value = parts[1];
         }

         NamespacedKey namespacedKey = new NamespacedKey(namespace, value);
         return this.grantAdvancement(player, namespacedKey);
      }
   }

   public int grantAllAdvancements(Player player) {
      if (player == null) {
         return 0;
      } else {
         int count = 0;

         try {
            Iterator<Advancement> iterator = Bukkit.advancementIterator();

            while(iterator.hasNext()) {
               Advancement advancement = (Advancement)iterator.next();
               if (this.grantAdvancement(player, advancement.getKey())) {
                  ++count;
               }
            }

            LOGGER.info("[NMSAdvancement] Granted " + count + " advancements to " + player.getName());
            return count;
         } catch (Exception var5) {
            LOGGER.warning("[NMSAdvancement] Failed to grant all advancements: " + var5.getMessage());
            return count;
         }
      }
   }

   public int grantAdvancementFrom(Player player, String fromKey) {
      if (player == null) {
         return 0;
      } else {
         int count = 0;
         Set<NamespacedKey> toGrant = new HashSet();
         Set<NamespacedKey> visited = new HashSet();
         Queue<NamespacedKey> queue = new LinkedList();
         NamespacedKey startKey = this.parseKey(fromKey);
         if (startKey == null) {
            return 0;
         } else {
            queue.add(startKey);

            try {
               while(!queue.isEmpty()) {
                  NamespacedKey current = (NamespacedKey)queue.poll();
                  if (!visited.contains(current)) {
                     visited.add(current);
                     toGrant.add(current);
                     Advancement advancement = Bukkit.getAdvancement(current);
                     if (advancement != null) {
                        for(NamespacedKey child : this.getChildren(advancement)) {
                           if (!visited.contains(child)) {
                              queue.add(child);
                           }
                        }
                     }
                  }
               }

               for(NamespacedKey key : toGrant) {
                  if (this.grantAdvancement(player, key)) {
                     ++count;
                  }
               }

               LOGGER.info("[NMSAdvancement] Granted " + count + " advancements from " + fromKey + " to " + player.getName());
            } catch (Exception var12) {
               LOGGER.warning("[NMSAdvancement] Failed to grant advancements from " + fromKey + ": " + var12.getMessage());
            }

            return count;
         }
      }
   }

   public int grantAdvancementUntil(Player player, String untilKey) {
      return this.grantAdvancementThrough(player, untilKey);
   }

   public int grantAdvancementThrough(Player player, String throughKey) {
      if (player == null) {
         return 0;
      } else {
         int count = 0;
         Set<NamespacedKey> toGrant = new HashSet();
         Set<NamespacedKey> visited = new HashSet();
         Queue<NamespacedKey> queue = new LinkedList();
         NamespacedKey targetKey = this.parseKey(throughKey);
         if (targetKey == null) {
            return 0;
         } else {
            queue.add(targetKey);

            try {
               while(!queue.isEmpty()) {
                  NamespacedKey current = (NamespacedKey)queue.poll();
                  if (!visited.contains(current)) {
                     visited.add(current);
                     toGrant.add(current);
                     Advancement advancement = Bukkit.getAdvancement(current);
                     if (advancement != null) {
                        for(NamespacedKey parent : this.getParents(advancement)) {
                           if (!visited.contains(parent)) {
                              queue.add(parent);
                           }
                        }
                     }
                  }
               }

               for(NamespacedKey key : toGrant) {
                  if (this.grantAdvancement(player, key)) {
                     ++count;
                  }
               }

               LOGGER.info("[NMSAdvancement] Granted " + count + " advancements through " + throughKey + " to " + player.getName());
            } catch (Exception var12) {
               LOGGER.warning("[NMSAdvancement] Failed to grant advancements through " + throughKey + ": " + var12.getMessage());
            }

            return count;
         }
      }
   }

   public boolean revokeAdvancement(Player player, NamespacedKey key) {
      if (player != null && key != null) {
         try {
            Advancement advancement = Bukkit.getAdvancement(key);
            if (advancement == null) {
               return false;
            } else {
               AdvancementProgress progress = player.getAdvancementProgress(advancement);

               for(String criterion : progress.getAwardedCriteria()) {
                  progress.revokeCriteria(criterion);
               }

               UUID uuid = player.getUniqueId();
               Set<NamespacedKey> completed = (Set)this.completedAdvancements.get(uuid);
               if (completed != null) {
                  completed.remove(key);
               }

               return true;
            }
         } catch (Exception var7) {
            LOGGER.warning("[NMSAdvancement] Failed to revoke advancement: " + var7.getMessage());
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean hasCompletedAdvancement(Player player, NamespacedKey key) {
      if (player != null && key != null) {
         try {
            Advancement advancement = Bukkit.getAdvancement(key);
            if (advancement == null) {
               return false;
            } else {
               AdvancementProgress progress = player.getAdvancementProgress(advancement);
               return progress.isDone();
            }
         } catch (Exception var5) {
            return false;
         }
      } else {
         return false;
      }
   }

   public Set<NamespacedKey> getCompletedAdvancements(Player player) {
      if (player == null) {
         return new HashSet();
      } else {
         Set<NamespacedKey> completed = new HashSet();

         try {
            Iterator<Advancement> iterator = Bukkit.advancementIterator();

            while(iterator.hasNext()) {
               Advancement advancement = (Advancement)iterator.next();
               AdvancementProgress progress = player.getAdvancementProgress(advancement);
               if (progress.isDone()) {
                  completed.add(advancement.getKey());
               }
            }
         } catch (Exception var6) {
         }

         return completed;
      }
   }

   public double getAdvancementProgress(Player player, NamespacedKey key) {
      if (player != null && key != null) {
         try {
            Advancement advancement = Bukkit.getAdvancement(key);
            if (advancement == null) {
               return (double)0.0F;
            } else {
               AdvancementProgress progress = player.getAdvancementProgress(advancement);
               int total = progress.getRemainingCriteria().size() + progress.getAwardedCriteria().size();
               return total == 0 ? (double)0.0F : (double)progress.getAwardedCriteria().size() / (double)total;
            }
         } catch (Exception var6) {
            return (double)0.0F;
         }
      } else {
         return (double)0.0F;
      }
   }

   private NamespacedKey parseKey(String key) {
      if (key == null) {
         return null;
      } else {
         String namespace = "minecraft";
         String value = key;
         if (key.contains(":")) {
            String[] parts = key.split(":", 2);
            namespace = parts[0];
            value = parts[1];
         }

         return new NamespacedKey(namespace, value);
      }
   }

   private Set<NamespacedKey> getChildren(Advancement advancement) {
      Set<NamespacedKey> children = new HashSet();

      try {
         Iterator<Advancement> iterator = Bukkit.advancementIterator();

         while(iterator.hasNext()) {
            Advancement other = (Advancement)iterator.next();

            try {
               Object handle = null;

               try {
                  Method getHandle = advancement.getClass().getMethod("getHandle");
                  handle = getHandle.invoke(advancement);
               } catch (Exception var11) {
               }

               if (handle != null) {
                  for(Method m : handle.getClass().getDeclaredMethods()) {
                     if (m.getName().toLowerCase().contains("parent")) {
                        m.setAccessible(true);
                        Object parent = m.invoke(handle);
                        if (parent != null && parent.toString().contains(advancement.getKey().toString())) {
                           children.add(other.getKey());
                        }
                        break;
                     }
                  }
               }
            } catch (Exception var12) {
            }
         }
      } catch (Exception var13) {
      }

      return children;
   }

   private Set<NamespacedKey> getParents(Advancement advancement) {
      Set<NamespacedKey> parents = new HashSet();

      try {
         Object handle = null;

         try {
            Method getHandle = advancement.getClass().getMethod("getHandle");
            handle = getHandle.invoke(advancement);
         } catch (Exception var12) {
         }

         if (handle != null) {
            for(Method m : handle.getClass().getDeclaredMethods()) {
               if (m.getName().toLowerCase().contains("parent")) {
                  m.setAccessible(true);
                  Object parent = m.invoke(handle);
                  if (parent != null) {
                     String parentString = parent.toString();
                     if (parentString.contains("#")) {
                        String keyStr = parentString.substring(parentString.indexOf("#") + 1);
                        NamespacedKey parentKey = this.parseKey(keyStr);
                        if (parentKey != null) {
                           parents.add(parentKey);
                        }
                     }
                  }
                  break;
               }
            }
         }
      } catch (Exception var13) {
      }

      return parents;
   }

   public void showAdvancementToast(Player fakePlayer, NamespacedKey advancementKey) {
      if (fakePlayer != null && advancementKey != null) {
         try {
            Advancement advancement = Bukkit.getAdvancement(advancementKey);
            if (advancement != null) {
            }
         } catch (Exception var4) {
         }
      }

   }

   public void removeAdvancements(Player player) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         this.completedAdvancements.remove(uuid);
         this.completedNMSAdvancements.remove(uuid);
      }

   }

   public String getAdvancementDisplay(Player player) {
      Set<NamespacedKey> completed = this.getCompletedAdvancements(player);
      if (completed.isEmpty()) {
         return "No advancements completed";
      } else {
         StringBuilder sb = new StringBuilder("\n§e=== Advancements for " + player.getName() + " ===\n");
         sb.append("§7Total: §f").append(completed.size()).append("\n");
         Map<String, List<String>> byCategory = new HashMap();

         for(NamespacedKey key : completed) {
            String category = key.getNamespace();
            ((List)byCategory.computeIfAbsent(category, (k) -> new ArrayList())).add(key.getKey());
         }

         for(Map.Entry<String, List<String>> entry : byCategory.entrySet()) {
            sb.append("§7").append((String)entry.getKey()).append(": §f").append(((List)entry.getValue()).size()).append("\n");
         }

         return sb.toString();
      }
   }

   public int grantStoryAdvancements(Player player) {
      return this.grantAdvancementFrom(player, "minecraft:story/root");
   }

   public int grantNetherAdvancements(Player player) {
      return this.grantAdvancementFrom(player, "minecraft:nether/root");
   }

   public int grantEndAdvancements(Player player) {
      return this.grantAdvancementFrom(player, "minecraft:end/root");
   }

   public int grantAdventureAdvancements(Player player) {
      return this.grantAdvancementFrom(player, "minecraft:adventure/root");
   }

   public int grantHusbandryAdvancements(Player player) {
      return this.grantAdvancementFrom(player, "minecraft:husbandry/root");
   }

   public static class AdvancementTrees {
      public static final String STORY_ROOT = "minecraft:story/root";
      public static final String STORY_MINE_STONE = "minecraft:story/mine_stone";
      public static final String STORY_UPGRADE_TOOLS = "minecraft:story/upgrade_tools";
      public static final String STORY_IRON_TOOLS = "minecraft:story/iron_tools";
      public static final String STORY_DEFLECT_ARROW = "minecraft:story/deflect_arrow";
      public static final String STORY_LAVA_BUCKET = "minecraft:story/lava_bucket";
      public static final String STORY_OBSIDIAN = "minecraft:story/obsidian";
      public static final String STORY_DIAMOND = "minecraft:story/mine_diamond";
      public static final String STORY_ENCHANT = "minecraft:story/enchant_item";
      public static final String STORY_ENTER_THE_NETHER = "minecraft:story/enter_the_nether";
      public static final String NETHER_ROOT = "minecraft:nether/root";
      public static final String NETHER_RETURN = "minecraft:nether/return_to_sender";
      public static final String NETHER_FORTRESS = "minecraft:nether/find_fortress";
      public static final String NETHER_WITHER = "minecraft:nether/summon_wither";
      public static final String NETHER_BREW = "minecraft:nether/brew_potion";
      public static final String END_ROOT = "minecraft:end/root";
      public static final String END_DRAGON = "minecraft:end/kill_dragon";
      public static final String END_ENTER_END = "minecraft:end/enter_end_gateway";
      public static final String ADVENTURE_ROOT = "minecraft:adventure/root";
      public static final String ADVENTURE_KILL_MOB = "minecraft:adventure/kill_a_mob";
      public static final String ADVENTURE_TRADE = "minecraft:adventure/trade";
      public static final String ADVENTURE_SLEEP = "minecraft:adventure/sleep_in_bed";
      public static final String HUSBANDRY_ROOT = "minecraft:husbandry/root";
      public static final String HUSBANDRY_TAME = "minecraft:husbandry/tame_an_animal";
      public static final String HUSBANDRY_BREAD = "minecraft:husbandry/plant_seed";
   }
}
