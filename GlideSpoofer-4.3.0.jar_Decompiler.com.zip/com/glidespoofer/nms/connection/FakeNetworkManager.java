package com.glidespoofer.nms.connection;

import com.google.common.collect.Queues;
import io.netty.channel.AbstractChannel;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelOutboundHandlerAdapter;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.ChannelPromise;
import io.netty.channel.EventLoop;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.util.ReferenceCountUtil;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.Queue;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FakeNetworkManager {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-FakeNetworkManager");
   private static NioEventLoopGroup eventExecutors = new NioEventLoopGroup(5);
   private static Class<?> networkManagerClass;
   private static Class<?> packetFlowClass;
   private static Constructor<?> networkManagerConstructor;
   private static Object serverboundFlow;
   private static Field channelField = null;
   private static Field addressField = null;
   private static Field connectedField = null;
   private static Field packetListenerField = null;
   private static Field queueField = null;
   private Object networkManager;
   private final Channel fakeChannel;
   private final SocketAddress socketAddress;
   private final int port;
   private final String ipAddress;

   private static void cacheFields() {
      LOGGER.info("[FakeNetworkManager] Caching fields for Connection class...");

      for(Field f : networkManagerClass.getDeclaredFields()) {
         Logger var10000 = LOGGER;
         String var10001 = f.getName();
         var10000.fine("[FakeNetworkManager] Field: " + var10001 + " type=" + f.getType().getName() + " static=" + Modifier.isStatic(f.getModifiers()) + " final=" + Modifier.isFinal(f.getModifiers()));
      }

      for(Field f : networkManagerClass.getDeclaredFields()) {
         if (Channel.class.isAssignableFrom(f.getType()) && !Modifier.isStatic(f.getModifiers())) {
            f.setAccessible(true);
            channelField = f;
            LOGGER.info("[FakeNetworkManager] Found channel field: " + f.getName());
            break;
         }
      }

      for(Field f : networkManagerClass.getDeclaredFields()) {
         if (SocketAddress.class.isAssignableFrom(f.getType()) && !Modifier.isStatic(f.getModifiers())) {
            f.setAccessible(true);
            addressField = f;
            LOGGER.info("[FakeNetworkManager] Found address field: " + f.getName());
            break;
         }
      }

      for(Field f : networkManagerClass.getDeclaredFields()) {
         if (f.getType() == Boolean.TYPE && !Modifier.isStatic(f.getModifiers()) && !Modifier.isFinal(f.getModifiers())) {
            f.setAccessible(true);
            connectedField = f;
            LOGGER.info("[FakeNetworkManager] Found connected field: " + f.getName());
            break;
         }
      }

      String[] queueFieldNames = new String[]{"queue", "pendingActions", "packetQueue", "receivedPackets"};

      for(String name : queueFieldNames) {
         try {
            Field f = networkManagerClass.getDeclaredField(name);
            if (Queue.class.isAssignableFrom(f.getType()) && !Modifier.isStatic(f.getModifiers())) {
               f.setAccessible(true);
               queueField = f;
               LOGGER.info("[FakeNetworkManager] Found queue field by name: " + name);
               break;
            }
         } catch (NoSuchFieldException var7) {
         }
      }

      if (queueField == null) {
         for(Field f : networkManagerClass.getDeclaredFields()) {
            int mods = f.getModifiers();
            if (Queue.class.isAssignableFrom(f.getType()) && !Modifier.isStatic(mods) && !Modifier.isFinal(mods)) {
               f.setAccessible(true);
               queueField = f;
               LOGGER.info("[FakeNetworkManager] Found queue field by type: " + f.getName());
               break;
            }
         }
      }

      for(Field f : networkManagerClass.getDeclaredFields()) {
         String typeName = f.getType().getName();
         int mods = f.getModifiers();
         if ((typeName.contains("PacketListener") || typeName.contains("ServerGamePacketListener") || typeName.contains("PlayerConnection")) && !Modifier.isStatic(mods)) {
            f.setAccessible(true);
            packetListenerField = f;
            LOGGER.info("[FakeNetworkManager] Found packetListener field: " + f.getName());
            break;
         }
      }

      boolean var34 = channelField != null;
      LOGGER.info("[FakeNetworkManager] Field caching complete: channel=" + var34 + ", address=" + (addressField != null) + ", queue=" + (queueField != null) + ", connected=" + (connectedField != null) + ", packetListener=" + (packetListenerField != null));
   }

   public FakeNetworkManager() {
      this("127.0.0.1", ThreadLocalRandom.current().nextInt(40000, 60000));
   }

   public FakeNetworkManager(String ipAddress, int port) {
      this.port = port;
      this.ipAddress = ipAddress;
      this.socketAddress = new InetSocketAddress(ipAddress, port);
      if (networkManagerConstructor == null) {
         throw new IllegalStateException("NetworkManager constructor not available");
      } else {
         try {
            if (serverboundFlow != null && networkManagerConstructor.getParameterCount() == 1) {
               this.networkManager = networkManagerConstructor.newInstance(serverboundFlow);
            } else {
               this.networkManager = networkManagerConstructor.newInstance();
            }

            this.fakeChannel = this.createFakeChannel();
            if (channelField != null) {
               channelField.set(this.networkManager, this.fakeChannel);
            }

            if (addressField != null) {
               addressField.set(this.networkManager, this.socketAddress);
            }

            if (queueField != null) {
               try {
                  Object existingQueue = queueField.get(this.networkManager);
                  if (existingQueue == null) {
                     queueField.set(this.networkManager, Queues.newConcurrentLinkedQueue());
                     LOGGER.fine("[FakeNetworkManager] Set queue field");
                  } else {
                     LOGGER.fine("[FakeNetworkManager] Queue field already initialized");
                  }
               } catch (IllegalAccessException e) {
                  LOGGER.fine("[FakeNetworkManager] Could not set queue field (may be final): " + e.getMessage());
               } catch (IllegalArgumentException e) {
                  LOGGER.warning("[FakeNetworkManager] Wrong type for queue field - skipping: " + e.getMessage());
               }
            }

            LOGGER.fine("[FakeNetworkManager] Created network manager for " + ipAddress + ":" + port);
         } catch (Exception e) {
            LOGGER.log(Level.WARNING, "[FakeNetworkManager] Failed to create network manager", e);
            throw new RuntimeException("Failed to create FakeNetworkManager", e);
         }
      }
   }

   private Channel createFakeChannel() {
      Channel channel = new FakeChannel(this.socketAddress);
      ChannelPipeline pipeline = channel.pipeline();
      boolean serializationOk = false;

      try {
         Method configureSerialization = networkManagerClass.getMethod("configureSerialization", ChannelPipeline.class, packetFlowClass, Boolean.TYPE, Object.class);
         configureSerialization.invoke((Object)null, pipeline, serverboundFlow, false, null);
         serializationOk = true;
         LOGGER.fine("[FakeNetworkManager] Called configureSerialization on pipeline");
      } catch (NoSuchMethodException var5) {
         LOGGER.fine("[FakeNetworkManager] configureSerialization method not found");
      } catch (Exception e) {
         LOGGER.fine("[FakeNetworkManager] configureSerialization failed: " + e.getMessage());
      }

      if (!serializationOk) {
         pipeline.addLast("encoder", new ChannelOutboundHandlerAdapter() {
            public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {
               ReferenceCountUtil.release(msg);
               promise.setSuccess();
            }
         });
         pipeline.addLast("decoder", new ChannelInboundHandlerAdapter() {
            public void channelRead(ChannelHandlerContext ctx, Object msg) {
               ReferenceCountUtil.release(msg);
            }
         });
         pipeline.addLast("prepender", new ChannelOutboundHandlerAdapter());
         pipeline.addLast("splitter", new ChannelInboundHandlerAdapter());
      }

      if (this.networkManager != null) {
         pipeline.addFirst("packet_handler", (ChannelHandler)this.networkManager);
      }

      LOGGER.fine("[FakeNetworkManager] Created FakeChannel for " + this.ipAddress + ":" + this.port);
      return channel;
   }

   public void initialize() {
      try {
         if (connectedField != null) {
            connectedField.setBoolean(this.networkManager, true);
         }

         if (this.fakeChannel != null && eventExecutors != null) {
            try {
               Field eventLoopField = AbstractChannel.class.getDeclaredField("eventLoop");
               eventLoopField.setAccessible(true);
               eventLoopField.set(this.fakeChannel, eventExecutors.next());
            } catch (Exception e) {
               LOGGER.warning("[FakeNetworkManager] Failed to set event loop: " + e.getMessage());
            }
         }

         LOGGER.fine("[FakeNetworkManager] Initialized successfully");

         try {
            Object eventLoop = AbstractChannel.class.getDeclaredField("eventLoop").get(this.fakeChannel);
            if (eventLoop instanceof EventLoop) {
               ((EventLoop)eventLoop).schedule(() -> {
                  try {
                     this.fakeChannel.pipeline().remove(ReadTimeoutHandler.class);
                     LOGGER.fine("[FakeNetworkManager] Cleaned up ReadTimeoutHandler");
                  } catch (Exception var2) {
                  }

               }, 2L, TimeUnit.SECONDS);
            }
         } catch (Exception var2) {
         }
      } catch (Exception e) {
         LOGGER.warning("[FakeNetworkManager] Failed to initialize: " + e.getMessage());
      }

   }

   public void setPacketListener(Object packetListener) {
      try {
         if (packetListenerField != null) {
            packetListenerField.set(this.networkManager, packetListener);
         }
      } catch (Exception e) {
         LOGGER.warning("[FakeNetworkManager] Failed to set packet listener: " + e.getMessage());
      }

   }

   public Object getNetworkManager() {
      return this.networkManager;
   }

   public Channel getFakeChannel() {
      return this.fakeChannel;
   }

   public SocketAddress getSocketAddress() {
      return this.socketAddress;
   }

   public int getPort() {
      return this.port;
   }

   public String getIpAddress() {
      return this.ipAddress;
   }

   public boolean isValid() {
      return this.networkManager != null;
   }

   public void stopReading() {
   }

   public Channel getChannel() {
      return this.fakeChannel;
   }

   static {
      try {
         networkManagerClass = Class.forName("net.minecraft.network.Connection");
         packetFlowClass = Class.forName("net.minecraft.network.protocol.PacketFlow");

         for(Object constant : packetFlowClass.getEnumConstants()) {
            if (constant.toString().equals("SERVERBOUND")) {
               serverboundFlow = constant;
               break;
            }
         }

         if (serverboundFlow == null && packetFlowClass.getEnumConstants().length >= 2) {
            serverboundFlow = packetFlowClass.getEnumConstants()[1];
         }

         try {
            networkManagerConstructor = networkManagerClass.getConstructor(packetFlowClass);
         } catch (NoSuchMethodException var4) {
            networkManagerConstructor = networkManagerClass.getConstructor();
         }

         networkManagerConstructor.setAccessible(true);
         cacheFields();
         LOGGER.info("[FakeNetworkManager] Initialized reflection successfully");
      } catch (Exception e) {
         LOGGER.log(Level.WARNING, "[FakeNetworkManager] Failed to initialize reflection", e);
      }

   }
}
