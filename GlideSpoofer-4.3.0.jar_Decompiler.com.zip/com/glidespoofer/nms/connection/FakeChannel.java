package com.glidespoofer.nms.connection;

import io.netty.channel.AbstractChannel;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelMetadata;
import io.netty.channel.ChannelOutboundBuffer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.ChannelPromise;
import io.netty.channel.DefaultChannelPipeline;
import io.netty.channel.EventLoop;
import io.netty.channel.socket.DefaultSocketChannelConfig;
import io.netty.channel.socket.ServerSocketChannel;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.SocketChannelConfig;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.util.AttributeKey;
import io.netty.util.ReferenceCountUtil;
import java.lang.reflect.Constructor;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FakeChannel extends AbstractChannel implements SocketChannel {
   private static final Logger LOGGER = Logger.getLogger("GlideSpoofer-FakeChannelSimple");
   private static final ChannelMetadata METADATA = new ChannelMetadata(true);
   private static volatile Constructor<DefaultChannelPipeline> pipelineConstructor;
   private final DefaultSocketChannelConfig config;
   private final SocketAddress localAddress;
   private final SocketAddress remoteAddress;
   private final ConcurrentHashMap<AttributeKey<?>, Attribute<?>> attributes;
   private boolean active = true;
   private volatile ChannelPipeline realPipeline;

   public FakeChannel(SocketAddress address) {
      super((Channel)null);
      this.localAddress = address;
      this.remoteAddress = address;
      this.config = new DefaultSocketChannelConfig(this, new Socket());
      this.config.setAutoRead(true);
      this.attributes = new ConcurrentHashMap();
   }

   public ChannelPipeline pipeline() {
      ChannelPipeline p = this.realPipeline;
      if (p == null) {
         synchronized(this) {
            p = this.realPipeline;
            if (p == null) {
               p = this.realPipeline = this.createRealPipeline();
            }
         }
      }

      return p;
   }

   private ChannelPipeline createRealPipeline() {
      if (pipelineConstructor == null) {
         throw new IllegalStateException("DefaultChannelPipeline constructor not available");
      } else {
         try {
            return (ChannelPipeline)pipelineConstructor.newInstance(this);
         } catch (Exception e) {
            throw new RuntimeException("Failed to create DefaultChannelPipeline", e);
         }
      }
   }

   public void removeReadTimeoutHandler() {
      try {
         ChannelPipeline p = this.realPipeline;
         if (p != null) {
            p.remove(ReadTimeoutHandler.class);
         }
      } catch (Exception var2) {
      }

   }

   public SocketChannelConfig config() {
      return this.config;
   }

   public InetSocketAddress localAddress() {
      return (InetSocketAddress)this.localAddress;
   }

   public InetSocketAddress remoteAddress() {
      return (InetSocketAddress)this.remoteAddress;
   }

   public ServerSocketChannel parent() {
      return null;
   }

   public ChannelMetadata metadata() {
      return METADATA;
   }

   public boolean isOpen() {
      return this.active;
   }

   public boolean isActive() {
      return this.active;
   }

   protected SocketAddress localAddress0() {
      return this.localAddress;
   }

   protected SocketAddress remoteAddress0() {
      return this.remoteAddress;
   }

   protected void doBind(SocketAddress localAddress) throws Exception {
   }

   protected void doDisconnect() throws Exception {
      this.active = false;
   }

   protected void doClose() throws Exception {
      this.active = false;
   }

   protected void doBeginRead() throws Exception {
   }

   protected void doWrite(ChannelOutboundBuffer in) throws Exception {
      while(true) {
         Object msg = in.current();
         if (msg == null) {
            return;
         }

         ReferenceCountUtil.release(msg);
         in.remove();
      }
   }

   protected AbstractChannel.AbstractUnsafe newUnsafe() {
      return new AbstractChannel.AbstractUnsafe() {
         public void connect(SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) {
            this.safeSetSuccess(promise);
         }
      };
   }

   public boolean isCompatible(EventLoop loop) {
      return true;
   }

   public boolean isInputShutdown() {
      return !this.active;
   }

   public boolean isOutputShutdown() {
      return !this.active;
   }

   public boolean isShutdown() {
      return !this.active;
   }

   public ChannelFuture shutdown() {
      return this.shutdown(this.newPromise());
   }

   public ChannelFuture shutdown(ChannelPromise promise) {
      this.active = false;
      return promise.setSuccess();
   }

   public ChannelFuture shutdownInput() {
      return this.shutdownInput(this.newPromise());
   }

   public ChannelFuture shutdownInput(ChannelPromise promise) {
      return promise.setSuccess();
   }

   public ChannelFuture shutdownOutput() {
      return this.shutdownOutput(this.newPromise());
   }

   public ChannelFuture shutdownOutput(ChannelPromise promise) {
      return promise.setSuccess();
   }

   public <T> boolean hasAttr(AttributeKey<T> key) {
      return this.attributes.containsKey(key);
   }

   public <T> Attribute<T> attr(AttributeKey<T> key) {
      return (Attribute)this.attributes.computeIfAbsent(key, (k) -> {
         Attribute<T> attr = new Attribute<T>(key);
         return attr;
      });
   }

   static {
      try {
         Constructor<DefaultChannelPipeline> ctor = DefaultChannelPipeline.class.getDeclaredConstructor(Channel.class);
         ctor.setAccessible(true);
         pipelineConstructor = ctor;
      } catch (Exception e) {
         LOGGER.log(Level.SEVERE, "[FakeChannel] Failed to get DefaultChannelPipeline constructor", e);
      }

   }

   private static class Attribute<T> implements io.netty.util.Attribute<T> {
      private final AttributeKey<T> key;
      private T value;

      Attribute(AttributeKey<T> key) {
         this.key = key;
      }

      public AttributeKey<T> key() {
         return this.key;
      }

      public T get() {
         return this.value;
      }

      public void set(T value) {
         this.value = value;
      }

      public T getAndSet(T value) {
         T old = this.value;
         this.value = value;
         return old;
      }

      public T setIfAbsent(T value) {
         if (this.value == null) {
            this.value = value;
            return null;
         } else {
            return this.value;
         }
      }

      public T getAndRemove() {
         T old = this.value;
         this.value = null;
         return old;
      }

      public boolean compareAndSet(T oldValue, T newValue) {
         if (this.value == oldValue) {
            this.value = newValue;
            return true;
         } else {
            return false;
         }
      }

      public void remove() {
         this.value = null;
      }
   }
}
